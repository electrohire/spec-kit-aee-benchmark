from copy import deepcopy


class BatchWriter:
    def __init__(self, db):
        self.db = db
        self.tokens = {}

    def _validate_operations(self, operations):
        """Validate operations structurally without modifying state.
        
        Returns the list of (op_type, parsed_data) tuples.
        Raises ValueError on any invalid operation.
        """
        if not isinstance(operations, list):
            raise ValueError('operations must be a list')
        
        validated = []
        for op in operations:
            if not isinstance(op, dict):
                raise ValueError('operation must be a dict')
            
            if 'op' not in op:
                raise ValueError('operation must have op field')
            
            op_type = op['op']
            
            if op_type == 'insert':
                if 'document' not in op:
                    raise ValueError('insert operation must have document field')
                if not isinstance(op['document'], dict):
                    raise ValueError('document must be a dict')
                # Reject extra fields
                if set(op.keys()) != {'op', 'document'}:
                    raise ValueError('insert operation has extra fields')
                validated.append(('insert', deepcopy(op['document'])))
            
            elif op_type == 'remove':
                if 'doc_id' not in op:
                    raise ValueError('remove operation must have doc_id field')
                doc_id = op['doc_id']
                # Reject bool even though bool is an int subclass
                if type(doc_id) is bool:
                    raise ValueError('doc_id must be an int, not bool')
                if not isinstance(doc_id, int) or doc_id <= 0:
                    raise ValueError('doc_id must be a positive integer')
                # Reject extra fields
                if set(op.keys()) != {'op', 'doc_id'}:
                    raise ValueError('remove operation has extra fields')
                validated.append(('remove', doc_id))
            
            else:
                raise ValueError('unknown operation type: ' + str(op_type))
        
        return validated

    def _simulate(self, operations):
        """Simulate operations in-memory without side effects.
        
        Returns (final_docs_dict, next_id, inserted_ids).
        Raises ValueError on any invalid operation.
        """
        validated = self._validate_operations(operations)
        
        # Read current state from storage
        storage = self.db.storage.read() or {}
        docs = {int(k): deepcopy(v) for k, v in storage.get('_default', {}).items()}
        table = self.db.table('_default')
        next_id = table._next_id if table._next_id is not None else (max(docs, default=0) + 1)
        
        inserted = []
        for op_type, data in validated:
            if op_type == 'insert':
                docs[next_id] = deepcopy(data)
                inserted.append(next_id)
                next_id += 1
            elif op_type == 'remove':
                doc_id = data
                if doc_id not in docs:
                    raise ValueError('doc_id {} not found'.format(doc_id))
                del docs[doc_id]
        
        return docs, next_id, inserted

    def preview(self, operations):
        """Preview the inserted IDs that apply would produce.
        
        Does not modify any data or consume IDs.
        Does not record/consume tokens.
        """
        _, _, inserted = self._simulate(operations)
        return inserted

    def apply(self, operations, token=None):
        """Apply operations atomically with optional idempotency token.
        
        Returns list of inserted document IDs.
        On error, restores the complete pre-batch default-table data.
        """
        if token is not None:
            if not isinstance(token, str) or not token:
                raise ValueError('invalid token')
        
        # Check for idempotency
        if token is not None:
            if token in self.tokens:
                stored_ops, stored_result = self.tokens[token]
                if stored_ops != operations:
                    raise ValueError('token conflict: different operations for same token')
                return deepcopy(stored_result)
        
        # Save original state for rollback
        original_storage = self.db.storage.read()
        original_table = self.db.table('_default')
        original_next_id = original_table._next_id
        
        try:
            docs, next_id, inserted = self._simulate(operations)
        except ValueError:
            # Rollback: restore original state
            if original_storage is not None:
                self.db.storage.write(original_storage)
            else:
                self.db.storage.write({})
            # Restore next_id
            original_table._next_id = original_next_id
            raise
        
        # Build final storage state
        final_storage = dict(original_storage) if original_storage else {}
        final_storage['_default'] = {str(k): v for k, v in docs.items()}
        
        # Write atomically
        self.db.storage.write(final_storage)
        
        # Update next_id on the table
        original_table._next_id = next_id
        
        # Clear caches
        for table in self.db._tables.values():
            table.clear_cache()
        
        # Store token for idempotency
        if token is not None:
            self.tokens[token] = (deepcopy(operations), deepcopy(inserted))
        
        return inserted
