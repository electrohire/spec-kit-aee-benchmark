"""Tag-aware bounded LRU cache."""

import copy

from . import LRUCache

__all__ = ("TaggedCache",)


def _validate_maxsize(maxsize):
    """Return maxsize if it is a positive integer (bool excluded), else raise."""
    if isinstance(maxsize, bool) or not isinstance(maxsize, int) or maxsize <= 0:
        raise ValueError("maxsize must be a positive integer, got %r" % (maxsize,))
    return maxsize


def _normalize_tags(tags):
    """Validate and deduplicate tags, consuming the iterable exactly once.

    Returns a set of unique strings. A bare string is rejected, as is any
    non-string entry. Raises ValueError before the caller mutates state.
    """
    if isinstance(tags, str):
        raise ValueError("tags must be an iterable of strings, not a bare string")
    seen = set()
    for tag in tags:
        if not isinstance(tag, str):
            raise ValueError("tags must be strings, got %r" % (tag,))
        seen.add(tag)
    return seen


class TaggedCache(LRUCache):
    """Bounded LRU cache whose entries carry deduplicated string tags.

    Values are deep-copied on input (``put``) and output (``get``) so the
    stored value is detached from caller objects. Tag memberships are
    removed on replacement, invalidation, eviction, and ``del`` so LRU
    eviction never leaves stale memberships.
    """

    def __init__(self, maxsize):
        _validate_maxsize(maxsize)
        LRUCache.__init__(self, maxsize)
        self._tags = {}
        self._tag_index = {}

    def put(self, key, value, tags=()):
        """Insert or replace ``key`` with a deep copy of ``value`` tagged by
        ``tags`` (a finite iterable of strings, deduplicated, consumed once).

        Invalid tags raise ValueError before any existing state changes.
        Replacing an existing key drops its old tag memberships and refreshes
        its LRU recency.
        """
        tag_set = _normalize_tags(tags)
        if key in self and key in self._tags:
            self._drop_memberships(key, self._tags[key])
        self[key] = copy.deepcopy(value)
        self._tags[key] = frozenset(tag_set)
        for tag in tag_set:
            self._tag_index.setdefault(tag, set()).add(key)

    def get(self, key, default=_MISSING):
        """Return a detached deep copy of the stored value for ``key``,
        refreshing its LRU recency. Raises KeyError for missing keys when no
        default is given."""
        if key in self:
            value = self[key]  # refreshes recency via LRUCache.__getitem__
            return copy.deepcopy(value)
        if default is _MISSING:
            raise KeyError(key)
        return default

    def invalidate(self, tag):
        """Remove all currently cached entries carrying ``tag``; return the
        number removed."""
        return self._remove_tagged(self._tag_index.get(tag, ()))

    def invalidate_many(self, tags, mode="any"):
        """Remove entries matching ``tags`` and return the number of distinct
        keys removed.

        ``mode='any'`` removes the union (entries carrying at least one
        requested tag); ``mode='all'`` removes entries carrying every
        requested tag. An empty requested tag set removes zero entries in
        either mode. Invalid ``mode`` or tags raise ValueError before any
        mutation.
        """
        if mode not in ("any", "all"):
            raise ValueError("mode must be 'any' or 'all', got %r" % (mode,))
        tag_set = _normalize_tags(tags)
        if not tag_set:
            return 0
        if mode == "any":
            keys = set()
            for tag in tag_set:
                keys.update(self._tag_index.get(tag, ()))
        else:
            key_sets = [self._tag_index.get(tag, set()) for tag in tag_set]
            keys = set(key_sets[0])
            for ks in key_sets[1:]:
                keys &= ks
        return self._remove_tagged(keys)

    def resize(self, maxsize):
        """Change the cache capacity in place. Invalid maxsize raises
        ValueError before any mutation. Shrinking evicts least-recently-used
        entries; growing does not evict. Surviving entries keep their LRU
        order and any absolute expiry."""
        _validate_maxsize(maxsize)
        current = self.maxsize
        if maxsize < current:
            while len(self) > maxsize:
                self.popitem()
        self.maxsize = maxsize

    def popitem(self):
        """Remove and return the least-recently-used ``(key, value)`` pair,
        dropping its tag memberships."""
        key, value = LRUCache.popitem(self)
        self._drop_memberships(key, self._tags.pop(key, ()))
        return key, value

    def __delitem__(self, key):
        LRUCache.__delitem__(self, key)
        self._drop_memberships(key, self._tags.pop(key, ()))

    def _drop_memberships(self, key, tag_set):
        for tag in tag_set:
            members = self._tag_index.get(tag)
            if members is None:
                continue
            members.discard(key)
            if not members:
                del self._tag_index[tag]

    def _remove_tagged(self, keys):
        for key in list(keys):
            if key in self:
                del self[key]
        return len(keys)


_MISSING = object()
