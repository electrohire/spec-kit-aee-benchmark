# cachetools Constitution
<!-- Sync Impact Report (temporary scratch for review; remove before commit)
Version change: none (unfilled template) -> 1.0.0
Modified principles: none (all principles newly added)
Added principles:
  I. Preserve Existing Public API Behavior
  II. Testable Acceptance Criteria
  III. Evidence Over Assertion
  IV. Simple Scoped Implementations
  V. Documented Assumptions and Regressions
Added sections: Scope and Deferred Intents; Development Workflow
Removed sections: none
Deferred TODOs: none
-->

## Core Principles

### I. Preserve Existing Public API Behavior

All changes MUST preserve the behavior of the existing public cachetools
API: exposed names, signatures, documented semantics, and error behavior.
New features MUST be additive (for example, a new module such as
cachetools.tagged built on the existing LRUCache) and MUST NOT alter,
shadow, or remove existing behavior. Any intended change to an existing
public API MUST be recorded as a regression note and requires a
constitution amendment first.

Rationale: cachetools is a published library; downstream code depends on
stable, predictable semantics.

### II. Testable Acceptance Criteria

Every requirement MUST state observable, testable acceptance criteria
before implementation starts. Each criterion MUST name the inputs, the
expected observable outcome (return value, raised exception, or state
after the operation), and any state-preservation guarantees (for
example, rejecting invalid input MUST leave prior value, tags, and
recency unchanged). A requirement that cannot be expressed as a
failing-then-passing test MUST be rewritten or deferred, not implemented
on assumption.

Rationale: testable criteria make completion verifiable and keep scope
honest.

### III. Evidence Over Assertion

Claims about behavior MUST distinguish observed evidence from unverified
assertions. A behavior counts as verified only when a command was run
and its output shows the expected result; otherwise it MUST be labeled
an unverified assumption. Test evidence MUST cite the command and the
observed outcome (pass/fail counts or concrete output), never a bare
paraphrase.

Rationale: in an autonomous workflow, unmarked assumptions become silent
regressions.

### IV. Simple Scoped Implementations

Implementations MUST be minimal and scoped to the stated requirement.
Prefer the smallest change that satisfies the acceptance criteria; do
not add configuration, abstraction layers, or speculative features the
criteria do not demand. Added complexity MUST be justified against a
specific criterion, not anticipated need.

Rationale: small, scoped changes are easier to verify and less likely to
violate Principle I.

### V. Documented Assumptions and Regressions

Unresolved assumptions, open questions, and any behavior that regressed
or was intentionally changed MUST be written down in project notes
(HANDOFF.md or the feature spec) with the date and evidence status
(verified/unverified). Deferred candidate requirements (for example, the
2026-09-21 put-recency claim variant) MUST be tracked as deferred
intents, not silently dropped or silently adopted.

Rationale: later phases and reviewers need a complete, auditable record
of what was assumed, deferred, and changed.

## Scope and Deferred Intents

The constitution governs process only; it does not authorize
implementation. The TaggedCache feature (R01-R03) and the Claim-A
candidate extension (put recency refresh, variant
put_no_recency_refresh, 2026-09-21) are deferred to later Spec Kit
phases (specify, plan, implement). Upstream tests MUST remain unchanged;
project-owned tests and notes (for example HANDOFF.md) MAY be added.

## Development Workflow

Work proceeds through the Spec Kit phases (constitution, specify, plan,
implement, converge) with artifacts under the specs directory and the
.specify directory. Each phase MUST close with a summary that cites the
artifacts it produced and the commands it ran. Convergence MUST rerun
public acceptance (acceptance_public.py) and project tests and state any
unresolved gaps explicitly.

## Governance

This constitution supersedes conflicting local practices. Amendments
MUST edit this file, bump the Version per semantic versioning (MAJOR:
principle removed or redefined; MINOR: principle or section added or
materially expanded; PATCH: wording or clarification), update Last
Amended to the ISO amendment date, and record the change in a Sync
Impact Report for review. Compliance is reviewed at each phase closing:
evidence of compliance (test runs, preserved APIs, documented
assumptions) MUST accompany the phase summary. The Ratified date records
original adoption and is not changed by amendments.

**Version**: 1.0.0 | **Ratified**: 2026-10-17 | **Last Amended**: 2026-10-17
