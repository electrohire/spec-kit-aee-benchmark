# Phase 0 Research: TaggedCache

**Date**: 2026-10-17 | **Feature**: 001-transactions

All technical-context unknowns are resolved below (none remain).
No unresolved clarifications remain.

## R1. Bounded storage primitive

- **Decision**: Build `TaggedCache` on the existing `cachetools.LRUCache` (src/cachetools/__init__.py:203) by subclassing it; do not reimplement LRU logic.
- **Rationale**: The milestone mandates using the existing LRUCache for bounded storage. Verified behavior (command run, output kept): `LRUCache.__setitem__` calls `Cache.__setitem__` then `move_to_end`, so overwriting a key refreshes recency; `LRUCache.popitem()` is a public method (no name mangling) that removes and returns the least-recently-used pair; with the default `getsizeof` every value costs exactly 1 slot (`_DefaultSize`), satisfying FR-013 for free.
- **Alternatives considered**: (a) Composition (hold an LRUCache instance) - rejected: the spec requires `len(cache)` on TaggedCache itself and `get` raising KeyError, both cleaner via subclassing; (b) fresh OrderedDict-based LRU - rejected: duplicates logic the milestone says to reuse.

## R2. Where tag membership lives

- **Decision**: Keep tag state in TaggedCache-owned containers, never inside the stored value: `self._tags: dict[key, frozenset[str]]` (key -> deduplicated tag set) and `self._tag_index: dict[str, set[key]]` (tag -> live keys carrying it).
- **Rationale**: Values are deep-copied in and out, so tags cannot ride inside the value. An explicit index makes `invalidate(tag)` O(entries carrying tag) with exact removal, and guarantees no stale memberships when entries are evicted or replaced (membership is removed at every removal path: replace, invalidate, eviction).
- **Alternatives considered**: (a) scan all entries per invalidate - rejected: O(n) per call and still needs a membership store for correctness on eviction; (b) store tags inside the value dict - rejected: corrupts the user's value and breaks deep-copy isolation.

## R3. Eviction hook without touching upstream code

- **Decision**: TaggedCache overrides only `popitem()`: call `super().popitem()` (evicts the true LRU entry from the inherited LRUCache), then drop that key's tag memberships from both containers. `Cache.__setitem__` (inherited) calls `self.popitem()` polymorphically, so evictions triggered by capacity automatically route through the override.
- **Rationale**: Verified in source: `Cache.__setitem__` (src/cachetools/__init__.py:72-86) invokes `self.popitem()` in its while-loop, and `LRUCache.popitem` is un-mangled. This is the single smallest override that keeps tag state consistent on every removal path while leaving all upstream code untouched (Constitution Principle I).
- **Alternatives considered**: (a) wrap/patch LRUCache - rejected: modifies shared behavior; (b) re-implement popitem with private access - rejected: `__order` is name-mangled in LRUCache and unreachable; (c) detect evictions by diffing keys after each put - rejected: O(n) and racy with replacement semantics.

## R4. get() semantics

- **Decision**: Implement `TaggedCache.get(key)` to call `self[key]` (inherited `LRUCache.__getitem__`, which refreshes recency) and return `copy.deepcopy(value)`; missing keys raise `KeyError` (inherited `Cache.__missing__` behavior). Do not inherit `Cache.get(key, default=None)`.
- **Rationale**: The milestone defines `get(key)` as returning a detached deep copy or raising KeyError - this differs from `Cache.get`, so it must be overridden. Deep copy on output plus deep copy on input in `put` gives full value isolation (FR-003). Verified: `Cache.__getitem__` routes missing keys to `__missing__` which raises `KeyError(key)`.
- **Alternatives considered**: (a) keep `default=None` parameter - rejected: spec says raise KeyError for missing keys; (b) return live reference - rejected: violates isolation.

## R5. Tag validation

- **Decision**: In `put`, validate tags before touching the cache: reject `isinstance(tags, (str, bytes))` (bare string is not a tag iterable) with ValueError; iterate `tags` to a list, rejecting any non-`str` entry with ValueError; deduplicate with `set()`. Only after validation succeed, perform the store.
- **Rationale**: FR-004/FR-012 require rejection before any existing state changes; validating first makes the store atomic w.r.t. invalid input. Iterables are consumed exactly once at put time (spec Assumptions).
- **Alternatives considered**: (a) accept any hashable tag - rejected: spec restricts tags to strings; (b) accept bare string as one tag - rejected: spec explicitly rejects bare strings.

## R6. maxsize validation

- **Decision**: In `TaggedCache.__init__`, require `isinstance(maxsize, int) and not isinstance(maxsize, bool) and maxsize > 0`, else raise ValueError; then delegate to `LRUCache.__init__(self, maxsize)` (default getsizeof).
- **Rationale**: FR-011 mandates positive integer excluding bool. ValueError chosen over TypeError for uniformity with the tag-validation error type (spec Assumptions); both are defensible, ValueError is the documented choice.
- **Alternatives considered**: (a) TypeError for wrong type - rejected for uniformity; (b) inherit unvalidated - rejected: bool passes `isinstance(int)` and 0/negatives would be accepted by the base class.

## R7. Testing strategy

- **Decision**: Project-owned tests in `tests/test_tagged.py` (new file; upstream test files untouched), run with `PYTHONPATH=src:. python -m pytest tests/test_tagged.py acceptance_public.py -v`. Public acceptance is `acceptance_public.py` (13 lines, 2 tests: basic put/get/invalidate/len and replacement tag swap).
- **Rationale**: Constitution Principle II/III; upstream tests must remain unchanged per the milestone.
- **Alternatives considered**: (a) extend upstream test files - rejected: prohibited.

## R8. Import surface

- **Decision**: New module `src/cachetools/tagged.py` exposing `TaggedCache`; do not add it to `cachetools.__all__` (keeps the existing public API byte-identical; `from cachetools.tagged import TaggedCache` is the documented path used by acceptance_public.py).
- **Rationale**: Principle I (preserve existing APIs) - changing `__all__` would alter `from cachetools import *` behavior. The acceptance suite imports the submodule directly, so no `__all__` change is needed.
- **Alternatives considered**: (a) add to `__all__` - rejected: changes existing star-import behavior.

## Consolidated decisions (no open items)

1. Subclass LRUCache; override `__init__`, `popitem`, `get`; add `put`, `invalidate`; internal `_tags`/`_tag_index`.
2. Deep copy on input (put) and output (get) via `copy.deepcopy`.
3. Tag validation before any mutation; ValueError on bare string, non-string entry, invalid maxsize.
4. Eviction consistency via the single `popitem` override (polymorphic call from inherited `Cache.__setitem__`).
5. New test file only; upstream untouched; `acceptance_public.py` is the public gate.
