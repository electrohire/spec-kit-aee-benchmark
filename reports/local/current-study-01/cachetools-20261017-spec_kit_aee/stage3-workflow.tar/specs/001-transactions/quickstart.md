# Quickstart / Validation Guide: TaggedCache

**Feature**: 001-transactions | **Prereqs**: Python 3.12, pytest (repo has 9.1.1), `PYTHONPATH=src:.`

## Run the suites

```bash
cd /testbed
PYTHONPATH=src:. python -m pytest acceptance_public.py -v        # public gate (2 tests)
PYTHONPATH=src:. python -m pytest tests/test_tagged.py -v       # project-owned tests
PYTHONPATH=src:. python -m pytest tests/ -q                     # upstream regression (must stay green, unmodified)
```

Expected: all pass; upstream test files unmodified (git status shows only new files: src/cachetools/tagged.py, tests/test_tagged.py).

## Scenario checks (each maps to spec FRs)

1. **Basic store/retrieve** (FR-002/003): `c=TaggedCache(2); c.put('a',1,['x']); c.get('a')==1; c.invalidate('x')==1; len(c)==0` (acceptance_public.py::test_public_basic).
2. **Replacement swaps tags** (FR-006): `c.put('a',1,['old']); c.put('a',2,['new']); c.invalidate('old')==0; c.get('a')==2` (acceptance_public.py::test_public_replacement).
3. **Deep-copy isolation** (FR-003): put a nested dict; mutate the returned copy and the original; `get` returns the unmutated value.
4. **KeyError on miss** (FR-003): `c.get('nope')` raises KeyError; `len` unchanged.
5. **Tag validation** (FR-004/012): on a populated cache, `c.put('a', 9, 'ab')` and `c.put('a', 9, ('a',1))` raise ValueError; value/tags/recency of 'a' and all other entries unchanged (verify via a follow-up eviction order probe).
6. **Dedup** (FR-004): `c.put('k',1,('a','a','b')); c.invalidate('a')==1` (single membership).
7. **Invalidate exactness** (FR-005): overlapping tags; count returned equals entries removed; survivors intact.
8. **Eviction consistency** (FR-007/013): maxsize 2, put 3 tagged keys; LRU evicted; `invalidate` on its tag returns 0 for the evicted entry; re-put same key with new tags is unaffected by stale state.
9. **Recency refresh** (FR-008/009): get on oldest entry protects it from next eviction; overwrite of oldest entry protects it.
10. **maxsize validation** (FR-011): 0, -1, True, False, 2.5, "3" all raise ValueError at construction; 1 and 3 accepted.
11. **len live count** (FR-010): after mixed puts/invalidates/evictions, `len(c)` equals live entry count.
12. **Upstream regression** (FR-001): full `tests/` suite green and unmodified.

See [contracts/tagged-cache.md](contracts/tagged-cache.md) for the full API contract and [data-model.md](data-model.md) for invariants.
