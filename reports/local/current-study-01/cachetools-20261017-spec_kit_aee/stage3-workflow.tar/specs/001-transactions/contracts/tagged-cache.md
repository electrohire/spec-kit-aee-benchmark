# Contract: cachetools.tagged.TaggedCache

**Module**: `src/cachetools/tagged.py` | **Import**: `from cachetools.tagged import TaggedCache`

## Public API

### `TaggedCache(maxsize)`

- **maxsize**: int > 0; bool rejected. Invalid -> `ValueError`, no object state created.
- **Effect**: constructs an LRU-bounded cache; every value costs 1 slot.

### `put(key, value, tags=())`

- **key**: hashable; unhashable -> `TypeError` (platform standard), no state change.
- **value**: arbitrary copyable object; stored as `copy.deepcopy(value)`.
- **tags**: finite iterable of `str`; deduplicated. Bare `str`/`bytes` as `tags` -> `ValueError`; any non-`str` entry -> `ValueError`. Rejection happens before any existing state (value, tags, recency, other entries) is modified.
- **Behavior**: insert or replace. Replace drops old tag memberships and refreshes recency (key becomes most-recently-used). On capacity overflow the least-recently-used entry is evicted with its tag memberships removed.
- **Returns**: `None`.

### `get(key)`

- **Returns**: `copy.deepcopy` of the stored value (detached; mutating it never affects the cache).
- **Raises**: `KeyError` for missing keys (no default parameter).
- **Effect**: refreshes the entry's LRU recency.

### `invalidate(tag)`

- **tag**: `str` (no validation error for unknown tags).
- **Returns**: `int` count of live entries removed.
- **Effect**: removes exactly the live entries currently carrying `tag`; untagged and other-tagged entries survive; `len` reflects live entries afterwards.

### Inherited observable behavior (unchanged from LRUCache)

- `len(cache)`, `key in cache`, `iter(cache)`, `cache[key]` (live value, refreshes recency), `del cache[key]` (tag memberships removed via TaggedCache `__delitem__` override), `cache.popitem()` (LRU pair, tags cleaned), `repr`.
- **Note**: `__delitem__` inherited from LRUCache removes the entry from `__order`; tag cleanup for `del cache[key]` is provided by TaggedCache overriding `__delitem__` to also drop tag memberships (keeps invariants for the full MutableMapping surface). This is additive to the contract above and required by the no-stale-membership invariant.

## Error table

| Condition | Exception | State after |
|-----------|-----------|-------------|
| `TaggedCache(0)`, `TaggedCache(-1)`, `TaggedCache(True)`, `TaggedCache(2.5)`, `TaggedCache("3")` | ValueError | no object usable |
| `put(k, v, tags="ab")` | ValueError | prior state identical |
| `put(k, v, tags=("a", 1))` | ValueError | prior state identical |
| `put([1], v)` | TypeError | prior state identical |
| `get(missing)` | KeyError | prior state identical |

## Non-goals

- No `get(key, default)` form; no tag iteration API; no concurrency guarantees; no changes to `cachetools.__all__`.
