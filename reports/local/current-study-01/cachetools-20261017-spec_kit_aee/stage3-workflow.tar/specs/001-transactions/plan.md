# Implementation Plan: Tagged Cache (TaggedCache)

**Branch**: `001-transactions` | **Date**: 2026-10-17 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-transactions/spec.md`

## Summary

Add `cachetools.tagged.TaggedCache(maxsize)`: a bounded, tag-aware LRU cache built by subclassing the existing `cachetools.LRUCache` (src/cachetools/__init__.py:203). New module `src/cachetools/tagged.py` only; no existing file is modified. `put` deep-copies values in, validates tags before mutating; `get` deep-copies out and raises KeyError on miss; `invalidate(tag)` removes exactly the live tagged entries and returns the count; tag membership is kept in two TaggedCache-owned maps and cleaned on every removal path (replace, invalidate, eviction via a single `popitem` override, `__delitem__` override). All existing cachetools APIs remain behaviorally unchanged.

## Technical Context

**Language/Version**: Python 3.12.14 (verified: `python --version`)

**Primary Dependencies**: none beyond stdlib (`collections.abc`, `copy`); the existing `cachetools.LRUCache` from `src/cachetools/__init__.py`

**Storage**: N/A (in-memory only)

**Testing**: pytest 9.1.1 (verified installed); public gate `acceptance_public.py`; project tests `tests/test_tagged.py` (new); upstream `tests/` untouched

**Target Platform**: CPython on Linux (repo testbed)

**Project Type**: library (single package, src layout)

**Performance Goals**: O(1) put/get; invalidate O(entries carrying tag); eviction O(1) per evicted entry; no full-cache scans

**Constraints**: upstream source and tests unmodified; additive-only public API; single-threaded; every value costs exactly 1 slot (default getsizeof)

**Scale/Scope**: 1 new module (~100 LOC) + 1 new test file; 6 method overrides/additions on one class

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution: [.specify/memory/constitution.md](../../.specify/memory/constitution.md) v1.0.0 (read this phase; evidence 730e6a12f424706a7f7ccba7cee9488fcf513774c21923dae91b9124650a8aee).

| # | Principle | Gate | Result |
|---|-----------|------|--------|
| I | Preserve Existing Public API Behavior | Change must be additive; no alter/shadow/remove of exposed names, signatures, documented semantics, or error behavior; new module built on existing LRUCache | **PASS (pre-Phase 0)**: only new files `src/cachetools/tagged.py`, `tests/test_tagged.py`; `src/cachetools/__init__.py` and all existing tests untouched; `__all__` unchanged; no monkeypatching |
| II | Testable Acceptable Criteria | Every requirement states observable inputs/outcomes/state-preservation before implementation | **PASS (pre-Phase 0)**: spec FR-001..FR-013 each map to named acceptance scenarios (User Stories 1-3) and quickstart scenario checks 1-12, including state-preservation guarantees for all rejection paths |
| III | Evidence Over Assertion | Behavior claims require command + observed output; unverified items labeled as such | **PASS (process gate)**: this plan cites verification commands; implement/converge phases MUST run `PYTHONPATH=src:. python -m pytest acceptance_public.py tests/ -v` and record output; until then all behavior claims stay `draft` with document-level evidence only |
| IV | Simple Scoped Implementations | Minimal change; no speculative features | **PASS (pre-Phase 0)**: one class, six members (`__init__`, `put`, `get`, `invalidate`, `popitem`, `__delitem__`), two internal dicts; no config, no new abstractions; `__delitem__` override justified by the no-stale-membership invariant (FR-007) for the MutableMapping surface |
| V | Documented Assumptions and Regressions | Assumptions/deferred intents written down with date and evidence status | **PASS (pre-Phase 0)**: spec.md Assumptions (2026-10-17) records the Claim-A variant-label ambiguity; HANDOFF.md tracks it as explicitly adopted per the latest requirement text (2026-09-21 text) - not silently adopted or dropped; no regressions intended |

**Gate result: PASS - no violations, Complexity Tracking not required.**

**Re-check after Phase 1 design: PASS (unchanged).** data-model.md invariants, contracts/tagged-cache.md API surface, and quickstart.md validation scenarios all stay within the additive-only, minimal-scope envelope; no new files or API changes were introduced by Phase 1. The contracts note that `__delitem__` is overridden (additive to the contract, invariant-required) - consistent with Principle IV justification above.

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── tagged-cache.md  #   public API contract for cachetools.tagged
└── tasks.md             # Phase 2 output ($speckit-tasks command - NOT created by $speckit-plan)
```

### Source Code (repository root)

```text
src/cachetools/
├── __init__.py          # existing - UNCHANGED (Cache, LRUCache, ...)
├── tagged.py            # NEW - TaggedCache(LRUCache) with put/get/invalidate
├── _decorators.py       # existing - UNCHANGED
└── keys.py              # existing - UNCHANGED

tests/
├── test_tagged.py       # NEW - project-owned tests for FR-001..FR-013
└── test_*.py            # existing upstream - UNCHANGED

acceptance_public.py     # existing public gate - UNCHANGED
HANDOFF.md               # project notes (new; tracks phase status + FR-009 decision)
```

**Structure Decision**: Single-project library layout (existing src/ + tests/). The feature adds exactly two code files (one module, one test file) plus notes; no new directories beyond `specs/001-transactions/contracts/`.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

No violations - table intentionally empty.
