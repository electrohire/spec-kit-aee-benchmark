# Phase 1 Data Model: TaggedCache

**Date**: 2026-10-17 | **Feature**: 001-transactions

## Entities

### Cache (TaggedCache)

- **Represents**: A bounded, tag-aware LRU cache (subclass of `cachetools.LRUCache`).
- **Fields**:
  - Inherited from `LRUCache`/`Cache`: `_Cache__data` (key -> stored deep-copied value), `_Cache__size` (key -> 1), `_Cache__currsize`, `_Cache__maxsize`, `_LRUCache__order` (recency order, least->most recent).
  - `maxsize`: positive int (bool excluded), set in `__init__` after validation.
  - `_tags`: `dict[key, frozenset[str]]` - deduplicated tag set per live key.
  - `_tag_index`: `dict[str, set[key]]` - tag -> set of live keys carrying it.
- **Invariants**:
  - `len(cache)` == number of live entries (inherited `__len__` over `__data`).
  - For every live key k: `_tags[k]` exists; for every tag t in `_tags[k]`: k in `_tag_index[t]` (bidirectional consistency).
  - No key appears in `_tags`/`_tag_index` unless it is live in `__data` (no stale memberships after replace, invalidate, or eviction).
  - Every live entry costs exactly 1 capacity slot (default `getsizeof`), so `__currsize` == `len(cache)`.

### Cache Entry

- **Represents**: One key-value pair occupying one slot.
- **Attributes**: key (hashable), value (deep copy, isolated), tag set (deduplicated strings), recency position (inherited `__order`).
- **State transitions**: absent -> present (put) -> replaced (put same key: old tag memberships dropped, recency refreshed) -> evicted (LRU, via `popitem` override: tag memberships dropped) -> removed (invalidate(tag)).

### Tag

- **Represents**: A string label forming an invalidation group; no state of its own beyond `_tag_index` membership.
- **Validation**: must be `str`; duplicates deduplicated; bare string passed as the whole `tags` argument is rejected (ValueError).

## Validation Rules (from spec)

| Rule | Source | Enforced at |
|------|--------|-------------|
| maxsize positive int, bool excluded | FR-011 | `TaggedCache.__init__` (ValueError) |
| keys hashable | FR-002 | inherited dict lookup (TypeError) |
| values deep-copied on input | FR-003 | `put` |
| get returns deep copy; KeyError on miss | FR-003 | `get` |
| tags finite iterable of str; deduplicated; bare str rejected | FR-004 | `put`, before any mutation (ValueError) |
| invalidate removes exactly tagged live entries, returns count | FR-005 | `invalidate` |
| replace drops old tag memberships | FR-006 | `put` (key-exists path) |
| eviction leaves no stale memberships | FR-007 | `popitem` override |
| get refreshes recency | FR-008 | inherited `LRUCache.__getitem__` via `get` |
| put overwrite refreshes recency | FR-009 | inherited `LRUCache.__setitem__` (verified: `__update` after store) |
| len counts live entries | FR-010 | inherited `__len__` + invariants |
| invalid replacement leaves value/tags/recency unchanged | FR-012 | `put` validates before store |
| 1 slot per value | FR-013 | default `getsizeof` (`_DefaultSize`) |
