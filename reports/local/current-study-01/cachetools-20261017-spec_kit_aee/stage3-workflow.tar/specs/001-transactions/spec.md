# Feature Specification: Tagged Cache (TaggedCache)

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: cachetools milestone 1 - build a bounded, tag-aware cache (TaggedCache) with put/get/invalidate, deep-copy value isolation, tag membership lifecycle, LRU eviction, and strict input validation, while preserving all existing cachetools APIs.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Store and Retrieve Tagged Entries (Priority: P1)

A library user creates a bounded tagged cache and stores values under keys, optionally labeled with tags. Retrieval returns a fully detached deep copy of the stored value; mutating the returned copy or the original value never affects the cache, and values are copied on input. Missing keys raise KeyError. Invalid tags (a bare string, or a non-string entry inside the iterable) are rejected with ValueError without altering any existing cache state.

**Why this priority**: This is the core value proposition - safe, isolated, tag-labeled storage. Without it, no other story is usable.

**Independent Test**: Fully testable by creating the cache, putting values (plain, nested, with duplicate tags), getting them back, mutating copies, and asserting isolation, KeyError on missing keys, and ValueError with state unchanged on invalid tags.

**Acceptance Scenarios**:

1. **Given** an empty cache, **When** put(key, value, tags=("a", "b")) is called, **Then** the entry is stored, len(cache) increases by 1, and get(key) returns a deep copy equal to the original value.
2. **Given** a cached value that is a mutable structure, **When** the caller mutates the object returned by get(key) or the original object passed to put, **Then** subsequent get(key) returns the unmutated stored value (detached deep copy on output, copy on input).
3. **Given** a cache containing key k, **When** get(missing) is called for an absent key, **Then** KeyError is raised and cache state is unchanged.
4. **Given** a non-empty cache, **When** put is called with tags as a bare string (e.g. "ab") or with a non-string entry in the tag iterable, **Then** ValueError is raised and the previous entry for that key (value, tags, recency) plus all other state is unchanged.
5. **Given** put(key, value, tags=("a", "a", "b")), **When** the entry is later inspected via tag-based operations, **Then** duplicate tags are deduplicated (the entry carries tags {"a", "b"}).
6. **Given** an unhashable key (e.g. a list), **When** put or get is attempted, **Then** the standard unhashable-key error (TypeError) is raised and state is unchanged.

---

### User Story 2 - Invalidate by Tag and Manage Membership Lifecycle (Priority: P2)

A library user removes all currently cached entries carrying a given tag in one call and learns how many were removed. Replacing an entry under an existing key drops its old tag memberships. Entries evicted by capacity limits leave no stale tag memberships that could affect later reuse of the same key. len(cache) always counts live entries.

**Why this priority**: Tag-based invalidation is the distinguishing capability over a plain LRU cache; it depends on P1 storage but is independently testable once entries exist.

**Independent Test**: Fully testable by populating entries with overlapping tags, calling invalidate(tag), and asserting exact removal counts, surviving entries, and len(cache); plus a replace-then-invalidate and an evict-then-reuse sequence.

**Acceptance Scenarios**:

1. **Given** entries k1 (tags a,b), k2 (tags a), k3 (no tags), **When** invalidate("a") is called, **Then** exactly k1 and k2 are removed, the return value is 2, k3 remains, and len(cache) reflects only live entries.
2. **Given** key k with tags ("a"), **When** put(k, new_value, tags=("b")) is called, **Then** the old tag membership "a" is removed; invalidate("a") returns 0 and invalidate("b") removes k.
3. **Given** a cache at capacity, **When** new puts evict the least-recently-used entry carrying tag t, **Then** invalidate(t) no longer counts the evicted entry, and a later put of the same key with different tags is not affected by stale memberships of the evicted entry.
4. **Given** a cache with no entries carrying tag t, **When** invalidate(t) is called, **Then** it returns 0 and state is unchanged.

---

### User Story 3 - Bounded Capacity with Strict Construction and Replacement Validation (Priority: P3)

A library user bounds the cache with a positive integer maxsize; every value costs exactly one capacity slot regardless of object size. Invalid maxsize values (including booleans, zero, negatives, non-integers) are rejected at construction. An invalid replacement (bad tags on an existing key) leaves the old value, tags, and recency completely unchanged.

**Why this priority**: Bounding and validation protect memory safety and contract integrity; they are verifiable once P1/P2 exist.

**Independent Test**: Fully testable by constructing with invalid maxsize values (expect rejection), filling a small cache to capacity, observing eviction of the least-recently-used entry, and attempting invalid replacements on live entries.

**Acceptance Scenarios**:

1. **Given** maxsize values 0, -1, True, False, 2.5, "3", **When** the cache is constructed, **Then** each is rejected (ValueError or TypeError) and no cache is created; positive integers (e.g. 1, 3) are accepted.
2. **Given** a cache with maxsize 2 holding k1 (oldest) and k2, **When** put(k3) is called, **Then** k1 is evicted, len(cache) is 2, and get(k1) raises KeyError.
3. **Given** a live entry k, **When** put(k, value, tags=("a", 1)) is attempted (invalid tag), **Then** ValueError is raised and k retains its old value, old tags, and its prior recency position (a subsequent eviction evicts the least-recently-used entry, not k, if k was not the LRU).

### Edge Cases

- Empty tag iterable (default) - entry stored with no tags; cannot be removed by any invalidate(tag).
- Duplicate tags in one put - deduplicated; membership counted once.
- invalidate(tag) with a tag never used - returns 0, no error.
- put with the same key and same value but different tags - old tag memberships replaced by new ones.
- Eviction of an entry, then re-put of the same key - no stale tag membership from the evicted incarnation remains.
- get on an entry refreshes its recency, protecting it from being the next eviction.
- Unhashable keys - rejected with the standard unhashable-key error, state unchanged.
- maxsize of 1 - every put evicts the previous entry (after recency refresh on overwrite, the overwritten key survives its own overwrite).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The feature MUST expose a new bounded tagged cache construct, TaggedCache, created with a single maxsize argument, in addition to (never replacing) all existing cachetools public APIs, which MUST remain behaviorally unchanged.
- **FR-002**: put(key, value, tags=()) MUST insert a new entry or replace an existing one for the same key; keys MUST be hashable and unhashable keys MUST be rejected without state change.
- **FR-003**: get(key) MUST return a detached deep copy of the stored value and MUST raise KeyError for missing keys; values MUST be deep-copied on input to put so that later mutation of the caller's original object never affects the cache.
- **FR-004**: tags MUST be a finite iterable of strings; tags MUST be deduplicated; a bare string passed as tags and any non-string entry within the iterable MUST be rejected with ValueError before any existing state is changed.
- **FR-005**: invalidate(tag) MUST remove exactly the currently cached entries carrying that tag and MUST return the number of entries removed; entries without the tag MUST survive; an unused tag MUST yield 0.
- **FR-006**: Replacing an existing key via put MUST remove the entry's previous tag memberships, so only the new tags apply afterwards.
- **FR-007**: LRU eviction MUST remove the least-recently-used live entry and MUST NOT leave stale tag memberships that affect later reuse of the same key or invalidate() counts.
- **FR-008**: get(key) on a present key MUST refresh that entry's LRU recency, making it the most-recently-used entry.
- **FR-009**: Overwriting an existing key via put MUST refresh that entry's LRU recency, making it the most-recently-used entry (Claim-A extension, variant put_no_recency_refresh, dated 2026-09-21; see Assumptions for the variant-name ambiguity).
- **FR-010**: len(cache) MUST count only live (currently cached) entries at all times.
- **FR-011**: maxsize MUST be a positive integer; booleans MUST be excluded even though they are integers; zero, negative, and non-integer values MUST be rejected at construction.
- **FR-012**: An invalid replacement (e.g. put with invalid tags on an existing key) MUST leave the old value, old tags, and the entry's recency position unchanged.
- **FR-013**: Every stored value MUST cost exactly one capacity slot regardless of the object's size or complexity.

### Key Entities

- **Cache Entry**: One key-value pair occupying a single capacity slot; attributes: key (hashable), value (stored as a deep copy), tag set (deduplicated strings), recency position (most- to least-recently-used).
- **Tag**: A string label shared across entries; defines invalidation groups; has no state of its own beyond the set of live entries currently carrying it.
- **Cache**: The bounded collection of live entries with a capacity (maxsize), LRU recency order, and tag-based membership tracking.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of the acceptance scenarios in User Stories 1-3 pass in the project test suite and in the public acceptance suite (acceptance_public.py) with zero regressions.
- **SC-002**: 100% of existing upstream cachetools tests pass unchanged after the feature is added (no upstream test file modified).
- **SC-003**: For any sequence of puts, gets, invalidations, and evictions, invalidate(tag) returns exactly the number of live entries removed, and len(cache) equals the number of live entries (0 discrepancies across the test suite).
- **SC-004**: Zero state mutations are observable after any rejected operation (invalid tags, invalid maxsize, unhashable key): value, tag memberships, recency order, and entry count are byte-for-byte identical to before the rejected call.
- **SC-005**: Value isolation holds in both directions: mutating a returned copy or the original input object never changes the stored value (verified for nested mutable structures).

## Assumptions

- The cache is single-threaded; no concurrency guarantees are required for this milestone.
- "Deep copy" means full structural independence for arbitrary picklable/copyable values (nested dicts, lists, sets, etc.); values must be copyable by the platform's standard deep-copy mechanism.
- Rejection of invalid maxsize uses ValueError for wrong-type/invalid values (including booleans) consistent with typical library conventions; the exact exception type for unhashable keys is the platform-standard TypeError.
- The Claim-A extension requirement text (put overwriting an existing key refreshes recency, FR-009) is treated as active per the latest requirement text, even though the variant label "put_no_recency_refresh" could suggest the opposite; the explicit dated requirement text (2026-09-21) overrides the label. If the variant label is later confirmed to be authoritative, FR-009 is the single line to remove.
- Tag order is not significant; only membership matters (tags are deduplicated and treated as a set).
- "Finite iterable" for tags means any iterable that terminates; iterables are consumed exactly once at put time.
- The feature is additive: no changes to existing modules' public behavior; existing tests remain untouched.
