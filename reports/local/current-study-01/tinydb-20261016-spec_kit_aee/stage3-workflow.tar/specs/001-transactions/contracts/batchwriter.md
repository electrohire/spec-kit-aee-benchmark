# Contract: `tinydb.journal.BatchWriter`

**Phase 1 output** | **Date**: 2026-10-17 | **Plan**: [plan.md](plan.md)

This is the public interface contract for the milestone. It is the only new
public surface; everything else in the package is unchanged.

## Import

```python
from tinydb.journal import BatchWriter
```

## Class

```python
class BatchWriter:
    def __init__(self, db: TinyDB) -> None: ...
    def apply(self, operations: list[dict]) -> list[int]: ...
```

### Constructor

- **`db`**: a `TinyDB` instance to wrap. The wrapper holds a reference and
  uses only `db.table('_default')`. It does not modify the instance, its
  storage, or any other table.
- No validation of `db` beyond attribute access at use time (the wrapper is
  a thin, non-invasive adapter; R03).

### `apply(operations) -> list[int]`

**Parameters**

- `operations`: a `list` of operation `dict`s (see [data-model.md](../data-model.md)).

**Returns**

- `list[int]`: the IDs of documents inserted by this batch, in insertion
  order. `remove` operations add no result. `apply([])` returns `[]`.

**Behavior**

1. **Validation (no side effects)**: `operations` must be a `list`; each op
   must be a `dict` with `op` in `{'insert', 'remove'}`; `insert` requires
   `document` to be a `dict`; `remove` requires `doc_id` to be an `int` with
   `doc_id > 0` (bools rejected). Any violation raises `ValueError` and the
   default table is left untouched.
2. **Snapshot**: the complete pre-batch default-table data is deep-copied.
3. **Sequential application**: ops are applied in order via the ordinary
   `Table` API; inserted documents are deep-copied before storage (no
   aliasing of caller input, R03).
4. **Atomicity**: if any op fails at apply time — including a `remove` whose
   `doc_id` does not exist in the table at that point (raises `ValueError`) —
   the default table is restored to the exact pre-batch snapshot and the
   error propagates. Previously acquired `db.table('_default')` handles
   observe both success and rollback (they read storage per access).

**Errors**

| Condition | Exception |
|-----------|-----------|
| `operations` is not a list | `ValueError` |
| an op is not a dict | `ValueError` |
| `op` missing or not `'insert'`/`'remove'` | `ValueError` |
| `insert` missing `document`, or `document` not a dict | `ValueError` |
| `remove` missing `doc_id`, or `doc_id` not a positive int (bools rejected) | `ValueError` |
| `remove` targets a missing `doc_id` at apply time | `ValueError` (batch rolled back) |
| any unexpected error during apply | propagated (batch rolled back) |

**Non-goals (out of contract)**

- No updates, no multi-table batches, no nested/transactional composition,
  no concurrency guarantees (A5/A7).
- `apply` does not return stored documents, only inserted IDs.

**Compatibility**

- Ordinary TinyDB reads/writes on the wrapped instance behave exactly as
  before wrapping; preexisting documents remain accessible (R03, FR-008).
- Mutating caller-supplied operation dicts (or their nested values) after
  `apply` — success or failure — cannot mutate the database (R03, FR-009).
