# Implementation Plan: Atomic Batch Journal Writer (BatchWriter)

**Branch**: `001-transactions` | **Date**: 2026-10-17 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/testbed/specs/001-transactions/spec.md`

**Note**: This template is filled in by the `$speckit-plan` command; its definition describes the execution workflow.

## Summary

Add a new module `tinydb/journal.py` exposing `BatchWriter(db)`. It wraps a
supplied `TinyDB` instance (default table only) and provides
`apply(operations)`: a list of operation dicts, each `{'op': 'insert',
'document': dict}` or `{'op': 'remove', 'doc_id': positive int}`. `apply`
validates every operation up front (malformed -> `ValueError`, no mutation),
snapshots the complete pre-batch default-table data, then applies operations
sequentially through the ordinary `Table` API (`insert` / `remove(doc_ids=...)`)
and returns the inserted doc IDs in insertion order (removes contribute
nothing; empty input -> `[]`). If any operation fails at apply time (a remove
targeting a missing ID is such a failure and raises `ValueError`), the default
table is restored to the exact pre-batch snapshot (deep-copied) so the batch
is all-or-nothing. Documents are deep-copied on insert so stored data and
returned results never alias caller input, and ordinary TinyDB reads/writes
and preexisting documents are untouched by the wrapper (constitution I).

## Technical Context

**Language/Version**: Python >=3.10,<4 (repo `pyproject.toml`); developed on
Python 3.12.14 (observed).

**Primary Dependencies**: none new. Reuses `tinydb.TinyDB`, `tinydb.Table`
(`insert`, `remove(doc_ids=...)`, `_read_table`), `copy.deepcopy`, stdlib only.

**Storage**: whatever storage the supplied `TinyDB` uses (e.g.
`MemoryStorage`, `JSONStorage`); `BatchWriter` never touches storage directly
except via `Table._read_table()` for the snapshot. No persistence changes.

**Testing**: pytest 9.1.1 (observed). Run with `python3 -m pytest -q
-o addopts=""` (repo `pytest.ini` addopts require pytest-cov, which is not
installed in this environment; upstream tests pass 223/223 with that flag).
Own tests go in `tests/test_journal.py` (new file; upstream test files
unchanged). Public gate: `acceptance_public.py`.

**Target Platform**: any platform supported by the repo (pure Python library).

**Project Type**: library (single package `tinydb` at repo root).

**Performance Goals**: correctness first; `apply` is O(batch size) table
writes through the existing `Table._update_table` path (one storage write per
operation). No performance targets stated; batches are expected small.

**Constraints**: additive only (no changes to existing public APIs); default
table only; synchronous single-threaded use; `ValueError` for malformed ops
and missing-ID removes (missing-ID error type pinned by
`acceptance_public.py::test_public_atomic`); rollback must be observable
through previously acquired `db.table('_default')` handles.

**Scale/Scope**: one new module (~120 LOC incl. docstrings), one new test
file, no changes to existing modules.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-checked after Phase 1 design.
Constitution: `.specify/memory/constitution.md` (TinyDB Constitution, v1.0.0,
verified by direct read).*

- **I. Preserve Existing Public API Behavior** ("New functionality MUST be
  additive; existing upstream tests MUST pass unchanged"): PASS. The plan
  adds only `tinydb/journal.py` + `tests/test_journal.py`; no existing file
  is modified. Observed baseline: `python3 -m pytest -q -o addopts="" tests/`
  -> `223 passed in 1.25s` (evidence ref
  `f6ab2ceb7566a60b0a13d2c082169419de9d3a97b7db0e05001807ce158f5296`).
- **II. Testable Acceptance Criteria** ("Acceptance evidence MUST come from
  running `acceptance_public.py` and the project's own tests"): PASS.
  FR-001..FR-009 each map to an observable scenario in
  [quickstart.md](quickstart.md) and a concrete falsification test recorded
  in the claims object; `acceptance_public.py` is the public gate (observed
  to currently fail collection with `ModuleNotFoundError: No module named
  'tinydb.journal'` until the module exists).
- **III. Evidence Over Assertion** ("Claims about behavior MUST distinguish
  observed evidence from unverified assertions"): PASS. This plan cites
  observed command outputs and source locations; every design decision in
  [research.md](research.md) names the file/line basis it was read from.
- **IV. Simple Scoped Implementations** ("A change MUST touch only the files
  its requirement names"): PASS. Only the two files named above are added;
  no speculative abstractions (no transactions framework, no multi-table
  support, no new dependencies — constitution Additional Constraints).
- **V. Documented Assumptions and Regressions** ("Unresolved assumptions ... MUST
  be recorded in `HANDOFF.md`"): PASS. Assumptions A1-A7 are recorded in
  spec.md and mirrored in HANDOFF.md; A2 (missing-ID error type) is resolved
  to `ValueError` by the public acceptance test (research.md D2) and is no
  longer open.

**Gate result (post-Phase 1 re-check): PASS. No violations; Complexity
Tracking not required.**

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── batchwriter.md
└── tasks.md             # Phase 2 output ($speckit-tasks command - NOT created by $speckit-plan)
```

### Source Code (repository root)

```text
tinydb/
├── __init__.py          # unchanged (no re-export required; import path is
│                        #   tinydb.journal per the milestone contract)
├── journal.py           # NEW: BatchWriter (the only production change)
├── database.py          # unchanged
├── table.py             # unchanged (insert/remove/_read_table reused)
└── storages.py          # unchanged

tests/
└── test_journal.py      # NEW: own tests for R01-R03 (upstream files unchanged)

acceptance_public.py     # public acceptance gate (unchanged, currently errors
                         #   with ModuleNotFoundError until journal.py exists)
```

**Structure Decision**: Single-project library layout (existing repo root
`tinydb/` package + `tests/`). The feature adds exactly one module
`tinydb/journal.py` as mandated by the milestone ("Implementation source:
tinydb/journal.py") and one dedicated test file. No new directories, no
`src/` migration, no package re-exports.

## Complexity Tracking

> No Constitution Check violations; table intentionally empty.
