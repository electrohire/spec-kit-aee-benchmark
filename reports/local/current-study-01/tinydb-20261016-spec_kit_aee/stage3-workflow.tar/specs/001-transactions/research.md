# Research: Atomic Batch Journal Writer (BatchWriter)

**Phase 0 output** | **Date**: 2026-10-17 | **Plan**: [plan.md](plan.md)

All technical-context unknowns were resolved during research; no
NEEDS CLARIFICATION markers remain in plan.md. Open item from the spec
(Assumption A2: error type of a missing-ID remove) is resolved below (D2).

## D1: Rollback mechanism — snapshot/restore via the ordinary Table API

- **Decision**: Before applying, snapshot the complete pre-batch default-table
  data with `deepcopy(self._db.table('_default')._read_table())` (raw
  `{doc_id: doc}` mapping, IDs as `document_id_class` ints). On any apply-time
  error, restore by rewriting the table with a single
  `table._update_table(lambda t: (t.clear(), t.update(snapshot)))`-equivalent
  updater, then clear the table's query cache. Apply each operation through
  the public `Table.insert(document)` and `Table.remove(doc_ids=[doc_id])`.
- **Rationale**: `Table._read_table()` reads the current storage state (no
  stale in-memory table copy exists in this codebase — every Table operation
  re-reads storage, verified in `tinydb/table.py` `_update_table`/`_read_table`),
  so a snapshot taken before the batch is the exact pre-batch state. Restoring
  through the same storage write path guarantees that *previously acquired*
  `db.table('_default')` handles observe the rollback, because they read
  storage on every access (FR-007). Using public `insert`/`remove` for the
  apply phase reuses existing ID generation and storage-write semantics
  (constitution I: additive, no behavior changes).
- **Alternatives considered**:
  1. *Undo log* (record inverse ops per step, replay on failure): rejected —
     more code, and a remove that restores a document must also restore its
     original ID; snapshot/restore is simpler and restores the *complete*
     pre-batch data as R02 demands, not just the inverse of applied steps.
  2. *Validate-then-apply with pre-checks only* (check all removes exist
     before applying): rejected — R02 says "validate and apply sequentially,
     but on any error restore"; a pre-check would still need a fallback for
     apply-time errors, and it would mis-handle a remove of a doc inserted
     earlier in the same batch (exists at apply time but not pre-batch).
  3. *Direct storage manipulation* (`db._storage.read()/write()`): rejected —
     bypasses `Table` semantics (ID class conversion, table creation),
     higher risk of diverging from ordinary behavior.

## D2: Error type for a missing-ID remove — `ValueError`

- **Decision**: A remove targeting a missing document ID raises `ValueError`
  and triggers rollback.
- **Rationale**: `acceptance_public.py::test_public_atomic` (observed,
  lines 22-27) asserts `pytest.raises(ValueError)` for a batch containing
  `{'op': 'remove', 'doc_id': 99}` against a table holding only doc 1. The
  public contract therefore pins the type; spec Assumption A2 is resolved.
- **Alternatives considered**: `KeyError` (natural for missing keys) —
  rejected because the public acceptance test requires `ValueError`.

## D3: Document copy semantics — `deepcopy` on insert

- **Decision**: Store `deepcopy(document)` for every insert (never the caller's
  object). The returned list contains only fresh ints (inserted doc IDs), so
  the return value cannot alias caller data either.
- **Rationale**: R03 requires that mutating an operation after `apply()` cannot
  mutate the database, including nested data. `Table.insert` itself only does
  `dict(document)` (shallow, verified in `tinydb/table.py`), which would leave
  nested lists/dicts aliased — so the copy must happen in `BatchWriter`.
  `copy.deepcopy` is stdlib, handles arbitrary nesting, and is the standard
  isolation primitive. Note: TinyDB already stores documents as plain dicts in
  storage (its own `insert` keeps nested references), so this is a deliberate,
  documented strengthening for the batch path only (constitution V).
- **Alternatives considered**: `json.loads(json.dumps(...))` — rejected: fails
  on non-JSON values (e.g. `datetime`), which TinyDB documents allow.
  Shallow `dict(document)` — rejected: aliases nested values, violates R03.

## D4: Validation strategy — validate all ops up front, then apply

- **Decision**: Two phases inside `apply`: (1) validate every operation
  (list input, dict ops, known `op`, required keys, `document` is a dict,
  `doc_id` is an int > 0 with `bool` excluded) — any failure raises
  `ValueError` *before* any mutation; (2) snapshot + sequential apply, with
  rollback on any apply-time error (missing-ID remove, or any unexpected
  exception from the Table API).
- **Rationale**: R01 requires `ValueError` for malformed ops with no partial
  application; validating first guarantees that. "Validate and apply
  sequentially" (R02) is honored: each op is checked and then applied in
  order; the up-front pass only adds the guarantee that malformed input never
  mutates. `isinstance(True, int)` is True in Python, so booleans must be
  explicitly rejected for `doc_id` (A1: positive integer).
- **Alternatives considered**: Single-pass check-then-apply per op — rejected:
  a malformed op at position N would leave ops 0..N-1 applied unless the
  rollback path also fires on `ValueError`; the two-phase design makes the
  malformed path trivially side-effect-free.

## D5: Test layout and run command

- **Decision**: New file `tests/test_journal.py` (pytest). Run
  `python3 -m pytest -q -o addopts="" tests/test_journal.py acceptance_public.py`
  (and the full upstream suite for regressions).
- **Rationale**: `pytest.ini` addopts include `--cov*` flags but pytest-cov is
  not installed in this environment (observed: `unrecognized arguments`); the
  `-o addopts=""` override is the minimal, non-invasive way to run tests
  without touching upstream config (constitution I/V). Upstream suite baseline
  observed: 223 passed.
- **Alternatives considered**: Editing `pytest.ini` to drop coverage flags —
  rejected: modifies upstream test configuration, out of scope.

## D6: Module surface

- **Decision**: `tinydb/journal.py` defines `class BatchWriter` with
  `__init__(self, db)` and `apply(self, operations) -> list[int]`.
  `__all__ = ['BatchWriter']`. No re-export from `tinydb/__init__.py`.
- **Rationale**: The milestone and `acceptance_public.py` import
  `from tinydb.journal import BatchWriter`; adding a re-export to
  `tinydb/__init__.py` would modify an existing public module for no
  contractual benefit (constitution IV).
- **Alternatives considered**: Re-exporting `BatchWriter` at package level —
  rejected as unnecessary public-API surface change.
