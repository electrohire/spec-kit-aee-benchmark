# Feature Specification: Atomic Batch Journal Writer (BatchWriter)

**Feature Branch**: `[001-transactions]`

**Created**: 2026-10-17

**Status**: Draft (updated for milestones 1-3, including Claim-A extensions R05b / R05 clarification)

**Input**: User description: "tinydb milestone 1: Build tinydb.journal.BatchWriter(db), wrapping a supplied TinyDB instance without changing its ordinary APIs. Use the default table only. R01: apply(operations) accepts a list of operation dictionaries. Each operation is either {'op':'insert','document':dict} or {'op':'remove','doc_id':positive integer}. Return a list of inserted document IDs (removes add no result). Empty input returns []. Unknown/malformed operations raise ValueError. R02: Batch application is atomic: validate and apply sequentially, but on any error restore the complete pre-batch default-table data. A remove targeting a missing ID is an error. Previously acquired db.table('_default') handles must reflect both success and rollback. R03: Ordinary TinyDB reads/writes and preexisting documents continue to work. Inserted and returned nested data must not alias the caller's input. Mutating an operation after apply cannot mutate the database."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a batch of insert/remove operations (Priority: P1)

A caller holding a TinyDB instance wraps it with a BatchWriter and submits a
batch of operations as a list of operation dictionaries. Each operation either
inserts a document (possibly with nested lists/dicts) into the default table or
removes an existing document by its positive integer document ID. The batch is
validated and applied sequentially, and the caller receives the list of inserted
document IDs in insertion order; remove operations contribute no result.

**Why this priority**: This is the core capability the feature exists to
provide. Without it the feature has no value; with it alone the feature is a
viable, testable MVP.

**Independent Test**: Can be fully tested by creating a TinyDB instance, wrapping
it with BatchWriter, calling apply() with a mixed insert/remove batch, and
asserting the returned ID list and the resulting default-table contents.

**Acceptance Scenarios**:

1. **Given** a default table containing preexisting documents, **When**
   apply() is called with a non-empty list of valid insert and remove
   operations, **Then** all operations are applied in order to the default
   table and a list of the inserted document IDs (insertion order; removes add
   nothing) is returned.
2. **Given** a BatchWriter, **When** apply() is called with an empty list,
   **Then** [] is returned and the default table is unchanged.
3. **Given** a batch containing an unknown or malformed operation (op not
   'insert'/'remove', missing or wrong-typed fields, non-dict operation,
   non-list input, or a doc_id that is not a positive integer), **When**
   apply() is called, **Then** a ValueError is raised and no partial changes
   remain in the default table.

---

### User Story 2 - Atomic all-or-nothing batch (Priority: P2)

A caller submits a batch that fails partway through (for example, a remove
targeting a missing document ID, or a malformed operation after several
successful ones). The whole batch is rolled back: the default table is restored
to its complete pre-batch state, and previously acquired handles to the default
table observe the rollback. On success, those same handles observe the applied
changes.

**Why this priority**: Atomicity is the safety property that makes batch
application trustworthy; it is the second pillar of the milestone after basic
application.

**Independent Test**: Can be fully tested by seeding the default table, acquiring
a table handle, applying a batch that fails mid-way, and asserting the table
handle shows exactly the pre-batch data; then applying a valid batch and
asserting the handle shows the updated data.

**Acceptance Scenarios**:

1. **Given** a non-empty pre-batch default table and a batch whose later
   operation targets a missing document ID, **When** apply() is called,
   **Then** an error is raised and the default table is restored to its
   complete pre-batch data (documents inserted earlier in the same batch are
   removed, documents removed earlier in the same batch are restored).
2. **Given** a previously acquired handle to the default table, **When** a
   successful batch is applied, **Then** the handle reflects the applied
   changes; when a failing batch is applied, **Then** the handle reflects the
   rolled-back pre-batch data.

---

### User Story 3 - Non-invasive wrap with independent data copies (Priority: P3)

A caller uses BatchWriter alongside ordinary TinyDB usage. Wrapping the
instance does not change ordinary TinyDB reads or writes, and preexisting
documents remain accessible and mutable through the ordinary API. Data inserted
via a batch and data returned by apply() are independent copies: mutating the
caller's input documents or the returned IDs' associated data afterwards cannot
mutate the database contents.

**Why this priority**: Compatibility and data-isolation guarantees protect
existing consumers; they refine the feature rather than define its core value.

**Independent Test**: Can be fully tested by inserting documents through the
ordinary API and through a batch, then mutating the caller's original input
dictionaries and verifying the database contents are unchanged, and by
performing ordinary TinyDB reads/writes before and after batch use.

**Acceptance Scenarios**:

1. **Given** a TinyDB instance with preexisting documents, **When** it is
   wrapped with BatchWriter and ordinary TinyDB reads/writes are performed
   before and after batch operations, **Then** all reads/writes behave exactly
   as without the wrapper.
2. **Given** a successful batch insert of a nested document, **When** the
   caller mutates the original input document afterwards, **Then** the stored
   document is unchanged; the returned inserted IDs identify the stored
   documents.

---

### User Story 4 - Idempotent batch replay with a token (Priority: P2)

A caller submits the same batch more than once (for example, after a retry) and
wants a repeated submission to be a no-op that returns the original result
instead of re-running the mutations. The caller supplies a nonempty string
idempotency token to apply(). The first successful run records the token with
the batch and its inserted IDs; a later call with the same token and an
identical batch returns a detached copy of the original inserted IDs without
rerunning any mutation, even if other direct database writes occurred in the
meantime. Reusing a token with different operations is an error that leaves the
data unchanged. A batch that fails does not consume its token, so the same
token can be retried after the failure is fixed. Omitting the token (None)
means normal, non-idempotent operation.

**Why this priority**: Idempotency lets callers retry batches safely (e.g. after
a dropped response) without duplicating inserts; it is a core reliability
guarantee layered on top of the atomic apply.

**Independent Test**: Can be fully tested by applying a batch with a token,
applying the identical batch with the same token again (optionally after a
direct db.insert), asserting the second call returns the same IDs and the table
is unchanged; then asserting a different batch with the same token raises
ValueError and leaves the table unchanged.

**Acceptance Scenarios**:

1. **Given** a successful apply() of a batch with a nonempty string token,
   **When** the identical batch is applied again with the same token (even after
   other direct database writes), **Then** a detached copy of the original
   inserted IDs is returned and no mutation is rerun (table contents unchanged
   by the replay).
2. **Given** a token already recorded by a successful batch, **When** a
different batch is applied with that same token, **Then** a ValueError is
   raised and the default table is unchanged.
3. **Given** a batch that fails, **When** it is applied with a token, **Then**
   the token is NOT consumed and the same token may be reused on a later
   attempt; the failed batch still rolls back per R02.
4. **Given** apply() called with a token that is not a nonempty string (None is
   the only other allowed value), **When** it is called, **Then** a ValueError
   is raised and the table is unchanged.

---

### Edge Cases

- Empty operations list: returns [] and leaves the table unchanged.
- Remove targeting a missing document ID: an error; the whole batch rolls back.
- doc_id that is 0, negative, or not an integer: ValueError (malformed).
- Operation that is not a dictionary, or a list that is not a list of
  dictionaries: ValueError.
- Insert whose 'document' value is not a dict: ValueError.
- A remove that targets a document inserted earlier in the same batch: allowed
  (sequential application; the document exists at that point).
- Failure after several successful operations: complete rollback of the
  pre-batch state, including undoing earlier inserts and restores of earlier
  removes within the same batch.
- Nested documents (dicts and lists at any depth) in inserts: stored and
  returned as copies, not aliases of the caller's input.
- doc_id given as a boolean (True/False): ValueError (bool is not accepted
  as a positive integer).
- Operation dict carrying fields beyond its op kind (e.g. an insert with a
  'doc_id' field or a remove with a 'document' field): ValueError.
- preview() called with a batch that would fail: raises the same error apply
  would raise, consumes no IDs, and leaves data and the next insertion ID
  unchanged.
- preview() called twice (or a returned list mutated): each call returns a
  fresh list; mutation of an earlier result changes nothing.
- Direct db.insert between wrapper calls: the next apply/preview continues
  the ID sequence from the state including that direct insert.
- Successful batch containing removes: the next insertion ID still advances
  past every ID the batch consumed (no reuse after removes).

- Token replay after other direct writes: the replay still returns the
  original inserted IDs and does not rerun the batch.
- Token reused with different operations: ValueError, table unchanged.
- A failed batch with a token: token not consumed; retry with same token works
  once the batch is valid.
- Token that is empty string, non-string, or None-with-operations: None is the
  normal no-token path; empty/non-string tokens raise ValueError.
- Mutating a list returned by a token replay: must not expose or corrupt the
  writer's internal token bookkeeping.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001** (R01): BatchWriter MUST wrap a supplied TinyDB instance and expose
  apply(operations), which accepts a list of operation dictionaries.
- **FR-002** (R01): Each operation MUST be either {'op': 'insert',
  'document': dict} or {'op': 'remove', 'doc_id': positive integer}; no other
  operation kinds are supported; only the default table is used.
- **FR-003** (R01): apply() MUST return the list of inserted document IDs in
  insertion order; remove operations MUST add no result; empty input MUST
  return [].
- **FR-004** (R01): Unknown or malformed operations MUST raise ValueError
  (including: op not 'insert'/'remove', missing or wrong-typed required fields,
  doc_id not a positive integer, document not a dict, non-dict operation,
  non-list input).
- **FR-005** (R02): Batch application MUST be atomic: operations are validated
  and applied sequentially, but on any error the complete pre-batch default-
  table data MUST be restored and no partial changes may remain.
- **FR-006** (R02): A remove targeting a missing document ID MUST be an error
  and MUST trigger the rollback in FR-005.
- **FR-007** (R02): Previously acquired handles to the default table (the table
  obtained via db.table('_default') before the batch) MUST reflect both
  successful application and rollback.
- **FR-008** (R03): Ordinary TinyDB reads/writes and preexisting documents MUST
  continue to work when a BatchWriter wraps the instance; the wrapper MUST NOT
  change ordinary TinyDB behavior.
- **FR-009** (R03): Inserted and returned nested data MUST NOT alias the
  caller's input; mutating an operation (or its document) after apply() MUST
  NOT mutate the database.
- **FR-010** (R04): A boolean MUST be rejected as a doc_id even though bool
  is an int subclass; operations MUST be validated structurally before any
  change is committed; ValueError MUST be raised for unsupported fields, a
  non-list operations argument, or a non-dict document; an empty dictionary
  MUST be accepted as a document.
- **FR-011** (R05): BatchWriter MUST expose preview(operations), returning the
  inserted document IDs that apply() would produce while leaving all table
  data and the next insertion ID unchanged, including when the batch would
  fail; preview and a failed apply MUST NOT consume document IDs; existing
  table handles and query caches MUST remain coherent after either.
- **FR-012** (R05b): preview() MUST return a new, detached list on every
  call; mutating a previously returned preview list MUST NOT affect later
  preview results or any internal writer state.
- **FR-013** (R05 clarification): apply() MUST advance the wrapper's
  next-insertion-ID state on every successful batch and write that state back
  to the underlying table so that subsequent inserts -- via apply() or direct
  db.insert -- continue the ID sequence without reuse or rewind, even across
  remove operations; a failed batch MUST NOT advance the sequence.
- **FR-014** (R06): Direct db.insert operations performed between wrapper
  calls MUST be seen by the wrapper; the wrapper MUST NOT cache a stale
  initial snapshot of table data or ID state.

- **FR-015** (R07): apply() MUST accept an optional idempotency token
  (default None). A token MUST be a nonempty string; any other non-None value
  MUST raise ValueError. Repeating an already successful batch with the same
  token and an identical operations list MUST return a detached copy of the
  original inserted IDs without rerunning any mutation, even if other direct
  database writes occurred since. Reusing a token with a different operations
  list MUST raise ValueError and MUST NOT change the data. A failed batch MUST
  NOT consume its token. token=None MUST mean normal, non-idempotent
  operation.
- **FR-016** (R08): Token bookkeeping MUST belong to the BatchWriter instance
  and MUST NOT be stored in user documents. preview() MUST NOT record or
  consume a token and MUST keep its original single-argument signature. Lists
  returned by apply() or preview() MUST NOT expose the writer's internal token
  bookkeeping through mutation.

### Key Entities

- **TinyDB instance**: The supplied database that BatchWriter wraps; source of
  the default table and of ordinary reads/writes. Not modified in its API.
- **Default table**: The single table BatchWriter operates on; holds preexisting
  and inserted documents; its complete data defines the pre-batch state for
  rollback.
- **Operation**: A dictionary describing one atomic step: an insert carrying a
  document dict, or a remove carrying a positive integer document ID.
- **Document**: A dict (possibly nested with lists/dicts) inserted into the
  default table; stored as an independent copy of the caller's input.
- **Document ID**: A positive integer identifying a document in the default
  table; the unit of the return value of apply() and of remove targeting.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of valid mixed insert/remove batches apply completely to the
  default table and return exactly the inserted document IDs in insertion order
  (removes contribute nothing).
- **SC-002**: 100% of failing batches (missing-ID remove, malformed operation,
  or error mid-batch) leave the default table byte-for-byte equal to its
  pre-batch state, as observed through both the wrapper and previously acquired
  table handles.
- **SC-003**: 100% of unknown/malformed operations raise ValueError; empty
  input returns [] in 100% of cases.
- **SC-004**: 100% of ordinary TinyDB reads/writes and preexisting-document
  accesses behave identically with and without the wrapper (no regressions in
  the existing test suite).
- **SC-005**: 0 aliasing faults: mutating caller input or returned data after
  apply() never changes stored documents, for nested data at any depth.
- **SC-006**: 100% of preview calls return exactly the IDs apply would
  produce while leaving table contents and the next insertion ID unchanged,
  including for batches that would fail.
- **SC-007**: 0 ID-consumption faults: preview and failed apply never
  consume or advance document IDs; every successful batch advances the
  sequence exactly by the number of inserts it performed.
- **SC-008**: 0 ID-reuse/rewind faults: after any mix of apply batches,
  removes, and direct db.insert calls, the next inserted ID is strictly
  greater than every ID used so far.
- **SC-009**: 100% of structurally invalid inputs (bool doc_id, unsupported
  fields, non-list operations, non-dict documents) raise ValueError with no
  committed change; empty-dict documents are accepted in 100% of cases.

- **SC-010**: 100% of repeated identical batch/token submissions return
  the original inserted IDs (a detached copy) and rerun 0 mutations, even when
  other direct database writes occurred in between; a token reused with
different operations raises ValueError in 100% of cases with no data change.
- **SC-011**: 0 token-leak faults: token bookkeeping never appears in user
  documents, preview() never records/consumes a token and keeps its original
  signature, and mutating any returned list never exposes or corrupts internal
  token state.

## Assumptions

- **A1** (from R01): A 'positive integer' doc_id means an integer > 0; 0,
  negatives, booleans, and non-integer values are malformed and raise
  ValueError.
- **A2** (from R02, resolved): "Any error" in atomicity includes malformed
  operations (ValueError) and missing-ID removes; the error type for a
  missing-ID remove is ValueError, as pinned by the public acceptance test.
  Every such error MUST trigger rollback.
- **A3** (from R02): "Complete pre-batch default-table data" is the exact set of
  documents (with their IDs) present in the default table immediately before
  apply() is called; rollback restores that exact state.
- **A4** (from R03): "Returned nested data" refers to the returned list of
  inserted document IDs plus the stored documents being independent copies of
  the caller's input documents; apply() itself returns only IDs.
- **A5** (scope): BatchWriter operates on the default table only; other tables
  are out of scope and are not part of the batch/rollback contract.
- **A6** (scope): The implementation lives in tinydb/journal.py; public
  acceptance is acceptance_public.py; upstream tests remain unchanged; own
  tests may be added.
- **A7** (assumption): apply() is synchronous and single-threaded; concurrent
  batch usage is out of scope for this milestone.
- **A8** (conflict resolution): An older generated note claiming "preview may
  consume IDs and bool IDs are accepted" is unverified and is superseded by
  R04/R05; this specification follows R04/R05 (bool doc_ids rejected; preview
  never consumes IDs). A previously passing happy-path smoke test does not
  verify these boundaries and is not treated as evidence for them.
- **A9** (from R05 clarification): "Writing the next-insertion-ID state back
  to the underlying table" means the table's own next-ID bookkeeping (used by
  ordinary inserts) reflects the highest ID consumed by any successful batch,
  so direct db.insert continues the sequence; no separate persistent
  counter file or new storage format is required.
- **A10** (from R07): "Identical batch" for token replay means the operations
  argument is equal to the operations list recorded for that token on its first
  successful run (compared by value, not identity); equality is evaluated on
  the validated, normalized operation data. The recorded inserted IDs are the
  return value of the first successful run.
- **A11** (from R07/R08): Token bookkeeping is in-memory state on the
  BatchWriter instance (not persisted to the database or to user documents),
  so a new BatchWriter instance has no knowledge of prior tokens; this matches
  the instance-scoped nature of the requirement. The public acceptance test
  reuses the same BatchWriter instance for the replay.
