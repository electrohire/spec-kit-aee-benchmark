# Quickstart / Validation Guide: BatchWriter

**Phase 1 output** | **Date**: 2026-10-17 | **Plan**: [plan.md](plan.md)

Runnable validation scenarios proving the feature works end-to-end. Contract
details: [contracts/batchwriter.md](contracts/batchwriter.md). Model details:
[data-model.md](data-model.md).

## Prerequisites

- Python 3.10+ (repo `requires-python = ">=3.10,<4"`); environment observed on
  Python 3.12.14 with pytest 9.1.1.
- `tinydb/journal.py` implemented (milestone deliverable).
- No new dependencies. `pytest-cov` is NOT installed here; always run pytest
  with `-o addopts=""` to bypass the repo `pytest.ini` coverage flags.

## Setup

```sh
cd /testbed
# PYTHONPATH is not required (repo root is the source root), but if you run
# from elsewhere use: export PYTHONPATH=src:.  (repo convention)
```

## Scenario 1 — Basic apply (R01)

```python
from tinydb import TinyDB
from tinydb.storages import MemoryStorage
from tinydb.journal import BatchWriter

db = TinyDB(storage=MemoryStorage)
db.insert({'x': 1})                 # preexisting doc, id 1
w = BatchWriter(db)

assert w.apply([]) == []            # empty batch
ids = w.apply([
    {'op': 'insert', 'document': {'x': 2, 'nested': {'a': [1, 2]}}},
    {'op': 'remove', 'doc_id': 1},
    {'op': 'insert', 'document': {'x': 3}},
])
assert ids == [2, 3]                # insertion order; removes add nothing
assert [d['x'] for d in db.all()] == [2, 3]
```

**Expected**: all asserts pass; `db.all()` shows docs 2 and 3 only.

## Scenario 2 — Atomic rollback (R02)

```python
db = TinyDB(storage=MemoryStorage)
db.insert({'x': 1})
table = db.table('_default')        # previously acquired handle
w = BatchWriter(db)

try:
    w.apply([
        {'op': 'insert', 'document': {'x': 2}},
        {'op': 'remove', 'doc_id': 99},   # missing ID -> error
    ])
    raise AssertionError('expected ValueError')
except ValueError:
    pass

assert [d['x'] for d in table.all()] == [1]   # handle sees rollback
assert [d['x'] for d in db.all()] == [1]

# Success path is visible through the same handle:
assert w.apply([{'op': 'remove', 'doc_id': 1}]) == []
assert table.all() == []
```

**Expected**: `ValueError` raised; after rollback the previously acquired
handle shows exactly the pre-batch data; after the successful batch it shows
the updated data.

## Scenario 3 — Malformed operations (R01)

```python
for bad in [
    'not-a-list',
    [{'op': 'update', 'doc_id': 1, 'values': {}}],   # unknown op
    [{'op': 'insert'}],                               # missing document
    [{'op': 'insert', 'document': [1, 2]}],           # document not a dict
    [{'op': 'remove', 'doc_id': 0}],                  # not positive
    [{'op': 'remove', 'doc_id': -1}],                 # not positive
    [{'op': 'remove', 'doc_id': '1'}],                # not an int
    [{'op': 'remove', 'doc_id': True}],               # bool rejected
    [42],                                             # op not a dict
]:
    try:
        w.apply(bad)
        raise AssertionError(f'expected ValueError for {bad!r}')
    except ValueError:
        pass
assert [d['x'] for d in db.all()] == []               # nothing mutated
```

**Expected**: every malformed input raises `ValueError`; table unchanged.

## Scenario 4 — No aliasing (R03)

```python
db = TinyDB(storage=MemoryStorage)
w = BatchWriter(db)
doc = {'x': 1, 'nested': {'a': [1, 2]}}
ids = w.apply([{'op': 'insert', 'document': doc}])

doc['x'] = 999
nested = doc['nested']
nested['a'].append(3)

stored = db.all()[0]
assert stored['x'] == 1 and stored['nested']['a'] == [1, 2]
assert ids == [1]
```

**Expected**: stored document is unaffected by post-`apply` mutation.

## Scenario 5 — Ordinary API compatibility (R03)

```python
db = TinyDB(storage=MemoryStorage)
w = BatchWriter(db)
db.insert({'a': 1})
w.apply([{'op': 'insert', 'document': {'a': 2}}])
db.update({'a': 42}, [1])
db.remove(db.get(doc_id=2))
assert [d['a'] for d in db.all()] == [42]
```

**Expected**: ordinary TinyDB reads/writes work unchanged around batch use.

## Test commands

```sh
cd /testbed
# Own tests for this feature (new file, added in implementation phase):
python3 -m pytest -q -o addopts="" tests/test_journal.py

# Public acceptance gate:
python3 -m pytest -q -o addopts="" acceptance_public.py

# Upstream regression suite (must remain 223 passed, unchanged):
python3 -m pytest -q -o addopts="" tests/
```

**Expected outcomes**: all three commands exit 0; upstream suite reports
`223 passed` (observed baseline 2026-10-17, before `journal.py` exists —
`acceptance_public.py` currently fails collection with
`ModuleNotFoundError: No module named 'tinydb.journal'`, which is the expected
pre-implementation state).
