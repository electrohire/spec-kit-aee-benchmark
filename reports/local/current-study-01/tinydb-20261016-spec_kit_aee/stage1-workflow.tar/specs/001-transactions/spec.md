# Feature Specification: Atomic Batch Journal Writer (BatchWriter)

**Feature Branch**: `[001-transactions]`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "tinydb milestone 1: Build tinydb.journal.BatchWriter(db), wrapping a supplied TinyDB instance without changing its ordinary APIs. Use the default table only. R01: apply(operations) accepts a list of operation dictionaries. Each operation is either {'op':'insert','document':dict} or {'op':'remove','doc_id':positive integer}. Return a list of inserted document IDs (removes add no result). Empty input returns []. Unknown/malformed operations raise ValueError. R02: Batch application is atomic: validate and apply sequentially, but on any error restore the complete pre-batch default-table data. A remove targeting a missing ID is an error. Previously acquired db.table('_default') handles must reflect both success and rollback. R03: Ordinary TinyDB reads/writes and preexisting documents continue to work. Inserted and returned nested data must not alias the caller's input. Mutating an operation after apply cannot mutate the database."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a batch of insert/remove operations (Priority: P1)

A caller holding a TinyDB instance wraps it with a BatchWriter and submits a
batch of operations as a list of operation dictionaries. Each operation either
inserts a document (possibly with nested lists/dicts) into the default table or
removes an existing document by its positive integer document ID. The batch is
validated and applied sequentially, and the caller receives the list of inserted
document IDs in insertion order; remove operations contribute no result.

**Why this priority**: This is the core capability the feature exists to
provide. Without it the feature has no value; with it alone the feature is a
viable, testable MVP.

**Independent Test**: Can be fully tested by creating a TinyDB instance, wrapping
it with BatchWriter, calling apply() with a mixed insert/remove batch, and
asserting the returned ID list and the resulting default-table contents.

**Acceptance Scenarios**:

1. **Given** a default table containing preexisting documents, **When**
   apply() is called with a non-empty list of valid insert and remove
   operations, **Then** all operations are applied in order to the default
   table and a list of the inserted document IDs (insertion order; removes add
   nothing) is returned.
2. **Given** a BatchWriter, **When** apply() is called with an empty list,
   **Then** [] is returned and the default table is unchanged.
3. **Given** a batch containing an unknown or malformed operation (op not
   'insert'/'remove', missing or wrong-typed fields, non-dict operation,
   non-list input, or a doc_id that is not a positive integer), **When**
   apply() is called, **Then** a ValueError is raised and no partial changes
   remain in the default table.

---

### User Story 2 - Atomic all-or-nothing batch (Priority: P2)

A caller submits a batch that fails partway through (for example, a remove
targeting a missing document ID, or a malformed operation after several
successful ones). The whole batch is rolled back: the default table is restored
to its complete pre-batch state, and previously acquired handles to the default
table observe the rollback. On success, those same handles observe the applied
changes.

**Why this priority**: Atomicity is the safety property that makes batch
application trustworthy; it is the second pillar of the milestone after basic
application.

**Independent Test**: Can be fully tested by seeding the default table, acquiring
a table handle, applying a batch that fails mid-way, and asserting the table
handle shows exactly the pre-batch data; then applying a valid batch and
asserting the handle shows the updated data.

**Acceptance Scenarios**:

1. **Given** a non-empty pre-batch default table and a batch whose later
   operation targets a missing document ID, **When** apply() is called,
   **Then** an error is raised and the default table is restored to its
   complete pre-batch data (documents inserted earlier in the same batch are
   removed, documents removed earlier in the same batch are restored).
2. **Given** a previously acquired handle to the default table, **When** a
   successful batch is applied, **Then** the handle reflects the applied
   changes; when a failing batch is applied, **Then** the handle reflects the
   rolled-back pre-batch data.

---

### User Story 3 - Non-invasive wrap with independent data copies (Priority: P3)

A caller uses BatchWriter alongside ordinary TinyDB usage. Wrapping the
instance does not change ordinary TinyDB reads or writes, and preexisting
documents remain accessible and mutable through the ordinary API. Data inserted
via a batch and data returned by apply() are independent copies: mutating the
caller's input documents or the returned IDs' associated data afterwards cannot
mutate the database contents.

**Why this priority**: Compatibility and data-isolation guarantees protect
existing consumers; they refine the feature rather than define its core value.

**Independent Test**: Can be fully tested by inserting documents through the
ordinary API and through a batch, then mutating the caller's original input
dictionaries and verifying the database contents are unchanged, and by
performing ordinary TinyDB reads/writes before and after batch use.

**Acceptance Scenarios**:

1. **Given** a TinyDB instance with preexisting documents, **When** it is
   wrapped with BatchWriter and ordinary TinyDB reads/writes are performed
   before and after batch operations, **Then** all reads/writes behave exactly
   as without the wrapper.
2. **Given** a successful batch insert of a nested document, **When** the
   caller mutates the original input document afterwards, **Then** the stored
   document is unchanged; the returned inserted IDs identify the stored
   documents.

---

### Edge Cases

- Empty operations list: returns [] and leaves the table unchanged.
- Remove targeting a missing document ID: an error; the whole batch rolls back.
- doc_id that is 0, negative, or not an integer: ValueError (malformed).
- Operation that is not a dictionary, or a list that is not a list of
  dictionaries: ValueError.
- Insert whose 'document' value is not a dict: ValueError.
- A remove that targets a document inserted earlier in the same batch: allowed
  (sequential application; the document exists at that point).
- Failure after several successful operations: complete rollback of the
  pre-batch state, including undoing earlier inserts and restores of earlier
  removes within the same batch.
- Nested documents (dicts and lists at any depth) in inserts: stored and
  returned as copies, not aliases of the caller's input.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001** (R01): BatchWriter MUST wrap a supplied TinyDB instance and expose
  apply(operations), which accepts a list of operation dictionaries.
- **FR-002** (R01): Each operation MUST be either {'op': 'insert',
  'document': dict} or {'op': 'remove', 'doc_id': positive integer}; no other
  operation kinds are supported; only the default table is used.
- **FR-003** (R01): apply() MUST return the list of inserted document IDs in
  insertion order; remove operations MUST add no result; empty input MUST
  return [].
- **FR-004** (R01): Unknown or malformed operations MUST raise ValueError
  (including: op not 'insert'/'remove', missing or wrong-typed required fields,
  doc_id not a positive integer, document not a dict, non-dict operation,
  non-list input).
- **FR-005** (R02): Batch application MUST be atomic: operations are validated
  and applied sequentially, but on any error the complete pre-batch default-
  table data MUST be restored and no partial changes may remain.
- **FR-006** (R02): A remove targeting a missing document ID MUST be an error
  and MUST trigger the rollback in FR-005.
- **FR-007** (R02): Previously acquired handles to the default table (the table
  obtained via db.table('_default') before the batch) MUST reflect both
  successful application and rollback.
- **FR-008** (R03): Ordinary TinyDB reads/writes and preexisting documents MUST
  continue to work when a BatchWriter wraps the instance; the wrapper MUST NOT
  change ordinary TinyDB behavior.
- **FR-009** (R03): Inserted and returned nested data MUST NOT alias the
  caller's input; mutating an operation (or its document) after apply() MUST
  NOT mutate the database.

### Key Entities

- **TinyDB instance**: The supplied database that BatchWriter wraps; source of
  the default table and of ordinary reads/writes. Not modified in its API.
- **Default table**: The single table BatchWriter operates on; holds preexisting
  and inserted documents; its complete data defines the pre-batch state for
  rollback.
- **Operation**: A dictionary describing one atomic step: an insert carrying a
  document dict, or a remove carrying a positive integer document ID.
- **Document**: A dict (possibly nested with lists/dicts) inserted into the
  default table; stored as an independent copy of the caller's input.
- **Document ID**: A positive integer identifying a document in the default
  table; the unit of the return value of apply() and of remove targeting.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of valid mixed insert/remove batches apply completely to the
  default table and return exactly the inserted document IDs in insertion order
  (removes contribute nothing).
- **SC-002**: 100% of failing batches (missing-ID remove, malformed operation,
  or error mid-batch) leave the default table byte-for-byte equal to its
  pre-batch state, as observed through both the wrapper and previously acquired
  table handles.
- **SC-003**: 100% of unknown/malformed operations raise ValueError; empty
  input returns [] in 100% of cases.
- **SC-004**: 100% of ordinary TinyDB reads/writes and preexisting-document
  accesses behave identically with and without the wrapper (no regressions in
  the existing test suite).
- **SC-005**: 0 aliasing faults: mutating caller input or returned data after
  apply() never changes stored documents, for nested data at any depth.

## Assumptions

- **A1** (from R01): A 'positive integer' doc_id means an integer > 0; 0,
  negatives, booleans, and non-integer values are malformed and raise
  ValueError.
- **A2** (from R02): "Any error" in atomicity includes malformed operations
  (ValueError) and missing-ID removes; the raised error type for a missing-ID
  remove is unspecified by the milestone and is left to the plan (it MUST
  trigger rollback either way).
- **A3** (from R02): "Complete pre-batch default-table data" is the exact set of
  documents (with their IDs) present in the default table immediately before
  apply() is called; rollback restores that exact state.
- **A4** (from R03): "Returned nested data" refers to the returned list of
  inserted document IDs plus the stored documents being independent copies of
  the caller's input documents; apply() itself returns only IDs.
- **A5** (scope): BatchWriter operates on the default table only; other tables
  are out of scope and are not part of the batch/rollback contract.
- **A6** (scope): The implementation lives in tinydb/journal.py; public
  acceptance is acceptance_public.py; upstream tests remain unchanged; own
  tests may be added.
- **A7** (assumption): apply() is synchronous and single-threaded; concurrent
  batch usage is out of scope for this milestone.
