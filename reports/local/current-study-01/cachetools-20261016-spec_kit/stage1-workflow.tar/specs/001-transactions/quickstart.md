# Quickstart / Validation Guide: TaggedCache

**Feature**: 001-transactions | **Date**: 2026-10-17

Run from repository root `/testbed`. All commands below are the
acceptance evidence for this feature (Constitution Principle III).

## Prerequisites

- Python 3 with the package importable from `src` (repo already supports
  `PYTHONPATH=src:.`).
- pytest available (used by `acceptance_public.py` and the new test
  file).

## Validation scenarios

### 1. Public acceptance suite (gate)

```bash
PYTHONPATH=src:. python -m pytest acceptance_public.py -v
```
Expected: 2 passed (`test_public_basic`, `test_public_replacement`).

### 2. New self-authored tests (R01-R03 + Claim-A)

```bash
PYTHONPATH=src:. python -m pytest tests/test_tagged.py -v
```
Expected: all pass. The file MUST cover at minimum:
- put/get round-trip + deep-copy detachment in both directions (R01)
- KeyError on miss (R01)
- tag dedup; bare-string rejection; non-string element rejection with
  state unchanged (R01)
- invalidate exact removal + return count; replacement drops old tags
  (R02)
- eviction leaves no stale tag memberships on key reuse (R02)
- get refreshes recency (R02)
- len counts live entries (R02)
- maxsize validation incl. bool exclusion (R03)
- invalid replacement leaves value/tags/recency unchanged (R03)
- overwrite-put refreshes recency (Claim-A extension)

### 3. Regression gate: upstream tests unmodified and green

```bash
git status --porcelain tests/ acceptance_public.py src/cachetools/__init__.py
git diff --stat tests/ acceptance_public.py
PYTHONPATH=src:. python -m pytest tests/ -q
```
Expected: no diff for `tests/` and `acceptance_public.py`; the only new
file under `src/cachetools/` is `tagged.py`; full upstream suite passes.

### 4. Smoke script (manual, optional)

```bash
PYTHONPATH=src:. python - <<'EOF'
from cachetools.tagged import TaggedCache
c = TaggedCache(2)
c.put('a', {'x': [1]}, ['t1', 't1', 't2'])
c.put('b', 2, ['t2'])
assert c.get('a') == {'x': [1]}
assert c.invalidate('t2') == 2 and len(c) == 0
try:
    c.put('k', 1, 'bare')
except ValueError:
    pass
else:
    raise SystemExit('bare string must be rejected')
try:
    TaggedCache(True)
except ValueError:
    pass
else:
    raise SystemExit('bool maxsize must be rejected')
print('smoke OK')
EOF
```
Expected: prints `smoke OK`.

## Exit criteria for the feature

- Scenarios 1-3 all pass with observed output recorded in the phase
  completion report.
- No file outside `src/cachetools/tagged.py`, `tests/test_tagged.py`,
  `specs/001-transactions/`, and notes (`HANDOFF.md`) is modified.
