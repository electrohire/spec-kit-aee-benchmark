# Data Model: TaggedCache

**Feature**: 001-transactions | **Date**: 2026-10-17

## Entities

### Entry (logical)

| Attribute | Type | Notes |
|---|---|---|
| key | hashable | Any hashable object; identity/equality per Python hashing. |
| value | deepcopy-able | Stored as `deepcopy(value)`; returned as `deepcopy(stored)`. Costs exactly 1 capacity slot. |
| tags | frozenset[str] | Deduplicated; empty set allowed. Never contains a bare string's characters. |
| recency | position in LRU order | Implicit; most-recently-used is evicted last. Refreshed by `get` hit and by `put` (insert AND overwrite — Claim-A extension, adopted per research.md R5). |

### Tag (logical)

- A `str` label shared by zero or more live entries.
- Value-compared; no normalization (case/whitespace-sensitive).
- A tag with no live entries holds no state (its index set is empty or
  absent).

### Capacity

- `maxsize`: positive `int`, `bool` excluded. Validated in `__init__`.
- Each live entry costs 1 slot regardless of value size.

## Storage layout (implementation-facing, from research.md R1/R2)

```
TaggedCache
├── _cache: LRUCache(maxsize)          # bounded LRU storage (existing class)
├── _key_tags: dict[key, frozenset]    # key -> its tags (live entries only)
└── _tag_keys: dict[str, set[key]]     # tag -> live keys carrying it
```

## Invariants (all MUST hold after every public call)

1. `set(self._key_tags) == set(self._cache)` — indexes cover exactly the
   live entries.
2. For every live key: `self._key_tags[key]` equals the deduplicated tags
   from the last successful `put` for that key.
3. For every tag `t`: `self._tag_keys[t]` (if present) equals
   `{k for k in live keys if t in self._key_tags[k]}`; empty sets are
   removed so no tag lingers with zero members.
4. `len(cache) == len(self._cache)` — counts live entries only.
5. `invalidate(t)` returns `len(self._tag_keys.get(t, ()))` and removes
   exactly those keys.
6. No operation mutates state before all validation succeeds (R01/R03
   atomicity).

## State transitions

| Operation | Transition |
|---|---|
| `put(k, v, tags)` new key | add entry (deepcopy v, frozenset tags); if over capacity, evict LRU entry(s) via `_remove` (cleans both indexes + LRU order). |
| `put(k, v, tags)` existing key | drop k's old tag memberships; store new deepcopy; register new tags; k moves to MRU (LRUCache `__setitem__` semantics; Claim-A). |
| `put` invalid tags | no transition; `ValueError` raised before mutation. |
| `get(k)` hit | return deepcopy; k moves to MRU. |
| `get(k)` miss | `KeyError`; no state change. |
| `invalidate(t)` | remove all keys in `self._tag_keys[t]` via `_remove`; return count; drop t's index entry. |
| LRU eviction (internal, during put) | evicted key removed via `_remove` — index cleanup identical to explicit delete, so no stale memberships (R02). |
| `__init__` invalid maxsize | no object state; `ValueError`. |

## Validation rules (input -> error)

| Input | Rule | Error |
|---|---|---|
| `maxsize` | `isinstance(int)`, not `bool`, `> 0` | `ValueError` |
| `tags` is `str` | bare string rejected before iteration | `ValueError` |
| `tags` not iterable | finite iterable required | `ValueError` |
| tag element not `str` | per-element type check | `ValueError` |
| key unhashable | dict key requirement | `TypeError` (standard Python; not part of R01-R03 error contract) |
