# Phase 0 Research: TaggedCache

**Feature**: 001-transactions | **Date**: 2026-10-17

## R1. How to reuse LRUCache for bounded storage

- **Decision**: Compose. `TaggedCache.__init__` creates
  `self._cache = LRUCache(maxsize)` and drives it through its public
  mapping protocol (`self._cache[key] = value`, `self._cache[key]`,
  `del self._cache[key]`, `key in self._cache`, `len(self._cache)`,
  `iter(self._cache)`). No subclassing, no access to name-mangled
  internals (`_LRUCache__order`).
- **Rationale**: The milestone mandates using the existing `LRUCache`;
  composition via the public protocol is the least-coupled reuse. It
  inherits for free: one-slot-per-value sizing (`getsizeof` default 1),
  LRU eviction on overflow, recency update on set AND on get (observed
  in `LRUCache.__setitem__`/`__getitem__`, `src/cachetools/__init__.py`
  lines 210-218), and order cleanup on delete/eviction (lines 220-231).
- **Alternatives considered**:
  1. Subclass `LRUCache` and override `__setitem__`/`__delitem__` —
     rejected: couples TaggedCache to internal layout, and TaggedCache
     must NOT behave like a mapping of raw values (its `get` returns
     deep copies and raises `KeyError` via a dedicated method, not
     `__getitem__` semantics).
  2. Reimplement LRU with `OrderedDict` inside tagged.py — rejected:
     duplicates existing code (Constitution Principle IV) and risks
     divergent eviction behavior.

## R2. Tag index design

- **Decision**: Two indexes kept in lockstep with the LRU cache:
  - `self._key_tags: dict[key, frozenset[str]]` — tags of each live key.
  - `self._tag_keys: dict[str, set[key]]` — live keys per tag.
  Both are updated in the same code path as the LRU cache mutation, and
  every removal path (explicit delete, `invalidate`, LRU eviction) goes
  through one internal `_remove(key)` helper that cleans both indexes.
- **Rationale**: O(1) lookup for `key in cache`, O(k) `invalidate(tag)`
  (k = removed entries), and a single choke point guarantees no stale
  memberships survive eviction or replacement (R02).
- **Alternatives considered**:
  1. Store tags *inside* the value wrapped in the LRU cache — rejected:
     would leak tag data through any value access and break the
     deep-copy-only value contract.
  2. Single `tag -> set[key]` index only, derive key tags by scanning —
     rejected: O(tags) per replacement/eviction; two indexes keep every
     operation O(1) or O(removed).

## R3. Validation order and atomicity

- **Decision**: In `put`, validate `tags` FIRST (bare string check, then
  finite iteration with per-entry `isinstance(tag, str)` check, then
  dedup into a frozenset). Only after validation succeeds does any state
  change happen: (a) if the key exists, remove its old tag memberships
  via `_remove`-style index cleanup, (b) `self._cache[key] = deepcopy(value)`,
  (c) register new tag memberships. `maxsize` is validated in
  `__init__` before the LRU cache is created.
- **Rationale**: R01/R03 require invalid input to leave existing state
  (value, tags, recency) byte-identical. Validating before mutation is
  the only way to guarantee that without rollback logic.
- **Alternatives considered**: mutate-then-rollback on error — rejected:
  more code, and a failed `deepcopy` mid-mutation would need unwinding.

## R4. maxsize validation rule (R03)

- **Decision**: Raise `ValueError` unless
  `isinstance(maxsize, int) and not isinstance(maxsize, bool) and
  maxsize > 0`. Booleans are explicitly excluded (`True`/`False` are
  `int` subclasses in Python). Zero and negatives are rejected. Floats
  and other non-ints are rejected.
- **Rationale**: Matches "positive integer, excluding bool" exactly.
  `LRUCache`/`Cache` do not validate `maxsize` themselves (observed:
  `Cache.__init__` stores it as-is), so TaggedCache owns this check.
- **Alternatives considered**: delegate to `LRUCache` — rejected: it has
  no validation to delegate to.

## R5. Claim-A open item: put recency refresh on overwrite

- **Decision**: Adopt the Claim-A extension behavior — overwriting an
  existing key via `put` refreshes its LRU recency (key becomes
  most-recently-used). No code decision is needed to implement it: the
  chosen composition (R1) calls `self._cache[key] = value` for both
  insert and replace, and `LRUCache.__setitem__` already moves the key
  to the MRU end (observed, lines 216-218 + `__update`). The extension
  is therefore satisfied by construction and is recorded as adopted
  behavior, tested explicitly.
- **Rationale**: The candidate extension text states the behavior
  positively ("overwriting an existing key via put refreshes its LRU
  recency, making it the most-recently-used entry"). The base spec's
  R02 already requires `get` to refresh recency and requires replacement
  to update value/tags; adding put-refresh is the only reading that
  keeps one consistent LRU policy (any access or write touches
  recency). The variant name `put_no_recency_refresh` is the label of
  the candidate *family*; the extension text is the operative
  requirement and it specifies refresh. If a hidden acceptance test
  expected the opposite, it would contradict the written extension
  text; the written text wins (Constitution Principle II: explicit,
  testable criteria govern).
- **Alternatives considered**: no-refresh on put (key keeps its old
  recency position on replace) — rejected: contradicts the extension
  text and would require deliberately NOT using `LRUCache.__setitem__`
  semantics (e.g., pop + reinsert at old position), adding complexity
  for no stated benefit.
- **Risk note (Principle V)**: recorded here and in data-model.md so
  later phases test it explicitly (overwrite then overfill; the
  overwritten key must survive as MRU).

## R6. Deep-copy semantics

- **Decision**: Use stdlib `copy.deepcopy` on input (store
  `deepcopy(value)`) and on output (return `deepcopy(stored)`).
- **Rationale**: "Detached deep copy" and "values are copied on input"
  (R01) are exactly `deepcopy` semantics for arbitrary hashable-keyed
  values; stdlib, no dependencies. Values need not be hashable or
  picklable, only deepcopy-able.
- **Alternatives considered**: `copy.copy` (shallow) — rejected: nested
  mutable structures would still alias. `pickle` round-trip — rejected:
  requires picklable values; `deepcopy` is the standard-library norm.

## R7. Tag input handling details

- **Decision**: `tags` default is `()`. A `str` (or `bytes`? no —
  strings only per spec) passed directly is rejected with `ValueError`
  BEFORE iteration (prevents treating `"ab"` as tags `"a"`, `"b"`).
  Any other argument is iterated once; each element must be `str` or
  `ValueError` is raised. Iteration happens in a try/except so a
  non-iterable (e.g., an int) also yields `ValueError` ("tags must be a
  finite iterable of strings"). Dedup via `frozenset(validated_tags)`. An
  empty iterable is valid (entry stored with no tags).
- **Rationale**: Covers every R01 validation clause with one code path;
  all rejection happens before state mutation (R3).
- **Alternatives considered**: accept `str` as a single tag — rejected:
  spec explicitly says reject a bare string.

## Open items

None remaining. R5's risk note is a tracked test requirement, not an
unresolved question.
