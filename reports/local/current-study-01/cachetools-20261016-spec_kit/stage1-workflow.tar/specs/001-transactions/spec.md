# Feature Specification: Tagged Cache (TaggedCache)

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "Build cachetools.tagged.TaggedCache(maxsize), using the existing cachetools.LRUCache for bounded storage and preserving all existing cachetools APIs. (R01-R03 plus Claim-A candidate extension, variant put_no_recency_refresh, 2026-09-21)"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Store and retrieve tagged entries (Priority: P1)

A developer creates a bounded cache that associates each stored value with a
set of string tags. They insert entries, retrieve values, and rely on
isolation from the originals.

**Why this priority**: Core value of the feature; without store/retrieve the
type is useless. This is the MVP slice.

**Independent Test**: Create the cache with a small capacity, insert one
entry with tags, read it back, and confirm the returned value equals the
stored value but is a separate object (mutating the returned value or the
original does not affect the other). Also confirm a missing key raises
`KeyError`.

**Acceptance Scenarios**:

1. **Given** an empty cache, **When** `put(key, value, tags)` is called with
   a finite iterable of string tags, **Then** the entry is stored and
   `get(key)` returns a value equal to the input value.
2. **Given** a stored entry whose value is a mutable object, **When**
   `get(key)` is called, **Then** the returned object is a detached deep
copy: mutating it (and mutating the original after re-put) does not affect
   the cached or returned counterpart.
3. **Given** a cache, **When** `get(missing_key)` is called, **Then**
   `KeyError` is raised and nothing else changes.
4. **Given** a cache, **When** `put` is called with a bare string as
   `tags`, or with a tag entry that is not a string, **Then** `ValueError`
is raised and the cache state (entries, tags, recency) is unchanged.
5. **Given** duplicate tags in the iterable, **When** `put` is called,
   **Then** the entry is stored with each tag only once.

---

### User Story 2 - Invalidate by tag and evict with clean state (Priority: P2)

A developer removes all entries carrying a tag in one call and relies on
bounded eviction to never leak stale tag memberships.

**Why this priority**: Tag-based bulk removal is the distinguishing
capability over the plain bounded cache; eviction hygiene is required for
correctness under capacity pressure.

**Independent Test**: Fill a small cache, call `invalidate(tag)`, and verify
the returned count and that exactly the tagged entries are gone. Then force
eviction by overfilling, re-put the evicted key with new tags, and verify
the old tags no longer match it.

**Acceptance Scenarios**:

1. **Given** entries with and without tag `t`, **When** `invalidate(t)` is
   called, **Then** exactly the entries carrying `t` are removed and the
   return value equals the number removed.
2. **Given** an existing key stored with old tags, **When** `put` is called
   for the same key with new tags, **Then** the old tag memberships are
   removed (invalidating an old tag no longer removes the entry) and the
   value is replaced.
3. **Given** a full cache, **When** a new entry is inserted and the
   least-recently-used entry is evicted, **Then** the evicted key's tag
   memberships no longer affect later reuse of that same key.
4. **Given** a cached entry, **When** `get(key)` is called, **Then** the
   entry becomes the most-recently-used for eviction order.
5. **Given** any sequence of operations, **When** `len(cache)` is called,
   **Then** it equals the number of live entries (never counting evicted or
   invalidated entries).

---

### User Story 3 - Safe construction and replacement (Priority: P3)

A developer constructs the cache with a capacity and expects invalid input
to fail fast and atomically.

**Why this priority**: Guard rails that prevent silent corruption; important
but secondary to the primary store/retrieve/invalidate flows.

**Independent Test**: Attempt construction with invalid capacities and
attempt a replacement with invalid tags; verify errors are raised and
existing state is untouched.

**Acceptance Scenarios**:

1. **Given** capacity input that is not a positive integer (zero, negative,
   non-integer, or a boolean), **When** the cache is constructed, **Then**
   `ValueError` is raised.
2. **Given** a stored entry, **When** `put` for the same key is called with
   invalid tags, **Then** the old value, old tag memberships, and old
   recency position are all unchanged.
3. **Given** any value object, **When** it is stored, **Then** it consumes
   exactly one capacity slot regardless of its size or complexity.

---

### Edge Cases

- Bare string passed as `tags` (must be rejected, not treated as an
  iterable of characters).
- Tag iterable containing a non-string entry (rejected before any state
  change).
- Duplicate tags in one `put` call (stored once).
- Replacing a key with the same value but different tags (old memberships
  removed; recency refreshed).
- Replacing a key with invalid tags after a prior valid put (state fully
  preserved, including recency).
- Eviction of a key, then re-put of the same key (no stale tag
  memberships from the evicted incarnation).
- `get` on a key that was invalidated or evicted (raises `KeyError`).
- Capacity of 1 (every put evicts the previous entry).
- `maxsize` given as `True`/`False` (rejected: booleans are excluded).
- Mutating a returned deep copy or the original object (no cross-talk with
  the cache).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST expose a new `TaggedCache` type in
  `cachetools.tagged` (module `src/cachetools/tagged.py`) constructed with a
  single `maxsize` argument (R01/R03 scope).
- **FR-002**: `put(key, value, tags=())` MUST insert or replace an entry;
  keys MUST be hashable; values MUST be copied on input so later mutation
  of the caller's object does not change the stored value (R01).
- **FR-003**: `get(key)` MUST return a detached deep copy of the stored
  value, or raise `KeyError` for a missing key; it MUST refresh the
  entry's recency (R01/R02).
- **FR-004**: `tags` MUST be a finite iterable of strings; the system MUST
  deduplicate tags per entry; a bare string MUST be rejected as `tags` and
  any non-string tag entry MUST raise `ValueError`, in both cases before
  any existing state is changed (R01).
- **FR-005**: `invalidate(tag)` MUST remove exactly the currently cached
  entries carrying that tag and return the number removed (R02).
- **FR-006**: Replacing an existing key MUST remove its old tag
  memberships (R02).
- **FR-007**: LRU eviction MUST remove the evicted entry's tag
  memberships so later reuse of the same key is not affected by stale
  state (R02).
- **FR-008**: `get` MUST refresh LRU recency of the accessed entry (R02).
- **FR-009**: `len(cache)` MUST count only live entries (R02).
- **FR-010**: `maxsize` MUST be a positive integer; booleans MUST be
  excluded; invalid values MUST raise `ValueError` (R03).
- **FR-011**: A replacement `put` with invalid input MUST leave the old
  value, old tags, and old recency unchanged (R03).
- **FR-012**: Every stored value MUST cost exactly one capacity slot,
  regardless of object size (R03).
- **FR-013**: All existing `cachetools` public APIs MUST remain importable
  and behaviorally unchanged; this feature is additive only (milestone
  constraint; Constitution Principle I).

### Key Entities

- **Cache entry**: one key, one stored (copied) value, a deduplicated set
  of string tags, and a recency position among live entries.
- **Tag**: a string label shared by zero or more live entries; the unit
  for bulk invalidation.
- **Capacity**: the positive-integer bound on the number of live entries;
  each entry costs one slot.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of the public acceptance suite (`acceptance_public.py`)
  passes unmodified.
- **SC-002**: 100% of the functional requirements FR-001..FR-013 are
  covered by at least one passing test with observed output.
- **SC-003**: Zero regressions: all pre-existing `cachetools` public APIs
  behave identically before and after the change (verified by the existing
  upstream test suite, unmodified).
- **SC-004**: Every invalid-input case in the specification (bare string
  tags, non-string tag entries, invalid `maxsize`, invalid replacement)
  raises the specified error and leaves observable state byte-identical to
  the pre-call state.
- **SC-005**: Under repeated store/retrieve/invalidate/evict cycles on a
  small capacity, `len(cache)` always equals the true number of live
  entries and `invalidate` counts always equal the number of entries
  actually removed.

## Assumptions

- The feature is a library addition to the existing `cachetools` package;
  no CLI, service, or UI is involved.
- "Deep copy" means the returned value is fully detached from the stored
  value (nested mutable structures included), consistent with standard
  deep-copy semantics for the value's type.
- Recency order (which entry is least-recently-used) is an observable
  behavior through eviction order and replacement behavior, not exposed as
  a separate query API.
- Tag strings are compared by value; no normalization (case, whitespace)
is applied.
- `put` returns nothing significant to callers (no return-value contract
  is specified).
- Only the new module `src/cachetools/tagged.py` and new self-authored
  tests are added; upstream tests and `acceptance_public.py` are never
  modified.
- **Claim-A candidate extension (variant `put_no_recency_refresh`,
  2026-09-21)**: recorded as an explicit candidate extension to R02 —
  overwriting an existing key via `put` refreshes its LRU recency, making
  it the most-recently-used entry. It is NOT silently merged into the base
  requirements; the base spec already requires recency refresh on `get`
  (FR-008) and replacement semantics (FR-006). Whether replacement via
  `put` also refreshes recency is flagged for the clarify/plan phase to
  resolve against the variant name, which suggests the candidate argues the
  opposite (no refresh on put). This is the single open item carried
  forward.
