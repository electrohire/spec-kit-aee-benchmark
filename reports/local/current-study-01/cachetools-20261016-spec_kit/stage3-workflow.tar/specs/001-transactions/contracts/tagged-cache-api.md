# Contract: TaggedCache Public API

**Feature**: 001-transactions | **Date**: 2026-10-17

This is the complete public surface added by this feature. It is
additive: nothing in `cachetools`'s existing public API changes.

## Module

`cachetools.tagged` (file `src/cachetools/tagged.py`).

Exported name: `TaggedCache`.

## Constructor

```python
TaggedCache(maxsize: int) -> TaggedCache
```

- `maxsize` MUST be a positive `int`; `bool` is excluded.
- Violation -> `ValueError` (no object usable afterward; nothing else
  is affected).

## Methods

### `put(key, value, tags=()) -> None`

- `key`: any hashable object.
- `value`: any `copy.deepcopy`-able object. Stored as a deep copy; later
  mutation of the caller's object does not affect the cache.
- `tags`: finite iterable of `str`; deduplicated. Default `()`.
  - Bare `str` -> `ValueError`.
  - Non-iterable -> `ValueError`.
  - Non-`str` element -> `ValueError`.
  - All validation happens BEFORE any state change; on `ValueError` the
    previous value, tags, and recency of an existing key are unchanged.
- New key: inserts. Existing key: replaces value/tags; old tag
  memberships are removed; the key becomes most-recently-used (Claim-A
  extension, adopted).
- Inserting beyond capacity evicts least-recently-used entries; evicted
  entries' tag memberships are removed.

### `get(key) -> value`

- Hit: returns a **detached deep copy** of the stored value; the entry
  becomes most-recently-used.
- Miss: raises `KeyError`.
- No default argument (spec fixes the two-argument behavior; a miss is an
  error, not a fallback).

### `invalidate(tag: str) -> int`

- Removes exactly the currently cached entries carrying `tag`.
- Returns the number of entries removed (0 if none).
- Unknown/empty tag -> returns 0, no state change.

### `invalidate_many(tags, mode='any') -> int`

- `tags`: same rules as `put` tags (finite iterable of `str`, dedup,
  generators consumed once, bare string rejected).
- `mode`: `'any'` (default) removes entries carrying at least one
  requested tag; `'all'` removes entries carrying every requested tag.
- Empty requested tag collection removes zero entries in either mode.
- Returns the number of distinct removed keys.
- Invalid `mode` or invalid `tags` -> `ValueError` before any mutation.
- For a single tag, behavior is identical to `invalidate(tag)`.

### `resize(maxsize) -> None`

- Validates capacity with the constructor rule (positive `int`, `bool`
  excluded) BEFORE any change; violation -> `ValueError` with all state
  (entries, tags, recency order, current capacity) unchanged.
- Shrinking evicts least-recently-used entries until the cache fits;
  growing evicts nothing.
- Surviving entries keep their LRU order and stored state (no
  re-copying, no reordering).

### `maxsize` (property) -> int

- Reports the current capacity (after any successful `resize`).

### Dunder / mapping-adjacent behavior

- `len(cache) -> int`: number of live entries.
- `key in cache -> bool`: membership test (no recency side effect).
- `iter(cache)`: iterates live keys (no recency side effect).
- `repr(cache)`: implementation detail; no contract beyond being a
  string.

## Error contract summary

| Trigger | Exception |
|---|---|
| invalid `maxsize` (non-int, bool, <= 0) | `ValueError` |
| `tags` bare string | `ValueError` |
| `tags` non-iterable | `ValueError` |
| non-string tag element | `ValueError` |
| `get` missing key | `KeyError` |
| invalid `invalidate_many` mode or tags | `ValueError` |
| invalid `resize` capacity | `ValueError` |
| unhashable key | `TypeError` (Python standard) |

## Non-goals (explicitly out of contract)

- No `pop`, `clear`, `__setitem__`/`__delitem__` mapping protocol on
  TaggedCache itself (not required by R01-R03; keep surface minimal).
- No TTL, no persistence, no thread-safety guarantees beyond what the
  underlying dict/LRUCache already provide.
- No tag normalization; no tag query API beyond `invalidate` /
  `invalidate_many`.
- No TTL/expiry (not in the frozen requirement set; see spec.md
  Assumptions for the Claim-A round-2 clarification).
