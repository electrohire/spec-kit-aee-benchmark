# Phase 0 Research: TaggedCache

**Feature**: 001-transactions | **Date**: 2026-10-17

## R1. How to reuse LRUCache for bounded storage

- **Decision**: Compose. `TaggedCache.__init__` creates
  `self._cache = LRUCache(maxsize)` and drives it through its public
  mapping protocol (`self._cache[key] = value`, `self._cache[key]`,
  `del self._cache[key]`, `key in self._cache`, `len(self._cache)`,
  `iter(self._cache)`). No subclassing, no access to name-mangled
  internals (`_LRUCache__order`).
- **Rationale**: The milestone mandates using the existing `LRUCache`;
  composition via the public protocol is the least-coupled reuse. It
  inherits for free: one-slot-per-value sizing (`getsizeof` default 1),
  LRU eviction on overflow, recency update on set AND on get (observed
  in `LRUCache.__setitem__`/`__getitem__`, `src/cachetools/__init__.py`
  lines 210-218), and order cleanup on delete/eviction (lines 220-231).
- **Alternatives considered**:
  1. Subclass `LRUCache` and override `__setitem__`/`__delitem__` —
     rejected: couples TaggedCache to internal layout, and TaggedCache
     must NOT behave like a mapping of raw values (its `get` returns
     deep copies and raises `KeyError` via a dedicated method, not
     `__getitem__` semantics).
  2. Reimplement LRU with `OrderedDict` inside tagged.py — rejected:
     duplicates existing code (Constitution Principle IV) and risks
     divergent eviction behavior.

## R2. Tag index design

- **Decision**: Two indexes kept in lockstep with the LRU cache:
  - `self._key_tags: dict[key, frozenset[str]]` — tags of each live key.
  - `self._tag_keys: dict[str, set[key]]` — live keys per tag.
  Both are updated in the same code path as the LRU cache mutation, and
  every removal path (explicit delete, `invalidate`, LRU eviction) goes
  through one internal `_remove(key)` helper that cleans both indexes.
- **Rationale**: O(1) lookup for `key in cache`, O(k) `invalidate(tag)`
  (k = removed entries), and a single choke point guarantees no stale
  memberships survive eviction or replacement (R02).
- **Alternatives considered**:
  1. Store tags *inside* the value wrapped in the LRU cache — rejected:
     would leak tag data through any value access and break the
     deep-copy-only value contract.
  2. Single `tag -> set[key]` index only, derive key tags by scanning —
     rejected: O(tags) per replacement/eviction; two indexes keep every
     operation O(1) or O(removed).

## R3. Validation order and atomicity

- **Decision**: In `put`, validate `tags` FIRST (bare string check, then
  finite iteration with per-entry `isinstance(tag, str)` check, then
  dedup into a frozenset). Only after validation succeeds does any state
  change happen: (a) if the key exists, remove its old tag memberships
  via `_remove`-style index cleanup, (b) `self._cache[key] = deepcopy(value)`,
  (c) register new tag memberships. `maxsize` is validated in
  `__init__` before the LRU cache is created.
- **Rationale**: R01/R03 require invalid input to leave existing state
  (value, tags, recency) byte-identical. Validating before mutation is
  the only way to guarantee that without rollback logic.
- **Alternatives considered**: mutate-then-rollback on error — rejected:
  more code, and a failed `deepcopy` mid-mutation would need unwinding.

## R4. maxsize validation rule (R03)

- **Decision**: Raise `ValueError` unless
  `isinstance(maxsize, int) and not isinstance(maxsize, bool) and
  maxsize > 0`. Booleans are explicitly excluded (`True`/`False` are
  `int` subclasses in Python). Zero and negatives are rejected. Floats
  and other non-ints are rejected.
- **Rationale**: Matches "positive integer, excluding bool" exactly.
  `LRUCache`/`Cache` do not validate `maxsize` themselves (observed:
  `Cache.__init__` stores it as-is), so TaggedCache owns this check.
- **Alternatives considered**: delegate to `LRUCache` — rejected: it has
  no validation to delegate to.

## R5. Claim-A open item: put recency refresh on overwrite

- **Decision**: Adopt the Claim-A extension behavior — overwriting an
  existing key via `put` refreshes its LRU recency (key becomes
  most-recently-used). No code decision is needed to implement it: the
  chosen composition (R1) calls `self._cache[key] = value` for both
  insert and replace, and `LRUCache.__setitem__` already moves the key
  to the MRU end (observed, lines 216-218 + `__update`). The extension
  is therefore satisfied by construction and is recorded as adopted
  behavior, tested explicitly.
- **Rationale**: The candidate extension text states the behavior
  positively ("overwriting an existing key via put refreshes its LRU
  recency, making it the most-recently-used entry"). The base spec's
  R02 already requires `get` to refresh recency and requires replacement
  to update value/tags; adding put-refresh is the only reading that
  keeps one consistent LRU policy (any access or write touches
  recency). The variant name `put_no_recency_refresh` is the label of
  the candidate *family*; the extension text is the operative
  requirement and it specifies refresh. If a hidden acceptance test
  expected the opposite, it would contradict the written extension
  text; the written text wins (Constitution Principle II: explicit,
  testable criteria govern).
- **Alternatives considered**: no-refresh on put (key keeps its old
  recency position on replace) — rejected: contradicts the extension
  text and would require deliberately NOT using `LRUCache.__setitem__`
  semantics (e.g., pop + reinsert at old position), adding complexity
  for no stated benefit.
- **Risk note (Principle V)**: recorded here and in data-model.md so
  later phases test it explicitly (overwrite then overfill; the
  overwritten key must survive as MRU).

## R6. Deep-copy semantics

- **Decision**: Use stdlib `copy.deepcopy` on input (store
  `deepcopy(value)`) and on output (return `deepcopy(stored)`).
- **Rationale**: "Detached deep copy" and "values are copied on input"
  (R01) are exactly `deepcopy` semantics for arbitrary hashable-keyed
  values; stdlib, no dependencies. Values need not be hashable or
  picklable, only deepcopy-able.
- **Alternatives considered**: `copy.copy` (shallow) — rejected: nested
  mutable structures would still alias. `pickle` round-trip — rejected:
  requires picklable values; `deepcopy` is the standard-library norm.

## R7. Tag input handling details

- **Decision**: `tags` default is `()`. A `str` (or `bytes`? no —
  strings only per spec) passed directly is rejected with `ValueError`
  BEFORE iteration (prevents treating `"ab"` as tags `"a"`, `"b"`).
  Any other argument is iterated once; each element must be `str` or
  `ValueError` is raised. Iteration happens in a try/except so a
  non-iterable (e.g., an int) also yields `ValueError` ("tags must be a
  finite iterable of strings"). Dedup via `frozenset(validated_tags)`. An
  empty iterable is valid (entry stored with no tags).
- **Rationale**: Covers every R01 validation clause with one code path;
  all rejection happens before state mutation (R3).
- **Alternatives considered**: accept `str` as a single tag — rejected:
  spec explicitly says reject a bare string.

## R8. invalidate_many any/all semantics (R04)

- **Decision**: `invalidate_many(tags, mode='any')` validates `mode` in
  `{"any", "all"}` and validates `tags` with the exact same rules as
  `put` (bare string rejected, finite iterable of str, dedup via
  frozenset, generators consumed once). Matching: `any` -> keys in the
  union of `_tag_keys[t]` over requested tags; `all` -> intersection
  (keys present in every requested tag's set, computed as
  `set.intersection(*sets)` over non-empty sets). Empty requested tag
  set -> returns 0 and removes nothing in BOTH modes (explicitly
  supersedes the old design note "empty all-tags matches every key").
  Returns the number of distinct removed keys. Removal reuses the same
  `_remove(key)` choke point as `invalidate`.
- **Rationale**: Union/intersection over the existing `tag -> set[key]`
  index gives O(sum of tag set sizes) matching with O(removed) mutation;
  reusing `_remove` guarantees invariant 3 (no stale memberships).
  `invalidate(tag)` is implemented with identical semantics to
  `invalidate_many((tag,), 'any')`, keeping one code path.
- **Alternatives considered**:
  1. Scan all live keys and test tag sets per key - rejected: O(n)
     per call vs O(matched) with the index.
  2. `all` mode with empty set matches every key (old design note) -
     REJECTED per R04: empty removes zero in either mode; the old prose
     is superseded and SC-006 requires a test proving it.

## R9. resize mechanics (R05)

- **Decision**: `resize(maxsize)` validates capacity with the R4 rule
  FIRST. On success: if shrinking, evict via repeated
  `self._cache.popitem()` (public LRU method) routed through
  `_remove(key)` until `len(self._cache) <= maxsize`; then update the
  internal capacity attribute (`self._cache._LRUCache__maxsize` - the
  name-mangled backing field of the `maxsize` property, the only write
  target that avoids rebuilding). Growing: update the capacity
  attribute only; no eviction. On failure: `ValueError`, zero state
  change. The `maxsize` property on TaggedCache delegates to
  `self._cache.maxsize`, so it reports the current capacity after
  resize.
- **Rationale**: `popitem()` evicts in true LRU order (the only
  observable recency order - `__iter__` is insertion order, observed).
  Updating the backing attribute preserves every surviving entry object
  and its recency position exactly (R05 + round-2 clarification: no
  re-copying, no recomputation of any per-entry state). Rebuilding a
  new LRUCache would re-insert keys in iteration (insertion) order,
  silently corrupting recency - rejected.
- **Alternatives considered**:
  1. Rebuild `self._cache = LRUCache(new_maxsize)` and re-put
     survivors - rejected: breaks LRU order (iteration is insertion
     order) and re-copies values.
  2. Expose a `maxsize.setter` on `Cache`/`LRUCache` - rejected: would
     modify existing upstream files (Constitution Principle I).
- **Risk note (Principle V)**: writing the name-mangled attribute is
  the one coupling point to LRUCache internals; it is confined to
  `tagged.py`, guarded by a single helper, and covered by
  shrink/grow/failed-resize tests asserting full state preservation
  (order verified via subsequent eviction order).

## R10. Generator tags and detachment (R06)

- **Decision**: Tag validation iterates the supplied iterable exactly
  once (`list(iter(tags))` after the bare-string guard) - a generator is
  consumed once and never re-iterated; on any validation failure nothing
  is stored and the cache is unchanged. Detachment: `deepcopy` on input
  and output (R6 decision) already guarantees returned values stay
  detached across repeated gets and puts, including nested
  lists/dicts; the milestone-2 requirement adds no new mechanism, only
  explicit tests (mutate a returned nested list, re-get, assert
  isolation; repeat after puts).
- **Rationale**: One consumption pass is the only reading of "consumed
  only once" and the only one that is safe for one-shot generators;
  `deepcopy` is the established detachment mechanism (R6).
- **Alternatives considered**: accept an already-materialized list only -
  rejected: spec explicitly allows generators.

## Open items

None remaining. R5 and R9 carry risk notes that are tracked test
requirements (explicit tests), not unresolved questions. The Claim-A
round-2 expiry clarification (R07/R08) is recorded in spec.md
Assumptions: no expiry attribute exists in the frozen requirement set,
so resize preserves entry state as-is; revisit if a TTL milestone lands.

