# Feature Specification: Tagged Cache (TaggedCache)

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "Build cachetools.tagged.TaggedCache(maxsize), using the existing cachetools.LRUCache for bounded storage and preserving all existing cachetools APIs. Milestone 1 (R01-R03) retained; Milestone 2 adds R04-R06; Claim-A candidate extensions (put_no_recency_refresh 2026-09-21; resize expiry preservation 2026-09-22) recorded."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Store and retrieve tagged entries (Priority: P1)

A developer creates a bounded cache that associates each stored value with a
set of string tags. They insert entries, retrieve values, and rely on
isolation from the originals.

**Why this priority**: Core value of the feature; without store/retrieve the
type is useless. This is the MVP slice.

**Independent Test**: Create the cache with a small capacity, insert one
entry with tags, read it back, and confirm the returned value equals the
stored value but is a separate object (mutating the returned value or the
original does not affect the other). Also confirm a missing key raises
`KeyError`.

**Acceptance Scenarios**:

1. **Given** an empty cache, **When** `put(key, value, tags)` is called with
   a finite iterable of string tags, **Then** the entry is stored and
   `get(key)` returns a value equal to the input value.
2. **Given** a stored entry whose value is a mutable object, **When**
   `get(key)` is called, **Then** the returned object is a detached deep
copy: mutating it (and mutating the original after re-put) does not affect
   the cached or returned counterpart.
3. **Given** a cache, **When** `get(missing_key)` is called, **Then**
   `KeyError` is raised and nothing else changes.
4. **Given** a cache, **When** `put` is called with a bare string as
   `tags`, or with a tag entry that is not a string, **Then** `ValueError`
is raised and the cache state (entries, tags, recency) is unchanged.
5. **Given** duplicate tags in the iterable, **When** `put` is called,
   **Then** the entry is stored with each tag only once.

---

### User Story 2 - Invalidate by tag and evict with clean state (Priority: P2)

A developer removes all entries carrying a tag in one call and relies on
bounded eviction to never leak stale tag memberships.

**Why this priority**: Tag-based bulk removal is the distinguishing
capability over the plain bounded cache; eviction hygiene is required for
correctness under capacity pressure.

**Independent Test**: Fill a small cache, call `invalidate(tag)`, and verify
the returned count and that exactly the tagged entries are gone. Then force
eviction by overfilling, re-put the evicted key with new tags, and verify
the old tags no longer match it.

**Acceptance Scenarios**:

1. **Given** entries with and without tag `t`, **When** `invalidate(t)` is
   called, **Then** exactly the entries carrying `t` are removed and the
   return value equals the number removed.
2. **Given** an existing key stored with old tags, **When** `put` is called
   for the same key with new tags, **Then** the old tag memberships are
   removed (invalidating an old tag no longer removes the entry) and the
   value is replaced.
3. **Given** a full cache, **When** a new entry is inserted and the
   least-recently-used entry is evicted, **Then** the evicted key's tag
   memberships no longer affect later reuse of that same key.
4. **Given** a cached entry, **When** `get(key)` is called, **Then** the
   entry becomes the most-recently-used for eviction order.
5. **Given** any sequence of operations, **When** `len(cache)` is called,
   **Then** it equals the number of live entries (never counting evicted or
   invalidated entries).

---

### User Story 3 - Safe construction and replacement (Priority: P3)

A developer constructs the cache with a capacity and expects invalid input
to fail fast and atomically.

**Why this priority**: Guard rails that prevent silent corruption; important
but secondary to the primary store/retrieve/invalidate flows.

**Independent Test**: Attempt construction with invalid capacities and
attempt a replacement with invalid tags; verify errors are raised and
existing state is untouched.

**Acceptance Scenarios**:

1. **Given** capacity input that is not a positive integer (zero, negative,
   non-integer, or a boolean), **When** the cache is constructed, **Then**
   `ValueError` is raised.
2. **Given** a stored entry, **When** `put` for the same key is called with
   invalid tags, **Then** the old value, old tag memberships, and old
   recency position are all unchanged.
3. **Given** any value object, **When** it is stored, **Then** it consumes
   exactly one capacity slot regardless of its size or complexity.

---

### User Story 4 - Bulk invalidation with any/all semantics (Priority: P2)

A developer removes many entries at once by several tags, choosing whether
an entry must carry *any* of the tags or *all* of them, and gets back the
number of distinct entries removed.

**Why this priority**: Bulk tag operations are the main scaling path for
tag-based cleanup; they build directly on the P1/P2 tag machinery.

**Independent Test**: Seed entries with overlapping tag sets, call the
bulk-invalidation method in each mode, and verify exactly the expected
entries are gone and the returned count equals the number of distinct
removed keys.

**Acceptance Scenarios**:

1. **Given** entries tagged {a}, {b}, and {a,b}, **When** bulk
   invalidation is requested with tags (a, b) in mode `any`, **Then** all
   three entries are removed and the return value is 3.
2. **Given** the same entries, **When** bulk invalidation is requested
   with tags (a, b) in mode `all`, **Then** only the entry tagged {a,b}
is removed and the return value is 1.
3. **Given** any cache state, **When** bulk invalidation is requested with
   an empty tag collection (empty list, empty tuple, or exhausted
generator), **Then** zero entries are removed in either mode and the
   return value is 0 (explicitly NOT the old design-note behavior of
   matching every key in `all` mode).
4. **Given** a cache state, **When** bulk invalidation is requested with an
   invalid mode (anything other than `any` or `all`) or invalid tags (bare
   string, non-iterable, non-string element), **Then** `ValueError` is
   raised and no entry is removed.
5. **Given** a single-tag request, **When** bulk invalidation is called
   with one tag, **Then** the result is identical to the single-tag
   `invalidate(tag)` (compatibility preserved).

---

### User Story 5 - Resize capacity safely (Priority: P3)

A developer changes the cache capacity at runtime and expects surviving
entries to keep their order and state; a failed resize must change
nothing.

**Why this priority**: Runtime capacity tuning is a convenience/correctness
guard rail; it depends on the P1 entry model and P2 LRU order.

**Independent Test**: Create a cache, populate it, shrink and grow it,
verify survivors, LRU order, and that an invalid resize leaves the cache
byte-identical.

**Acceptance Scenarios**:

1. **Given** a cache with capacity 5 and 3 entries, **When** it is resized
   to 2, **Then** the two least-recently-used entries are evicted, the
   remaining entry order is preserved, and the capacity now reports 2.
2. **Given** a cache with capacity 2 and 2 entries, **When** it is resized
   to 5, **Then** no entry is evicted and the capacity now reports 5.
3. **Given** any cache state, **When** a resize is requested with an
   invalid capacity (non-integer, boolean, zero, negative), **Then**
   `ValueError` is raised and all entries, tags, recency order, and the
   previous capacity are unchanged.
4. **Given** a cache that has entries, **When** it is shrunk to a smaller
   capacity, **Then** evicted entries' tag memberships are removed exactly
   as with LRU eviction (no stale tags).
5. **Given** a surviving entry across a resize, **When** the resize
   completes, **Then** the entry's stored state is preserved as-is (no
   re-copying, no expiry recomputation — see Assumptions for the expiry
   clarification note).

---

### Edge Cases

- Bare string passed as `tags` (must be rejected, not treated as an
  iterable of characters).
- Tag iterable containing a non-string entry (rejected before any state
  change).
- Duplicate tags in one `put` call (stored once).
- Replacing a key with the same value but different tags (old memberships
  removed; recency refreshed).
- Replacing a key with invalid tags after a prior valid put (state fully
  preserved, including recency).
- Eviction of a key, then re-put of the same key (no stale tag
  memberships from the evicted incarnation).
- `get` on a key that was invalidated or evicted (raises `KeyError`).
- Capacity of 1 (every put evicts the previous entry).
- `maxsize` given as `True`/`False` (rejected: booleans are excluded).
- Mutating a returned deep copy or the original object (no cross-talk with
  the cache).

- Bulk invalidation with duplicate tags in the request (deduplicated
  before matching; count is distinct removed keys).
- Bulk invalidation `all` mode with an empty tag set (removes zero,
  never every key — supersedes the old design note).
- Bulk invalidation with a generator tag source (consumed exactly once;
  on validation failure the cache is unchanged).
- Resize to the same capacity (no-op; state unchanged).
- Resize shrinking to exactly the current entry count (no eviction).
- Resize with boolean/zero/negative/non-int capacity (rejected, state
  preserved).
- Growing then shrinking back (order and entries survive the round trip).
## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST expose a new `TaggedCache` type in
  `cachetools.tagged` (module `src/cachetools/tagged.py`) constructed with a
  single `maxsize` argument (R01/R03 scope).
- **FR-002**: `put(key, value, tags=())` MUST insert or replace an entry;
  keys MUST be hashable; values MUST be copied on input so later mutation
  of the caller's object does not change the stored value (R01).
- **FR-003**: `get(key)` MUST return a detached deep copy of the stored
  value, or raise `KeyError` for a missing key; it MUST refresh the
  entry's recency (R01/R02).
- **FR-004**: `tags` MUST be a finite iterable of strings; the system MUST
  deduplicate tags per entry; a bare string MUST be rejected as `tags` and
  any non-string tag entry MUST raise `ValueError`, in both cases before
  any existing state is changed (R01).
- **FR-005**: `invalidate(tag)` MUST remove exactly the currently cached
  entries carrying that tag and return the number removed (R02).
- **FR-006**: Replacing an existing key MUST remove its old tag
  memberships (R02).
- **FR-007**: LRU eviction MUST remove the evicted entry's tag
  memberships so later reuse of the same key is not affected by stale
  state (R02).
- **FR-008**: `get` MUST refresh LRU recency of the accessed entry (R02).
- **FR-009**: `len(cache)` MUST count only live entries (R02).
- **FR-010**: `maxsize` MUST be a positive integer; booleans MUST be
  excluded; invalid values MUST raise `ValueError` (R03).
- **FR-011**: A replacement `put` with invalid input MUST leave the old
  value, old tags, and old recency unchanged (R03).
- **FR-012**: Every stored value MUST cost exactly one capacity slot,
  regardless of object size (R03).
- **FR-013**: All existing `cachetools` public APIs MUST remain importable
- **FR-014**: `invalidate_many(tags, mode='any')` MUST remove entries
  by tag set: mode `any` removes entries carrying at least one requested
  tag (union); mode `all` removes entries carrying every requested tag;
  it MUST return the number of distinct removed keys (R04).
- **FR-015**: An empty requested tag collection MUST remove zero entries
  in either mode; an invalid `mode` or invalid `tags` MUST raise
  `ValueError` before any mutation (R04).
- **FR-016**: `invalidate(tag)` MUST remain fully compatible with
  `invalidate_many` for single-tag requests (R04).
- **FR-017**: `resize(maxsize)` MUST validate the capacity first (same
  rule as FR-010); a failed resize MUST preserve all state (entries,
  tags, recency order, current capacity); a successful shrink MUST evict
  least-recently-used entries; a successful grow MUST evict nothing;
  surviving entries MUST keep their LRU order; the `maxsize` property
  MUST report the current capacity after a successful resize (R05).
- **FR-018**: Tag iterables (including generators) MUST be consumed
  exactly once per call; on validation failure the cache MUST be
  unchanged (R06).
- **FR-019**: Returned values MUST remain detached across repeated
  `get`s and `put`s, including nested mutable structures (R06).
  and behaviorally unchanged; this feature is additive only (milestone
  constraint; Constitution Principle I).

### Key Entities

- **Cache entry**: one key, one stored (copied) value, a deduplicated set
  of string tags, and a recency position among live entries.
- **Tag**: a string label shared by zero or more live entries; the unit
  for bulk invalidation.
- **Capacity**: the positive-integer bound on the number of live entries;
  each entry costs one slot.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of the public acceptance suite (`acceptance_public.py`)
  passes unmodified.
- **SC-002**: 100% of the functional requirements FR-001..FR-019 are
  covered by at least one passing test with observed output.
- **SC-003**: Zero regressions: all pre-existing `cachetools` public APIs
  behave identically before and after the change (verified by the existing
  upstream test suite, unmodified).
- **SC-004**: Every invalid-input case in the specification (bare string
  tags, non-string tag entries, invalid `maxsize`, invalid replacement)
  raises the specified error and leaves observable state byte-identical to
  the pre-call state.
- **SC-005**: Under repeated store/retrieve/invalidate/evict cycles on a
  small capacity, `len(cache)` always equals the true number of live
  entries and `invalidate` counts always equal the number of entries
  actually removed.

- **SC-006**: Bulk invalidation and resize boundary cases (empty tag
  set in both modes, invalid mode, invalid capacity, shrink/grow order
  preservation) each have a passing test with observed output, and the
  superseded design-note behaviors (empty `all` matches every key;
  resize flushes the cache) are demonstrably NOT implemented.## Assumptions

- The feature is a library addition to the existing `cachetools` package;
  no CLI, service, or UI is involved.
- "Deep copy" means the returned value is fully detached from the stored
  value (nested mutable structures included), consistent with standard
  deep-copy semantics for the value's type.
- Recency order (which entry is least-recently-used) is an observable
  behavior through eviction order and replacement behavior, not exposed as
  a separate query API.
- Tag strings are compared by value; no normalization (case, whitespace)
is applied.
- `put` returns nothing significant to callers (no return-value contract
  is specified).
- Only the new module `src/cachetools/tagged.py` and new self-authored
  tests are added; upstream tests and `acceptance_public.py` are never
  modified.
- **Claim-A candidate extension (variant `put_no_recency_refresh`,
- **Milestone 2 supersession (R04/R05)**: an old generated design
  note claimed "empty all-tags matches every key and resizing may flush
  the cache". That prose is superseded by R04 (empty requested tags
  remove zero entries in either mode) and R05 (resize preserves
  surviving entries; a failed resize preserves all state). The spec and
  tests follow R04/R05, not the old note.
- **Claim-A candidate extension, round 2 (2026-09-22) — R05
  clarification on expiry**: the extension text references expiry as
  entry state ("R07/R08 define the expiry as entry state"), but no
  R07/R08 expiry requirement exists in the current frozen requirements
  (R01-R06 only). Resolution for this milestone: entries have NO expiry
  attribute; therefore "preserving absolute expiry across resize" is
  vacuously satisfied by preserving the entry's stored state exactly as-is (no re-copying of value identity beyond the existing deep-copy
  contract, no recomputation of any time-based state). If a future
  milestone adds R07/R08 (TTL/expiry), this assumption MUST be revisited
  and resize MUST then preserve each surviving entry's absolute expiry
  timestamp rather than dropping or recomputing it. Tracked as an open
  item for clarify/plan.
  2026-09-21)**: recorded as an explicit candidate extension to R02 —
  overwriting an existing key via `put` refreshes its LRU recency, making
  it the most-recently-used entry. It is NOT silently merged into the base
  requirements; the base spec already requires recency refresh on `get`
  (FR-008) and replacement semantics (FR-006). Whether replacement via
  `put` also refreshes recency is flagged for the clarify/plan phase to
  resolve against the variant name, which suggests the candidate argues the
  opposite (no refresh on put). This is the single open item carried
  forward.
