# Implementation Plan: Tagged Cache (TaggedCache)

**Branch**: `001-transactions` | **Spec**: [spec.md](spec.md) | **Date**: 2026-10-17

## Summary

Add a new additive public type `TaggedCache(maxsize)` in a new module
`src/cachetools/tagged.py`. It wraps the existing `cachetools.LRUCache`
for bounded LRU storage and layers tag bookkeeping on top so entries can
be invalidated by tag (single tag or many, any/all). Every stored value
is deep-copied on input and on retrieval; `get` misses raise `KeyError`;
tag input is validated strictly (finite iterable of strings, deduplicated,
generators consumed once, bare strings and non-string entries rejected
with `ValueError` before any state change); `maxsize` must be a positive
integer excluding booleans; `resize` changes capacity safely (shrink
evicts LRU, grow evicts nothing, failure preserves all state); the
`maxsize` property reports the current capacity. All existing
cachetools APIs remain untouched (no edits to existing modules).

## Technical Context

**Language/Version**: Python 3 (package `cachetools` 5.5.2; standard
library only — no new dependencies; `copy` is stdlib)
**Primary Dependencies**: existing `cachetools.LRUCache`
(`src/cachetools/__init__.py`) for bounded LRU storage; stdlib `copy`
**Storage**: in-memory only (dicts + `OrderedDict` inside LRUCache)
**Testing**: pytest (`tests/test_tagged.py`, new file, self-authored);
public gate `acceptance_public.py` (unmodified)
**Target Users**: library consumers (Python developers) — no CLI/UI
**Performance Goals**: O(1) amortized put/get/invalidate-per-removed-entry;
each value costs exactly one capacity slot regardless of object size
**Constraints**: additive only; upstream `tests/` and
`acceptance_public.py` unmodified; no changes to existing public API
behavior (Constitution Principle I)

### Observed facts from the codebase (evidence, 2026-10-17)

- `src/cachetools/__init__.py` (v5.5.2) defines `Cache` and `LRUCache`.
- `LRUCache.__setitem__` = `Cache.__setitem__` + `__update(key)`
  (`OrderedDict.move_to_end` or insert) — so any assignment, including a
  replacement of an existing key, moves the key to the
  most-recently-used end (observed, lines 216-218, 233-237).
- `LRUCache.__getitem__` calls `__update(key)` after a hit (lines 210-214)
  — recency refresh on read is built in.
- `LRUCache.__delitem__` removes the key from `__order` (lines 220-222);
  `popitem()` evicts via `self.pop(key)`, which routes through
  `__delitem__` (lines 224-231) — so eviction and explicit delete both
clean the LRU order.
- `Cache.__setitem__` computes `size = self.getsizeof(value)` (default 1)
  and evicts via `popitem()` while over capacity (lines 87-105) — values
  cost one slot by default.
- `Cache.__init__` performs **no** `maxsize` validation (lines 62-70) —
  `TaggedCache` must validate `maxsize` itself (R03).
- `src/cachetools/` currently has no `tagged.py` (observed `ls`);
  `acceptance_public.py` imports `from cachetools.tagged import
  TaggedCache` — the module and class name are fixed by the public
  contract.
- Upstream tests: `tests/test_*.py` (13 files) must remain unmodified.
- `Cache` exposes a read-only `maxsize` property (observed, lines ~148-152)
  backed by the name-mangled `self.__maxsize` set in `Cache.__init__` — a
  runtime capacity change therefore either updates that attribute or
  rebuilds the LRU cache (see research.md R7).
- `LRUCache.popitem()` is a public method returning the LRU `(key, value)`
  pair (observed, lines 224-231) — usable for shrink-eviction without
  reaching into `__order`.
- `LRUCache.__iter__` inherits `Cache.__iter__` (plain dict, insertion
  order — NOT recency order, observed lines 126-128 + 208) — recency
  order is only observable via `popitem()`/eviction, so any reordering
  logic must use `popitem()`, not iteration.

## Constitution Check

*GATE: MUST pass before Phase 0 research — re-evaluate after Phase 1.*

| # | Principle (`.specify/memory/constitution.md` v1.0.0) | Status | Notes |
|---|---|---|---|
| I | Preserve Existing Public API Behavior | PASS | New module only; zero edits to existing files in `src/cachetools/`; upstream tests untouched; `acceptance_public.py` unmodified. |
| II | Testable Acceptable Criteria | PASS | Every FR-001..FR-013 maps to a concrete scenario in spec.md and a planned test in `tests/test_tagged.py`; no vague acceptance language. |
| III | Evidence Over Assertion | PASS | This plan cites observed line-level facts from the codebase; later phases must attach command output to every completion claim. |
| IV | Simple, Scoped Implementations | PASS | Single new module `src/cachetools/tagged.py` + one new test file; reuses `LRUCache` instead of reimplementing LRU; no new dependencies; no unrelated refactors. |
| V | Documented Assumptions and Regressions | PASS | Assumptions carried in spec.md; the one open item (Claim-A variant) is resolved below in Phase 0 and tracked in `research.md`. |

**Gate result: PASS** (no violations; no justification needed).

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── spec.md                      # Feature specification (created)
├── plan.md                      # This file
├── research.md                  # Phase 0: decisions + open-item resolution
├── data-model.md                # Phase 1: entities and invariants
├── quickstart.md                # Phase 1: validation scenarios
├── contracts/                   # Phase 1: public API contract
│   └── tagged-cache-api.md
└── checklists/
    └── requirements.md          # Spec quality checklist (created)
```

### Source Code (repository root)

```text
src/cachetools/
├── __init__.py                  # UNCHANGED (LRUCache reused as-is)
├── tagged.py                    # NEW: TaggedCache implementation
└── ...                          # all other modules UNCHANGED
tests/
├── test_tagged.py               # NEW: self-authored tests for TaggedCache
└── ...                          # all upstream test files UNCHANGED
```

**Structure Type**: Python library (src layout); additive module +
test file only.

## Phase 0 — Research (see research.md)

Resolved items: (1) reuse `LRUCache` via its public mapping protocol
rather than subclassing or poking at name-mangled internals; (2) tag
index design (`key -> frozenset`, `tag -> set(keys)`); (3) validation
ordering (validate tags before touching state); (4) `maxsize` validation
rule; (5) Claim-A open item disposition (put-refresh adopted); (6)
`invalidate_many` any/all set semantics with empty-removes-zero (R04);
(7) `resize` mechanics: popitem-based shrink + capacity update, rebuild
rejected (R05); (8) generator tags consumed exactly once (R06). Details
and alternatives in [research.md](research.md).

## Phase 1 — Design (see data-model.md, contracts/, quickstart.md)

- Entities and invariants (incl. resize transitions): [data-model.md](data-model.md)
- Public API contract (incl. `invalidate_many`, `resize`, `maxsize`
  property): [contracts/tagged-cache-api.md](contracts/tagged-cache-api.md)
- Validation scenarios (incl. milestone-2 boundaries): [quickstart.md](quickstart.md)

## Complexity Tracking

Justified deviations from the constitution: none.

| Concern | Decision | Justification |
|---|---|---|
| (none) | — | Design is minimal: one wrapper class, two index dicts, stdlib `copy`. |
