# cachetools Constitution
<!-- Project: cachetools (milestone 1: cachetools.tagged.TaggedCache) -->

## Sync Impact Report
<!-- Temporary scratch for human review of this amendment; remove before commit. -->
- Version change: (none, unversioned scaffold) -> 1.0.0
- Modified principles: scaffold placeholders -> five adopted principles
  - [PRINCIPLE_1_NAME] -> I. Preserve Existing Public API Behavior
  - [PRINCIPLE_2_NAME] -> II. Testable Acceptance Criteria
  - [PRINCIPLE_3_NAME] -> III. Evidence Over Assertion
  - [PRINCIPLE_4_NAME] -> IV. Simple, Scoped Implementations
  - [PRINCIPLE_5_NAME] -> V. Documented Assumptions and Regressions
- Added sections: Development Workflow (new); Governance rules concretized
- Removed sections: none
- Follow-up TODOs: none

## Core Principles

### I. Preserve Existing Public API Behavior
All existing `cachetools` public APIs MUST remain importable, callable, and
behaviorally unchanged. New functionality MUST be additive (for example, the
new `cachetools.tagged.TaggedCache` type) and MUST NOT alter, shadow, or
remove existing names, signatures, or semantics. Upstream test files MUST
remain unmodified; any observed behavior change in existing APIs is a defect
and MUST be reported as a regression before merging.
Rationale: this is a library milestone layered on a maintained package;
downstream code relies on the current contract, so additions are safe only
while the existing surface is byte-for-byte stable.

### II. Testable Acceptance Criteria
Every requirement MUST state at least one concrete, observable, testable
acceptance criterion (input, action, expected output or exception). Vague
language ("should", "fast", "clean") MUST NOT define acceptance. Each
requirement MUST be verifiable by a test or a recorded command whose output
can be inspected, and the public acceptance suite `acceptance_public.py`
MUST pass unmodified. Candidate extensions (for example, the Claim-A
`put_no_recency_refresh` variant) MUST be recorded explicitly as extensions
and MUST NOT silently alter the base requirement text.
Rationale: autonomous phases cannot ask for clarification; only
machine-checkable criteria keep later phases convergent.

### III. Evidence Over Assertion
Claims of completion MUST cite observed evidence: a test command with its
exit status and output, or an inspected artifact. Unverified expectations
MUST be labeled as assumptions, not facts. Hidden or unavailable acceptance
evidence MUST NOT be claimed as executed. Distinguish in every handoff
between (a) observed, (b) inferred, and (c) unverified.
Rationale: fabricated or assumed test results poison later phases; evidence
is the only transferable state between phases.

### IV. Simple, Scoped Implementations
Prefer the smallest implementation that satisfies the stated requirements
within the declared scope (for milestone 1: `src/cachetools/tagged.py` and
its own tests). Reuse existing components (for example, `cachetools.LRUCache`
for bounded storage) instead of reimplementing them. No new dependencies,
no speculative features, no refactoring of unrelated code. Any added
complexity MUST be justified in writing against a stated requirement.
Rationale: scope creep and gratuitous complexity are the main failure modes
of autonomous implementation; reuse also reduces regression risk on the
preserved public API.

### V. Documented Assumptions and Regressions
Unresolved assumptions, open questions, and known regressions MUST be
written down where the next phase will see them (`HANDOFF.md` and the
feature docs under `specs/`). Each item MUST state what is assumed, what
evidence would confirm or refute it, and what decision it blocks. A
regression MUST be recorded the moment it is observed, with the command
that reproduces it.
Rationale: conversation history does not survive across phases; written
assumptions and regressions are the only durable record.

## Development Workflow
- Feature documents live in `specs/001-transactions/` (feature directory
  `specs/001-transactions`); keep them concise and keep every claim
  evidence-explicit.
- Phase order is fixed: constitution -> specify -> plan -> tasks ->
  implement. The constitution phase MUST NOT create or modify application
  source, tests, or deployment artifacts; it writes only this file.
- Implementation is deferred to later phases and MUST target
  `src/cachetools/tagged.py`; its own tests MAY be added, but upstream tests
  and `acceptance_public.py` MUST remain unchanged.
- Each phase MUST end with a completion report that references the artifacts
  it produced and the commands it ran.

## Governance
- This constitution supersedes all other project practices and prior design
  notes; where older notes conflict with it, the constitution wins.
- Amendments: edit `.specify/memory/constitution.md`, update the Sync Impact
  Report, bump the version, and record the rationale in the completion
  report. No other files are amended by a constitution change.
- Versioning: MAJOR.MINOR.PATCH. MAJOR for removed or redefined
  principles; MINOR for added principles or materially expanded guidance;
  PATCH for wording, typos, and non-semantic clarifications.
- Compliance review: before a phase is marked done, verify that its
  artifacts satisfy the principles above and that all claims carry observed
  evidence; violations MUST be fixed or recorded as documented exceptions
  with a follow-up item.
- Ratification: 2026-10-17, by the approved principle inputs supplied for
  this autonomous benchmark (milestone 1, cachetools).

**Version**: 1.0.0 | **Ratified**: 2026-10-17 | **Last Amended**: 2026-10-17
