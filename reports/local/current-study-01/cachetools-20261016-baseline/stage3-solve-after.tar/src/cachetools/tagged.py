"""Tagged cache implementation built on top of :class:`LRUCache`."""

import copy
import math
import time

from . import LRUCache

__all__ = ("TaggedCache",)

_marker = object()


def _normalize_tags(tags):
    """Validate and deduplicate *tags*, returning a tuple of strings.

    A bare string is rejected, as are non-string entries.  The iterable
    must be finite; any iteration error propagates to the caller.  The
    iterable is consumed exactly once.

    """
    if isinstance(tags, str):
        raise ValueError("tags must be an iterable of strings, not a str")
    try:
        iterator = iter(tags)
    except TypeError as exc:
        raise ValueError(
            "tags must be an iterable of strings, got %r" % (tags,)
        ) from exc
    seen = set()
    result = []
    for tag in iterator:
        if not isinstance(tag, str):
            raise ValueError("tags must be an iterable of strings, got %r" % (tag,))
        if tag not in seen:
            seen.add(tag)
            result.append(tag)
    return tuple(result)


def _validate_maxsize(maxsize):
    """Return *maxsize* if it is a positive integer (bool excluded),
    otherwise raise ``ValueError``.

    """
    if isinstance(maxsize, bool) or not isinstance(maxsize, int):
        raise ValueError("maxsize must be a positive integer, got %r" % (maxsize,))
    if maxsize < 1:
        raise ValueError("maxsize must be a positive integer, got %r" % (maxsize,))
    return maxsize


def _validate_ttl(ttl):
    """Return *ttl* if it is a finite nonnegative int/float (bool
    excluded), otherwise raise ``ValueError``.

    ``None`` is returned unchanged and means "no expiration".

    """
    if ttl is None:
        return None
    if isinstance(ttl, bool) or not isinstance(ttl, (int, float)):
        raise ValueError("ttl must be None or a finite nonnegative number, got %r" % (ttl,))
    if not math.isfinite(ttl) or ttl < 0:
        raise ValueError("ttl must be None or a finite nonnegative number, got %r" % (ttl,))
    return ttl


class _TaggedLRUCache(LRUCache):
    """LRUCache that reports evicted keys to its owner."""

    def __init__(self, maxsize, on_evict):
        LRUCache.__init__(self, maxsize)
        self._on_evict = on_evict

    def popitem(self):
        key, value = LRUCache.popitem(self)
        self._on_evict(key)
        return key, value


class TaggedCache:
    """A tag-aware bounded cache backed by :class:`LRUCache`.

    Values are stored as detached deep copies and are copied on input.
    Each entry costs exactly one capacity slot regardless of object
    size.  Keys must be hashable; tags must be strings.

    Entries may carry an absolute expiry timestamp (set with the
    ``ttl`` argument of :meth:`put`).  The constructor accepts a
    ``timer`` callable (defaulting to :func:`time.monotonic`) used to
    compute expiry times.  Expired entries are removed lazily before
    ``get``, ``put``, ``len``/``__contains__``, ``resize``, and tag
    invalidation, without touching the recency of surviving entries.

    """

    def __init__(self, maxsize, timer=None):
        self.__maxsize = _validate_maxsize(maxsize)
        self.__timer = time.monotonic if timer is None else timer
        # key -> tuple of tags, kept in sync with self.__data
        self.__tags = {}
        # key -> absolute expiry timestamp (float) or None (no expiry)
        self.__expires = {}
        # tag -> list of keys, kept in sync with self.__data
        self.__memberships = {}
        self.__data = _TaggedLRUCache(self.__maxsize, self.__evicted)

    @property
    def maxsize(self):
        """The maximum size of the cache."""
        return self.__maxsize

    @property
    def timer(self):
        """The timer function used by the cache."""
        return self.__timer

    @property
    def currsize(self):
        """The current number of entries in the cache."""
        self.__expire_all(self.__timer())
        return len(self.__data)

    def __len__(self):
        self.__expire_all(self.__timer())
        return len(self.__data)

    def __contains__(self, key):
        try:
            self.__data[key]  # refreshes recency, like LRUCache
        except KeyError:
            return False
        expires = self.__expires.get(key)
        return expires is None or self.__timer() < expires

    def put(self, key, value, tags=(), ttl=None):
        """Insert or replace *key* with a deep copy of *value*.

        *tags* must be a finite iterable of strings (generators are
        accepted and consumed exactly once); duplicate tags are removed
        while preserving first-seen order.  Overwriting an existing key
        replaces its tag memberships and refreshes its LRU recency,
        making it the most-recently-used entry.

        *ttl* is either ``None`` (no expiration) or a finite
        nonnegative int/float (bool excluded); a positive TTL expires
        the entry at ``timer() + ttl`` and a zero TTL is immediately
        expired.  Invalid input (bad tags, an unhashable key, or an
        invalid TTL) raises before any existing state is changed.

        """
        tag_tuple = _normalize_tags(tags)
        ttl = _validate_ttl(ttl)
        # touching the key validates hashability before any mutation
        existing = key in self.__data
        new_value = copy.deepcopy(value)
        now = self.__timer()
        self.__expire_all(now)
        if ttl is None:
            expiry = None
        else:
            expiry = now + ttl
        if existing:
            # drop old tag memberships before the LRU update so an
            # eviction can never resurrect stale ones
            self.__remove_memberships(key)
            self.__data[key] = new_value
            self.__tags[key] = tag_tuple
            self.__expires[key] = expiry
        else:
            self.__data[key] = new_value
            self.__tags[key] = tag_tuple
            self.__expires[key] = expiry
        for tag in tag_tuple:
            self.__add_membership(tag, key)
        if expiry is not None and now >= expiry:
            # TTL zero (or already-past expiry) is immediately expired
            self.__remove_entry(key)

    def get(self, key):
        """Return a detached deep copy of the value stored under *key*.

        Refreshes the LRU recency of *key*.  Raises ``KeyError`` for
        missing or expired keys.

        """
        now = self.__timer()
        try:
            self.__data[key]  # refreshes recency via LRUCache.__getitem__
        except KeyError:
            raise KeyError(key) from None
        expires = self.__expires.get(key)
        if expires is not None and now >= expires:
            self.__remove_entry(key)
            raise KeyError(key) from None
        value = self.__data[key]
        return copy.deepcopy(value)

    def invalidate(self, tag):
        """Remove all currently cached entries carrying *tag*.

        Returns the number of live entries removed.  Expired entries
        are dropped first and are not counted.

        """
        if not isinstance(tag, str):
            raise ValueError("tag must be a string, got %r" % (tag,))
        now = self.__timer()
        self.__expire_all(now)
        keys = list(self.__memberships.get(tag, ()))
        for key in keys:
            self.__remove_entry(key)
        return len(keys)

    def invalidate_many(self, tags, mode='any'):
        """Remove entries according to *mode* and return the number of
        distinct keys removed.

        With ``mode='any'`` (the default), entries carrying any of the
        supplied tags are removed (the union).  With ``mode='all'``,
        only entries carrying every supplied tag are removed.  An empty
        tag iterable removes zero entries in either mode.  Invalid
        *mode* or invalid *tags* raise ``ValueError`` before any
        mutation.  *tags* may be a generator and is consumed exactly
        once.

        """
        if mode not in ('any', 'all'):
            raise ValueError("mode must be 'any' or 'all', got %r" % (mode,))
        tag_tuple = _normalize_tags(tags)
        if not tag_tuple:
            return 0
        now = self.__timer()
        self.__expire_all(now)
        if mode == 'any':
            removed = set()
            for tag in tag_tuple:
                removed.update(self.__memberships.get(tag, ()))
        else:
            wanted = set(tag_tuple)
            removed = set()
            for key, entry_tags in self.__tags.items():
                if wanted <= set(entry_tags):
                    removed.add(key)
        for key in removed:
            self.__remove_entry(key)
        return len(removed)

    def resize(self, maxsize):
        """Change the capacity of the cache to *maxsize*.

        *maxsize* must be a positive integer (bool excluded); an invalid
        value raises ``ValueError`` and leaves the cache completely
        unchanged.  Expired entries are dropped first (without touching
        the recency of surviving entries).  Shrinking evicts
        least-recently-used entries; growing evicts nothing.  Surviving
        entries keep their values, tag memberships, LRU order, and
        absolute expiry times.

        """
        new_maxsize = _validate_maxsize(maxsize)
        now = self.__timer()
        self.__expire_all(now)
        if new_maxsize < self.__maxsize:
            while len(self.__data) > new_maxsize:
                self.__data.popitem()  # evicts LRU, cleans tag state
        self.__maxsize = new_maxsize
        self.__data._Cache__maxsize = new_maxsize

    def __getitem__(self, key):
        return self.get(key)

    def __delitem__(self, key):
        if key not in self:
            raise KeyError(key)
        self.__remove_entry(key)

    def pop(self, key, default=_marker):
        if key in self:
            value = self.get(key)
            self.__remove_entry(key)
            return value
        if default is _marker:
            raise KeyError(key)
        return default

    def clear(self):
        """Remove all entries from the cache."""
        self.__data.clear()
        self.__tags.clear()
        self.__expires.clear()
        self.__memberships.clear()

    def __repr__(self):
        return "TaggedCache(maxsize=%r, currsize=%r)" % (self.__maxsize, len(self))

    # -- internal helpers -------------------------------------------------

    def __evicted(self, key):
        self.__remove_entry(key)

    def __remove_entry(self, key):
        """Remove *key* from all internal state (no timer call)."""
        self.__remove_memberships(key)
        self.__tags.pop(key, None)
        self.__expires.pop(key, None)
        if key in self.__data:
            del self.__data[key]

    def __expire_all(self, now):
        """Drop every expired entry without touching surviving recency."""
        for key in list(self.__expires):
            expires = self.__expires[key]
            if expires is not None and now >= expires:
                self.__remove_entry(key)

    def __add_membership(self, tag, key):
        self.__memberships.setdefault(tag, []).append(key)

    def __remove_memberships(self, key):
        for tag in self.__tags.get(key, ()):
            members = self.__memberships.get(tag)
            if members:
                try:
                    members.remove(key)
                except ValueError:
                    pass
                if not members:
                    del self.__memberships[tag]
