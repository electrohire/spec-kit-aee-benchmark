"""Tagged cache implementation built on top of :class:`LRUCache`."""

import copy

from . import LRUCache

__all__ = ("TaggedCache",)

_marker = object()


def _normalize_tags(tags):
    """Validate and deduplicate *tags*, returning a tuple of strings.

    A bare string is rejected, as are non-string entries.  The iterable
    must be finite; any iteration error propagates to the caller.

    """
    if isinstance(tags, str):
        raise ValueError("tags must be an iterable of strings, not a str")
    try:
        iterator = iter(tags)
    except TypeError as exc:
        raise ValueError(
            "tags must be an iterable of strings, got %r" % (tags,)
        ) from exc
    seen = set()
    result = []
    for tag in iterator:
        if not isinstance(tag, str):
            raise ValueError("tags must be an iterable of strings, got %r" % (tag,))
        if tag not in seen:
            seen.add(tag)
            result.append(tag)
    return tuple(result)


class _TaggedLRUCache(LRUCache):
    """LRUCache that reports evicted keys to its owner."""

    def __init__(self, maxsize, on_evict):
        LRUCache.__init__(self, maxsize)
        self._on_evict = on_evict

    def popitem(self):
        key, value = LRUCache.popitem(self)
        self._on_evict(key)
        return key, value


class TaggedCache:
    """A tag-aware bounded cache backed by :class:`LRUCache`.

    Values are stored as detached deep copies and are copied on input.
    Each entry costs exactly one capacity slot regardless of object
    size.  Keys must be hashable; tags must be strings.

    """

    def __init__(self, maxsize):
        if isinstance(maxsize, bool) or not isinstance(maxsize, int):
            raise ValueError("maxsize must be a positive integer, got %r" % (maxsize,))
        if maxsize < 1:
            raise ValueError("maxsize must be a positive integer, got %r" % (maxsize,))
        self.__maxsize = maxsize
        # key -> tuple of tags, kept in sync with self.__data
        self.__tags = {}
        # tag -> list of keys, kept in sync with self.__data
        self.__memberships = {}
        self.__data = _TaggedLRUCache(maxsize, self.__evicted)

    @property
    def maxsize(self):
        """The maximum size of the cache."""
        return self.__maxsize

    @property
    def currsize(self):
        """The current number of entries in the cache."""
        return len(self.__data)

    def __len__(self):
        return len(self.__data)

    def __contains__(self, key):
        return key in self.__data

    def put(self, key, value, tags=()):
        """Insert or replace *key* with a deep copy of *value*.

        *tags* must be a finite iterable of strings; duplicate tags are
        removed while preserving first-seen order.  Overwriting an
        existing key replaces its tag memberships and refreshes its LRU
        recency, making it the most-recently-used entry.  Invalid input
        (bad tags or an unhashable key) raises before any existing state
        is changed.

        """
        tag_tuple = _normalize_tags(tags)
        # touching the key validates hashability before any mutation
        existing = key in self.__data
        new_value = copy.deepcopy(value)
        if existing:
            # drop old tag memberships before the LRU update so an
            # eviction can never resurrect stale ones
            self.__remove_memberships(key)
            self.__data[key] = new_value
            self.__tags[key] = tag_tuple
        else:
            self.__data[key] = new_value
            self.__tags[key] = tag_tuple
        for tag in tag_tuple:
            self.__add_membership(tag, key)

    def get(self, key):
        """Return a detached deep copy of the value stored under *key*.

        Refreshes the LRU recency of *key*.  Raises ``KeyError`` for
        missing keys.

        """
        if key not in self.__data:
            raise KeyError(key)
        value = self.__data[key]  # refreshes recency via LRUCache.__getitem__
        return copy.deepcopy(value)

    def invalidate(self, tag):
        """Remove all currently cached entries carrying *tag*.

        Returns the number of entries removed.

        """
        if not isinstance(tag, str):
            raise ValueError("tag must be a string, got %r" % (tag,))
        keys = list(self.__memberships.get(tag, ()))
        for key in keys:
            del self[key]
        return len(keys)

    def __getitem__(self, key):
        return self.get(key)

    def __delitem__(self, key):
        if key not in self.__data:
            raise KeyError(key)
        self.__remove_memberships(key)
        del self.__data[key]
        del self.__tags[key]

    def pop(self, key, default=_marker):
        if key in self:
            value = self.get(key)
            del self[key]
            return value
        if default is _marker:
            raise KeyError(key)
        return default

    def clear(self):
        """Remove all entries from the cache."""
        self.__data.clear()
        self.__tags.clear()
        self.__memberships.clear()

    def __repr__(self):
        return "TaggedCache(maxsize=%r, currsize=%r)" % (self.__maxsize, len(self))

    # -- internal helpers -------------------------------------------------

    def __evicted(self, key):
        self.__remove_memberships(key)
        self.__tags.pop(key, None)

    def __add_membership(self, tag, key):
        self.__memberships.setdefault(tag, []).append(key)

    def __remove_memberships(self, key):
        for tag in self.__tags.get(key, ()):
            members = self.__memberships.get(tag)
            if members:
                try:
                    members.remove(key)
                except ValueError:
                    pass
                if not members:
                    del self.__memberships[tag]
