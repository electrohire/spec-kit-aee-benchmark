"""Tagged cache built on top of :class:`~cachetools.LRUCache`.

Provides :class:`TaggedCache`, a bounded LRU cache whose entries carry a
finite set of string tags.  Entries can be looked up by key (returning a
detached deep copy) or removed in bulk by tag via :meth:`TaggedCache.invalidate`.
"""

import collections
import copy

from . import LRUCache

_SENTINEL = object()


def _normalize_tags(tags):
    """Validate *tags* and return a tuple of the unique string tags.

    Raises ``ValueError`` if *tags* is a bare string or contains a non-string
    entry.  The iterable is fully consumed (and must be finite) before any
    mutation of the cache is allowed to happen.
    """
    if isinstance(tags, (str, bytes)):
        raise ValueError("tags must be an iterable of strings, not %r" % type(tags).__name__)
    try:
        iterator = iter(tags)
    except TypeError:
        raise ValueError("tags must be an iterable of strings, got %r" % type(tags).__name__)
    seen = set()
    result = []
    for tag in iterator:
        if not isinstance(tag, str):
            raise ValueError("tags must be an iterable of strings, got %r" % (tag,))
        if tag not in seen:
            seen.add(tag)
            result.append(tag)
    return tuple(result)


class _TaggedLRUCache(LRUCache):
    """LRUCache that records evicted keys so tag memberships can be pruned."""

    def __init__(self, maxsize):
        LRUCache.__init__(self, maxsize)
        self._evicted = []

    def popitem(self):
        key, value = LRUCache.popitem(self)
        self._evicted.append(key)
        return (key, value)


class TaggedCache:
    """A bounded LRU cache with per-entry string tags.

    Values are deep-copied on input and on retrieval, so callers can never
    observe or mutate the stored state through a returned reference.  Each
    value costs exactly one capacity slot regardless of its size.

    """

    def __init__(self, maxsize):
        if isinstance(maxsize, bool) or not isinstance(maxsize, int) or maxsize < 1:
            raise ValueError("maxsize must be a positive integer, got %r" % (maxsize,))
        self.__maxsize = maxsize
        self.__cache = _TaggedLRUCache(maxsize)
        # tag -> set of keys currently carrying that tag
        self.__tags = collections.defaultdict(set)
        # key -> set of tags currently held by that key
        self.__key_tags = {}

    @property
    def maxsize(self):
        """The maximum number of entries the cache can hold."""
        return self.__maxsize

    def __len__(self):
        """Number of live entries currently cached."""
        return len(self.__cache)

    def __contains__(self, key):
        return key in self.__cache

    def put(self, key, value, tags=()):
        """Insert or replace *key* with a deep copy of *value*.

        *tags* must be a finite iterable of strings; a bare string is
        rejected.  Duplicates are ignored.  If the key already exists, its
        old tag memberships are replaced and its LRU recency is refreshed.

        """
        # Validate and normalize tags before touching any state, so that an
        # invalid replacement leaves the old value/tags/recency unchanged.
        new_tags = _normalize_tags(tags)
        cache = self.__cache
        evicted = cache._evicted
        if key in cache:
            # drop old tag memberships before storing the new value
            for tag in self.__key_tags.pop(key, ()):
                self.__tags[tag].discard(key)
            self.__prune_empty()
            cache[key] = copy.deepcopy(value)
        else:
            if len(cache) == cache.maxsize:
                # insertion will evict exactly the least-recently-used key
                evicted.clear()
                cache[key] = copy.deepcopy(value)
                for old_key in evicted:
                    self.__forget(old_key)
            else:
                cache[key] = copy.deepcopy(value)
        self.__key_tags[key] = set(new_tags)
        for tag in new_tags:
            self.__tags[tag].add(key)

    def __forget(self, key):
        """Drop all tag memberships of an evicted or removed *key*."""
        for tag in self.__key_tags.pop(key, ()):
            self.__tags[tag].discard(key)
        self.__prune_empty()

    def __prune_empty(self):
        for tag in list(self.__tags):
            if not self.__tags[tag]:
                del self.__tags[tag]

    def get(self, key, default=_SENTINEL):
        """Return a detached deep copy of the value stored under *key*.

        Raises ``KeyError`` if *key* is not cached.  A successful lookup
        refreshes the entry's LRU recency.

        """
        if key not in self.__cache:
            if default is _SENTINEL:
                raise KeyError(key)
            return default
        value = self.__cache[key]  # refreshes LRU recency
        return copy.deepcopy(value)

    def invalidate(self, tag):
        """Remove every currently cached entry carrying *tag*.

        Returns the number of entries removed.  Unknown tags remove nothing
        and return ``0``.

        """
        keys = set(self.__tags.get(tag, ()))
        if not keys:
            return 0
        for key in keys:
            del self.__cache[key]
            self.__forget(key)
        return len(keys)

    def pop(self, key, default=_SENTINEL):
        """Remove *key* and return a deep copy of its value."""
        if key not in self.__cache:
            if default is _SENTINEL:
                raise KeyError(key)
            return default
        value = self.__cache[key]
        del self.__cache[key]
        self.__forget(key)
        return value

    def clear(self):
        """Remove all entries and tag memberships."""
        self.__cache.clear()
        self.__tags.clear()
        self.__key_tags.clear()

    def __repr__(self):
        return "%s(maxsize=%r, currsize=%r)" % (
            type(self).__name__,
            self.__maxsize,
            len(self.__cache),
        )
