"""Tagged cache built on top of :class:`~cachetools.LRUCache`.

Provides :class:`TaggedCache`, a bounded LRU cache whose entries carry a
finite set of string tags and an optional absolute expiry.  Entries can be
looked up by key (returning a detached deep copy) or removed in bulk by tag
via :meth:`TaggedCache.invalidate` / :meth:`TaggedCache.invalidate_many`.
"""

import collections
import copy
import math
import time

from . import LRUCache

_SENTINEL = object()


def _normalize_tags(tags):
    """Validate *tags* and return a tuple of the unique string tags.

    Raises ``ValueError`` if *tags* is a bare string or contains a non-string
    entry.  The iterable is fully consumed (and must be finite) before any
    mutation of the cache is allowed to happen.

    """
    if isinstance(tags, (str, bytes)):
        raise ValueError(
            "tags must be an iterable of strings, not %r" % type(tags).__name__
        )
    try:
        iterator = iter(tags)
    except TypeError:
        raise ValueError(
            "tags must be an iterable of strings, got %r" % type(tags).__name__
        )
    seen = set()
    result = []
    for tag in iterator:
        if not isinstance(tag, str):
            raise ValueError(
                "tags must be an iterable of strings, got %r" % (tag,)
            )
        if tag not in seen:
            seen.add(tag)
            result.append(tag)
    return tuple(result)


def _validate_ttl(ttl):
    """Validate *ttl* and return it unchanged.

    ``None`` means no expiration.  Any other value must be a finite
    nonnegative int or float (bool excluded); otherwise ``ValueError`` is
    raised before any cache state is touched.

    """
    if ttl is None:
        return None
    if isinstance(ttl, bool) or not isinstance(ttl, (int, float)):
        raise ValueError("ttl must be None or a finite nonnegative number, got %r" % (ttl,))
    if not math.isfinite(ttl) or ttl < 0:
        raise ValueError("ttl must be None or a finite nonnegative number, got %r" % (ttl,))
    return ttl


def _validate_maxsize(maxsize):
    """Validate *maxsize* and return it unchanged.

    Must be a positive integer (bool excluded); otherwise ``ValueError``.

    """
    if isinstance(maxsize, bool) or not isinstance(maxsize, int) or maxsize < 1:
        raise ValueError("maxsize must be a positive integer, got %r" % (maxsize,))
    return maxsize


class _TaggedLRUCache(LRUCache):
    """LRUCache that records evicted keys so tag memberships can be pruned."""

    def __init__(self, maxsize):
        LRUCache.__init__(self, maxsize)
        self._evicted = []

    def popitem(self):
        key, value = LRUCache.popitem(self)
        self._evicted.append(key)
        return (key, value)

    def _resize(self, maxsize):
        """Change capacity, evicting least-recently-used entries if shrinking.

        Growing never evicts.  Surviving entries keep their values, tags,
        LRU order and absolute expiries.  Evicted keys are appended to
        ``self._evicted``.

        """
        if maxsize == self.maxsize:
            return
        self._evicted.clear()
        self._Cache__maxsize = maxsize
        while len(self) > maxsize:
            key, value = LRUCache.popitem(self)
            self._evicted.append(key)


class TaggedCache:
    """A bounded LRU cache with per-entry string tags and optional TTLs.

    Values are deep-copied on input and on retrieval, so callers can never
    observe or mutate the stored state through a returned reference.  Each
    value costs exactly one capacity slot regardless of its size.

    :param maxsize: maximum number of entries; a positive integer (bool
        excluded).
    :param timer: callable returning the current time; defaults to
        ``time.monotonic``.  Only consulted when TTLs are in use.

    """

    def __init__(self, maxsize, timer=None):
        _validate_maxsize(maxsize)
        self.__maxsize = maxsize
        self.__cache = _TaggedLRUCache(maxsize)
        self.__timer = time.monotonic if timer is None else timer
        # key -> absolute expiry (timer()+ttl) or None for immortal entries
        self.__expiry = {}
        # tag -> set of keys currently carrying that tag
        self.__tags = collections.defaultdict(set)
        # key -> set of tags currently held by that key
        self.__key_tags = {}

    @property
    def maxsize(self):
        """The maximum number of entries the cache can hold."""
        return self.__maxsize

    def __len__(self):
        """Number of live entries currently cached."""
        self.__purge_expired()
        return len(self.__cache)

    def __contains__(self, key):
        return key in self.__cache

    def put(self, key, value, tags=(), ttl=None):
        """Insert or replace *key* with a deep copy of *value*.

        *tags* must be a finite iterable of strings; a bare string is
        rejected.  Duplicates are ignored.  If the key already exists, its
        old tag memberships are replaced, its prior expiry is replaced by
        the new one and its LRU recency is refreshed.

        *ttl* is ``None`` (no expiration) or a finite nonnegative int/float
        (bool excluded); the entry then expires at ``timer() + ttl``.  A
        zero TTL is expired immediately.  Invalid input raises ``ValueError
        `` before any state is changed.

        """
        # Validate everything before touching any state, so that an invalid
        # replacement leaves the old value/tags/recency/expiry unchanged.
        new_tags = _normalize_tags(tags)
        _validate_ttl(ttl)
        self.__purge_expired()
        cache = self.__cache
        evicted = cache._evicted
        if ttl is None:
            expiry = None
        else:
            expiry = self.__timer() + ttl
        if key in cache:
            # drop old tag memberships before storing the new value
            for tag in self.__key_tags.pop(key, ()):
                self.__tags[tag].discard(key)
            self.__prune_empty()
            cache[key] = copy.deepcopy(value)
            self.__expiry[key] = expiry
        else:
            if len(cache) == cache.maxsize:
                # insertion will evict exactly the least-recently-used key
                evicted.clear()
                cache[key] = copy.deepcopy(value)
                for old_key in evicted:
                    self.__forget(old_key)
            else:
                cache[key] = copy.deepcopy(value)
            self.__expiry[key] = expiry
        self.__key_tags[key] = set(new_tags)
        for tag in new_tags:
            self.__tags[tag].add(key)

    def __forget(self, key):
        """Drop all tag memberships and the expiry of a removed *key*."""
        for tag in self.__key_tags.pop(key, ()):
            self.__tags[tag].discard(key)
        self.__expiry.pop(key, None)
        self.__prune_empty()

    def __prune_empty(self):
        for tag in list(self.__tags):
            if not self.__tags[tag]:
                del self.__tags[tag]

    def __purge_expired(self):
        """Remove all expired entries.

        Expired entries are discarded without touching the LRU recency of
        the surviving entries.

        """
        cache = self.__cache
        expiry = self.__expiry
        if not expiry:
            return
        try:
            now = self.__timer()
        except Exception:
            # a failing timer cannot make entries expire
            return
        for key in list(expiry):
            if expiry[key] is not None and now >= expiry[key]:
                if key in cache:
                    del cache[key]
                self.__forget(key)

    def get(self, key, default=_SENTINEL):
        """Return a detached deep copy of the value stored under *key*.

        Raises ``KeyError`` if *key* is not cached or is expired.  A
        successful lookup refreshes the entry's LRU recency.

        """
        self.__purge_expired()
        if key not in self.__cache:
            if default is _SENTINEL:
                raise KeyError(key)
            return default
        value = self.__cache[key]  # refreshes LRU recency
        return copy.deepcopy(value)

    def invalidate(self, tag):
        """Remove every currently cached live entry carrying *tag*.

        Returns the number of entries removed.  Unknown tags remove nothing
        and return ``0``.

        """
        self.__purge_expired()
        keys = set(self.__tags.get(tag, ()))
        if not keys:
            return 0
        for key in keys:
            del self.__cache[key]
            self.__forget(key)
        return len(keys)

    def invalidate_many(self, tags, mode="any"):
        """Remove entries in bulk by tag.

        ``mode='any'`` removes the union of entries carrying any of the
        requested tags; ``mode='all'`` removes entries carrying every
        requested tag.  An empty requested tag set removes zero entries for
        either mode.  Returns the number of distinct removed keys.  An
        invalid *mode* or *tags* raises ``ValueError`` before any mutation.

        """
        if mode not in ("any", "all"):
            raise ValueError("mode must be 'any' or 'all', got %r" % (mode,))
        # validate and normalize before touching any state
        requested = _normalize_tags(tags)
        if not requested:
            return 0
        self.__purge_expired()
        if mode == "any":
            keys = set()
            for tag in requested:
                keys.update(self.__tags.get(tag, ()))
        else:
            keys = set(self.__tags.get(requested[0], ()))
            for tag in requested[1:]:
                keys.intersection_update(self.__tags.get(tag, ()))
        if not keys:
            return 0
        for key in keys:
            del self.__cache[key]
            self.__forget(key)
        return len(keys)

    def resize(self, maxsize):
        """Change the cache capacity.

        *maxsize* must be a positive integer (bool excluded), otherwise a
        ``ValueError`` is raised and all state is left unchanged.  Expired
        entries are removed first.  Shrinking evicts the
        least-recently-used entries first; growing never evicts.
        Surviving entries keep their values, tags, LRU order and absolute
        expiries.

        """
        _validate_maxsize(maxsize)
        self.__purge_expired()
        if maxsize == self.__maxsize:
            return
        evicted = self.__cache._evicted
        self.__cache._resize(maxsize)
        for old_key in evicted:
            self.__forget(old_key)
        self.__maxsize = maxsize

    def pop(self, key, default=_SENTINEL):
        """Remove *key* and return a deep copy of its value."""
        self.__purge_expired()
        if key not in self.__cache:
            if default is _SENTINEL:
                raise KeyError(key)
            return default
        value = self.__cache[key]
        del self.__cache[key]
        self.__forget(key)
        return value

    def clear(self):
        """Remove all entries and tag memberships."""
        self.__cache.clear()
        self.__tags.clear()
        self.__key_tags.clear()
        self.__expiry.clear()

    def __repr__(self):
        return "%s(maxsize=%r, currsize=%r)" % (
            type(self).__name__,
            self.__maxsize,
            len(self.__cache),
        )
