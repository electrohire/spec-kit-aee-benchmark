<!--
Sync Impact Report (temporary scratch for human review; remove before committing)
- Version change: (none, initial ratification) -> 1.0.0
- Modified principles: none (new document)
- Added sections: Core Principles (I-V), Additional Constraints, Development Workflow, Governance
- Removed sections: none
- Follow-up TODOs: none
-->

# cachetools Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
All existing public `cachetools` APIs MUST retain their current observable
behavior. New functionality (e.g., `cachetools.tagged.TaggedCache`) MUST be
added alongside existing code, built on existing building blocks such as
`cachetools.LRUCache`, and MUST NOT rename, remove, or change the semantics
of existing public names. Upstream tests MUST remain unchanged and MUST keep
passing.
Rationale: this is a library with released consumers; regressions in
existing behavior are breaking changes and are out of scope for additive
milestones.

### II. Testable Acceptance Criteria
Every requirement MUST carry at least one concrete, observable acceptance
criterion (specific inputs -> expected value, exception type, or state
change). Requirements that cannot be stated this way MUST be split or
rejected. Verification MUST be by executable tests (pytest) against
`acceptance_public.py` and project-authored tests.
Rationale: deterministic, machine-checkable criteria make autonomous work
verifiable without human interpretation.

### III. Evidence Over Assertion
Claims about system behavior MUST be labeled as observed evidence (the
command executed and its output) or as unverified assertions. Unverified
assertions MUST NOT be reported as passing, and test results MUST NOT be
claimed without command evidence.
Rationale: in an autonomous benchmark, fabricated or unattributed test
evidence is a critical failure mode.

### IV. Simple, Scoped Implementation
Prefer the smallest implementation that satisfies the stated requirements.
New behavior MUST live in the designated source location (for this
milestone, `src/cachetools/tagged.py`). MUST NOT add dependencies,
configuration surface, or speculative features beyond the requirements
(YAGNI).
Rationale: small, scoped diffs minimize regression risk to the preserved
public API and keep review effort proportional.

### V. Document Unresolved Assumptions and Regressions
Unresolved assumptions, deferred decisions, and known or suspected
regressions MUST be recorded in persistent notes (e.g., `HANDOFF.md` and
spec documents), each tied to the requirement or feature it affects.
Rationale: phase handoffs clear conversation history; only durable
artifacts carry context between phases.

## Additional Constraints
- Implementation source for milestone 1: `src/cachetools/tagged.py`,
  exposing `TaggedCache(maxsize)` using the existing `cachetools.LRUCache`
  for bounded storage.
- Upstream tests MUST remain unchanged; `acceptance_public.py` is the
  public acceptance gate and MUST NOT be modified.
- Spec and plan documents for this feature live under
  `specs/001-transactions` (`SPECIFY_FEATURE_DIRECTORY`).
- Python only; no new runtime dependencies.

## Development Workflow
- Phases proceed in order: constitution -> specify -> plan -> tasks ->
  implementation. Application implementation is deferred to later phases
  and MUST NOT be started from the constitution phase.
- This constitution phase writes only
  `.specify/memory/constitution.md`; it MUST NOT create or modify
  application source, tests, templates, or other artifacts.
- Each requirement (R01-R03 and any approved extensions) MUST be traceable
  to at least one test in `acceptance_public.py` or a project-authored
test before the work is marked complete.

## Governance
This constitution supersedes conflicting project practices. Amendments
MUST be made by editing `.specify/memory/constitution.md`, incrementing the
version per semantic versioning (MAJOR: principle removal or redefinition;
MINOR: new principle or materially expanded guidance; PATCH: wording or
clarification), updating `LAST_AMENDED_DATE`, and noting the change in a
Sync Impact Report until committed. Compliance MUST be reviewed at each
phase boundary: preserved-API checks, test evidence, and documented
assumptions. Deferred non-governance intents MUST be listed as Next
Actions with the appropriate follow-up Spec Kit command (e.g.,
`$speckit-specify`) rather than executed here.

**Version**: 1.0.0 | **Ratified**: 2026-10-17 | **Last Amended**: 2026-10-17
