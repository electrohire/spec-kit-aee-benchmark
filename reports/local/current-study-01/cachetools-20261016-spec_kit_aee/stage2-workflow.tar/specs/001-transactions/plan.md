# Implementation Plan: Tagged Cache (TaggedCache)

**Branch**: `001-transactions` | **Date**: 2026-10-17 | **Spec**: specs/001-transactions/spec.md

**Input**: Feature specification from `/testbed/specs/001-transactions/spec.md`

## Summary

Add `cachetools.tagged.TaggedCache(maxsize)`: a bounded, tag-aware cache
built on the existing `cachetools.LRUCache` for bounded storage and LRU
recency. `put(key, value, tags=())` stores a deep copy of `value` under a
hashable key with a deduplicated set of string tags; `get(key)` returns a
detached deep copy or raises `KeyError`; `invalidate(tag)` removes every live
entry carrying `tag` and returns the count removed. Tag membership is tracked
in a private tag->keys index kept consistent on put/replace, invalidate, and
LRU eviction. `maxsize` must be a positive integer (bool excluded). All
existing cachetools APIs are preserved unchanged; upstream tests stay
unmodified and passing.

## Technical Context

**Language/Version**: Python 3.12 (verified in environment: 3.12.14; repo is
pure-Python 3.x library)

**Primary Dependencies**: stdlib only (`collections.abc`, `copy`, `types`,
`functools`); existing `cachetools.LRUCache` from `src/cachetools/__init__.py`

**Storage**: In-memory only

**Testing**: pytest 9.1.1 (verified installed); upstream suite in `tests/`
plus new `tests/test_tagged.py`; public gate `acceptance_public.py`
(unchanged)

**Target Platform**: Any Python platform (pure library, no platform code)

**Project Type**: Library (single package, src layout)

**Performance Goals**: put/get O(1) amortized; invalidate O(k) where k is the
number of removed entries (plus their tags); eviction O(tags of evicted key).
No behavior change or overhead for existing cache classes (new module only).

**Constraints**: No new runtime dependencies; no behavior changes to existing
modules; upstream tests and `acceptance_public.py` unmodifiable; fail-fast
validation before any state change (ValueError).

**Scale/Scope**: One new module (`src/cachetools/tagged.py`, ~120 lines) plus
one new test file; zero edits to existing source files.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Gates from `.specify/memory/constitution.md` (v1.0.0):

- **I. Code Quality** (type hints, docstrings, no dead code): PASS by design -
  `TaggedCache` public methods get annotations and docstrings; no dead code.
- **II. Testing** (new behavior covered; upstream suite green): PASS -
  `tests/test_tagged.py` planned; upstream baseline verified 216 passed
  (evidence: aeccefc9fad8781fc6f8ef662aee28425a2f27191706206b35075cff99376eac).
- **III. Simplicity** (no new deps; reuse existing primitives): PASS -
  reuses `LRUCache` instead of re-implementing LRU bookkeeping.
- **IV. API Compatibility** (existing public API unchanged): PASS - additive
  module only; no edits to `src/cachetools/__init__.py` or other modules.
- **V. Validation** (fail fast, before state mutation): PASS - tag/maxsize
  validation precedes any mutation (FR-004, FR-011).

Post-design re-check (after Phase 1): still PASS, no violations.

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── tagged-cache-api.md
└── tasks.md             # Phase 2 output ($speckit-tasks - NOT created here)
```

### Source Code (repository root)

```text
src/cachetools/
├── __init__.py          # UNCHANGED (existing caches, Cache base)
├── tagged.py            # NEW: TaggedCache (this feature)
└── ...                  # UNCHANGED

tests/
├── test_tagged.py       # NEW: project-authored tests for TaggedCache
└── ...                  # UNCHANGED (upstream suite)

acceptance_public.py     # UNCHANGED public gate (imported by hidden acceptance)
```

**Structure Decision**: Single-project src layout (existing). Additive module
`src/cachetools/tagged.py` + additive `tests/test_tagged.py`; no new
directories, no edits to existing files (keeps FR-013/preservation trivially
true and upstream diff empty).

## Complexity Tracking

> No Constitution Check violations; nothing to justify.
