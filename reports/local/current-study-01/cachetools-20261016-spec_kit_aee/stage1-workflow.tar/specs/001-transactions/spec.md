# Feature Specification: Tagged Cache (TaggedCache)

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "Build cachetools.tagged.TaggedCache(maxsize), using the
existing cachetools.LRUCache for bounded storage and preserving all existing
cachetools APIs. R01 put/get/copying/tags validation; R02 invalidate/recency/
eviction hygiene; R03 maxsize validation and atomic replacement. Claim-A
candidate extension (variant put_no_recency_refresh, 2026-09-21): R02
extension - overwriting an existing key via put refreshes its LRU recency, making
it the most-recently-used entry."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Store and Retrieve Tagged Entries (Priority: P1)

A developer creates a bounded `TaggedCache(maxsize)` and stores values under
hashable keys with string tags. Retrieval by key returns a detached deep copy
of the stored value; a missing key raises `KeyError`. Values are copied on
input as well, so later mutation of the caller's object does not change the
cached content. Tags are deduplicated; a bare string or a non-string tag entry
is rejected with `ValueError` before any existing state changes.

**Why this priority**: Core value of the feature - safe, tagged, bounded
storage. Without it nothing else works.

**Independent Test**: Create a cache, put a value with tags, get it back and
assert equality plus detachment (mutate the returned object, re-get, value
unchanged); assert `KeyError` for a missing key; assert `ValueError` for
`tags="x"` and `tags=[1]` and that state is unchanged after rejection.

**Acceptance Scenarios**:

1. **Given** an empty `TaggedCache(2)`, **When** `put('a', 1, ['x'])` then
   `get('a')` returns `1`.
2. **Given** a cached mutable value, **When** the caller mutates the original
   object after `put`, **Then** `get` returns the value as stored at insertion
   (copied on input).
3. **Given** a cached value, **When** the caller mutates the object returned by
   `get`, **Then** a subsequent `get` returns the unmutated stored value
   (detached deep copy).
4. **Given** any key not present, **When** `get(key)` is called, **Then**
   `KeyError` is raised.
5. **Given** a cache with existing entries, **When** `put(key, value, tags)` is
   called with a bare string as `tags` or a non-string tag entry, **Then**
   `ValueError` is raised and no existing entries, tags, or recency change.
6. **Given** `put('a', 1, ['x', 'x', 'y'])`, **When** the entry is inspected
   via `invalidate`, **Then** the entry is tagged exactly once per distinct
   tag (`invalidate('x') == 1`, `invalidate('y') == 1`).

---

### User Story 2 - Invalidate by Tag and Correct LRU Eviction (Priority: P2)

A developer removes all currently cached entries carrying a given tag in one
call and learns how many were removed. Replacing a key removes its old tag
memberships. When the cache is full, the least-recently-used entry is evicted
and eviction leaves no stale tag memberships that could affect later reuse of
the evicted key. `get` refreshes LRU recency. `len(cache)` counts live
entries.

**Why this priority**: Tag-based bulk removal and eviction correctness are the
second core value; they depend on Story 1's storage but are independently
testable.

**Independent Test**: Fill a small cache, call `invalidate(tag)` and assert the
returned count and that only tagged entries were removed; put past capacity and
assert the LRU victim was evicted and that re-putting the same key with new
tags does not resurrect old memberships.

**Acceptance Scenarios**:

1. **Given** entries tagged `'x'` and `'y'`, **When** `invalidate('x')`,
   **Then** it returns the number of removed entries and only those entries are
   gone; `invalidate` of an unknown tag returns `0`.
2. **Given** a key stored with tags `['old']`, **When** the same key is
   re-put with tags `['new']`, **Then** `invalidate('old')` returns `0` and
   `get(key)` returns the new value (old memberships removed).
3. **Given** a full cache, **When** a new entry is put, **Then** the
   least-recently-used entry is evicted, `len` stays at `maxsize`, and a later
   `put` of the evicted key with different tags does not carry the old tags.
4. **Given** a full cache where one entry was just `get`-accessed, **When** a
   new entry is put, **Then** the accessed entry survives and a different LRU
   entry is evicted (get refreshes recency).
5. **Given** any sequence of puts/gets/invalidates, **When** `len(cache)` is
   called, **Then** it equals the number of live entries and never exceeds
   `maxsize`.

---

### User Story 3 - Configuration and Replacement Safety (Priority: P3)

A developer constructs the cache with a positive integer `maxsize` (booleans
are rejected) and relies on replacement being atomic: invalid replacement
input (bad tags, bad value handling) leaves the previously stored value, tags,
and recency exactly as they were. Every value costs exactly one capacity slot
regardless of object size.

**Why this priority**: Guards against data corruption and misconfiguration;
important but exercised less frequently than put/get/invalidate.

**Independent Test**: Assert `TaggedCache(0)`, `TaggedCache(-1)`,
`TaggedCache(True)`, `TaggedCache(2.0)` raise `ValueError`; put a valid entry,
attempt `put` with invalid tags, and assert the old value/tags/recency are
unchanged; put `maxsize` large objects and confirm the (maxsize+1)th evicts the
LRU entry (one slot per value).

**Acceptance Scenarios**:

1. **Given** a non-positive, non-integer, or boolean `maxsize`, **When** the
   cache is constructed, **Then** `ValueError` is raised.
2. **Given** a key with value `v1` and tags `['t']`, **When** `put(key, v2,
   ['bad'])` (non-string tag) fails, **Then** `get(key)` still returns a copy
   of `v1`, `invalidate('t')` still returns `1`, and the entry's recency is
   unchanged.
3. **Given** `maxsize` entries of very different object sizes, **When** one
   more entry is put, **Then** exactly the LRU entry is evicted (each value
   occupies one slot regardless of size).

### Edge Cases

- `put` with `tags=()` (default) or an empty iterable: entry stored with no
tags; `invalidate(anything)` does not remove it.
- `put` with a tag iterable containing duplicates: stored once per distinct
tag (deduplicated); order of first occurrence preserved for determinism.
- `put` with an infinite/lazy iterable of tags: iteration is finite by
  contract; validation must complete before state change (a bare string is
  rejected rather than iterated character-by-character).
- Re-putting an evicted key: behaves as a fresh insertion with the new tags
  only (no stale memberships from before eviction).
- `invalidate` with a tag that no live entry carries: returns `0`, state
  unchanged.
- Replacement of a key with the same value but different tags: old tag
  memberships removed, new memberships applied, recency refreshed (R02
  extension).
- `maxsize` given as `bool` (`True`/`False`): rejected (`ValueError`) even
  though `bool` is an `int` subclass.
- `maxsize` given as a float or other non-int: rejected (`ValueError`).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001** (R01): `TaggedCache(maxsize)` MUST accept a `maxsize` that is a
  positive integer (bool excluded); all other values MUST raise `ValueError`
  (R03).
- **FR-002** (R01): `put(key, value, tags=())` MUST insert or replace an entry
  for a hashable key; the stored value MUST be an independent deep copy of the
  input value.
- **FR-003** (R01): `get(key)` MUST return a detached deep copy of the stored
  value, and MUST raise `KeyError` when the key is absent.
- **FR-004** (R01): `tags` MUST be a finite iterable of strings; a bare string
  MUST be rejected and non-string entries MUST be rejected, both with
  `ValueError`, in both cases BEFORE any existing cache state (entries, tags,
  recency) is modified; duplicate tags MUST be deduplicated.
- **FR-005** (R02): `invalidate(tag)` MUST remove exactly the currently cached
  entries carrying `tag` and MUST return the number removed.
- **FR-006** (R02): Replacing an existing key MUST remove its previous tag
  memberships before applying the new ones.
- **FR-007** (R02): LRU eviction MUST remove the evicted entry's tag
  memberships so later reuse of the same key carries no stale memberships.
- **FR-008** (R02): `get(key)` on a hit MUST refresh that entry's LRU recency.
- **FR-009** (R02): `len(cache)` MUST count live entries and MUST never exceed
  `maxsize`.
- **FR-010** (R02 extension, Claim-A, variant `put_no_recency_refresh`,
  2026-09-21): Overwriting an existing key via `put` MUST refresh its LRU
  recency, making it the most-recently-used entry.
- **FR-011** (R03): A failed replacement (invalid input) MUST leave the
  previous value, tags, and recency unchanged.
- **FR-012** (R03): Every value MUST occupy exactly one capacity slot
  regardless of object size.
- **FR-013** (preservation): All existing public `cachetools` APIs MUST retain
  their current behavior; the new cache MUST be built on the existing
  `cachetools.LRUCache` for bounded storage; upstream tests MUST remain
  unchanged and passing.

### Key Entities

- **TaggedCache**: A bounded cache instance configured by `maxsize`; holds
  live entries; enforces LRU eviction and tag bookkeeping.
- **Entry**: A live mapping of one hashable key to one deep-copied value and a
  set of distinct string tags; occupies exactly one capacity slot; has an LRU
  recency position.
- **Tag**: A distinct string identifying an entry for bulk invalidation; an
  entry may carry zero or more tags; a tag may be carried by many entries.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of the milestone's acceptance scenarios (User Stories 1-3)
  pass as executable tests, including the public acceptance suite
  (`acceptance_public.py`) and project-authored tests, with zero failures.
- **SC-002**: 100% of existing upstream tests pass unchanged after the feature
  is added (no regressions in existing `cachetools` APIs).
- **SC-003**: For every rejection case (invalid `maxsize`, bare-string tags,
  non-string tag entries, invalid replacement input), 100% leave observable
  cache state (entries, tags, recency, length) exactly as before the call.
- **SC-004**: After any sequence of at least 1000 mixed operations (put,
  replace, get, invalidate, eviction) on a small cache, `len` equals the live
  entry count, never exceeds `maxsize`, and no evicted key's old tags affect a
  later re-put of that key (0 stale memberships).
- **SC-005**: Retrieval isolation: mutating either the input object or a
  returned object never changes the stored value (verified for nested
  container values, not only scalars).

## Assumptions

- **A1**: "Detached deep copy" means a copy deep enough that mutating nested
  container structures in the input or returned object does not affect the
  stored value; scalar values are equal-valued copies.
- **A2**: `put` returns no value (consistent with existing `cachetools`
  caches); the observable contract is via `get`, `len`, and `invalidate`.
- **A3**: Tag validation is performed by materializing the tag iterable into a
  finite sequence of strings; a bare string is rejected explicitly (not
  treated as an iterable of characters); an infinite iterable is out of
  contract (tags must be finite).
- **A4**: Recency ordering follows standard LRU semantics: `put` (insert or
  replace) and `get` (hit) mark an entry most-recently-used; eviction removes
  the least-recently-used entry. This includes the Claim-A extension
  (FR-010): replacing an existing key refreshes its recency.
- **A5**: Invalid `maxsize` values include `0`, negatives, booleans, floats,
  and non-numeric types; all raise `ValueError` at construction.
- **A6**: The feature is delivered as an additive module
  (`src/cachetools/tagged.py`) with no changes to existing modules' behavior
  and no new dependencies.
- **A7**: `invalidate` accepts a single tag (string); bulk/multi-tag
  invalidation is out of scope for this milestone.
- **A8**: The Claim-A candidate extension is treated as an active requirement
  (FR-010) per the milestone input; the variant label
  `put_no_recency_refresh` is noted for traceability only and does NOT
  override FR-010 (i.e., recency refresh on overwrite IS required).
