# Feature Specification: Tagged Cache (TaggedCache)

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft (updated 2026-10-17 for milestone 2 + round-2 clarification; updated 2026-10-17 for milestone 3 R07/R08 entry expiry)

**Input**: User description: "Build cachetools.tagged.TaggedCache(maxsize), using the
existing cachetools.LRUCache for bounded storage and preserving all existing
cachetools APIs. R01 put/get/copying/tags validation; R02 invalidate/recency/
eviction hygiene; R03 maxsize validation and atomic replacement. Claim-A
candidate extension (variant put_no_recency_refresh, 2026-09-21): R02
extension - overwriting an existing key via put refreshes its LRU recency, making
it the most-recently-used entry. Milestone 2 (retaining R01-R03): R04
invalidate_many(tags, mode='any'); R05 resize(maxsize) with maxsize property;
R06 generator tags consumed once + repeated-get/put detachment. Conflicting
evidence: an old generated design note ('empty all-tags matches every key and
resizing may flush the cache') is superseded by R04/R05. Claim-A candidate
extensions, round 2 (2026-09-22): R05 clarification - resize must preserve the
absolute expiry of surviving entries (R07/R08 define the expiry as entry
state). Milestone 3 (retaining R01-R06): R07 constructor accepts timer=None (default time.monotonic); put adds ttl=None, where None means no expiration and a finite nonnegative int/float excluding bool sets expiry at timer()+ttl; invalid TTL raises ValueError before any mutation; TTL zero is immediately expired; at the exact expiry boundary a key is expired. R08 expired entries are removed before get, put, len, resize, and invalidation, without touching the recency of surviving entries; overwriting an entry replaces its prior expiry; tag invalidation counts only live entries; a missing/expired get raises KeyError; existing callers without timer/ttl retain previous behavior."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Store and Retrieve Tagged Entries (Priority: P1)

A developer creates a bounded `TaggedCache(maxsize)` and stores values under
hashable keys with string tags. Retrieval by key returns a detached deep copy
of the stored value; a missing key raises `KeyError`. Values are copied on
input as well, so later mutation of the caller's object does not change the
cached content. Tags are deduplicated; a bare string or a non-string tag entry
is rejected with `ValueError` before any existing state changes.

**Why this priority**: Core value of the feature - safe, tagged, bounded
storage. Without it nothing else works.

**Independent Test**: Create a cache, put a value with tags, get it back and
assert equality plus detachment (mutate the returned object, re-get, value
unchanged); assert `KeyError` for a missing key; assert `ValueError` for
`tags="x"` and `tags=[1]` and that state is unchanged after rejection.

**Acceptance Scenarios**:

1. **Given** an empty `TaggedCache(2)`, **When** `put('a', 1, ['x'])` then
   `get('a')` returns `1`.
2. **Given** a cached mutable value, **When** the caller mutates the original
   object after `put`, **Then** `get` returns the value as stored at insertion
   (copied on input).
3. **Given** a cached value, **When** the caller mutates the object returned by
   `get`, **Then** a subsequent `get` returns the unmutated stored value
   (detached deep copy).
4. **Given** any key not present, **When** `get(key)` is called, **Then**
   `KeyError` is raised.
5. **Given** a cache with existing entries, **When** `put(key, value, tags)` is
   called with a bare string as `tags` or a non-string tag entry, **Then**
   `ValueError` is raised and no existing entries, tags, or recency change.
6. **Given** `put('a', 1, ['x', 'x', 'y'])`, **When** the entry is inspected
   via `invalidate`, **Then** the entry is tagged exactly once per distinct
   tag (`invalidate('x') == 1`, `invalidate('y') == 1`).

---

### User Story 2 - Invalidate by Tag and Correct LRU Eviction (Priority: P2)

A developer removes all currently cached entries carrying a given tag in one
call and learns how many were removed. Replacing a key removes its old tag
memberships. When the cache is full, the least-recently-used entry is evicted
and eviction leaves no stale tag memberships that could affect later reuse of
the evicted key. `get` refreshes LRU recency. `len(cache)` counts live
entries.

**Why this priority**: Tag-based bulk removal and eviction correctness are the
second core value; they depend on Story 1's storage but are independently
testable.

**Independent Test**: Fill a small cache, call `invalidate(tag)` and assert the
returned count and that only tagged entries were removed; put past capacity and
assert the LRU victim was evicted and that re-putting the same key with new
tags does not resurrect old memberships.

**Acceptance Scenarios**:

1. **Given** entries tagged `'x'` and `'y'`, **When** `invalidate('x')`,
   **Then** it returns the number of removed entries and only those entries are
   gone; `invalidate` of an unknown tag returns `0`.
2. **Given** a key stored with tags `['old']`, **When** the same key is
   re-put with tags `['new']`, **Then** `invalidate('old')` returns `0` and
   `get(key)` returns the new value (old memberships removed).
3. **Given** a full cache, **When** a new entry is put, **Then** the
   least-recently-used entry is evicted, `len` stays at `maxsize`, and a later
   `put` of the evicted key with different tags does not carry the old tags.
4. **Given** a full cache where one entry was just `get`-accessed, **When** a
   new entry is put, **Then** the accessed entry survives and a different LRU
   entry is evicted (get refreshes recency).
5. **Given** any sequence of puts/gets/invalidates, **When** `len(cache)` is
   called, **Then** it equals the number of live entries and never exceeds
   `maxsize`.

---

### User Story 3 - Configuration and Replacement Safety (Priority: P3)

A developer constructs the cache with a positive integer `maxsize` (booleans
are rejected) and relies on replacement being atomic: invalid replacement
input (bad tags, bad value handling) leaves the previously stored value, tags,
and recency exactly as they were. Every value costs exactly one capacity slot
regardless of object size.

**Why this priority**: Guards against data corruption and misconfiguration;
important but exercised less frequently than put/get/invalidate.

**Independent Test**: Assert `TaggedCache(0)`, `TaggedCache(-1)`,
`TaggedCache(True)`, `TaggedCache(2.0)` raise `ValueError`; put a valid entry,
attempt `put` with invalid tags, and assert the old value/tags/recency are
unchanged; put `maxsize` large objects and confirm the (maxsize+1)th evicts the
LRU entry (one slot per value).

**Acceptance Scenarios**:

1. **Given** a non-positive, non-integer, or boolean `maxsize`, **When** the
   cache is constructed, **Then** `ValueError` is raised.
2. **Given** a key with value `v1` and tags `['t']`, **When** `put(key, v2,
   ['bad'])` (non-string tag) fails, **Then** `get(key)` still returns a copy
   of `v1`, `invalidate('t')` still returns `1`, and the entry's recency is
   unchanged.
3. **Given** `maxsize` entries of very different object sizes, **When** one
   more entry is put, **Then** exactly the LRU entry is evicted (each value
   occupies one slot regardless of size).

### User Story 4 - Multi-Tag Invalidation, Resizing, and Lazy Tags (Priority: P2)

A developer invalidates entries matching several tags in one call, choosing
whether to remove entries carrying ANY of the supplied tags or only entries
carrying ALL of them. The developer can change the cache capacity at runtime:
shrinking evicts least-recently-used entries while growing never evicts, and a
failed resize leaves the cache exactly as it was. Tags may be supplied as
generators (lazy iterables) and are consumed exactly once. Returned values
stay detached across repeated `get` and `put` calls, including nested lists
and dicts.

**Why this priority**: Bulk invalidation and runtime resizing extend the core
tagged-cache value to operational use; they build on Stories 1-3 but are
independently testable.

**Independent Test**: Put entries with overlapping tag sets, call
`invalidate_many` in both modes and assert the removed keys and returned
counts; assert empty tag requests remove nothing; assert invalid mode or
invalid tags raise `ValueError` with state unchanged. Fill a cache, shrink it
and assert the LRU victims were evicted with surviving order preserved; grow it
and assert nothing was evicted; assert a failed `resize` (e.g., `True`, `0`,
`-1`, `2.5`) leaves capacity and all state unchanged and that the `maxsize`
property reports the current capacity. Pass a generator as `tags` and assert
it is consumed exactly once and that repeated `get`/`put` never alias the
stored value.

**Acceptance Scenarios**:

1. **Given** entries with tags `{'a','b'}`, `{'b'}`, and `{'c'}`, **When**
   `invalidate_many(['a','b'])` (mode `'any'`), **Then** the first two entries
   are removed, the third survives, and the return value is the number of
   distinct removed keys (`2`).
2. **Given** the same entries, **When** `invalidate_many(['a','b'], mode='all')`,
   **Then** only the entry carrying both `'a'` and `'b'` is removed and the
   return value is `1`.
3. **Given** any non-empty cache, **When** `invalidate_many(())` or
   `invalidate_many([], mode='all')` is called, **Then** zero entries are
   removed in either mode and state is unchanged (empty requested tags never
   match; an empty `'all'` request does NOT match every key).
4. **Given** a cache, **When** `invalidate_many` is called with an invalid
   `mode` (not `'any'`/`'all'`) or invalid tags (bare string, non-string
   entry), **Then** `ValueError` is raised BEFORE any mutation and state is
   unchanged.
5. **Given** a full cache of `maxsize` entries, **When** `resize(smaller)` is
   called, **Then** the least-recently-used entries are evicted until the live
   count equals the new capacity, surviving entries keep their relative LRU
   order, and the `maxsize` property reports the new capacity.
6. **Given** a cache, **When** `resize(larger)` is called, **Then** no entry is
   evicted, the `maxsize` property reports the new capacity, and the cache can
   then hold up to the new capacity.
7. **Given** a cache with entries, **When** `resize(True)`, `resize(0)`,
   `resize(-1)`, or `resize(2.5)` is called, **Then** `ValueError` is raised
   and capacity, entries, tags, and recency are all unchanged.
8. **Given** a cache, **When** `put` is called with a generator as `tags`,
   **Then** the generator is consumed exactly once, the entry is stored with
   the yielded (deduplicated) tags, and a generator that raises mid-iteration
   or a bare string is rejected with `ValueError` before any state change.
9. **Given** a nested value (list/dict), **When** it is `get`-retrieved
   repeatedly and `put`-replaced repeatedly, **Then** every returned object is
   a fresh detached deep copy: mutating any returned object or the original
   input never changes the stored value, and two successive `get`s are not the
   same object.

### User Story 5 - Time-Limited Entries (TTL) (Priority: P2)

A developer creates a cache with an optional controllable timer (defaulting to
the standard monotonic clock) and stores entries with an optional time-to-live.
Entries without a TTL never expire. Entries with a TTL expire at the absolute
moment `timer() + ttl`; a zero TTL is already expired at insertion time, and an
entry is treated as expired at the exact expiry boundary. Expired entries are
purged before `get`, `put`, `len`, `resize`, and invalidation, and purging
never changes the relative recency of surviving entries. Overwriting an entry
replaces its prior expiry. Invalidation counts only live (unexpired) entries.
A `get` for a missing or expired key raises `KeyError`. Callers who never use
`timer` or `ttl` observe exactly the previous behavior.

**Why this priority**: Time-limited entries are a core requested capability of
milestone 3 and interact with every existing operation (purge-before-operation
is a cross-cutting correctness rule); they depend on Story 1 storage and
Story 2 recency/LRU semantics but are independently testable with a fake
timer.

**Independent Test**: Build a cache with a fake timer; put an entry with a TTL
and advance the fake clock to the exact expiry, then assert `get` raises
`KeyError` and `len` is `0`; put with an invalid TTL (negative, `bool`,
non-numeric, non-finite) and assert `ValueError` with state unchanged; put
with `ttl=0` and assert the entry is immediately expired; verify a surviving
entry's recency is unchanged after a purge; verify `ttl=None` entries never
expire.

**Acceptance Scenarios**:

1. **Given** a cache built with a fake timer, **When** `put('a', 1, ttl=5)` is
   called at `timer()==10`, **Then** the entry is live while `timer() < 15`
   and `get('a')` raises `KeyError` at `timer() == 15` (exact boundary is
   expired).
2. **Given** a cache, **When** `put('a', 1, ttl=0)` is called, **Then** the
   entry is immediately expired: `get('a')` raises `KeyError` and `len` does
   not count it.
3. **Given** an entry with a TTL, **When** the same key is re-put with
   `ttl=None`, **Then** the entry no longer expires; re-putting with a new
   finite TTL sets a new expiry from the new `timer()` value (prior expiry
   replaced).
4. **Given** one expired and one live entry, **When** `len`, `put`, `get`
   (of the live key), `resize`, or `invalidate` is called, **Then** the
   expired entry is removed first, the live entry survives, and the live
   entry's relative recency is unchanged by the purge.
5. **Given** an entry carrying tag `'x'` that has expired, **When**
   `invalidate('x')` is called, **Then** it returns `0` (expired entries are
   not counted; only live entries are removed and counted).
6. **Given** `put` with an invalid TTL (negative number, `bool`, non-numeric,
   or non-finite such as infinity/NaN), **Then** `ValueError` is raised BEFORE
   any state change (no insert, no replace, no recency change).
7. **Given** a cache constructed with a custom `timer` callable, **Then** that
   timer is the sole source of time for all expiry decisions; with the
   default construction (`timer=None`) the standard monotonic clock is used.
8. **Given** a cache and `put` calls that never pass `ttl` (and a constructor
   that never passes `timer`), **Then** behavior is identical to the
   pre-milestone-3 contract (entries never expire; all R01-R06 behavior
   unchanged).

### Edge Cases

- `put` with `tags=()` (default) or an empty iterable: entry stored with no
tags; `invalidate(anything)` does not remove it.
- `put` with a tag iterable containing duplicates: stored once per distinct
tag (deduplicated); order of first occurrence preserved for determinism.
- `put` with an infinite/lazy iterable of tags: iteration is finite by
  contract; validation must complete before state change (a bare string is
  rejected rather than iterated character-by-character).
- Re-putting an evicted key: behaves as a fresh insertion with the new tags
  only (no stale memberships from before eviction).
- `invalidate` with a tag that no live entry carries: returns `0`, state
  unchanged.
- Replacement of a key with the same value but different tags: old tag
  memberships removed, new memberships applied, recency refreshed (R02
  extension).
- `maxsize` given as `bool` (`True`/`False`): rejected (`ValueError`) even
  though `bool` is an `int` subclass.
- `maxsize` given as a float or other non-int: rejected (`ValueError`).

- `invalidate_many` with duplicate tags in the request: the request is
  deduplicated for matching (a tag listed twice does not change which entries
  match or the returned count).
- `invalidate_many` in mode `'all'` with a single tag: removes exactly the
  entries carrying that tag, identical to `invalidate(tag)`.
- `resize` to the same capacity: valid no-op; entries, tags, and LRU order
  unchanged.
- `resize` while the cache is empty: valid; only the capacity changes.
- Shrink below the live count where some entries share tags: eviction is by
  LRU recency only; tag membership of evicted entries is fully removed (no
  stale memberships, consistent with FR-007).
- Generator tags: the same generator object must not be re-consumed by the
  cache after `put` returns; the cache stores only the materialized tag set.
- Expiry (forward reference): when entry expiry state exists (defined by
  R07/R08, not in the current milestone input), `resize` MUST preserve each
  surviving entry's absolute expiry; dropping expiries (making entries
  immortal) or recomputing them from the resize time is a violation (R05
  clarification, round 2).

- TTL on replacement: re-putting an existing key with `ttl=None` clears any
  prior expiry (entry becomes immortal); re-putting with a finite TTL sets a
  fresh absolute expiry computed from the current `timer()` value (the prior
  expiry is never extended or reused).
- `ttl=0`: the entry is expired at insertion time; it is never observable via
  `get`, `len`, or invalidation, and it occupies no effective capacity in
  observable state (it is purged before any operation).
- Exact expiry boundary: at `timer() == timer_at_put + ttl` the entry is
  expired (comparison is inclusive); just before that instant it is live.
- Invalid TTL values: negative numbers, `bool` (`True`/`False`), non-numeric
  types, and non-finite numbers (infinity, NaN) all raise `ValueError` before
  any state change; `ttl=None` is always valid.
- Expired entry with tags: its tag memberships are removed at purge time, so
  later invalidation of that tag counts only live entries.
- Purge ordering: expiry purging happens before the requested operation and
  does not reorder or otherwise touch the recency of surviving entries; a
  `get` that follows a purge still refreshes the hit entry's recency as usual.
- `timer` argument: any callable returning a number is accepted; the default
  (`timer=None`) is the standard monotonic clock; the timer is consulted only
  for expiry decisions and never mutates caller state.
- Backward compatibility: caches and `put` calls that never use `timer`/`ttl`
  behave exactly as before milestone 3 (no expiry, no clock reads required for
  observable behavior).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001** (R01): `TaggedCache(maxsize)` MUST accept a `maxsize` that is a
  positive integer (bool excluded); all other values MUST raise `ValueError`
  (R03).
- **FR-002** (R01): `put(key, value, tags=())` MUST insert or replace an entry
  for a hashable key; the stored value MUST be an independent deep copy of the
  input value.
- **FR-003** (R01): `get(key)` MUST return a detached deep copy of the stored
  value, and MUST raise `KeyError` when the key is absent.
- **FR-004** (R01): `tags` MUST be a finite iterable of strings; a bare string
  MUST be rejected and non-string entries MUST be rejected, both with
  `ValueError`, in both cases BEFORE any existing cache state (entries, tags,
  recency) is modified; duplicate tags MUST be deduplicated.
- **FR-005** (R02): `invalidate(tag)` MUST remove exactly the currently cached
  entries carrying `tag` and MUST return the number removed.
- **FR-006** (R02): Replacing an existing key MUST remove its previous tag
  memberships before applying the new ones.
- **FR-007** (R02): LRU eviction MUST remove the evicted entry's tag
  memberships so later reuse of the same key carries no stale memberships.
- **FR-008** (R02): `get(key)` on a hit MUST refresh that entry's LRU recency.
- **FR-009** (R02): `len(cache)` MUST count live entries and MUST never exceed
  `maxsize`.
- **FR-010** (R02 extension, Claim-A, variant `put_no_recency_refresh`,
  2026-09-21): Overwriting an existing key via `put` MUST refresh its LRU
  recency, making it the most-recently-used entry.
- **FR-011** (R03): A failed replacement (invalid input) MUST leave the
  previous value, tags, and recency unchanged.
- **FR-012** (R03): Every value MUST occupy exactly one capacity slot
  regardless of object size.
- **FR-013** (preservation): All existing public `cachetools` APIs MUST retain
  their current behavior; the new cache MUST be built on the existing
  `cachetools.LRUCache` for bounded storage; upstream tests MUST remain
  unchanged and passing.
- **FR-014** (R04): `invalidate_many(tags, mode='any')` MUST remove the union
  of live entries carrying any of the supplied tags when `mode='any'`, and
  only live entries carrying every supplied tag when `mode='all'`; it MUST
  return the number of distinct removed keys.
- **FR-015** (R04): An empty requested tag set MUST remove zero entries in
  either mode (in particular, an empty `'all'` request MUST NOT match every
  key) and MUST return `0`.
- **FR-016** (R04): `invalidate_many` MUST reject an invalid `mode` (anything
  other than `'any'` or `'all'`) and invalid tags (bare string, non-string
  entries) with `ValueError` BEFORE any mutation; `invalidate(tag)` MUST
  remain compatible (same semantics as `invalidate_many([tag], mode='any')`).
- **FR-017** (R05): `resize(maxsize)` MUST validate its argument first as a
  positive integer excluding `bool` (else `ValueError`); shrinking MUST evict
  least-recently-used entries until the live count equals the new capacity
  while preserving surviving entries' relative LRU order; growing MUST not
  evict; a failed resize MUST preserve all state (capacity, entries, tags,
  recency).
- **FR-018** (R05): The `maxsize` property MUST report the cache's current
  capacity (initial value from construction; updated by successful `resize`).
- **FR-019** (R05 clarification, Claim-A round 2, 2026-09-22): Preserving a
  surviving entry across `resize` MUST preserve its absolute expiry (R07/R08
  define the expiry as entry state); a resize that drops expiries (making
  entries immortal) or recomputes them from the resize time MUST NOT be
  accepted as satisfying R05. Expiry itself is out of scope until R07/R08 are
  added; this clause constrains any future expiry state.
- **FR-020** (R06): Tags MUST be accepted as any finite iterable, including
  generators, and MUST be consumed exactly once; the cache MUST store only the
  materialized (deduplicated) tag set, never the original iterable.
- **FR-021** (R06): Returned values MUST remain detached across repeated
  `get`s and `put`s, including nested lists and dicts; no returned object
  (or object nested within one) may alias the stored value or any other
  returned object.
- **FR-022** (R07): The constructor MUST accept `timer=None`; when `timer`
  is `None` the standard monotonic clock is used, otherwise the supplied
  callable is the sole source of time for expiry decisions.
- **FR-023** (R07): `put` MUST accept `ttl=None`, meaning no expiration; a
  finite nonnegative `int`/`float` (excluding `bool`) MUST set the entry's
  absolute expiry to `timer() + ttl` at insertion time.
- **FR-024** (R07): An invalid TTL (negative number, `bool`, non-numeric,
  non-finite) MUST raise `ValueError` BEFORE any mutation (no insert, no
  replace, no recency or expiry change).
- **FR-025** (R07): A `ttl=0` entry MUST be immediately expired (unobservable
  via `get`, `len`, or invalidation), and an entry MUST be treated as expired
  at the exact boundary `timer() == timer_at_put + ttl` (inclusive
  comparison); it is live just before that instant.
- **FR-026** (R08): Expired entries MUST be removed before `get`, `put`,
  `len`, `resize`, and invalidation, and the purge MUST NOT change the
  relative recency of surviving entries.
- **FR-027** (R08): Overwriting an entry MUST replace its prior expiry
  (`ttl=None` clears the expiry; a finite TTL sets a fresh absolute expiry
  from the current `timer()`); tag invalidation MUST count only live
  (unexpired) entries; a `get` for a missing or expired key MUST raise
  `KeyError`.
- **FR-028** (R08): Existing callers that never pass `timer` or `ttl` MUST
  retain exactly the pre-milestone-3 behavior (entries never expire).

### Key Entities

- **TaggedCache**: A bounded cache instance configured by `maxsize`; holds
  live entries; enforces LRU eviction and tag bookkeeping.
- **Entry**: A live mapping of one hashable key to one deep-copied value and a
  set of distinct string tags; occupies exactly one capacity slot; has an LRU
  recency position; carries an optional absolute expiry (milestone 3, R07/R08)
  that is entry state preserved by resize (FR-019) and replaced on overwrite
  (FR-027).
- **Timer**: The time source for expiry decisions; defaults to the standard
  monotonic clock when the constructor is given `timer=None`; any supplied
  callable is used exclusively for computing and comparing expiries.
- **Tag**: A distinct string identifying an entry for bulk invalidation; an
  entry may carry zero or more tags; a tag may be carried by many entries.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of the milestone's acceptance scenarios (User Stories 1-3)
  pass as executable tests, including the public acceptance suite
  (`acceptance_public.py`) and project-authored tests, with zero failures.
- **SC-002**: 100% of existing upstream tests pass unchanged after the feature
  is added (no regressions in existing `cachetools` APIs).
- **SC-003**: For every rejection case (invalid `maxsize`, bare-string tags,
  non-string tag entries, invalid replacement input), 100% leave observable
  cache state (entries, tags, recency, length) exactly as before the call.
- **SC-004**: After any sequence of at least 1000 mixed operations (put,
  replace, get, invalidate, eviction) on a small cache, `len` equals the live
  entry count, never exceeds `maxsize`, and no evicted key's old tags affect a
  later re-put of that key (0 stale memberships).
- **SC-005**: Retrieval isolation: mutating either the input object or a
  returned object never changes the stored value (verified for nested
  container values, not only scalars).
- **SC-006**: `invalidate_many` removes exactly the entries described by the
  requested tag set and mode in 100% of test cases (union for `'any'`,
  intersection for `'all'`), returns the exact distinct removed-key count,
  removes zero entries for empty requests in both modes, and leaves state
  unchanged for 100% of invalid mode/tag inputs.
- **SC-007**: `resize` succeeds for 100% of valid positive non-bool integer
  capacities: shrinking evicts exactly the least-recently-used entries (no
  other evictions), growing evicts none, surviving LRU order is preserved in
  100% of cases, the `maxsize` property always reports the current capacity,
  and 100% of invalid inputs (bool, zero, negative, float, non-numeric) leave
  all state unchanged.
- **SC-008**: A generator passed as tags is consumed exactly once in 100% of
  cases (verified with an instrumented generator), and repeated `get`/`put`
  cycles (>= 10 per key) produce 100% detached copies for nested list/dict
  values (mutation of any returned object never changes stored state).
- **SC-009**: With a controllable timer, 100% of TTL boundary cases behave
  exactly as specified: an entry with `ttl=T` is live at every instant before
  `timer_at_put + T` and expired at exactly that instant (inclusive
  boundary); `ttl=0` entries are unobservable in 100% of cases; 100% of
  invalid TTL inputs (negative, `bool`, non-numeric, non-finite) raise
  `ValueError` and leave all observable state (entries, tags, recency,
  capacity, length) unchanged.
- **SC-010**: In 100% of mixed sequences (puts with/without TTL, gets,
  replacements, invalidations, resizes, evictions) the expired-entry purge is
  invisible to surviving entries: their relative recency is unchanged by
  purges, `len` never counts expired entries, invalidation counts never
  include expired entries, and `get` of a missing or expired key raises
  `KeyError` in 100% of cases; callers that never use `timer`/`ttl` observe
  behavior identical to the pre-milestone-3 contract in 100% of cases.

## Assumptions

- **A1**: "Detached deep copy" means a copy deep enough that mutating nested
  container structures in the input or returned object does not affect the
  stored value; scalar values are equal-valued copies.
- **A2**: `put` returns no value (consistent with existing `cachetools`
  caches); the observable contract is via `get`, `len`, and `invalidate`.
- **A3**: Tag validation is performed by materializing the tag iterable into a
  finite sequence of strings; a bare string is rejected explicitly (not
  treated as an iterable of characters); an infinite iterable is out of
  contract (tags must be finite).
- **A4**: Recency ordering follows standard LRU semantics: `put` (insert or
  replace) and `get` (hit) mark an entry most-recently-used; eviction removes
  the least-recently-used entry. This includes the Claim-A extension
  (FR-010): replacing an existing key refreshes its recency.
- **A5**: Invalid `maxsize` values include `0`, negatives, booleans, floats,
  and non-numeric types; all raise `ValueError` at construction.
- **A6**: The feature is delivered as an additive module
  (`src/cachetools/tagged.py`) with no changes to existing modules' behavior
  and no new dependencies.
- **A7**: `invalidate` accepts a single tag (string) and remains compatible
  with `invalidate_many([tag], mode='any')`; bulk/multi-tag invalidation is
  provided by `invalidate_many` (R04).
- **A8**: The Claim-A candidate extension is treated as an active requirement
  (FR-010) per the milestone input; the variant label
  `put_no_recency_refresh` is noted for traceability only and does NOT
  override FR-010 (i.e., recency refresh on overwrite IS required).
- **A9**: The conflicting old design note ('empty all-tags matches every key
  and resizing may flush the cache') is superseded by R04/R05 and MUST NOT be
  relied upon; specifically, empty requested tags remove zero entries and
  resizing never flushes the cache.
- **A10**: The R05 round-2 clarification (absolute-expiry preservation) is
  recorded as FR-019 and is binding for any implementation that introduces
  expiry state (R07/R08); since the current milestone input defines no expiry
  behavior, no expiry is implemented or tested in this milestone.
- **A11**: `invalidate_many` deduplicates the requested tag set for matching
  (duplicates in the request do not change the match set or the returned
count); the returned count is always the number of distinct removed keys.
- **A12**: A "finite nonnegative int/float excluding bool" TTL accepts `int`
  and `float` values `>= 0` that are finite; `bool` is rejected although it is
  an `int` subclass; negative, non-numeric, and non-finite values (infinity,
  NaN) are invalid. The expiry is the absolute instant `timer() + ttl`
  computed once at insertion (or replacement); it is not recomputed on later
  reads.
- **A13**: "Without touching the recency of surviving entries" (R08) means the
  purge removes only expired entries and leaves the relative LRU order of the
  survivors exactly as it was before the purge; a subsequent `get` hit still
  refreshes recency as usual (FR-008).

## Requirement Traceability

| Milestone input | Spec requirement(s) | Notes |
|-----------------|---------------------|-------|
| R01 | FR-002, FR-003, FR-004 | put/get/copying/tags |
| R02 | FR-005, FR-006, FR-007, FR-008, FR-009 | invalidate, replace, eviction, recency, len |
| R02 extension (Claim-A, 2026-09-21) | FR-010 | recency refresh on overwrite (A8) |
| R03 | FR-001, FR-011, FR-012 | maxsize validation, atomic replacement, one slot per value |
| Preservation | FR-013 | existing APIs unchanged; built on LRUCache |
| R04 (milestone 2) | FR-014, FR-015, FR-016 | invalidate_many any/all, empty=zero, fail-fast |
| R05 (milestone 2) | FR-017, FR-018 | resize validation, LRU shrink, grow, maxsize property |
| R05 clarification (round 2, 2026-09-22) | FR-019 | absolute-expiry preservation (binding when R07/R08 land; A10) |
| R06 (milestone 2) | FR-020, FR-021 | generator tags consumed once; repeated detachment |
| R07 (milestone 3) | FR-022, FR-023, FR-024, FR-025 | timer default, ttl semantics, invalid TTL, boundary |
| R08 (milestone 3) | FR-026, FR-027, FR-028 | purge-before-operation, expiry replacement, live-only counts, back-compat |
| Conflicting design note | A9 | superseded by R04/R05; MUST NOT be relied upon |
