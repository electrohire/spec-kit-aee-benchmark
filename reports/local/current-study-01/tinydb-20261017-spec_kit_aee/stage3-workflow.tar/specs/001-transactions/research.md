# Research: Atomic Batch Transactions for TinyDB

**Date**: 2026-10-17 | **Phase**: 0 (Outline & Research)

All NEEDS CLARIFICATION items from the Technical Context were resolved
against the inspected source (evidence refs in parentheses). No unknowns
remain.

## R1. Where is the default table state, and how is it persisted?

- **Decision**: The default table `_default` is one entry in the storage
  payload: `storage.read() -> {table_name: {doc_id: doc}}` (or `None` for an
  empty db). All table mutations go through `Table._update_table`, which
  does a full read-modify-write of that payload (evidence: 419a1205, table.py
  lines 787-834; 5ff4ec30, storages.py `MemoryStorage.read/write`;
  3f0a5a01, database.py `default_table_name = '_default'`).
- **Rationale**: A batch can therefore be made atomic by snapshotting the
  complete payload once (`db.storage.read()`, `None`-safe) before applying,
  and restoring it on error. Restoring the payload restores the *complete*
  pre-batch default-table data (R02), and because `Table` reads storage on
  every operation, previously acquired `db.table('_default')` handles observe
  the restored state (R02).
- **Alternatives considered**:
  - *In-memory staging then one final write*: fewer storage round-trips, but
    it would bypass `Table._update_table`'s per-op validation (duplicate-ID
    check) and would need to re-implement doc-ID assignment; rejected as
    larger surface and more divergence from ordinary TinyDB behavior (Principle
    IV).
  - *Monkey-patching `Table`/`Storage`*: rejected - violates Principle I
    (no behavior change to existing APIs) and is fragile.
  - *Using `Table.remove(doc_ids=[...])` directly for removes*: rejected - it
    *silently skips* missing IDs (evidence: e4589338, table.py remove
    docstring/implementation), but R02 requires a missing-ID remove to be an
    error. BatchWriter must check existence itself before each remove.

## R2. How are document IDs assigned, and what must rollback restore?

- **Decision**: `Table._get_next_id` keeps a per-handle cursor
  (`Table._next_id`): after computing `max_id + 1` it stores
  `self._next_id = next_id + 1` (evidence: 419a1205, table.py lines 727-758).
  Snapshot and restore `table._next_id` around the batch.
- **Rationale**: After a rolled-back insert, the cursor would otherwise be
  advanced, so the next *successful* insert would skip an ID (e.g. 1 then 3
  instead of 1 then 2). Restoring the cursor keeps ID assignment identical to
  the no-batch sequence. Restoring it also keeps a previously acquired
  handle's behavior consistent with the rolled-back storage state (R02).
- **Alternatives considered**: Recomputing the cursor lazily (set
  `_next_id = None`) - simpler, but changes observable ID sequences vs the
  pre-batch state; rejected in favor of exact restore.

## R3. How do previously acquired table handles observe state?

- **Decision**: `TinyDB.table(name)` caches handles in `self._tables` and
  returns the same instance (evidence: b30165a6, database.py lines 111-131).
  Every `Table` data operation re-reads storage (`_read_table` / `_update_table`),
  but `Table.search` consults `_query_cache` (LRU) which is only cleared by
  `_update_table` (evidence: 419a1205 line 837 `self.clear_cache()`; c5eae2f0
  shows `update` flows; e4589338 remove flows). `BatchWriter.apply` performs
  all writes through `table._update_table`, so each applied op clears the
  cache of the *same* cached handle; on success the final op's cache clear
  leaves the handle fresh.
- **Rationale**: No handle manipulation is needed for success (cache is
  already cleared by the last `_update_table`) or rollback (storage restored
  + cache cleared by the last applied op). An empty batch applies no ops, so
  no stale-cache risk exists. `apply` still defensively clears the cache of
  the default handle after success to make the guarantee explicit and
  robust to future refactors.
- **Alternatives considered**: Replacing `db._tables[name]` with a fresh
  `Table` - rejected: changes identity of previously acquired handles
  (violates R02's "previously acquired handles must reflect" - they must be
  the *same* handles, now correct).

## R4. Insert copy semantics (no aliasing, R03)

- **Decision**: `Table.insert` stores `dict(document)` - a *shallow* copy
  (evidence: 419a1205, table.py insert updater). Nested mappings/lists are
  therefore shared between the stored document and the caller's input. The
  batch must deep-copy: insert `copy.deepcopy(document)` and deep-copy the
  stored document when building the returned ID->document view.
- **Rationale**: R03 requires both directions: mutating the caller's input
  after `apply` must not change the db (deep-copy at insert time), and the
  returned data must not alias the db (deep-copy on return). Deep-copying the
  *stored* state for the return value also protects the rollback snapshot
  from being mutated by callers who keep the returned objects.
- **Alternatives considered**: Shallow copy + documentation - rejected: fails
  the nested-data clause of R03. Copy-on-write wrappers - rejected: more
  complexity than needed (Principle IV).

## R5. Operation validation rules (R01)

- **Decision**: Validate *all* operations before applying *any* (two-phase:
  validate, then apply sequentially). An operation is valid iff it is a
  `dict` with exactly the keys `{'op','document'}` and `op == 'insert'` and
  `document` is a `Mapping` (not a `str`/`bytes`), or exactly
  `{'op','doc_id'}` and `op == 'remove'` and `doc_id` is a positive `int`
  with `doc_id > 0` (bools rejected: `bool` is an `int` subclass but
  `True`/`False` are not positive integers in the domain sense). Any other
  shape raises `ValueError` before any write.
- **Rationale**: R01 says unknown/malformed operations raise `ValueError`;
  validating first makes malformed input fail with *no* side effects, which
  is the only reading consistent with R02's atomicity ("validate and apply
  sequentially, but on any error restore"). The strict-shape rule (extra
  fields rejected) is recorded as an assumption in spec.md.
- **Alternatives considered**: Validate lazily per op during apply - rejected:
  a malformed op at position k would leave ops 1..k-1 applied before the
  error (partial state), contradicting atomicity. Accepting extra fields -
  rejected: unspecified; strict is the safer, documented choice.

## R6. Error propagation and rollback trigger

- **Decision**: `apply` raises `ValueError` for malformed ops (pre-apply) and
  for a `remove` whose `doc_id` is absent from the current table state
  (checked at apply time, since earlier ops in the same batch may have
  created/removed documents). Any other exception raised during apply
  (e.g. storage failure, duplicate-ID `ValueError` from `Table.insert`) also
  triggers rollback and is re-raised unchanged.
- **Rationale**: R02: "a remove targeting a missing ID is an error" and "on
  any error restore the complete pre-batch default-table data". Re-raising
  the original exception preserves type/message for callers and for
  `acceptance_public.py` (`pytest.raises(ValueError)`).
- **Alternatives considered**: Swallowing errors and returning partial IDs -
  rejected: violates R01/R02. Wrapping in a custom exception - rejected:
  acceptance expects `ValueError`.

## R7. Testing approach

- **Decision**: New `tests/test_journal.py` (pytest, matches `tests/` style)
  covering: R01 (returns, ordering, empty, every malformed shape), R02
  (rollback of inserts, removes, mixed; missing-ID remove; pre-acquired
  handle reflects success *and* rollback; ID-cursor restore), R03 (ordinary
  API coexistence, deep-copy both directions, post-apply mutation of caller
  ops). Run `acceptance_public.py` plus the full upstream `tests/` to prove
  no regression (Constitution I/II/III).
- **Rationale**: Upstream tests must remain unchanged; a new file is the
  minimal additive change. `acceptance_public.py` is the public contract.
- **Alternatives considered**: Extending `tests/test_tables.py` - rejected:
  upstream tests must remain unchanged.
