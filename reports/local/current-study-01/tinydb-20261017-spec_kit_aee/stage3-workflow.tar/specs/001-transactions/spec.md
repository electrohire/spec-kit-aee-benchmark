# Feature Specification: Atomic Batch Transactions for TinyDB

**Feature Branch**: `001-transactions`
**Created**: 2026-10-17
**Updated**: 2026-10-17 (milestones 2 and 3 plus Claim-A extensions consolidated)
**Status**: Draft
**Input**: Consolidated requirements from tinydb milestones 1-3 and the Claim-A
candidate extensions: `BatchWriter(db)` wraps a supplied TinyDB instance
(default table only) and provides an atomic `apply(operations)` with strict
structural validation, a side-effect-free `preview(operations)`, a
continuing next-insertion-ID sequence, and optional idempotency tokens for
`apply`. Ordinary TinyDB APIs and preexisting documents must keep working
unchanged.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a batch of inserts and removes atomically (Priority: P1)

A caller with a TinyDB instance supplies a batch of operations (insert a
document, or remove a document by its ID) to `BatchWriter.apply` and gets
back the list of IDs of the inserted documents, in operation order. If
every operation is valid, the default table ends up with exactly the
expected documents and the next-insertion-ID sequence continues without
reuse or rewind.

**Why this priority**: This is the core value of the feature; without it
there is nothing to use. It is independently deliverable: a caller can run
a fully valid batch and observe the resulting table.

**Independent Test**: Start from a known table state, call `apply` with a
mix of valid insert and remove operations, and verify (a) the returned ID
list matches the inserted documents in operation order, (b) the final
default table equals the pre-batch state plus inserts minus removes, (c)
subsequent direct inserts continue the ID sequence, and (d) removes
contribute no entries to the result.

**Acceptance Scenarios**:

1. **Given** an empty default table, **When** `apply` is called with
   `[]`, **Then** it returns `[]` and the table remains empty.
2. **Given** an empty default table, **When** `apply` is called with one
   insert operation, **Then** it returns a single-element list whose entry
   is the ID of the inserted document, and the table contains that
document.
3. **Given** a table containing documents with known IDs, **When** `apply`
   is called with a remove operation for an existing ID, **Then** the
document is removed and the returned list is `[]`.
4. **Given** any valid batch mixing inserts and removes, **When** `apply`
   succeeds, **Then** the returned list contains exactly the inserted IDs,
   in operation order, and the final default-table state equals the
   pre-batch state plus inserts minus removes.
5. **Given** a successful batch, **When** the caller then performs a direct
   insert on the wrapped instance, **Then** the new document receives the
   next ID in the continuing sequence (no reuse, no rewind), even if the
   batch also performed removes.
6. **Given** a successful batch, **When** the caller submits another batch
   (via `apply` or `preview`), **Then** ID assignment continues from the
   same sequence.

---

### User Story 2 - Roll back the whole batch on any error (Priority: P1)

A caller submits a batch in which some operation is invalid (unknown
operation kind, malformed fields, or a remove targeting a missing ID).
The whole batch fails: the default table is restored to its complete
pre-batch state, including documents inserted earlier in the same batch
and documents removed earlier in the same batch, and no IDs are consumed
by the failed batch.

**Why this priority**: Atomicity is the defining property of this
feature; a partial application would silently corrupt the caller's data
and defeat the purpose of batching.

**Independent Test**: Seed the table with known documents, call `apply`
with a batch that inserts, removes an existing document, and then
contains an invalid operation; verify the exception is raised, the table
equals its complete pre-batch state, and the next successful insert uses
the ID the failed batch would have used.

**Acceptance Scenarios**:

1. **Given** a non-empty default table, **When** `apply` is called with a
   batch whose last operation is a remove of a missing ID, **Then** an
   error is raised and the table equals its complete pre-batch state
   (pre-batch documents present, earlier batch inserts absent).
2. **Given** a non-empty default table, **When** `apply` is called with a
   batch whose first operation is invalid, **Then** an error is raised and
   the table is unchanged.
3. **Given** any batch that fails at operation k, **When** `apply`
   raises, **Then** the table equals the pre-batch state even though
   operations 1..k-1 were individually valid and applied.
4. **Given** a failed batch that would have inserted documents, **When**
   the caller next performs any insert, **Then** the failed batch consumed
   no IDs: the next ID equals what the failed batch's first insert would
   have received.
5. **Given** a previously acquired default-table handle, **When** a batch
   rolls back, **Then** the handle reflects the restored pre-batch state.

---

### User Story 3 - Preview a batch without any side effects (Priority: P2)

A caller asks `BatchWriter.preview(operations)` what `apply` would produce
for a batch. The preview returns the list of inserted IDs that `apply`
would return, but changes nothing: no documents are added or removed, no
IDs are consumed, and the next insertion ID is unchanged, including when
the batch is invalid. Repeated previews are independent of each other.

**Why this priority**: Preview lets callers simulate and plan batches
safely; it is a distinct, independently testable capability layered on the
same validation and ID-assignment rules as `apply`.

**Independent Test**: From a known state, call `preview` with a valid
batch and with an invalid batch; verify the returned IDs, that the table
and the next insertion ID are unchanged in both cases, that a later
`apply` of the same batch returns the same IDs, and that mutating a
previously returned preview list changes nothing.

**Acceptance Scenarios**:

1. **Given** an empty default table, **When** `preview` is called with one
   insert operation, **Then** it returns `[1]` and the table remains
   empty.
2. **Given** a table with known state, **When** `preview` is called with a
   valid mixed batch, **Then** it returns the IDs `apply` would return and
   the table state and next insertion ID are unchanged.
3. **Given** any table state, **When** `preview` is called with an invalid
   batch, **Then** it raises the same kind of error `apply` would raise
   and nothing changed, including the next insertion ID.
4. **Given** a previously returned preview list, **When** the caller
   mutates that list, **Then** subsequent `preview` results and any
   internal writer state are unaffected.
5. **Given** a `preview` call with a batch, **When** the caller then calls
   `apply` with the same batch, **Then** `apply` returns the same IDs the
   preview reported.

---

### User Story 4 - Replay a successful batch idempotently by token (Priority: P2)

A caller submits a successful batch with an idempotency token. Re-submitting
the same token with an identical batch returns the original inserted IDs
again without applying the batch a second time, even if other direct
writes happened in between. Reusing the token with different operations is
an error that changes nothing. Failed batches never claim a token.

**Why this priority**: Idempotent replay protects callers from
accidental double-submission (retries) of a batch; it is an independent,
optionally used capability.

**Independent Test**: Submit a batch with a token, submit it again (with
and without intervening direct writes), verify the same IDs are returned
and the batch applied exactly once; submit the token with different
operations and verify an error with no data change; submit a failing
batch with a fresh token, then a valid batch with the same token, and
verify the token was not consumed by the failure.

**Acceptance Scenarios**:

1. **Given** a successful `apply(ops, token=t)`, **When** `apply(ops,
   token=t)` is called again with the identical operations, **Then** the
   original inserted IDs are returned again (a detached copy) and the
   batch is not re-applied.
2. **Given** a successful tokenized batch, **When** direct database writes
   occur and then the same token/operations are resubmitted, **Then** the
   original IDs are returned and the batch is still not re-applied.
3. **Given** a token already used for a successful batch, **When** `apply`
   is called with that token but different operations, **Then** an error is
   raised and the table is unchanged.
4. **Given** a batch that fails (invalid operations or missing-ID remove)
   with a token, **Then** the token is not consumed: a later valid batch
   with the same token applies normally.
5. **Given** `apply` called with a token that is not a nonempty string
   (e.g., empty string, number, or a non-string), **Then** an error is
   raised and nothing changes.
6. **Given** a repeated successful tokenized batch, **When** the caller
   mutates the returned list, **Then** a later repeat returns the original
   IDs unchanged.

---

### User Story 5 - Coexist safely with ordinary TinyDB usage (Priority: P3)

A caller keeps using the underlying TinyDB instance normally (reads,
writes, previously acquired default-table handles) while also using a
`BatchWriter` over it. Preexisting documents remain readable; direct
writes between batch calls are seen by the wrapper; handles acquired
before a batch reflect both successes and rollbacks; and neither the
database nor the caller's data shares mutable state with the batch
operations or with token bookkeeping.

**Why this priority**: The wrapper must be transparent to existing usage
patterns; aliasing bugs, stale snapshots, or stale handles would make the
feature unsafe to adopt.

**Independent Test**: Acquire a default-table handle before calling
`apply`; run a successful batch, a direct insert, another batch, and a
failing batch; assert the handle reflects the current state in every
case; mutate the caller's operation dictionaries and returned lists after
successful calls and assert stored documents and writer state are
unaffected.

**Acceptance Scenarios**:

1. **Given** a table with preexisting documents, **When** ordinary
   reads/writes are performed around batch calls, **Then** they behave
   exactly as without the wrapper, and preexisting documents remain
   readable.
2. **Given** a default-table handle acquired before `apply`, **When** a
   batch succeeds or rolls back, **Then** the handle reflects the
   resulting state in both cases.
3. **Given** a successful `apply` with nested documents, **When** the
   caller mutates its own operation dictionaries afterwards, **Then** the
   stored documents are unchanged.
4. **Given** a successful `apply`, **When** the caller mutates the
   returned nested data, **Then** the stored documents are unchanged.
5. **Given** a successful batch, **When** the caller performs a direct
   `db.insert` and then calls `apply` or `preview` again, **Then** the
   wrapper sees the direct write (no stale initial snapshot) and IDs
   continue the sequence.
