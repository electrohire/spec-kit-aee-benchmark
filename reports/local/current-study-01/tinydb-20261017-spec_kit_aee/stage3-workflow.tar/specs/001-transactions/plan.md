# Implementation Plan: Atomic Batch Transactions for TinyDB

**Branch**: `001-transactions` | **Date**: 2026-10-17 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-transactions/spec.md`

## Summary

Add `tinydb/journal.py` with `BatchWriter(db)` (R01-R03). `apply(operations)`
validates every operation up front (strict insert/remove shape), then applies
the batch sequentially to the `_default` table through
`Table._update_table` (the existing storage-level read-modify-write path).
Before the batch, `BatchWriter` snapshots the complete pre-batch storage
state (`db.storage.read()`, `None`-safe) and the table's `_next_id` cursor;
on any error it restores both and re-raises, so the default table is
byte-for-byte back to its pre-batch state and a previously acquired
`db.table('_default')` handle observes the rollback. On success it clears the
table's query cache so pre-acquired handles observe the new state. No existing
tinydb module is modified (Constitution Principle I).

## Technical Context

**Language/Version**: Python 3.12 (verified interpreter: 3.12.14); code stays
compatible with the stdlib-only, type-hinted style of tinydb 4.9.0

**Primary Dependencies**: none (pure stdlib: `copy`, `collections.abc`,
`typing`); no new third-party packages

**Storage**: TinyDB `Storage` backends (MemoryStorage/JSONStorage); a batch's
atomic unit is the complete storage payload (`dict[table] -> dict[doc_id] ->
doc`), which is exactly what `Storage.read()`/`write()` carry

**Testing**: pytest 9.1.1 (already used by `tests/`); new file
`tests/test_journal.py`; public acceptance `acceptance_public.py`

**Target Platform**: any platform supported by CPython 3.12 (pure Python)

**Project Type**: library

**Performance Goals**: none measurable for this milestone; cost is one extra
storage read (snapshot) per batch plus the per-operation read-modify-writes
already used by ordinary TinyDB operations

**Constraints**: no new dependencies; no modification of existing public APIs
or `tests/` (upstream tests stay unchanged); default table only

**Scale/Scope**: one new module (`tinydb/journal.py`), one public class
(`BatchWriter`) with one public method (`apply`), one new test file

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

- **I. Preserve Existing Public API Behavior**: PASS. `journal.py` is purely
  additive; `BatchWriter` wraps a supplied `TinyDB` instance and never
  monkey-patches or subclasses it; ordinary reads/writes and previously
  acquired table handles keep working (verified by design: every handle
  re-reads storage per operation, and the batch clears the query cache on
  success / restores storage on rollback).
- **II. Testable Acceptance Criteria**: PASS. Every FR in spec.md has concrete
  inputs/outputs (e.g. `apply([insert {'x':1}]) == [1]`,
  `apply([insert, remove missing])` raises `ValueError` and leaves
  `[v['x'] for v in db.all()] == [1]`); `acceptance_public.py` encodes the
  public contract and `tests/test_journal.py` will cover the edge cases.
- **III. Evidence Over Assertion**: PASS (process). The implementation phase
  must record exact commands and outputs (pytest runs, acceptance run) in
  `HANDOFF.md`; no "done" without evidence.
- **IV. Simple, Scoped Implementations**: PASS. Smallest change: one module,
  one class, one method; no configuration knobs, no context manager, no
  multi-table support, no speculative abstractions.
- **V. Documented Assumptions and Regressions**: PASS. Assumptions live in
  `spec.md` (Assumptions) and `research.md`; `HANDOFF.md` tracks open items
  and regressions (none known at plan time).

**Gate result: PASS** - no violations, Complexity Tracking not required.

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── batchwriter-api.md
└── tasks.md             # Phase 2 output ($speckit-tasks command - NOT created by $speckit-plan)
```

### Source Code (repository root)

```text
tinydb/
├── journal.py        # NEW: BatchWriter (atomic batch apply on _default table)
├── database.py       # unchanged (TinyDB, table registry, storage access)
├── table.py          # unchanged (Table._update_table used as apply path)
├── storages.py       # unchanged (Storage.read/write carry the snapshot)
└── ...               # all other modules unchanged

tests/
└── test_journal.py   # NEW: unit + integration tests for BatchWriter (R01-R03)

acceptance_public.py  # existing public acceptance suite (unchanged)
```

**Structure Decision**: Single-project layout (default). The new module is
placed inside the package as `tinydb/journal.py` exactly as mandated by the
milestone (importable as `tinydb.journal.BatchWriter`), and tests follow the
existing `tests/test_*.py` convention. No new directories, no new packages.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

Not applicable - Constitution Check passed with no violations.
