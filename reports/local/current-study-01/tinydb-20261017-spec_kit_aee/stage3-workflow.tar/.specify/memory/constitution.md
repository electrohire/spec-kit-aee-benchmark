<!--
Sync Impact Report (temporary scratch for human review; remove before committing)
- Version change: (unversioned template) -> 1.0.0
- Modified principles: none renamed; initial ratification adds five principles
  - PRINCIPLE_1 placeholder -> I. Preserve Existing Public API Behavior
  - PRINCIPLE_2 placeholder -> II. Testable Acceptance Criteria
  - PRINCIPLE_3 placeholder -> III. Evidence Over Assertion
  - PRINCIPLE_4 placeholder -> IV. Simple, Scoped Implementations
  - PRINCIPLE_5 placeholder -> V. Documented Assumptions and Regressions
- Added sections: Project Context (Milestone 1), Development Workflow
- Removed sections: none
- Follow-up TODOs: none
-->
# tinydb Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
New components MUST wrap existing public APIs without changing their
behavior. Ordinary `TinyDB` reads/writes and previously acquired
table handles MUST continue to work exactly as before. Any intended
change to a public signature or semantic MUST be stated explicitly in
the spec and handoff notes; silent behavior drift is a defect.
Rationale: Milestone 1 adds `tinydb.journal.BatchWriter(db)` around a
supplied `TinyDB` instance; the ordinary TinyDB APIs are the contract
this work must not break.

### II. Testable Acceptance Criteria
Every requirement MUST carry at least one testable acceptance criterion:
a concrete input, a concrete expected output, or a concrete observable
state. Requirements without an observable check MUST be rejected or
refined before implementation begins. Acceptance is judged against the
public acceptance suite (`acceptance_public.py`) plus project tests.
Rationale: Verifiable criteria keep the autonomous workflow auditable
and prevent "done" claims that cannot be checked.

### III. Evidence Over Assertion
Claims about system behavior MUST be labeled as observed evidence
(command run, output, or test result) or as unverified assertions. A
claim of tests passing requires the exact command and its output. No
evidence, no claim: unresolved or unverified items MUST be recorded
explicitly rather than implied.
Rationale: In an autonomous benchmark, unverified assertions are the
main source of false completion; evidence discipline makes gaps
visible.

### IV. Simple, Scoped Implementations
Implementations MUST be the smallest change that satisfies the
approved requirements. No speculative abstractions, configuration
knobs, or new dependencies beyond the stated scope. Complexity beyond
the requirement MUST be justified in the handoff notes; otherwise it
MUST be removed.
Rationale: The milestone is a single `BatchWriter` class in
`tinydb/journal.py`; scope creep risks breaking the preserved APIs
required by Principle I.

### V. Documented Assumptions and Regressions
Unresolved assumptions, open questions, and any regressions observed
during the work MUST be written into the handoff notes (e.g.
`HANDOFF.md`) with the evidence or absence of evidence noted. A phase
MUST NOT close while a known regression is undocumented or
unmitigated.
Rationale: Later phases run without conversation history; only written
notes carry assumptions and regressions forward.

## Project Context (Milestone 1)
- Project: tinydb, a lightweight pure-Python document database with no
  external dependencies.
- Milestone 1 deliverable: `tinydb.journal.BatchWriter(db)` wrapping a
  supplied `TinyDB` instance, operating on the default table only
  (`_default`), with atomic batch `apply(operations)` semantics.
- Feature directory: `/testbed/specs/001-transactions`.
- Implementation source: `tinydb/journal.py`.
- Public acceptance: `acceptance_public.py`; upstream tests in `tests/`
  MUST remain unchanged.
- Application implementation is deferred to later phases; this phase
  establishes governance only.

## Development Workflow
- Follow the Spec Kit phase order: constitution -> specify -> plan ->
  tasks -> implement -> converge; each phase completes with a done
  action that references its artifacts.
- Run tests with `PYTHONPATH=src:.` from `/testbed`; record the exact
  command and output as evidence (Principle III).
- Do not modify upstream tests or `acceptance_public.py`;
  project-authored tests live in the feature directory or `tests/`
  additions.
- Keep `HANDOFF.md` current; it is the only reliable cross-phase memory
  (Principle V).

## Governance
- This constitution supersedes all other conflicting practices and
  guidance for this project.
- Amendments: edit `.specify/memory/constitution.md`, update the Sync
  Impact Report, bump the version per the policy below, and update the
  date fields (ISO `YYYY-MM-DD`).
- Versioning policy (semantic):
  - MAJOR: removal or redefinition of a principle.
  - MINOR: new principle or materially expanded section.
  - PATCH: clarifications, wording, or typo fixes.
- Compliance review: every phase MUST verify its deliverable against
  all five principles before closing; violations MUST be fixed or
  documented as regressions (Principle V).

**Version**: 1.0.0 | **Ratified**: 2026-10-17 | **Last Amended**: 2026-10-17
