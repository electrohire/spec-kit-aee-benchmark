# Feature Specification: Atomic Batch Transactions for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "Build tinydb.journal.BatchWriter(db), wrapping a supplied TinyDB instance without changing its ordinary APIs. Use the default table only. apply(operations) accepts a list of operation dictionaries (insert/remove), returns inserted document IDs, and is atomic: on any error the complete pre-batch default-table data is restored. Ordinary TinyDB reads/writes and preexisting documents continue to work; inserted and returned nested data must not alias the caller's input."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a batch of inserts and removes atomically (Priority: P1)

A caller with a TinyDB instance supplies a batch of operations (insert a
document, or remove a document by its ID) to `BatchWriter.apply` and
gets back the list of IDs of the documents that were inserted, in
operation order. If every operation is valid, the default table ends up
with exactly the expected documents.

**Why this priority**: This is the core value of the feature; without it
there is nothing to use. It is independently deliverable: a caller can
run a fully valid batch and observe the resulting table.

**Independent Test**: Start from a known table state, call `apply` with a
mix of valid insert and remove operations, and verify (a) the returned
ID list matches the inserted documents in order, (b) the default table
contains exactly the expected documents afterwards, and (c) removes
contribute no entries to the returned list.

**Acceptance Scenarios**:

1. **Given** an empty default table, **When** `apply` is called with
   `[]`, **Then** it returns `[]` and the table remains empty.
2. **Given** an empty default table, **When** `apply` is called with one
   insert operation, **Then** it returns a single-element list whose
   entry is the ID of the inserted document, and the table contains
   that document.
3. **Given** a table containing documents with known IDs, **When**
   `apply` is called with a remove operation for an existing ID, **Then**
   the document is removed and the returned list is `[]`.
4. **Given** any valid batch mixing inserts and removes, **When**
   `apply` succeeds, **Then** the returned list contains exactly the
   inserted IDs, in operation order, and the final default-table state
   equals the pre-batch state plus inserts minus removes.

---

### User Story 2 - Roll back the whole batch on any error (Priority: P1)

A caller submits a batch in which some operation is invalid (unknown
operation kind, malformed fields, or a remove targeting a missing ID).
The whole batch fails: the default table is restored to its complete
pre-batch state, including documents inserted earlier in the same batch
and documents removed earlier in the same batch.

**Why this priority**: Atomicity is the defining property of this
feature; a partial application would silently corrupt the caller's data
and defeat the purpose of batching. It is independently testable with a
batch whose later operation is invalid.

**Independent Test**: Seed the table with known documents, call `apply`
with a batch that inserts, removes an existing document, and then
contains an invalid operation; verify the exception is raised and the
table is byte-for-byte identical to the pre-batch state.

**Acceptance Scenarios**:

1. **Given** a non-empty default table, **When** `apply` is called with a
   batch whose last operation is a remove of a missing ID, **Then** an
   error is raised and the table equals its complete pre-batch state
   (pre-batch documents present, earlier batch inserts absent).
2. **Given** a non-empty default table, **When** `apply` is called with a
   batch whose first operation is invalid, **Then** an error is raised
   and the table is unchanged.
3. **Given** any batch that fails at operation k, **When** `apply`
   raises, **Then** the table equals the pre-batch state even though
   operations 1..k-1 were individually valid and applied.

---

### User Story 3 - Reject malformed input with a clear error (Priority: P2)

A caller passes an operation that is not a well-formed insert or remove
(unknown operation kind, missing/extra/invalid fields, wrong types, or a
non-integer/non-positive document ID). The batch is rejected with a
`ValueError` and the table is left unchanged.

**Why this priority**: Clear, consistent rejection of bad input protects
callers from silent misbehavior; it is a correctness guarantee layered
on top of the core flow.

**Independent Test**: For each malformed shape, call `apply` with a
single-element batch, assert `ValueError` is raised, and assert the
table state is unchanged.

**Acceptance Scenarios**:

1. **Given** any table state, **When** `apply` receives an operation with
   an unknown `op` value, **Then** `ValueError` is raised and the table
   is unchanged.
2. **Given** any table state, **When** an insert operation lacks a
   `document` field, its `document` is not a mapping, or an extra
   unknown field is present, **Then** `ValueError` is raised and the
   table is unchanged.
3. **Given** any table state, **When** a remove operation lacks a
   `doc_id`, its `doc_id` is not an integer, is not positive, or an
   extra unknown field is present, **Then** `ValueError` is raised and
   the table is unchanged.
4. **Given** any table state, **When** `apply` receives a non-list
   argument or a batch element that is not a mapping, **Then**
   `ValueError` is raised and the table is unchanged.

---

### User Story 4 - Coexist safely with ordinary TinyDB usage (Priority: P2)

A caller keeps using the underlying TinyDB instance normally (reads,
writes, previously acquired default-table handles) while also using a
`BatchWriter` over it. Preexisting documents remain readable; handles
acquired before a batch reflect both successful batches and rollbacks;
and neither the database nor the caller's data shares mutable state
with the batch operations.

**Why this priority**: The wrapper must be transparent to existing usage
patterns; aliasing bugs or stale handles would make the feature unsafe
to adopt.

**Independent Test**: Acquire a default-table handle before calling
`apply`; run a successful batch and a failing batch; assert the handle
reflects the current state in both cases; mutate the caller's operation
dictionaries after a successful `apply` and assert the stored documents
are unaffected.

**Acceptance Scenarios**:

1. **Given** a table with preexisting documents, **When** ordinary
   reads/writes are performed around batch calls, **Then** they behave
   exactly as without the wrapper, and preexisting documents remain
   readable.
2. **Given** a default-table handle acquired before `apply`, **When** a
   batch succeeds or rolls back, **Then** the handle reflects the
   resulting state (new documents visible after success; rolled-back
   state visible after failure).
3. **Given** a successful `apply` with nested documents, **When** the
   caller mutates its own operation dictionaries afterwards, **Then**
   the stored documents are unchanged.
4. **Given** a successful `apply`, **When** the caller mutates the
   returned nested data, **Then** the stored documents are unchanged.

---

### Edge Cases

- Empty batch: returns `[]`, table unchanged.
- Batch of only removes (all existing IDs): returns `[]`, documents
  removed.
- Remove of a missing ID: error; full rollback (User Story 2).
- Insert followed by remove of that same inserted ID within one batch:
  both apply in order; the inserted ID is still reported in the result
  and the document is not present afterwards.
- Duplicate removes of the same existing ID in one batch: the first
  remove succeeds, the second targets a now-missing ID and errors; full
  rollback.
- Non-list `operations` argument (e.g., a string or a single dict):
  `ValueError`.
- Batch element that is not a mapping (e.g., a string or list):
  `ValueError`.
- `doc_id` of type boolean: `ValueError` (booleans are not accepted as
  document IDs).
- `doc_id` of zero, negative, or non-integer numeric: `ValueError`.
- `document` that is not a mapping (e.g., a list or string): `ValueError`.
- Nested documents (dicts/lists inside the document): accepted; stored
  and returned as independent copies.
- Extra unknown keys in an operation mapping: `ValueError` (strict
  shape).
- Operations list containing `None` elements: `ValueError`.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST provide a `BatchWriter` component that
  wraps a supplied TinyDB instance and operates on the default table
  only; it MUST NOT alter the ordinary APIs of the wrapped instance.
- **FR-002**: `BatchWriter.apply(operations)` MUST accept a list of
  operation mappings. Each operation MUST be exactly one of: an insert,
  `{'op': 'insert', 'document': <mapping>}`, or a remove,
  `{'op': 'remove', 'doc_id': <positive integer>}`.
- **FR-003**: On success, `apply` MUST return a list containing exactly
  the IDs of the inserted documents, in operation order; remove
  operations MUST contribute no entries to the result.
- **FR-004**: `apply([])` MUST return `[]` and MUST leave the table
  unchanged.
- **FR-005**: `apply` MUST raise `ValueError` for unknown or malformed
  operations: unknown `op` values; insert operations with a missing
  `document`, a non-mapping `document`, or extra unknown fields; remove
  operations with a missing `doc_id`, a non-integer or non-positive
  `doc_id` (booleans rejected), or extra unknown fields; a non-list
  `operations` argument; or a batch element that is not a mapping.
- **FR-006**: Batch application MUST be atomic: operations are validated
  and applied sequentially, and on any error the complete pre-batch
  default-table data MUST be restored, including undoing inserts and
  removes that succeeded earlier in the same batch.
- **FR-007**: A remove targeting a missing document ID MUST be treated
  as an error and MUST trigger the FR-006 rollback.
- **FR-008**: Previously acquired default-table handles MUST reflect both
  successful batches and rolled-back batches (no stale cached state).
- **FR-009**: Ordinary TinyDB reads and writes, and preexisting
  documents, MUST continue to work unchanged while a `BatchWriter` is in
  use.
- **FR-010**: Inserted documents and returned data MUST NOT alias the
  caller's input: mutating the caller's operation mappings after a
  successful `apply` MUST NOT mutate the stored documents, and mutating
  the returned nested data MUST NOT mutate the stored documents.

### Key Entities *(include if feature involves data)*

- **Batch**: an ordered list of operations submitted to a single `apply`
  call; the unit of atomicity.
- **Insert operation**: the operation kind that adds one document
  (a mapping) to the default table and yields a new document ID.
- **Remove operation**: the operation kind that deletes one document by
  its positive integer ID from the default table.
- **Document ID**: the unique integer identifier assigned to a document
  in the table; positive integers only.
- **Document**: a mapping of fields; MAY contain nested mappings and
  lists.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of valid batches (including the empty batch) are
  applied fully: the returned ID list matches the inserted documents in
  order, and the final default-table state equals the pre-batch state
  plus inserts minus removes.
- **SC-002**: 100% of invalid batches (malformed operations, unknown
  kinds, missing-ID removes) raise an error and leave the default table
  exactly equal to its pre-batch state, with zero partial changes.
- **SC-003**: 100% of ordinary TinyDB operations performed around batch
  calls behave identically to the unmodified instance, and preexisting
  documents remain readable (no regressions in existing behavior).
- **SC-004**: 0 aliasing defects: after any successful batch, mutating
  caller-side operation data or returned data never changes stored
  documents, verified for nested structures.

## Assumptions

- The wrapped TinyDB instance is supplied by the caller; `BatchWriter`
  does not create, open, or persist storage itself and does not change
  how the instance is constructed.
- "Default table" means the table named `_default` (the instance's
  default table); other tables are out of scope and MUST NOT be touched
  by `apply`.
- "Positive integer" for `doc_id` excludes booleans, zero, negatives,
  and non-integer numbers; IDs are the integers assigned by the table.
- "Mapping" for `document` means a key/value mapping; documents are
  stored as independent deep copies of the caller's input.
- Strict operation shape is required: extra unknown fields in an
  operation mapping are malformed and rejected.
- "On any error" in FR-006 covers the operation-level errors defined by
  FR-005 and FR-007 (and any other error raised while applying a
  batch); the guarantee is that the default table is restored to its
  complete pre-batch state regardless of which operation failed.
- Results of remove operations are not reported; only inserted IDs are
  returned.
- Concurrency, persistence across process restarts, and transactions on
  non-default tables are out of scope for this milestone.
- Public acceptance is judged by `acceptance_public.py`; upstream tests
  remain unchanged and are used as regression evidence.
