"""
This module provides :class:`BatchWriter`, a small batch/journal layer on
top of an existing :class:`~tinydb.TinyDB` instance.

It does not modify the wrapped database's ordinary APIs; it simply applies
lists of operations to the database's *default* table in an atomic way.
"""

import copy
from collections.abc import Mapping
from typing import Any, Optional

from .database import TinyDB

__all__ = ('BatchWriter',)


class BatchWriter:
    """
    Apply batches of operations to a TinyDB default table atomically.

    A ``BatchWriter`` wraps an existing :class:`~tinydb.TinyDB` instance
    and exposes a single :meth:`apply` method that takes a list of
    operation dictionaries::

        writer = BatchWriter(db)
        doc_ids = writer.apply([
            {'op': 'insert', 'document': {'x': 1}},
            {'op': 'remove', 'doc_id': 1},
        ])

    The batch is applied sequentially. If any operation fails (for
    example a remove targeting a document ID that does not exist), the
    complete pre-batch state of the default table is restored before the
    error is re-raised, so a batch either fully succeeds or has no
    effect at all.
    """

    #: The set of operation names understood by :meth:`apply`
    _KNOWN_OPS = ('insert', 'remove')

    def __init__(self, db: TinyDB) -> None:
        """
        Create a batch writer for the given database.

        :param db: the TinyDB instance to wrap
        """
        self._db = db
        self._table_name = db.default_table_name

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    @classmethod
    def _validate_operation(cls, operation: Any) -> None:
        """
        Validate a single operation dictionary.

        Raises :class:`ValueError` if the operation is malformed.
        """

        if not isinstance(operation, Mapping):
            raise ValueError(
                'Each operation must be a dict, got {!r}'.format(
                    type(operation).__name__
                )
            )

        op = operation.get('op')
        if op not in cls._KNOWN_OPS:
            raise ValueError(
                'Unknown operation {!r}; expected one of {}'.format(
                    op, list(cls._KNOWN_OPS)
                )
            )

        if op == 'insert':
            if 'document' not in operation:
                raise ValueError("'insert' operation requires a 'document' key")
            document = operation['document']
            if not isinstance(document, Mapping):
                raise ValueError(
                    "'insert' operation 'document' must be a dict, got "
                    '{!r}'.format(type(document).__name__)
                )
        elif op == 'remove':
            if 'doc_id' not in operation:
                raise ValueError("'remove' operation requires a 'doc_id' key")
            doc_id = operation['doc_id']
            if isinstance(doc_id, bool) or not isinstance(doc_id, int):
                raise ValueError(
                    "'remove' operation 'doc_id' must be a positive integer, "
                    'got {!r}'.format(doc_id)
                )
            if doc_id <= 0:
                raise ValueError(
                    "'remove' operation 'doc_id' must be a positive integer, "
                    'got {!r}'.format(doc_id)
                )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def apply(self, operations: list) -> list[int]:
        """
        Apply a batch of operations to the default table atomically.

        Supported operations:

        - ``{'op': 'insert', 'document': <dict>}`` -- insert a new
          document; its ID is appended to the returned list.
        - ``{'op': 'remove', 'doc_id': <positive int>}`` -- remove the
          document with the given ID; the ID must exist, otherwise the
          whole batch is rolled back.

        :param operations: a list of operation dictionaries
        :returns: a list of the IDs of all documents inserted by this
            batch (in insertion order); removes do not add results
        :raises ValueError: if any operation is malformed or if a remove
            targets a missing document ID
        """

        if not isinstance(operations, list):
            raise ValueError(
                'operations must be a list of operation dicts, got {!r}'.format(
                    type(operations).__name__
                )
            )

        # Validate the whole batch up front so that no partial state is
        # ever created for syntactically invalid batches.
        for operation in operations:
            self._validate_operation(operation)

        table = self._db.table(self._table_name)

        # Snapshot the complete database state (which includes the
        # default table) before touching anything. A deep copy is used
        # so that later mutations of the live data cannot affect the
        # snapshot.
        snapshot = copy.deepcopy(self._db.storage.read())

        # Remember the table's internal ID counter so it can be restored
        # on rollback.
        prev_next_id = table._next_id

        inserted_ids: list[int] = []

        try:
            for operation in operations:
                if operation['op'] == 'insert':
                    # Deep-copy the document so neither the database nor
                    # the returned data can alias the caller's input.
                    document = copy.deepcopy(dict(operation['document']))

                    doc_id = table._get_next_id()

                    def _insert_updater(
                        t: dict, _id: int = doc_id, _doc: dict = document
                    ) -> None:
                        if _id in t:
                            raise ValueError(
                                'Document with ID {} already exists'.format(_id)
                            )
                        t[_id] = _doc

                    table._update_table(_insert_updater)
                    inserted_ids.append(doc_id)

                else:  # operation['op'] == 'remove'
                    doc_id = operation['doc_id']

                    def _remove_updater(t: dict, _id: int = doc_id) -> None:
                        if _id not in t:
                            raise ValueError(
                                'Document with ID {} does not exist'.format(_id)
                            )
                        del t[_id]

                    table._update_table(_remove_updater)
        except Exception:
            # Roll back to the complete pre-batch state.
            self._rollback(snapshot)

            # Restore the table's internal ID counter so that future
            # inserts continue from the pre-batch ID sequence.
            table._next_id = prev_next_id

            # Make sure previously acquired table handles see the
            # rolled-back state (their query caches may still hold
            # results computed from the failed batch).
            table.clear_cache()

            raise

        # On success, previously acquired handles must reflect the new
        # state. Table reads always go through the storage, but the query
        # cache may still hold stale results.
        table.clear_cache()

        return inserted_ids

    # ------------------------------------------------------------------
    # Rollback
    # ------------------------------------------------------------------

    def _rollback(self, snapshot: Optional[dict]) -> None:
        """
        Restore the default table to its pre-batch state.

        :param snapshot: a deep copy of the database data taken before
            the batch was applied (may be ``None`` for an empty database)
        """

        current = self._db.storage.read()
        if current is None:
            current = {}

        # Determine whether the default table existed before the batch.
        if snapshot is None or self._table_name not in snapshot:
            # It did not exist: remove it from the current data.
            current.pop(self._table_name, None)
            if not current:
                # Write an empty dict rather than None: storages are not
                # guaranteed to accept ``None``.
                self._db.storage.write({})
            else:
                self._db.storage.write(current)
        else:
            # It existed: restore its pre-batch contents.
            current[self._table_name] = copy.deepcopy(
                snapshot[self._table_name]
            )
            self._db.storage.write(current)
