"""
This module provides :class:`BatchWriter`, a small batch/journal layer on
top of an existing :class:`~tinydb.TinyDB` instance.

It does not modify the wrapped database's ordinary APIs; it simply applies
lists of operations to the database's *default* table in an atomic way.
"""

import copy
import hashlib
from collections.abc import Mapping
from typing import Any, Optional

from .database import TinyDB

__all__ = ('BatchWriter',)


class BatchWriter:
    """
    Apply batches of operations to a TinyDB default table atomically.

    A ``BatchWriter`` wraps an existing :class:`~tinydb.TinyDB` instance
    and exposes an :meth:`apply` method that takes a list of operation
    dictionaries::

        writer = BatchWriter(db)
        doc_ids = writer.apply([
            {'op': 'insert', 'document': {'x': 1}},
            {'op': 'remove', 'doc_id': 1},
        ])

    as well as a :meth:`preview` method that simulates a batch and returns
    the IDs that ``apply`` would produce without changing any data or
    consuming any IDs.

    The batch is applied sequentially. If any operation fails (for
    example a remove targeting a document ID that does not exist), the
    complete pre-batch state of the default table is restored before the
    error is re-raised, so a batch either fully succeeds or has no
    effect at all.

    .. note::

        A previously generated note claimed that ``preview`` may consume
        IDs and that boolean document IDs are accepted. That note is
        superseded: ``preview`` never consumes IDs (see
        :meth:`preview`) and boolean ``doc_id`` values are rejected
        because ``bool`` is a subclass of ``int`` but not a valid
        document ID.
    """

    #: The set of operation names understood by :meth:`apply`
    _KNOWN_OPS = ('insert', 'remove')

    def __init__(self, db: TinyDB) -> None:
        """
        Create a batch writer for the given database.

        :param db: the TinyDB instance to wrap
        """
        self._db = db
        self._table_name = db.default_table_name
        # Idempotency-token bookkeeping (R07/R08).  This state
        # belongs to *this* BatchWriter instance only; it is never
        # written into the database or into user documents.
        #
        # Maps token -> (fingerprint of the operation list, list
        # of the inserted IDs returned by the successful batch).
        self._tokens = {}

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    @classmethod
    def _validate_operation(cls, operation: Any) -> None:
        """
        Structurally validate a single operation dictionary.

        This happens *before* any change is committed, so malformed
        batches can never leave partial state behind.

        Raises :class:`ValueError` if the operation is malformed.
        """

        if not isinstance(operation, Mapping):
            raise ValueError(
                'Each operation must be a dict, got {!r}'.format(
                    type(operation).__name__
                )
            )

        op = operation.get('op')
        if op not in cls._KNOWN_OPS:
            raise ValueError(
                'Unknown operation {!r}; expected one of {}'.format(
                    op, list(cls._KNOWN_OPS)
                )
            )

        if op == 'insert':
            if 'document' not in operation:
                raise ValueError("'insert' operation requires a 'document' key")
            document = operation['document']
            if not isinstance(document, Mapping):
                raise ValueError(
                    "'insert' operation 'document' must be a dict, got "
                    '{!r}'.format(type(document).__name__)
                )
        elif op == 'remove':
            if 'doc_id' not in operation:
                raise ValueError("'remove' operation requires a 'doc_id' key")
            doc_id = operation['doc_id']
            # ``bool`` is a subclass of ``int`` but is explicitly not a
            # valid document ID.
            if isinstance(doc_id, bool) or not isinstance(doc_id, int):
                raise ValueError(
                    "'remove' operation 'doc_id' must be a positive integer, "
                    'got {!r}'.format(doc_id)
                )
            if doc_id <= 0:
                raise ValueError(
                    "'remove' operation 'doc_id' must be a positive integer, "
                    'got {!r}'.format(doc_id)
                )

    @classmethod
    def _validate_operations(cls, operations: Any) -> None:
        """
        Structurally validate a whole batch of operations.

        Raises :class:`ValueError` for non-list input or for any
        malformed operation. No state is modified.
        """

        if not isinstance(operations, list):
            raise ValueError(
                'operations must be a list of operation dicts, got {!r}'.format(
                    type(operations).__name__
                )
            )
        for operation in operations:
            cls._validate_operation(operation)

    @classmethod
    def _validate_token(cls, token: Optional[str]) -> None:
        """
        Validate an idempotency token (R07).

        ``None`` means a normal, non-idempotent operation and is
        always valid.  Any other token must be a *nonempty
        string*; anything else raises :class:`ValueError`.
        """

        if token is None:
            return
        if not isinstance(token, str) or not token:
            raise ValueError(
                'Idempotency token must be a nonempty string, got '
                '{!r}'.format(token)
            )

    @staticmethod
    def _fingerprint(operations: list) -> str:
        """
        Compute a stable fingerprint of an operation list.

        The fingerprint is used to decide whether a token is being
        re-used with the *identical* batch (R07).  It is based on a
        canonical JSON serialisation of the (already structurally
        validated) operations, so structurally equal batches
        produce equal fingerprints.
        """

        import json

        return hashlib.sha256(
            json.dumps(operations, sort_keys=True,
                       separators=(',', ':')).encode('utf-8')
        ).hexdigest()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def preview(self, operations: list) -> list[int]:
        """
        Simulate a batch and return the IDs ``apply`` would produce.

        The simulation is performed on a detached copy of the current
        table data: no data is written, no document IDs are consumed,
        and no caches are touched. In particular, a preview does not
        change the next ID that a subsequent insert (via ``apply`` or
        via a direct ``db.insert``) will receive, even if the previewed
        batch errors out.

        The returned list is a new, detached list on every call; mutating
        a previously returned list has no effect on later previews or on
        any internal writer state.

        :param operations: a list of operation dictionaries (same format
            as for :meth:`apply`)
        :returns: a new list of the IDs that a successful ``apply`` of
            the same operations would return
        :raises ValueError: if any operation is malformed or if a remove
            targets a missing document ID
        """

        # Validate structurally before touching anything.
        self._validate_operations(operations)

        table = self._db.table(self._table_name)

        # Work on a deep copy of the current table data so that the real
        # table (and its query cache) is never touched.
        data = self._db.storage.read()
        raw = data.get(self._table_name, {}) if data else {}
        # Storage may keep document IDs as strings (e.g. JSON file);
        # normalise them to integers for the simulation.
        sim = {int(k): copy.deepcopy(v) for k, v in raw.items()}

        # Determine the next ID exactly like the table handle would
        # (see ``Table._get_next_id``), without modifying the handle's
        # counter: use the handle's cached counter when available,
        # otherwise fall back to the maximum ID currently in use.
        if table._next_id is not None:
            next_id = table._next_id
        else:
            next_id = max(sim) + 1 if sim else 1

        inserted_ids: list[int] = []
        for operation in operations:
            if operation['op'] == 'insert':
                sim[next_id] = copy.deepcopy(dict(operation['document']))
                inserted_ids.append(next_id)
                next_id += 1
            else:  # operation['op'] == 'remove'
                doc_id = operation['doc_id']
                if doc_id not in sim:
                    raise ValueError(
                        'Document with ID {} does not exist'.format(doc_id)
                    )
                del sim[doc_id]

        # Return a fresh, detached list.
        return list(inserted_ids)

    def apply(self, operations: list) -> list[int]:
        """
        Apply a batch of operations to the default table atomically.

        Supported operations:

        - ``{'op': 'insert', 'document': <dict>}`` -- insert a new
          document; its ID is appended to the returned list.
        - ``{'op': 'remove', 'doc_id': <positive int>}`` -- remove the
          document with the given ID; the ID must exist, otherwise the
          whole batch is rolled back.

        A successful batch advances the table's next-insertion-ID state
        (which is persisted via the underlying storage), so subsequent
        inserts -- via ``apply`` or direct ``db.insert`` -- continue the
        ID sequence without reuse or rewind, even across remove
        operations. A failed batch consumes no IDs.

        :param operations: a list of operation dictionaries
        :returns: a new list of the IDs of all documents inserted by
            this batch (in insertion order); removes do not add results
        :raises ValueError: if any operation is malformed or if a remove
            targets a missing document ID
        """

        # Validate the whole batch structurally up front so that no
        # partial state is ever created for invalid batches.
        self._validate_operations(operations)

        table = self._db.table(self._table_name)

        # Snapshot the complete database state (which includes the
        # default table) before touching anything. A deep copy is used
        # so that later mutations of the live data cannot affect the
        # snapshot.
        snapshot = copy.deepcopy(self._db.storage.read())

        # Remember the table's internal ID counter so it can be restored
        # on rollback.
        prev_next_id = table._next_id

        inserted_ids: list[int] = []

        try:
            for operation in operations:
                if operation['op'] == 'insert':
                    # Deep-copy the document so neither the database nor
                    # the returned data can alias the caller's input.
                    document = copy.deepcopy(dict(operation['document']))

                    doc_id = table._get_next_id()

                    def _insert_updater(
                        t: dict, _id: int = doc_id, _doc: dict = document
                    ) -> None:
                        if _id in t:
                            raise ValueError(
                                'Document with ID {} already exists'.format(_id)
                            )
                        t[_id] = _doc

                    table._update_table(_insert_updater)
                    inserted_ids.append(doc_id)

                else:  # operation['op'] == 'remove'
                    doc_id = operation['doc_id']

                    def _remove_updater(t: dict, _id: int = doc_id) -> None:
                        if _id not in t:
                            raise ValueError(
                                'Document with ID {} does not exist'.format(_id)
                            )
                        del t[_id]

                    table._update_table(_remove_updater)
        except Exception:
            # Roll back to the complete pre-batch state.
            self._rollback(snapshot)

            # Restore the table's internal ID counter so that future
            # inserts continue from the pre-batch ID sequence (a failed
            # batch must not consume IDs).
            table._next_id = prev_next_id

            # Make sure previously acquired table handles see the
            # rolled-back state (their query caches may still hold
            # results computed from the failed batch).
            table.clear_cache()

            raise

        # On success the table's ``_next_id`` now points past all IDs
        # used by this batch. ``_update_table`` already persisted the
        # table data (which determines the next ID for a fresh table
        # handle), and the in-memory counter keeps the live handle in
        # sync, so subsequent inserts -- via ``apply`` or direct
        # ``db.insert`` -- continue the sequence without reuse or
        # rewind.

        # Previously acquired handles must reflect the new state. Table
        # reads always go through the storage, but the query cache may
        # still hold stale results.
        table.clear_cache()

        # Return a fresh, detached list.
        return list(inserted_ids)

    # ------------------------------------------------------------------
    # Rollback
    # ------------------------------------------------------------------

    def _rollback(self, snapshot: Optional[dict]) -> None:
        """
        Restore the default table to its pre-batch state.

        :param snapshot: a deep copy of the database data taken before
            the batch was applied (may be ``None`` for an empty database)
        """

        current = self._db.storage.read()
        if current is None:
            current = {}

        # Determine whether the default table existed before the batch.
        if snapshot is None or self._table_name not in snapshot:
            # It did not exist: remove it from the current data.
            current.pop(self._table_name, None)
            if not current:
                # Write an empty dict rather than None: storages are not
                # guaranteed to accept ``None``.
                self._db.storage.write({})
            else:
                self._db.storage.write(current)
        else:
            # It existed: restore its pre-batch contents.
            current[self._table_name] = copy.deepcopy(
                snapshot[self._table_name]
            )
            self._db.storage.write(current)
