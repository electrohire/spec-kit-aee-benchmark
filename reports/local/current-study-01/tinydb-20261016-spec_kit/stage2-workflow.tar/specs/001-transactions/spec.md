# Feature Specification: Atomic Batch Transactions for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Updated (milestone 2 + Claim-A extensions active)

**Input**: User description: "Build tinydb.journal.BatchWriter(db), wrapping a supplied TinyDB instance without changing its ordinary APIs. Use the default table only. R01: apply(operations) accepts a list of operation dictionaries ({'op':'insert','document':dict} or {'op':'remove','doc_id':positive integer}); return a list of inserted document IDs (removes add no result); empty input returns []; unknown/malformed operations raise ValueError. R02: Batch application is atomic: validate and apply sequentially, but on any error restore the complete pre-batch default-table data; a remove targeting a missing ID is an error; previously acquired db.table('_default') handles must reflect both success and rollback. R03: Ordinary TinyDB reads/writes and preexisting documents continue to work; inserted and returned nested data must not alias the caller's input; mutating an operation after apply cannot mutate the database."

Input (milestone 2, active): "R04: Reject bool as a doc_id even though bool is an int subclass. Validate operations structurally before committing changes; raise ValueError for unsupported fields, non-list operations, or non-dict documents. Accept empty dictionaries as documents. R05: Add preview(operations), returning the inserted IDs that apply would produce but leaving all data and the next insertion ID unchanged, including on errors. Preview and failed apply must not consume IDs. Existing table handles and query caches must remain coherent. R06: Compatibility: direct db.insert operations between calls must be seen by the wrapper. Do not cache a stale initial snapshot." R01-R03 remain active unless explicitly replaced (none replaced).

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a batch of insert and remove operations (Priority: P1)

A developer wraps an existing TinyDB database with the batch writer and submits a list of operations. Each operation is either an insert (carrying a document) or a remove (carrying a document ID). The operations are validated and applied in order to the default table, and the developer receives the IDs of the inserted documents, in submission order. Removes contribute no result.

**Why this priority**: This is the core value of the feature; without it the feature does not exist.

**Independent Test**: Create a database, apply a batch of inserts and removes, and assert on the returned IDs and the resulting default-table contents. This alone delivers a usable, if non-atomic, MVP.

**Acceptance Scenarios**:

1. **Given** an empty database, **When** `apply([{'op':'insert','document':{'a':1}}, {'op':'insert','document':{'b':2}}])` is called, **Then** it returns the two new document IDs in submission order and the default table contains both documents.
2. **Given** a database containing a document with a known ID, **When** `apply([{'op':'remove','doc_id':<that ID>}])` is called, **Then** it returns `[]` and the document is no longer present.
3. **Given** any database, **When** `apply([])` is called, **Then** it returns `[]` and the table is unchanged.
4. **Given** a database, **When** a batch mixes inserts and removes, **Then** only inserted IDs are returned, in the order the inserts appeared.

---

### User Story 2 - Fail atomically and restore pre-batch state (Priority: P1)

A developer submits a batch in which a later operation is malformed or targets a missing document. The whole batch must have no net effect: the default table is restored to exactly its pre-batch contents, including any documents inserted earlier in the same failed batch, and a `ValueError` is raised.

**Why this priority**: Atomicity is the defining property of a transaction; without it the feature is unsafe to use.

**Independent Test**: Pre-populate a database, apply a batch that fails partway (missing `doc_id` or malformed operation), and assert the table equals the pre-batch snapshot and that `ValueError` was raised.

**Acceptance Scenarios**:

1. **Given** a pre-existing document, **When** `apply([insert, remove of a missing ID])` is called, **Then** a `ValueError` is raised and the table contains only the pre-existing document (the earlier insert is rolled back).
2. **Given** pre-existing documents, **When** `apply([remove of an existing ID, remove of a missing ID])` is called, **Then** a `ValueError` is raised and the removed pre-existing document is restored.
3. **Given** a handle to the default table acquired before the batch, **When** a batch succeeds or rolls back, **Then** the handle reflects the post-batch (or restored) data.

---

### User Story 3 - Preserve ordinary database behavior and data independence (Priority: P2)

A developer continues to use the wrapped database normally (ordinary reads, writes, pre-existing documents) while also using the batch writer. Data passed into, or returned from, a batch never shares identity with the database's stored data, so later mutation on either side cannot corrupt the other.

**Why this priority**: Guarantees the wrapper is transparent and safe; required for trust, but secondary to the P1 apply/rollback flows.

**Independent Test**: Read and write via the ordinary API around batches; mutate a caller's input document after `apply` and assert the database is unchanged; mutate a returned or copied stored document and assert the database is unchanged.

**Acceptance Scenarios**:

1. **Given** pre-existing documents and ordinary reads/writes, **When** a batch is applied, **Then** ordinary behavior is unaffected and pre-existing documents remain readable and writable.
2. **Given** a batch containing nested documents, **When** `apply` returns and the caller then mutates the input operation's document, **Then** the database contents are unchanged.
3. **Given** a batch containing nested documents, **When** the caller mutates a returned document or a copy of stored data, **Then** no aliasing exists: neither mutation affects the other or the database.

---

### User Story 4 - Preview a batch without side effects (Priority: P1)

A developer wants to know what document IDs a batch of inserts would produce before committing it. The batch writer exposes a preview capability that computes exactly the IDs `apply` would return, but changes nothing: no documents are added or removed, the next insertion ID is not consumed, and an invalid batch raises `ValueError` with zero side effects.

**Why this priority**: Preview is the safety mechanism that makes non-atomic inspection of batches possible; without it callers cannot plan ID-dependent work.

**Independent Test**: Call preview on a batch, assert the returned IDs match what a later `apply` of the same batch returns, and assert the table contents and ID sequencing are unchanged by the preview, including when the preview raises.

**Acceptance Scenarios**:

1. **Given** an empty database, **When** `preview([{'op':'insert','document':{}}])` is called, **Then** it returns `[1]` and the table is still empty.
2. **Given** a database whose next insertion ID would be N, **When** `preview` of a batch inserting K documents is called, **Then** it returns the K IDs starting at N, and a subsequent `apply` of the same batch returns the same K IDs (the preview consumed nothing).
3. **Given** any database, **When** `preview` is called with a malformed batch or a batch containing a remove of a missing ID, **Then** a `ValueError` is raised and the table, the next insertion ID, and all handles are unchanged.
4. **Given** a previously returned preview list, **When** the caller mutates it, **Then** subsequent `preview` calls and internal state are unaffected (each preview returns a new, detached list).

---

### User Story 5 - Keep ID sequencing coherent across interleaved ordinary writes (Priority: P2)

A developer mixes ordinary TinyDB writes with batch writes. The batch writer must always see the database's current state, and successful batches must keep the ID sequence moving forward so that neither the wrapper nor ordinary `insert` ever reuses or rewinds an ID, even across removes.

**Why this priority**: Correct sequencing under mixed use is required for trust in any real workload; it is secondary to the core apply/preview/rollback flows.

**Independent Test**: Insert directly, apply a batch, insert directly again, and assert the IDs continue monotonically with no reuse; repeat after a batch that removes documents.

**Acceptance Scenarios**:

1. **Given** a database where an ordinary insert just used ID 1, **When** a batch inserting two documents is applied, **Then** the batch returns IDs 2 and 3 (the wrapper saw the direct insert; no stale snapshot).
2. **Given** a successful batch that inserted and removed documents, **When** further inserts happen via `apply` or ordinary `insert`, **Then** IDs continue from the highest ID ever assigned in the default table (no reuse, no rewind).
3. **Given** a failed batch, **When** the next insert happens, **Then** the failed batch did not consume any IDs.

---

### Edge Cases

- **Malformed operations**: a non-dict entry, an unknown `op` value, a missing `document`/`doc_id` field, a `doc_id` that is not a positive integer, or a non-dict `document` must each raise `ValueError` and roll back the whole batch.
- **Missing target**: a `remove` whose `doc_id` does not exist in the default table is an error (`ValueError`) and triggers rollback.
- **Empty batch**: `apply([])` returns `[]` and leaves the table untouched.
- **Interleaved use**: ordinary TinyDB reads/writes performed before, between, or after batches must continue to work against the same default table.
- **Nested data**: documents containing nested dicts/lists must be stored and returned as independent copies.
- **Pre-existing handles**: a `db.table('_default')` handle acquired before a batch must observe both successful application and rollback.
- **Bool IDs**: `True`/`False` are not valid document IDs even though they are integer subclasses; they must raise `ValueError`.
- **Unsupported fields**: operations carrying fields beyond `op`/`document`/`doc_id` (or `document` on a remove, `doc_id` on an insert) are malformed and raise `ValueError` before any change is committed.
- **Non-list input**: passing a non-list to `apply`/`preview` raises `ValueError`.
- **Empty document**: `{'op':'insert','document':{}}` is a valid insert.
- **Preview purity**: preview never mutates data, never advances the next insertion ID, and returns a fresh detached list each call.
- **Failed apply sequencing**: a rolled-back batch must not consume or reserve any document IDs.
- **Interleaved direct inserts**: ordinary `db.insert` between batch calls must be reflected in the IDs the wrapper assigns next.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST provide a batch writer that wraps a supplied TinyDB database instance and operates on the default table only, without changing the database's ordinary public behavior.
- **FR-002**: The batch writer MUST expose an `apply` capability that accepts a list of operation dictionaries, where each operation is either `{'op':'insert','document':<document>}` or `{'op':'remove','doc_id':<positive integer>}`. A non-list input MUST be rejected with `ValueError`.
- **FR-003**: `apply` MUST validate and apply the operations sequentially and MUST return a list containing only the IDs of inserted documents, in submission order; removes MUST add no result; empty input MUST return `[]`.
- **FR-004**: `apply` MUST raise `ValueError` for unknown or malformed operations (non-dict entry, unknown `op`, missing `document`/`doc_id`, non-positive-integer `doc_id`, non-dict `document`). `bool` values MUST be rejected as `doc_id` even though they are integer subclasses. Operations MUST be validated structurally before any change is committed: unsupported fields (fields beyond `op`/`document`/`doc_id`, or `document` on a remove / `doc_id` on an insert), non-list operation inputs, and non-dict documents MUST each raise `ValueError`. An empty dictionary MUST be accepted as a document.
- **FR-004a**: The batch writer MUST expose a `preview` capability that returns the list of inserted document IDs that `apply` of the same operations would produce, without changing any table data, without consuming or advancing the next insertion ID, and without affecting existing table handles or query caches; on any error it MUST raise `ValueError` with zero side effects. Each `preview` call MUST return a new, detached list: mutating a previously returned preview list MUST NOT affect subsequent preview results or any internal state.
- **FR-004b**: A successful `apply` MUST advance the wrapper's next-insertion-ID state by the number of documents inserted in the batch and MUST persist that state to the underlying table so that subsequent inserts - via `apply` or via ordinary `db.insert` - continue the ID sequence without reuse or rewind, even across remove operations. A failed `apply` MUST NOT consume any IDs.
- **FR-004c**: The batch writer MUST observe the database's current state on every call: ordinary `db.insert` operations performed between calls MUST be seen by the wrapper, and no stale initial snapshot MAY be cached.
- **FR-005**: Batch application MUST be atomic: on any error during the batch, the complete pre-batch default-table data MUST be restored, including undoing inserts applied earlier in the same batch.
- **FR-006**: A `remove` targeting a document ID that does not exist in the default table MUST be treated as an error and MUST trigger rollback.
- **FR-007**: Handles to the default table acquired before a batch MUST reflect both successful application and rollback.
- **FR-008**: Ordinary TinyDB reads and writes, and pre-existing documents, MUST continue to work unchanged while the batch writer is in use.
- **FR-009**: Inserted data and returned data MUST NOT alias the caller's input; mutating an operation after `apply` MUST NOT mutate the database, and mutating returned or stored nested data MUST NOT affect the caller's input or the database.

### Key Entities *(include if feature involves data)*

- **Operation**: A single unit of batch work. Either an insert (carries a document to add) or a remove (carries the ID of a document to delete). Validated structurally before the batch is applied; only the fields `op`, `document` (insert) and `doc_id` (remove) are supported; `doc_id` must be a positive integer and `bool` is not a valid ID.
- **Batch**: An ordered list of operations submitted together. Applied as a unit: either all of its effects persist or none do.
- **Document**: A JSON-like data object stored in the default table, identified by a unique positive integer ID. May contain nested structures.
- **Default table**: The single named table the batch writer reads and writes; the only table in scope for this feature.
- **Next insertion ID**: The sequence position for the next document ID in the default table. Advanced by successful batches and by ordinary inserts; never consumed by preview or failed batches; never reused or rewound.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of well-formed batches apply completely and return exactly the inserted document IDs in order, with the default table reflecting every operation.
- **SC-002**: 100% of batches containing any error (malformed operation or missing remove target) leave the default table byte-for-byte identical to its pre-batch state, and raise `ValueError`.
- **SC-003**: 100% of ordinary TinyDB reads/writes and pre-existing documents behave identically with and without the batch writer in use.
- **SC-004**: Zero observable aliasing: mutating caller input after `apply`, or mutating returned/stored nested data, never changes the database or the other side (verified by dedicated tests).
- **SC-005**: The public acceptance suite (`acceptance_public.py`) and the unchanged upstream test suite both pass, with evidence recorded.
- **SC-006**: 100% of preview calls leave table data and the next insertion ID exactly as they were (including when preview raises), and each preview returns a fresh list whose mutation cannot affect later results.
- **SC-007**: 100% of ID sequences observed across mixed ordinary/batch usage are strictly monotonic with no reuse or rewind, including across removes and after failed batches.
- **SC-008**: 100% of structurally malformed inputs (bool IDs, unsupported fields, non-list operations, non-dict documents) are rejected with `ValueError` before any change is committed; empty-dictionary documents are accepted.

## Assumptions

- The batch writer wraps an already-constructed TinyDB database; it does not create, open, or configure storage.
- Only the default table is in scope; other tables are neither read nor modified by the batch writer.
- Document IDs are the positive integers assigned by the database on insert; the batch writer does not accept caller-chosen IDs.
- Atomicity is scoped to the default table's data; no cross-table or cross-database transactions are implied.
- The feature is additive: it does not alter any existing TinyDB public API or behavior.
- Validation of the whole operation list occurs before any mutation; the observable contract is that a single `ValueError` is raised and the pre-batch state is restored.
- Document IDs are assigned by the database's own sequence; the wrapper's job is to keep that sequence coherent (advance it on successful batches, persist it to the table, never consume it in preview or failed batches), not to choose IDs.
- `preview` is a read-only computation over the current table state plus the batch; it shares no state with the caller's returned list.

## Conflicting Evidence - Resolved

- **Conflict**: An older generated note claimed "preview may consume IDs and bool IDs are accepted".
- **Resolution**: That note is unverified and is **superseded** by the current requirements R04/R05 (FR-004, FR-004a): preview MUST NOT consume IDs and MUST leave all state unchanged, and `bool` MUST be rejected as a `doc_id`. Any implementation or test relying on the older note is invalid.
- **Note**: A previously passing happy-path smoke test does not verify these boundaries (preview purity, bool rejection, sequencing across removes); dedicated tests for each boundary are required (see success criteria SC-006..SC-008).
