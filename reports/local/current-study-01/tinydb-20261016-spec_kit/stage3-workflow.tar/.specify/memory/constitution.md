<!-- Sync Impact Report (temporary scratch; remove before committing the amended constitution)
  Version change: (unversioned template) -> 1.0.0
  Modified principles:
    [PRINCIPLE_1..5 placeholders] -> I. Preserve Existing Public API Behavior;
    II. Testable Acceptance Criteria; III. Evidence Over Assertion;
    IV. Simple Scoped Implementations; V. Documented Assumptions and Regressions
  Added sections: Additional Constraints; Development Workflow
  Removed sections: none
  Follow-up TODOs: none
-->
# TinyDB Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
New functionality MUST be additive: it wraps or extends existing components
without changing the behavior of existing TinyDB public APIs (TinyDB, Table,
Query, operators, storages, middlewares). Existing upstream tests MUST pass
unchanged. Any proposed change to existing public behavior MUST be rejected
or explicitly documented as a breaking change with a migration note.

Rationale: TinyDB is a library consumed by downstream code; silent behavior
changes are regressions by definition.

### II. Testable Acceptance Criteria
Every requirement MUST state observable, testable acceptance criteria:
concrete inputs, outputs, and error behavior. A requirement that cannot be
verified by a test is incomplete and MUST be refined before implementation.
Acceptance evidence MUST come from running `acceptance_public.py` and the
project's own tests, not from reasoning alone.

Rationale: Requirements such as R01-R03 of the current milestone are the
reference style: each names inputs, outputs, and failure modes.

### III. Evidence Over Assertion
Claims about behavior MUST distinguish observed evidence (command output,
test results) from unverified assertions. Test results MUST NOT be claimed
without the command that produced them. Unverified claims MUST be labeled as
assumptions or hypotheses.

Rationale: In an autonomous workflow, unverifiable claims are the primary
source of false completion reports.

### IV. Simple Scoped Implementations
Implementations MUST be minimal and scoped to the stated requirement.
Speculative features, abstractions, and dependencies are prohibited (YAGNI).
A change MUST touch only the files its requirement names (for the current
milestone: `tinydb/journal.py` and its own tests) unless a defect forces
otherwise, and any such forcing MUST be documented.

### V. Documented Assumptions and Regressions
Unresolved assumptions, regressions, and known gaps MUST be recorded in
`HANDOFF.md` or the phase notes, each with the evidence that motivated it.
A phase MUST NOT be marked complete while a known regression or unresolved
assumption is left undocumented.

## Additional Constraints

- Language and runtime: Python, as supported by this repository's
  `pyproject.toml`; no new runtime dependencies.
- Implementation source for the current milestone: `tinydb/journal.py`
  (`tinydb.journal.BatchWriter`), default table only.
- Public acceptance gate: `acceptance_public.py`; upstream tests in `tests/`
  MUST remain unchanged.
- Workflow artifacts live in `/testbed` (`.specify/`, `specs/001-transactions`);
  implementation source root is `/testbed` (`PYTHONPATH=src:.` if needed).

## Development Workflow

- Work proceeds in Spec Kit phases (constitution -> specify -> plan ->
  tasks -> implement/analyze); application implementation is deferred out of
  the constitution phase.
- Quality gates before a phase is marked done: (1) own tests pass with
  `pytest`; (2) `acceptance_public.py` passes; (3) upstream tests remain
  unchanged and pass; (4) evidence (commands + outputs) is recorded.
- Notes and handoff state are kept in `HANDOFF.md`; documents stay concise
  and evidence-explicit.

## Governance

This constitution supersedes all other project practices and guidance. Its
principles are non-negotiable; per-phase exceptions MUST be recorded in
`HANDOFF.md` with rationale. Amendments require: an updated Sync Impact
Report, a semantic version bump (MAJOR for principle removal/redefinition,
MINOR for added principles or materially expanded guidance, PATCH for
clarifications), updated dates, and a compliance review of in-flight work
against the amended text. Compliance is reviewed at every phase boundary.

**Version**: 1.0.0 | **Ratified**: 2026-10-17 | **Last Amended**: 2026-10-17
