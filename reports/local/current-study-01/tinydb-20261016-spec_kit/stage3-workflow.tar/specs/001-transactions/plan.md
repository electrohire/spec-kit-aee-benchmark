# Implementation Plan: Atomic Batch Transactions for TinyDB

**Branch**: `001-transactions` | **Date**: 2026-10-17 (updated for milestone 3) | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/testbed/specs/001-transactions/spec.md` (milestones 1-3 + Claim-A extensions; R01-R08 all active)

## Summary

Add `tinydb.journal.BatchWriter`, a thin wrapper around a supplied `TinyDB` instance that applies batches of insert/remove operations on the **default table only**, atomically (all-or-nothing with full snapshot/rollback), with a side-effect-free `preview`, coherent ID sequencing across interleaved ordinary writes, strict structural validation (bools rejected as IDs, unsupported fields rejected, empty dicts accepted), and per-instance idempotency tokens that let a successful batch be replayed safely. Purely additive: no existing `tinydb` module, upstream test, or `acceptance_public.py` is modified.

## Technical Context

**Language/Version**: Python 3.12 (observed `python3 --version` -> `Python 3.12.14`).

**Primary Dependencies**: stdlib only (`copy.deepcopy`, `collections.abc.Mapping`, `functools`). The in-repo `tinydb` package (observed `tinydb/{database,table,storages}.py`).

**Storage**: whatever the supplied `TinyDB` uses (tests use `MemoryStorage`; `acceptance_public.py` uses it too). The writer only calls the table's existing public API plus the table's storage through the table (never opens files). Key observed internals (`tinydb/table.py`): `Table._get_next_id()` (line 727) computes next ID from `max(table.keys())` when `self._next_id is None`, else from the cursor; `Table._update_table()` (line 790) does a full storage read-modify-write and calls `clear_cache()`; `Table.remove(doc_ids=...)` silently skips missing IDs (line 608) - so the writer must check existence itself; `Table.insert()` shallow-copies via `dict(document)` (line 137) - so the writer deep-copies; `TinyDB.table()` caches Table instances in `self._tables` (observed `database.py` line 98/127), so previously acquired handles are the same objects the writer uses.

**Testing**: pytest (`python3 -m pytest -o addopts="" ...`; repo `pytest.ini` addopts reference `pytest-cov`, which is **not installed**, so `addopts` must be overridden). Public acceptance: `acceptance_public.py` (unchanged; imports `from tinydb.journal import BatchWriter`).

**Target Platform**: Any platform supported by this repository (pure Python library).

**Project Type**: library (in-repo module `tinydb/journal.py`)

**Performance Goals**: No numeric goals. Constraint: one full-table deep copy per batch (snapshot) plus one extra storage write on failure (rollback); token bookkeeping is a small per-instance dict. Acceptable for a correctness-first wrapper.

**Constraints**: Additive only (Constitution I); upstream tests in `tests/` unchanged; `acceptance_public.py` is the public gate; default table only; single `ValueError` type for all validation/atomicity/token failures.

**Scale/Scope**: One new module (`tinydb/journal.py`, ~150-200 lines incl. docstrings) plus one new test file; no changes to existing modules.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution: `.specify/memory/constitution.md` (v1.0.0). Gates evaluated against it:

- **I. Preserve Existing Public API Behavior - PASS.** Design adds a new module only; `tinydb/__init__.py`, `database.py`, `table.py`, `storages.py`, and all existing tests are untouched. Evidence: `grep -rn "journal" tinydb/ tests/` returns no matches (module does not exist yet; verified 2026-10-17); plan touches only `tinydb/journal.py` + new tests.
- **II. Testable Acceptance Criteria - PASS.** Every FR-001..FR-011 maps to named tests in `contracts/batch-writer.md` (T01-T24) and `quickstart.md` scenarios; `acceptance_public.py` read in full and verified to target exactly this module.
- **III. Evidence Over Assertion - PASS (process rule).** Plan records observed evidence (commands + outputs) for every repository fact; implementation phase must record test command outputs before claiming done.
- **IV. Simple Scoped Implementations - PASS.** One module, stdlib only, no new abstractions; no speculative features (no cross-table, no caller-chosen IDs, no context-manager sugar, no token persistence).
- **V. Documented Assumptions and Regressions - PASS.** Open questions resolved in `research.md`; remaining assumptions carried in spec.md (incl. token-scope assumptions).

**Gate result: PASS - no violations, no Complexity Tracking entries required.**

### Post-Design Re-Check (after Phase 1)

- **I. PASS (re-confirmed).** Zero changes to existing modules. All rollback/sequencing behavior is implemented inside `tinydb/journal.py` using only the table's public API (`insert`, `remove(doc_ids=...)`, `all()`, `clear_cache()`) and the table's storage read/write path; the only private attribute touched is the table's own `_next_id` cursor (reset to `None`, the same value `truncate()` uses), an internal reset, not an API change.
- **II. PASS (re-confirmed).** Contract T01-T24 + quickstart S1-S7 give every FR (FR-001..FR-011) a runnable check, including all milestone-2/3 boundaries (preview purity, bool rejection, unsupported fields, ID sequencing across removes, token replay/mismatch/failure/invalid).
- **III. PASS (re-confirmed).** All repository facts in research.md cite observed command output; quickstart records the pre-implementation baseline (`223 passed`) and the failing-collection state of the acceptance gate as evidence anchors.
- **IV. PASS (re-confirmed).** One new module, stdlib `copy`/`functools` only; alternatives (undo log, re-insert restore, storage transaction API, persisted token log) rejected with rationale in research.md.
- **V. PASS (re-confirmed).** Research resolved all open questions (R1-R12); remaining assumptions in spec.md; no regressions expected (additive-only).

**Post-design gate result: PASS.**

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
|-- plan.md              # This file ($speckit-plan command output)
|-- research.md          # Phase 0 output ($speckit-plan command)
|-- data-model.md        # Phase 1 output ($speckit-plan command)
|-- quickstart.md        # Phase 1 output ($speckit-plan command)
|-- contracts/           # Phase 1 output ($speckit-plan command)
|   `-- batch-writer.md  # Public API contract for tinydb.journal.BatchWriter
`-- tasks.md             # Phase 2 output ($speckit-tasks command - NOT created by $speckit-plan)
```

### Source Code (repository root)

```text
tinydb/
|-- __init__.py          # unchanged (BatchWriter imported directly from tinydb.journal)
|-- database.py          # unchanged (TinyDB)
|-- table.py             # unchanged (Table, Document)
|-- storages.py          # unchanged (Storage, MemoryStorage, JSONStorage)
`-- journal.py           # NEW: BatchWriter (this feature)

tests/
|-- conftest.py          # unchanged
|-- test_*.py            # unchanged upstream tests
`-- test_journal.py      # NEW: own tests for BatchWriter (R01-R08)

acceptance_public.py     # unchanged public acceptance gate
```

**Structure Decision**: Single-project layout (existing repository). The feature is one additive module inside the existing `tinydb` package plus one additive test file. `acceptance_public.py` imports `tinydb.journal` directly, so the module must be importable as `tinydb.journal`; keeping `__init__.py` unchanged is the lowest-risk choice and satisfies Constitution I.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

No violations - section intentionally empty.
