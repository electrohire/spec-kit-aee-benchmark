# Research: Atomic Batch Transactions for TinyDB (milestones 1-3)

**Feature**: 001-transactions | **Date**: 2026-10-17 (updated for milestone 3)

All repository facts below cite observed command output (run 2026-10-17 in `/testbed`).

## R1. Rollback mechanism: snapshot + storage write + cache clear

- **Decision**: Before any mutation, take `deepcopy` of the raw default-table data (`table._read_table()` shape: `dict[int->str keys, Mapping]`). On error: restore via the table's storage path (read full DB state, replace the `'_default'` entry with the snapshot, `storage.write(...)`), then `table.clear_cache()` and `table._next_id = None`.
- **Rationale**: Observed `tinydb/table.py`: `_update_table()` (line 790) performs a full storage read-modify-write and calls `clear_cache()`; `truncate()` (line 681) also resets `self._next_id = None`. `TinyDB.table()` caches Table instances in `self._tables` (observed `database.py` line 98/127), so a previously acquired handle is the *same* object the writer uses - clearing its cache covers the writer's handle and any user handle. `MemoryStorage.write` replaces `self.memory` wholesale (observed `storages.py`), so no stale state survives.
- **Alternatives considered**: *Fresh Table instance per batch* - rejected: user-held old handles would point at a different object; the spec requires **previously acquired** handles to reflect the result. *Undo log* - rejected: more code, same observable behavior. *Re-insert restore* - rejected: would consume IDs (violates R05/R02 sequencing).

## R2. ID sequencing across interleaved ordinary writes and removes (R05 clarification, R06)

- **Decision**: Do **not** cache an initial snapshot of the table or of the ID cursor. For each batch, read the current table at batch start (`table._read_table()`), compute the batch's starting ID as `max(keys)+1` (or 1 if empty), and assign sequential IDs to inserts in submission order. After a successful batch, set `table._next_id = last_inserted_id + 1` (or leave `None` if the batch inserted nothing) so the Table's own cursor continues the sequence. On rollback, set `table._next_id = None` so the next insert re-derives from the restored max ID.
- **Rationale**: Observed `_get_next_id()` (line 727): when `self._next_id is None` it reads the table and uses `max(keys)+1`; otherwise it uses/increments the cursor. Because the writer assigns IDs explicitly (it does not call `table.insert(document)` for ID assignment - see R3), the Table's cursor would not know about batch inserts unless the writer syncs it; writing `_next_id` back is exactly the "wrapper writes that state back to the underlying table" requirement. Direct `db.insert` between calls goes through the same cursor, so both paths continue one sequence. Removing documents never lowers `_next_id`, so no reuse/rewind across removes.
- **Alternatives considered**: *Call `table.insert()` and let it assign IDs* - rejected: `insert()` shallow-copies (`dict(document)`, line 137), violating R03 no-aliasing for nested data; and on rollback the consumed cursor would leak IDs. *Store the writer's own cursor in a hidden document* - rejected: R08 forbids bookkeeping in user documents; a hidden table is out of scope (default table only).

## R3. No-aliasing of inserted/returned nested data (R03)

- **Decision**: Deep-copy each insert document before storing (`deepcopy(document)`); deep-copy the snapshot (R1) and the restored snapshot on rollback. `apply` returns only `int` IDs (immutable), so the return value cannot alias caller data; `preview` returns `list(range(start, start+n))` built fresh on each call (R05b).
- **Rationale**: `Table.insert` only does `table[doc_id] = dict(document)` (observed) - a **shallow** copy, so nested dicts/lists would still alias the caller's input. A `deepcopy` before insert breaks the link in both directions. Reading documents back through the Table API always constructs fresh `Document` objects from raw storage data, so reads are already alias-free.
- **Alternatives considered**: *`json` round-trip* - rejected: not safe for non-JSON values; *manual recursive copy* - rejected: `copy.deepcopy` is stdlib and complete.

## R4. Exact validation semantics (R01 + R04)

- **Decision**: Structural validation of the **whole** operation list happens before any mutation. Per entry: must be a `dict` (else `ValueError`); must contain exactly the known keys for its op - `{'op','document'}` for insert, `{'op','doc_id'}` for remove; any other/missing key -> `ValueError` (R04 "unsupported fields"). `op` must be exactly `'insert'` or `'remove'`. `document` must be a `Mapping` and not a `bool`; **empty dicts are accepted** (R04). `doc_id` must be an `int` with `isinstance(doc_id, bool)` explicitly rejected, and `> 0`. The outer `operations` must be a `list` (non-list -> `ValueError`, R04). A remove whose `doc_id` is absent from the *current* table at apply time -> `ValueError` (R02) and rollback.
- **Rationale**: R04 (milestone 2) explicitly tightens R01: "raise ValueError for unsupported fields, non-list operations, or non-dict documents. Accept empty dictionaries as documents." and "Reject bool as a doc_id even though bool is an int subclass." (Note: an earlier draft of research.md said "extra keys are ignored" - that was superseded by R04 and is corrected here.)
- **Alternatives considered**: *Ignore extra keys* - rejected: superseded by R04. *Accept `bool` IDs* - rejected: explicitly superseded per the conflicting-evidence resolution in spec.md.

## R5. Preview purity and detachment (R05, R05b)

- **Decision**: `preview(operations)` validates exactly like `apply` (same structural rules, same missing-ID check against current state) but performs **no** mutation: it computes the starting ID from the current table (`max(keys)+1` or 1) and returns a **new list** of the IDs the inserts would get, in submission order. It never touches `table._next_id`, never writes storage, never records tokens, and on any error raises `ValueError` with all state (data, next insertion ID, query caches) unchanged. Each call returns a fresh list object; mutating a previously returned list cannot affect later results or internal state (R05b).
- **Rationale**: R05: "returning the inserted IDs that apply would produce but leaving all data and the next insertion ID unchanged, including on errors. Preview and failed apply must not consume IDs. Existing table handles and query caches must remain coherent." R05b (Claim-A): "preview must return a new, detached list on every call."
- **Alternatives considered**: *Run the batch on a shadow table* - rejected: overkill; IDs depend only on `max(keys)+1`, a pure computation. *Cache preview results* - rejected: R05b requires a fresh list per call and forbids aliasing.

## R6. Test environment specifics

- **Decision**: Run tests with `python3 -m pytest -o addopts="" <paths>` from `/testbed`. Public gate: `python3 -m pytest -o addopts="" acceptance_public.py`.
- **Rationale**: Observed: `pytest.ini` addopts include `--cov` flags but `import pytest_cov` fails (`ModuleNotFoundError`) in this environment; overriding `addopts` works (evidence: `python3 -m pytest -o addopts="" tests/test_utils.py -q` -> `12 passed`). Observed: `acceptance_public.py` currently fails collection with `ModuleNotFoundError: No module named 'tinydb.journal'` - the module does not exist yet, confirming the implementation target.
- **Alternatives considered**: *Install pytest-cov* - rejected: no network; *edit pytest.ini* - rejected: shared upstream configuration.

## R7. Where the module lives and how it is exposed

- **Decision**: New file `tinydb/journal.py` defining `class BatchWriter` with `__init__(self, db)`, `apply(self, operations, token=None) -> list[int]`, `preview(self, operations) -> list[int]`. No change to `tinydb/__init__.py`.
- **Rationale**: The requirement names the implementation source `tinydb/journal.py`; `acceptance_public.py` (observed in full) imports `from tinydb.journal import BatchWriter` - module path and class name are fixed. Leaving `__init__.py` untouched is minimal and additive (Constitution I/IV).
- **Alternatives considered**: *Re-export in `__init__.py`* - rejected: not required and would modify an existing public module.

## R8. "Apply sequentially" and rollback triggers (R02)

- **Decision**: Validate **all** operations up front (R04: "Validate operations structurally before committing changes"), then apply in order; during application the only expected failure is a remove targeting a missing ID (checked against the *current* table state before each remove, so `[remove 1, remove 1]` fails on the second). Any `ValueError` triggers the R1 rollback and is re-raised.
- **Rationale**: Satisfies both "validate and apply sequentially" (R01/R02) and "structurally before committing" (R04) with a single deterministic `ValueError`.
- **Alternatives considered**: *Lazy validation during apply* - rejected: R04 requires structural validation before any commit.

## R9. Idempotency token storage and semantics (R07, R08)

- **Decision**: Per-instance `dict[str, tuple[bytes, list[int]]]` on the `BatchWriter` object (e.g. `self._tokens`), mapping token -> (canonical byte form of the submitted operations, original inserted IDs). Canonical form: `repr(operations)` after structural validation is sufficient and stable within a process (tokens are per-instance and never persisted, so cross-process stability is not required; `repr` of a validated list of dicts is deterministic). Flow in `apply(operations, token=None)`: (1) if `token is not None`: it must be a `str` and non-empty, else `ValueError` **before any mutation**; (2) validate operations structurally (R4); (3) if `token is not None` and `token in self._tokens`: if canonical form differs -> `ValueError` (no data change); if identical -> return `list(stored_ids)` (fresh copy), no mutations, no re-recording; (4) run the normal batch (snapshot/apply/rollback); (5) on success only, store `self._tokens[token] = (canonical, inserted_ids)`; on failure store nothing (token not consumed). `token=None` skips all token logic (normal operation).
- **Rationale**: R07: "Repeating an already successful identical batch/token returns a detached copy of the original inserted IDs without rerunning mutations, even if other direct database writes occurred" (so replay must not re-apply, and the stored IDs are the *original* ones, not recomputed). "Reusing a token with different operations raises ValueError without changing data. Failed batches do not consume a token. None means normal operation; invalid tokens raise ValueError." R08: bookkeeping belongs to the instance, never in user documents; preview never records/consumes tokens and keeps its original single-argument signature; returned lists must not expose bookkeeping through mutation (hence `list(stored_ids)` copies).
- **Alternatives considered**: *Persist tokens in a hidden table* - rejected: R08 forbids bookkeeping in user documents and the default-table-only scope; a hidden table would also survive process restarts, which is not required. *Store token -> result only (no ops comparison)* - rejected: R07 requires mismatch detection (same token, different ops -> `ValueError`). *Hash-based comparison* - rejected: `repr` equality is exact and collision-free for this use; hashing adds a collision risk for no benefit.

## R10. Token edge cases

- **Decision**: Invalid token = not a `str`, or `str` of length 0 -> `ValueError` before validation of operations and before any mutation (data unchanged). A token that failed validation (or failed at apply, e.g. missing remove ID) is **not** stored, so the same token can be retried with corrected operations. Two `BatchWriter` instances over the same `db` do not share tokens (per-instance dict). Replaying a token whose batch inserted zero documents returns `[]` (a fresh empty list). A replay must also be returned when the table has since been modified by direct writes (the stored original IDs are returned, not recomputed).
- **Rationale**: Direct reading of R07/R08 plus spec Assumptions ("two different writer instances ... do not share token state", "a batch that failed validation is not recorded, so its token remains free").
- **Alternatives considered**: *Token consumed on first use even if failed* - rejected: R07 explicitly says failed batches do not consume a token.

## R11. Interaction of tokens with rollback and sequencing

- **Decision**: Token recording happens only after a fully successful batch (all ops applied, storage written, `_next_id` synced). A replay does **not** touch `_next_id` or storage at all (no mutations). A mismatched-token `ValueError` occurs after structural validation but before snapshot/apply, so it cannot change data or the ID cursor.
- **Rationale**: Keeps R02 atomicity and R05-clarification sequencing invariants intact: the only paths that mutate storage are successful batch applies.
- **Alternatives considered**: *Record token before apply, delete on failure* - rejected: unnecessary; store-on-success is simpler and equivalent.

## R12. Superseded conflicting note (milestone 2 evidence packet)

- **Decision**: The older generated note "preview may consume IDs and bool IDs are accepted" is **unverified and superseded** by R04/R05. This plan and all artifacts treat preview as side-effect-free and bool IDs as invalid. Any test or code relying on the older note is invalid.
- **Rationale**: Milestone 2 requirement text explicitly supersedes it; spec.md records the resolution under "Conflicting Evidence - Resolved". A previously passing happy-path smoke test does not verify these boundaries - dedicated tests (contract T13-T24) cover them.
- **Alternatives considered**: *Keep both behaviors behind a flag* - rejected: no requirement supports it; it would violate R04/R05.

## Consolidated Open Questions

**None.** All Technical Context unknowns resolved; no NEEDS CLARIFICATION markers remain in plan.md or spec.md.
