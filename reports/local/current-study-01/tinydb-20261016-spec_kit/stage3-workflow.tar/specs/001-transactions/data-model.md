# Data Model: Atomic Batch Transactions for TinyDB (milestones 1-3)

**Feature**: 001-transactions | **Date**: 2026-10-17 (updated for milestone 3)

## Entities

### BatchWriter (new, `tinydb/journal.py`)
A per-database wrapper object. Fields (all private, in-memory, per-instance):

| Field | Type | Notes |
|-------|------|-------|
| `_db` | `TinyDB` | supplied instance; never reconfigured |
| `_table` | `Table` | `self._db.table('_default')` - cached reference to the **same** object `TinyDB.table()` returns (observed `database.py` `_tables` cache), so handle coherence is automatic |
| `_tokens` | `dict[str, tuple[str, list[int]]]` | R07/R08 token bookkeeping: token -> (canonical ops form, original inserted IDs). Per-instance only; never persisted; never in user documents |

### Operation (input, not stored)
A `dict`, one of two exact shapes (R01 + R04):

| Field | Type | Applies to | Rules |
|-------|------|-----------|-------|
| `op` | `str` | both | exactly `'insert'` or `'remove'` |
| `document` | `Mapping`, not `bool` | `op='insert'` | required; **empty dict accepted**; nested data deep-copied on insert (R03) |
| `doc_id` | `int`, not `bool` | `op='remove'` | required; `> 0`; `bool` explicitly rejected (R04) |

- Entry must be a `dict`; the outer `operations` must be a `list` (R04).
- **Unsupported or missing fields -> `ValueError`** (R04 tightens R01; the earlier "extra keys are ignored" reading is superseded).
- The writer never mutates the caller's operation dicts or list (R03).

### Batch
An ordered `list[Operation]`.

- Empty list is valid -> `apply([])` returns `[]`, no state change.
- Applied as a unit: all effects persist, or none do (R02).
- Output: `list[int]` of inserted document IDs in submission order; removes contribute nothing. Always a fresh list (R05b).

### Document
A JSON-like mapping stored in the default table, identified by a positive integer ID.

- ID assignment: computed by the writer as `max(current keys)+1` (or 1 if empty) and advanced per insert (R05 clarification); the writer syncs `table._next_id` so ordinary `db.insert` continues the same sequence (R06). IDs are never caller-chosen.
- Nested dicts/lists are stored as deep copies (R03).
- Read back through the Table API as fresh `Document` objects - no aliasing.

### Idempotency token (R07/R08)

| Aspect | Rule |
|--------|------|
| Type | nonempty `str`; anything else (incl. `''`, non-str) -> `ValueError` before any mutation |
| Scope | per `BatchWriter` instance; never shared, never persisted, never in user documents |
| Binding | on success, token -> (canonical ops form, original inserted IDs) |
| Replay | same token + identical ops -> fresh copy of the original IDs, zero mutations, even after direct DB writes |
| Mismatch | same token + different ops -> `ValueError`, zero data change |
| Failure | a failed batch stores nothing; the token remains free for retry |
| `None` | normal operation; all token logic skipped |
| `preview` | never records or consumes a token; keeps single-argument signature (R08) |

### Default table (scope boundary)

- The single table the writer touches, accessed via `db.table('_default')`.
- Raw shape in storage: the `'_default'` entry of the whole-database state `dict[str, dict[str, Any]]` (observed `Storage.read/write`).
- **Snapshot**: `deepcopy` of the raw `'_default'` table dict taken after validation, before any mutation; the only state kept between batch start and end.
- Other tables: never read, written, or snapshotted.

## Relationships

- `BatchWriter 1--N Operation` (one batch = ordered list).
- `Operation 1--1 Document` (insert) or `Operation 1--1 doc_id` (remove).
- `Document N--1 Default table`.
- `BatchWriter 1--1 TinyDB` (wraps; does not own storage lifetime).
- `BatchWriter 1--N Token` (in-memory, per instance; token 1--1 successful batch result).
- `Default table 1--1 Storage` (shared with all Table handles; the rollback path writes through it).

## Validation Rules (spec FR-001, FR-004, FR-004a, FR-010)

Structural validation of the **entire** list occurs before any mutation (R04):

1. `operations` not a `list` -> `ValueError`.
2. Entry not a `dict` -> `ValueError`.
3. `op` not exactly `'insert'`/`'remove'` -> `ValueError`.
4. Unsupported/missing fields (key set not exactly `{'op','document'}` / `{'op','doc_id'}`) -> `ValueError`.
5. `document` present but not a `Mapping`, or is a `bool` -> `ValueError` (empty dict OK).
6. `doc_id` present but `bool`, not `int`, or `<= 0` -> `ValueError`.
7. `token` (when not `None`) not a nonempty `str` -> `ValueError` before any mutation (R07).
8. `remove` whose `doc_id` is not present in the table at apply time -> `ValueError` (R02) and rollback.
9. Token already bound to different operations -> `ValueError`, no data change (R07).

## State Transitions (per `apply(operations, token=None)` call)

```
IDLE --token valid? (if given)--> VALIDATE (structural, whole list)
VALIDATE --token replay hit (identical ops)--> REPLAY (return fresh copy of stored IDs; no mutation; done)
VALIDATE --token mismatch--> ERROR (ValueError; no mutation; token unchanged)
VALIDATE --ok--> SNAPSHOT_TAKEN --apply op i ok--> SNAPSHOT_TAKEN (i+1)
SNAPSHOT_TAKEN --all ops ok--> COMMITTED (storage holds new state; _next_id synced; token stored if given; return inserted IDs)
SNAPSHOT_TAKEN --any error--> ROLLBACK (storage restored; _next_id=None; clear_cache(); token NOT stored; ValueError raised)
VALIDATE --structural error--> ERROR (ValueError; no mutation occurred; token NOT consumed)
```

- COMMITTED: inserted IDs returned in order; `table._next_id = last_inserted_id + 1` (or left `None` if no inserts) so subsequent `apply`/`db.insert` continue the sequence without reuse or rewind, even across removes (R05 clarification, R06).
- ROLLBACK: default-table data identical to pre-batch state; `table._next_id = None` so the next insert re-derives from the restored max ID (research R1/R2); `clear_cache()` so cached queries refresh.
- REPLAY: zero storage writes, zero cache changes, zero cursor changes.

## `preview(operations)` state effect

None. Pure computation: validate (rules 1-6) + missing-ID check (rule 8) against current state, then return a **fresh** `list[int]` of the IDs the inserts would receive (`max(keys)+1 ... `). No storage write, no `_next_id` change, no token interaction (R05, R05b, R08). On error: `ValueError`, all state unchanged.
