# Quickstart / Validation Guide: Atomic Batch Transactions for TinyDB

**Feature**: 001-transactions | **Date**: 2026-10-17

This is a validation/run guide. It proves the feature works end-to-end; it does not contain implementation code. API details: [contracts/batch-writer.md](contracts/batch-writer.md). Data shapes: [data-model.md](data-model.md).

## Prerequisites

- Python 3.12 (observed `python3 --version` → `Python 3.12.14`).
- Repository root `/testbed`; the package is importable from the root (`python3 -c "import tinydb"` → `/testbed/tinydb/__init__.py`).
- pytest is installed; **pytest-cov is NOT** installed, so always override the repo's `pytest.ini` addopts with `-o addopts=""` (evidence: `python3 -m pytest -o addopts="" tests/test_utils.py -q` → `12 passed`).

## Setup (implementation phase)

1. Create `tinydb/journal.py` with `BatchWriter` per the contract.
2. Create `tests/test_journal.py` covering T01–T12 from the contract's Test Mapping.
3. Do **not** modify `acceptance_public.py`, `tests/` upstream files, or any existing `tinydb/` module.

## Validation Scenarios

### S1 — Public acceptance gate (R01 + R02 core)

```bash
cd /testbed && python3 -m pytest -o addopts="" acceptance_public.py -v
```

**Expected**: `test_public_basic` and `test_public_atomic` both PASS. Before implementation this command fails collection with `ModuleNotFoundError: No module named 'tinydb.journal'` (observed) — passing after implementation is the primary end-to-end proof.

### S2 — Own test suite (R01–R03 full coverage)

```bash
cd /testbed && python3 -m pytest -o addopts="" tests/test_journal.py -v
```

**Expected**: all T01–T12 scenarios pass, including: empty batch `[]`; insert ID ordering; every malformed-op `ValueError`; rollback restoring the complete pre-batch table (T05/T06); pre-acquired handle visibility after success and rollback (T07); ID sequencing after rollback (T08); ordinary API transparency (T09); no-aliasing of nested data (T10); duplicate-remove failure (T11); other tables untouched (T12).

### S3 — Upstream regression gate (Constitution I)

```bash
cd /testbed && python3 -m pytest -o addopts="" tests/ -q
```

**Expected**: the full unchanged upstream suite passes (baseline before implementation, recorded 2026-10-17: `223 passed in 1.28s`; after implementation: same count, no failures).

### S4 — Manual smoke check (no-aliasing, R03)

```bash
cd /testbed && python3 - <<'PY'
from tinydb import TinyDB
from tinydb.storages import MemoryStorage
from tinydb.journal import BatchWriter

db = TinyDB(storage=MemoryStorage)
w = BatchWriter(db)
op = {'op': 'insert', 'document': {'nested': {'a': [1, 2]}}}
ids = w.apply([op])
assert ids == [1], ids
op['document']['nested']['a'].append(99)          # mutate caller input
doc = db.get(doc_id=1)
assert doc['nested']['a'] == [1, 2], doc          # DB unaffected
doc['nested']['a'].append(7)                      # mutate returned doc
assert db.get(doc_id=1)['nested']['a'] == [1, 2]  # still unaffected
print('S4 OK')
PY
```

**Expected**: prints `S4 OK`.

### S5 — Rollback with a pre-acquired handle (R02)

```bash
cd /testbed && python3 - <<'PY'
from tinydb import TinyDB
from tinydb.storages import MemoryStorage
from tinydb.journal import BatchWriter

db = TinyDB(storage=MemoryStorage)
t = db.table('_default')          # pre-acquired handle
db.insert({'x': 1})
try:
    w = BatchWriter(db)
    w.apply([{'op': 'insert', 'document': {'x': 2}},
             {'op': 'remove', 'doc_id': 99}])
    raise SystemExit('expected ValueError')
except ValueError:
    pass
assert [d['x'] for d in t.all()] == [1], t.all()  # handle sees rollback
ids = BatchWriter(db).apply([{'op': 'insert', 'document': {'x': 3}}])
assert ids == [2] and [d['x'] for d in t.all()] == [1, 3]
print('S5 OK')
PY
```

**Expected**: prints `S5 OK` (rollback visible through the old handle; next ID after rollback is `2`, no reuse of the rolled-back ID).

## Done Criteria (phase gate evidence)

- S1 passes (record command + output).
- S2 passes (record command + output).
- S3 passes with the same result as the pre-implementation baseline (record both).
- S4 and S5 print `OK`.
- `git status --short` shows no modifications to upstream `tests/`, `acceptance_public.py`, or existing `tinydb/` modules (only new `tinydb/journal.py`, `tests/test_journal.py`, and spec artifacts).
