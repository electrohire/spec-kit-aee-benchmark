# Contract: `tinydb.journal.BatchWriter`

**Feature**: 001-transactions | **Date**: 2026-10-17 (updated for milestone 3)
**Status**: normative for the implementation phase; `acceptance_public.py` is the public gate.

## Public API

```python
class BatchWriter:
    def __init__(self, db: TinyDB) -> None: ...
    def apply(self, operations: list[dict], token: str | None = None) -> list[int]: ...
    def preview(self, operations: list[dict]) -> list[int]: ...
```

- Import path: `from tinydb.journal import BatchWriter` (fixed by `acceptance_public.py`).
- `db`: any `TinyDB` instance; the writer only uses `db.table('_default')` and the table's storage. It does not create, open, or close storage.
- Only the default table is affected.
- All methods raise `ValueError` for every contract violation listed below; no other exception type is part of the contract.

## `apply(operations, token=None)` contract

**Precondition**: `operations` is a `list` of operation dicts per [data-model.md](../data-model.md) (rules V1-V6). `token`, when not `None`, is a nonempty `str` (rule V7).

**Behavior** (order matters):
1. If `token is not None`: validate token type/non-emptiness first; on failure raise `ValueError` with **no** mutation and **no** token state change.
2. Validate every operation structurally (V1-V6) **before any mutation**. On violation: raise `ValueError`; no table mutation has occurred; a given token is **not** consumed.
3. Token replay check: if `token is not None` and the token is already bound to a **different** operations form -> `ValueError`, no data change, binding unchanged. If bound to the **identical** form -> return a **fresh copy** of the originally stored inserted IDs; perform **no** mutation (no storage write, no cursor change, no cache change), even if direct database writes occurred since the original batch.
4. Snapshot the default table (deep copy of raw table data).
5. Compute the batch's starting ID from the current table (`max(keys)+1`, or 1 if empty) and apply operations sequentially:
   - `insert`: store a **deep copy** of `document` under the next sequential ID; record the ID.
   - `remove`: if `doc_id` is not present in the current table state -> `ValueError` (V8); otherwise remove it.
6. On success: sync `table._next_id` to `last_inserted_id + 1` (leave `None` if no inserts) so subsequent `apply`/`db.insert` continue the sequence without reuse or rewind (R05 clarification, R06); if `token is not None`, store the binding (token -> canonical ops, inserted IDs); return the list of inserted IDs in submission order (removes add nothing). Empty input returns `[]`.
7. On any error during steps 4-5: restore the snapshot to the default table via the table's storage, `clear_cache()`, reset `table._next_id = None`, store **no** token binding, and raise `ValueError`.

**Postconditions**:
- Success: default table contains all inserted documents (nested data deep-copied) and all removed documents are gone; other tables untouched; previously acquired `db.table('_default')` handles observe the new state; ID sequence advanced and synced.
- Failure: default table **completely** identical to pre-batch state (data and ID-sequencing behavior); previously acquired handles observe the restored state; token (if any) remains free; `ValueError` raised.
- Replay: zero observable mutation; returned list is a fresh object.
- Invariant (all paths): the caller's `operations` list and its dicts are never mutated; stored data never aliases caller data; returned IDs are plain immutable `int`s in a fresh list that does not expose internal state (mutating it cannot affect the writer, later calls, or token bookkeeping - R05b, R08).

**Errors**:

| Condition | Exception |
|-----------|-----------|
| `operations` not a `list` | `ValueError` |
| Non-dict operation entry | `ValueError` |
| Unknown/missing `op` | `ValueError` |
| Unsupported or missing fields (V4) | `ValueError` |
| Missing/non-Mapping/bool `document` | `ValueError` |
| Missing/non-int/bool/non-positive `doc_id` | `ValueError` |
| `remove` of a missing `doc_id` | `ValueError` |
| `token` not a nonempty `str` | `ValueError` (before any mutation) |
| Token reused with different operations | `ValueError` (no data change) |

## `preview(operations)` contract

- **Signature**: exactly one argument (R08); no token parameter, ever.
- Validates structurally (V1-V6) and checks remove targets against the current table (V8); on any violation raises `ValueError` with **all** state unchanged (data, next insertion ID, query caches, token bookkeeping).
- On success returns a **new, detached list** (fresh object every call - R05b) of the IDs that `apply` would assign to the inserts, in submission order, computed from the current table state. Removes contribute nothing.
- **No side effects**: no storage write, no `_next_id` change, no cache change, no token recording/consumption. Calling `preview` any number of times (including before a later `apply`) must not shift the IDs `apply` will return.
- Mutating a previously returned preview list cannot affect subsequent preview results or any internal writer state (R05b).

## Non-goals (explicit)

- No cross-table transactions; no caller-chosen IDs; no context-manager; no partial-commit; no token persistence across processes/instances; no changes to any existing TinyDB public API.

## Test Mapping (own tests, `tests/test_journal.py`)

| ID | Requirement | Test scenario |
|----|-------------|---------------|
| T01 | R01 | empty batch -> `[]`, table unchanged |
| T02 | R01 | two inserts -> returns `[1, 2]`, both present |
| T03 | R01 | mixed insert/remove -> only insert IDs returned, in order |
| T04 | R01/R04 | each malformed op (non-list operations, non-dict entry, bad op, unsupported field, missing document, non-dict document, bool document, missing doc_id, bool doc_id, zero/negative doc_id, float doc_id) -> `ValueError`, table unchanged |
| T05 | R01 | empty-dict document accepted; stored as `{}` |
| T06 | R02 | insert then remove-missing -> `ValueError`, table equals pre-batch snapshot |
| T07 | R02 | remove-existing then remove-missing -> `ValueError`, removed doc restored |
| T08 | R02 | pre-acquired `db.table('_default')` handle reflects success and rollback (incl. after `search()` cache use) |
| T09 | R02/R05 | after rollback, next insert continues correct ID sequence (no ID reuse/collision) |
| T10 | R03 | ordinary `db.insert`/`db.all`/`db.get` before/after batches still work; pre-existing docs intact |
| T11 | R03 | nested dict/list: mutating caller's operation after `apply` does not change DB; mutating a returned/stored doc does not change the operation or DB |
| T12 | R01/R02 | batch with duplicate removes of the same ID -> second remove is a missing-ID error -> rollback |
| T13 | R02 | rollback restores even when other tables exist (other tables untouched) |
| T14 | R05 | preview returns the IDs apply would produce; data and next insertion ID unchanged (apply afterwards returns the same IDs) |
| T15 | R05 | preview on a failing batch raises `ValueError` and consumes no IDs (apply afterwards unaffected) |
| T16 | R05 | existing table handles and query caches remain coherent after preview (cached `search()` results refresh correctly) |
| T17 | R05b | preview returns a new list object each call; mutating a returned preview list does not affect later previews or internal state |
| T18 | R05/R06 | direct `db.insert` between calls is seen: apply after direct insert continues the sequence (no reuse/rewind), including after removes |
| T19 | R06 | no stale initial snapshot: wrapper created before direct inserts still sees them |
| T20 | R07 | replay of successful identical batch/token returns fresh copy of original IDs, zero mutations, even after direct DB writes in between |
| T21 | R07 | token reuse with different operations -> `ValueError`, data unchanged, original binding intact (replay still works) |
| T22 | R07 | failed batch (validation or missing ID) does not consume the token; retry with same token succeeds |
| T23 | R07 | invalid tokens (empty string, non-string, e.g. `b'x'`, `1`) -> `ValueError` before any mutation; `token=None` is normal operation |
| T24 | R08 | token bookkeeping is per-instance (two writers over same db do not share); never in user documents; mutating returned lists (apply or preview) cannot expose/corrupt bookkeeping; `preview` signature unchanged and never touches tokens |

Public gate: `acceptance_public.py` (`test_public_basic`, `test_public_atomic`) must pass unmodified.
