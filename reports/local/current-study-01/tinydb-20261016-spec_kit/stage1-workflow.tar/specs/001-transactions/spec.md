# Feature Specification: Atomic Batch Transactions for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "Build tinydb.journal.BatchWriter(db), wrapping a supplied TinyDB instance without changing its ordinary APIs. Use the default table only. R01: apply(operations) accepts a list of operation dictionaries ({'op':'insert','document':dict} or {'op':'remove','doc_id':positive integer}); return a list of inserted document IDs (removes add no result); empty input returns []; unknown/malformed operations raise ValueError. R02: Batch application is atomic: validate and apply sequentially, but on any error restore the complete pre-batch default-table data; a remove targeting a missing ID is an error; previously acquired db.table('_default') handles must reflect both success and rollback. R03: Ordinary TinyDB reads/writes and preexisting documents continue to work; inserted and returned nested data must not alias the caller's input; mutating an operation after apply cannot mutate the database."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a batch of insert and remove operations (Priority: P1)

A developer wraps an existing TinyDB database with the batch writer and submits a list of operations. Each operation is either an insert (carrying a document) or a remove (carrying a document ID). The operations are validated and applied in order to the default table, and the developer receives the IDs of the inserted documents, in submission order. Removes contribute no result.

**Why this priority**: This is the core value of the feature; without it the feature does not exist.

**Independent Test**: Create a database, apply a batch of inserts and removes, and assert on the returned IDs and the resulting default-table contents. This alone delivers a usable, if non-atomic, MVP.

**Acceptance Scenarios**:

1. **Given** an empty database, **When** `apply([{'op':'insert','document':{'a':1}}, {'op':'insert','document':{'b':2}}])` is called, **Then** it returns the two new document IDs in submission order and the default table contains both documents.
2. **Given** a database containing a document with a known ID, **When** `apply([{'op':'remove','doc_id':<that ID>}])` is called, **Then** it returns `[]` and the document is no longer present.
3. **Given** any database, **When** `apply([])` is called, **Then** it returns `[]` and the table is unchanged.
4. **Given** a database, **When** a batch mixes inserts and removes, **Then** only inserted IDs are returned, in the order the inserts appeared.

---

### User Story 2 - Fail atomically and restore pre-batch state (Priority: P1)

A developer submits a batch in which a later operation is malformed or targets a missing document. The whole batch must have no net effect: the default table is restored to exactly its pre-batch contents, including any documents inserted earlier in the same failed batch, and a `ValueError` is raised.

**Why this priority**: Atomicity is the defining property of a transaction; without it the feature is unsafe to use.

**Independent Test**: Pre-populate a database, apply a batch that fails partway (missing `doc_id` or malformed operation), and assert the table equals the pre-batch snapshot and that `ValueError` was raised.

**Acceptance Scenarios**:

1. **Given** a pre-existing document, **When** `apply([insert, remove of a missing ID])` is called, **Then** a `ValueError` is raised and the table contains only the pre-existing document (the earlier insert is rolled back).
2. **Given** pre-existing documents, **When** `apply([remove of an existing ID, remove of a missing ID])` is called, **Then** a `ValueError` is raised and the removed pre-existing document is restored.
3. **Given** a handle to the default table acquired before the batch, **When** a batch succeeds or rolls back, **Then** the handle reflects the post-batch (or restored) data.

---

### User Story 3 - Preserve ordinary database behavior and data independence (Priority: P2)

A developer continues to use the wrapped database normally (ordinary reads, writes, pre-existing documents) while also using the batch writer. Data passed into, or returned from, a batch never shares identity with the database's stored data, so later mutation on either side cannot corrupt the other.

**Why this priority**: Guarantees the wrapper is transparent and safe; required for trust, but secondary to the P1 apply/rollback flows.

**Independent Test**: Read and write via the ordinary API around batches; mutate a caller's input document after `apply` and assert the database is unchanged; mutate a returned or copied stored document and assert the database is unchanged.

**Acceptance Scenarios**:

1. **Given** pre-existing documents and ordinary reads/writes, **When** a batch is applied, **Then** ordinary behavior is unaffected and pre-existing documents remain readable and writable.
2. **Given** a batch containing nested documents, **When** `apply` returns and the caller then mutates the input operation's document, **Then** the database contents are unchanged.
3. **Given** a batch containing nested documents, **When** the caller mutates a returned document or a copy of stored data, **Then** no aliasing exists: neither mutation affects the other or the database.

---

### Edge Cases

- **Malformed operations**: a non-dict entry, an unknown `op` value, a missing `document`/`doc_id` field, a `doc_id` that is not a positive integer, or a non-dict `document` must each raise `ValueError` and roll back the whole batch.
- **Missing target**: a `remove` whose `doc_id` does not exist in the default table is an error (`ValueError`) and triggers rollback.
- **Empty batch**: `apply([])` returns `[]` and leaves the table untouched.
- **Interleaved use**: ordinary TinyDB reads/writes performed before, between, or after batches must continue to work against the same default table.
- **Nested data**: documents containing nested dicts/lists must be stored and returned as independent copies.
- **Pre-existing handles**: a `db.table('_default')` handle acquired before a batch must observe both successful application and rollback.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST provide a batch writer that wraps a supplied TinyDB database instance and operates on the default table only, without changing the database's ordinary public behavior.
- **FR-002**: The batch writer MUST expose an `apply` capability that accepts a list of operation dictionaries, where each operation is either `{'op':'insert','document':<document>}` or `{'op':'remove','doc_id':<positive integer>}`.
- **FR-003**: `apply` MUST validate and apply the operations sequentially and MUST return a list containing only the IDs of inserted documents, in submission order; removes MUST add no result; empty input MUST return `[]`.
- **FR-004**: `apply` MUST raise `ValueError` for unknown or malformed operations (non-dict entry, unknown `op`, missing `document`/`doc_id`, non-positive-integer `doc_id`, non-dict `document`).
- **FR-005**: Batch application MUST be atomic: on any error during the batch, the complete pre-batch default-table data MUST be restored, including undoing inserts applied earlier in the same batch.
- **FR-006**: A `remove` targeting a document ID that does not exist in the default table MUST be treated as an error and MUST trigger rollback.
- **FR-007**: Handles to the default table acquired before a batch MUST reflect both successful application and rollback.
- **FR-008**: Ordinary TinyDB reads and writes, and pre-existing documents, MUST continue to work unchanged while the batch writer is in use.
- **FR-009**: Inserted data and returned data MUST NOT alias the caller's input; mutating an operation after `apply` MUST NOT mutate the database, and mutating returned or stored nested data MUST NOT affect the caller's input or the database.

### Key Entities *(include if feature involves data)*

- **Operation**: A single unit of batch work. Either an insert (carries a document to add) or a remove (carries the ID of a document to delete). Validated before the batch is applied.
- **Batch**: An ordered list of operations submitted together. Applied as a unit: either all of its effects persist or none do.
- **Document**: A JSON-like data object stored in the default table, identified by a unique positive integer ID. May contain nested structures.
- **Default table**: The single named table the batch writer reads and writes; the only table in scope for this feature.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of well-formed batches apply completely and return exactly the inserted document IDs in order, with the default table reflecting every operation.
- **SC-002**: 100% of batches containing any error (malformed operation or missing remove target) leave the default table byte-for-byte identical to its pre-batch state, and raise `ValueError`.
- **SC-003**: 100% of ordinary TinyDB reads/writes and pre-existing documents behave identically with and without the batch writer in use.
- **SC-004**: Zero observable aliasing: mutating caller input after `apply`, or mutating returned/stored nested data, never changes the database or the other side (verified by dedicated tests).
- **SC-005**: The public acceptance suite (`acceptance_public.py`) and the unchanged upstream test suite both pass, with evidence recorded.

## Assumptions

- The batch writer wraps an already-constructed TinyDB database; it does not create, open, or configure storage.
- Only the default table is in scope; other tables are neither read nor modified by the batch writer.
- Document IDs are the positive integers assigned by the database on insert; the batch writer does not accept caller-chosen IDs.
- Atomicity is scoped to the default table's data; no cross-table or cross-database transactions are implied.
- The feature is additive: it does not alter any existing TinyDB public API or behavior.
- Validation of the whole operation list may occur before any mutation, but the observable contract is that a single `ValueError` is raised and the pre-batch state is restored.
