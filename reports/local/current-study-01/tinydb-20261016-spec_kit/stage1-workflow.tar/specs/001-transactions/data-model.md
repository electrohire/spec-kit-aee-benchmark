# Phase 1 Data Model: Atomic Batch Transactions for TinyDB

**Feature**: 001-transactions | **Date**: 2026-10-17

## Entities

### Operation
A single unit of batch work (spec §Key Entities).

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `op` | `str` | yes | exactly `'insert'` or `'remove'` |
| `document` | `Mapping` (dict) | for `op='insert'` | must be a Mapping; `bool` rejected; nested structures allowed |
| `doc_id` | `int` | for `op='remove'` | must be `int` (not `bool`) and `> 0` |

- Entry must be a `dict`; otherwise `ValueError`.
- Extra keys are ignored (research R4).
- State: immutable input — the writer never mutates the caller's operation dict (R03).

### Batch
An ordered `list[Operation]`.

- Empty list is valid → `apply([])` returns `[]`, no state change.
- Applied as a unit: all effects persist, or none do (R02).
- Output: `list[int]` of inserted document IDs in submission order; removes contribute nothing.

### Document
A JSON-like mapping stored in the default table, identified by a positive integer ID.

- ID assignment: done by the existing `Table` machinery (`_get_next_id`), **not** by the writer; IDs are never caller-chosen (spec §Assumptions).
- Nested dicts/lists are stored as deep copies (R03; research R3).
- Read back through the Table API as fresh `Document` objects — no aliasing with storage or caller data.

### Default table (scope boundary)

- The single table the writer touches, accessed via `db.table('_default')`.
- Raw shape in storage: `dict[str, dict[int, Mapping]]` under the `'_default'` key of the whole-database state `dict[str, dict[str, Any]]` (observed `Storage.read/write` signatures).
- **Snapshot**: `deepcopy` of the raw `'_default'` table dict taken before any mutation; the only state the writer keeps between the start and end of a batch.
- Other tables: never read, written, or snapshotted.

## Relationships

- `BatchWriter 1──N Operation` (one batch = ordered list).
- `Operation 1──1 Document` (insert) or `Operation 1──1 doc_id` (remove).
- `Document N──1 Default table`.
- `BatchWriter 1──1 TinyDB` (wraps; does not own storage lifetime).
- `Default table 1──1 Storage` (shared with all Table handles; the rollback path writes through it).

## Validation Rules (from spec FR-004, FR-006)

1. Non-dict entry → `ValueError`.
2. `op` not in `{'insert','remove'}` → `ValueError`.
3. `insert` without `document`, or `document` not a Mapping (or is `bool`) → `ValueError`.
4. `remove` without `doc_id`, or `doc_id` not a positive `int` (bools rejected) → `ValueError`.
5. `remove` whose `doc_id` is not present in the table at apply time → `ValueError` (R02).

## State Transitions (per `apply` call)

```
 IDLE --validate ok--> SNAPSHOT_TAKEN --apply op i ok--> SNAPSHOT_TAKEN (i+1)
 SNAPSHOT_TAKEN --all ops ok--> COMMITTED (storage holds new state; return inserted IDs)
 SNAPSHOT_TAKEN --any error--> ROLLBACK (storage restored to snapshot; cache cleared; ValueError raised)
 IDLE --validation error--> ROLLBACK_NOOP (no mutation happened; ValueError raised)
```

- COMMITTED: inserted IDs returned in order; table `_next_id` left as the Table set it (subsequent inserts continue the sequence).
- ROLLBACK: default-table data byte-identical to pre-batch state; `table._next_id = None` so the next insert re-derives from the restored max ID (research R1); `clear_cache()` called so cached queries refresh.
