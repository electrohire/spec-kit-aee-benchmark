# Contract: `tinydb.journal.BatchWriter`

**Feature**: 001-transactions | **Date**: 2026-10-17
**Status**: normative for the implementation phase; `acceptance_public.py` is the public gate.

## Public API

```python
class BatchWriter:
    def __init__(self, db: TinyDB) -> None: ...
    def apply(self, operations: list[dict]) -> list[int]: ...
```

- Import path: `from tinydb.journal import BatchWriter` (fixed by `acceptance_public.py`).
- `db`: any `TinyDB` instance; the writer only uses `db.table('_default')` and the table's storage. It does not create, open, or close storage.
- Only the default table is affected.

## `apply(operations)` contract

**Precondition**: `operations` is a `list` (or sequence) of operation dicts per [data-model.md](../data-model.md) §Operation. If it is not list-like, behavior is unspecified (implementation may raise `TypeError`); the acceptance contract only defines list inputs.

**Behavior**:
1. Validate every operation up front (rules V1–V4 in data-model.md). On violation: raise `ValueError`; no table mutation has occurred.
2. Snapshot the default table (deep copy of raw table data).
3. Apply operations sequentially:
   - `insert`: insert a **deep copy** of `document`; record the returned ID.
   - `remove`: if `str(doc_id)` is not in the current table data → `ValueError` (rule V5); otherwise remove it.
4. On success: return the list of inserted IDs, in submission order (removes add nothing). Empty input returns `[]`.
5. On any error during steps 2–3: restore the snapshot to the default table via the table's storage, clear the default table's query cache, reset its ID cursor, and raise `ValueError` (re-raised if it was already a `ValueError`; other exception types are wrapped in `ValueError` only if they stem from the batch — implementation detail, not part of the public contract).

**Postconditions**:
- Success: default table contains all inserted documents (nested data deep-copied) and all removed documents are gone; other tables untouched; previously acquired `db.table('_default')` handles observe the new state.
- Failure: default table is **complete**ly identical to its pre-batch state (data and ID-sequencing behavior); previously acquired handles observe the restored state; `ValueError` raised.
- Invariant (both): the caller's `operations` list and its dicts are never mutated; stored data never aliases caller data; returned IDs are plain immutable `int`s.

**Errors**:

| Condition | Exception |
|-----------|-----------|
| Non-dict operation entry | `ValueError` |
| Unknown/missing `op` | `ValueError` |
| Missing/non-Mapping/bool `document` | `ValueError` |
| Missing/non-int/bool/non-positive `doc_id` | `ValueError` |
| `remove` of a missing `doc_id` | `ValueError` |

## Non-goals (explicit)

- No cross-table transactions; no caller-chosen IDs; no context-manager; no partial-commit; no changes to any existing TinyDB public API.

## Test Mapping (own tests, `tests/test_journal.py`)

| ID | Requirement | Test scenario |
|----|-------------|---------------|
| T01 | R01 | empty batch → `[]`, table unchanged |
| T02 | R01 | two inserts → returns `[1, 2]`, both present |
| T03 | R01 | mixed insert/remove → only insert IDs returned, in order |
| T04 | R01 | each malformed op (non-dict, bad op, missing document, non-dict document, missing doc_id, bool doc_id, zero/negative doc_id, float doc_id) → `ValueError` |
| T05 | R02 | insert then remove-missing → `ValueError`, table equals pre-batch snapshot |
| T06 | R02 | remove-existing then remove-missing → `ValueError`, removed doc restored |
| T07 | R02 | pre-acquired `db.table('_default')` handle reflects success and rollback (incl. after `search()` cache use) |
| T08 | R02 | after rollback, next insert continues correct ID sequence (no ID reuse/collision) |
| T09 | R03 | ordinary `db.insert`/`db.all`/`db.get` before/after batches still work; pre-existing docs intact |
| T10 | R03 | nested dict/list: mutating caller's operation after `apply` does not change DB; mutating a returned/stored doc does not change the operation or DB |
| T11 | R01/R02 | batch with duplicate removes of the same ID → second remove is a missing-ID error → rollback |
| T12 | R02 | rollback restores even when other tables exist (other tables untouched) |

Public gate: `acceptance_public.py` (`test_public_basic`, `test_public_atomic`) must pass unmodified.
