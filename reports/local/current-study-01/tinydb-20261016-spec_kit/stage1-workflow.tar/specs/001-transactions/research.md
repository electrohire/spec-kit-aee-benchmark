# Phase 0 Research: Atomic Batch Transactions for TinyDB

**Feature**: 001-transactions | **Date**: 2026-10-17 | **Input**: `plan.md` Technical Context + spec.md

All NEEDS CLARIFICATION items from the plan: **none remained** after repository inspection. Each open question below is resolved with a Decision/Rationale/Alternatives entry. All repository facts cite observed command output from this phase.

## R1. How to atomically restore complete pre-batch default-table data (R02)

- **Decision**: Snapshot the default table's raw data **before** applying any operation: `snapshot = deepcopy(table._read_table())`. On any error, restore by writing the snapshot back through the same storage the table uses: `storage = table.storage; state = storage.read() or {}; state['_default'] = deepcopy(snapshot); storage.write(state)`. Then clear the default table's query cache (`table.clear_cache()`) and reset its ID cursor (`table._next_id = None`).
- **Rationale**: `Table._read_table()` (observed, `tinydb/table.py`) returns the raw table dict from `self._storage.read()` — the single source of truth. `Table._update_table()`'s docstring confirms the storage interface only supports read/write of the *complete* database state, so a storage-level write is the only way to atomically replace the whole table. Writing the snapshot back through `table.storage` means **every** `Table` instance bound to that storage (including previously acquired `db.table('_default')` handles) sees the restored data, because every read path (`get`, `__iter__`, `__len__`, `search`) goes through `_read_table()` → `storage.read()`. `deepcopy` both ways prevents aliasing between snapshot, storage, and caller data (R03). Resetting `_next_id` guarantees subsequent inserts re-derive IDs from the restored max ID (observed: `_get_next_id()` recomputes from `max(table.keys())` when `_next_id is None`), so ID sequencing stays consistent after rollback.
- **Alternatives considered**:
  1. *Undo log (inverse operations)* — rejected: would need to track and invert every insert/remove; a full snapshot is simpler, provably complete ("restore the **complete** pre-batch data"), and the table is small relative to the operation count.
  2. *Re-raise through `Table` API (re-insert removed docs, remove inserted docs)* — rejected: cannot restore documents that were *replaced* or that had nested identity, and re-inserting would assign new IDs; also more code paths to fail.
  3. *New storage-level transaction API* — rejected: would modify existing modules (`storages.py`, `table.py`), violating Constitution I/IV.

## R2. How previously acquired `db.table('_default')` handles must reflect success and rollback (R02)

- **Decision**: No handle-specific work is needed for success (normal writes already flow through storage). For rollback, in addition to the storage write, call `default_table.clear_cache()` (observed public method, `tinydb/table.py`) so any cached `search()` results are invalidated.
- **Rationale**: Verified by inspection: `Table.get()` reads `self._read_table()`; `Table.__iter__` reads `self._read_table()`; `Table.__len__` reads `self._read_table()`; only `search()` uses `self._query_cache` (observed grep: `_query_cache` appears only at lines 107/251/281/706). `TinyDB.table()` caches table instances in `self._tables` (observed `database.py`), so a previously acquired handle is the *same* object the writer uses — clearing its cache covers the writer's handle and any user handle. `MemoryStorage.write` replaces `self.memory` wholesale (observed), so no stale state survives.
- **Alternatives considered**: *Create a fresh Table instance per batch* — rejected: user-held old handles would then point at a different object; the spec explicitly requires **previously acquired** handles to reflect the result.

## R3. No-aliasing of inserted/returned nested data (R03)

- **Decision**: Deep-copy each insert document before handing it to the table (`table.insert(deepcopy(document))`); deep-copy the snapshot (R1); deep-copy the restored snapshot on rollback (R1). `apply` returns only `int` IDs, which are immutable, so the return value cannot alias caller data.
- **Rationale**: `Table.insert` itself only does `table[doc_id] = dict(document)` (observed) — a **shallow** copy, so nested dicts/lists would still alias the caller's input. A `deepcopy` before insert breaks the link in both directions (mutating the operation after `apply` cannot mutate the DB, and mutating stored nested data cannot mutate the operation). Reading documents back through the Table API always constructs fresh `Document` objects from raw storage data, so reads are already alias-free; the snapshot/restore deepcopies cover the writer's own copies.
- **Alternatives considered**: *`json.loads(json.dumps(...))`* — rejected: not safe for non-JSON values and slower; *manual recursive copy* — rejected: `copy.deepcopy` is stdlib and handles all cases.

## R4. Exact validation semantics for operations (R01)

- **Decision**: For each entry, in order: it must be a `dict`; `op` must be exactly `'insert'` or `'remove'`; for `insert`, key `document` must be present and be a `Mapping` (but **not** a `bool`); for `remove`, key `doc_id` must be present, be an `int` (not `bool`), and be `> 0`. Any violation raises `ValueError`. Extra keys are ignored. A remove whose `doc_id` is absent from the table at apply time raises `ValueError` (R02) and rolls back.
- **Rationale**: Matches the frozen requirement text ("positive integer", "dict", "unknown/malformed operations raise ValueError"). Excluding `bool` is deliberate: `isinstance(True, int)` is `True` in Python, and `True`/`False` are not positive-integer document IDs in any sensible reading. Extra keys are ignored because the requirement says each operation *is* one of two shapes — it does not say "no other keys allowed" — and ignoring is the least surprising behavior for a library.
- **Alternatives considered**: *Strict key-set equality* — rejected as over-strict without requirement support; *accepting `doc_id` strings* — rejected: requirement says positive integer; `Table` keys are stored as strings internally, so the writer must convert `str(doc_id)` when checking membership (observed `get()` uses `table.get(str(doc_id))`).

## R5. Test environment specifics

- **Decision**: Run tests with `python3 -m pytest -o addopts="" <paths>` (repo root `/testbed`, `PYTHONPATH=src:.` harmless; package is importable from root). Public gate: `python3 -m pytest -o addopts="" acceptance_public.py`.
- **Rationale**: Observed: `pytest.ini` addopts include `--cov` flags but `import pytest_cov` fails with `ModuleNotFoundError` in this environment, so plain `pytest` would error out; overriding `addopts` on the command line works (evidence: `python3 -m pytest -o addopts="" tests/test_utils.py -q` → `12 passed in 0.01s`). Observed: `acceptance_public.py` currently fails collection with `ModuleNotFoundError: No module named 'tinydb.journal'` — the module does not exist yet, confirming the implementation target and that the acceptance file must not be modified.
- **Alternatives considered**: *Install pytest-cov* — rejected: no network access and unnecessary; *edit pytest.ini* — rejected: it is repository configuration shared with upstream tests.

## R6. Where the module lives and how it is exposed

- **Decision**: New file `tinydb/journal.py` defining `class BatchWriter` with `__init__(self, db)` and `apply(self, operations) -> list[int]`. No change to `tinydb/__init__.py`.
- **Rationale**: The requirement names the implementation source as `tinydb/journal.py`, and `acceptance_public.py` (observed in full) imports `from tinydb.journal import BatchWriter` — so the module path and class name are fixed. Leaving `__init__.py` untouched is the minimal additive change (Constitution I/IV).
- **Alternatives considered**: *Re-export in `tinydb/__init__.py`* — rejected: not required by any requirement and would modify an existing public module.

## R7. What "apply sequentially" means for rollback triggers

- **Decision**: Validate **all** operations up front (cheap, catches malformed ops before any mutation), then apply in order; during application the only expected failure is a remove targeting a missing ID (checked against the current table state before each remove). Any `ValueError` (or any unexpected exception from the Table API) triggers the R1 rollback and re-raises `ValueError` for validation/missing-ID cases.
- **Rationale**: The requirement says "validate and apply sequentially" — pre-validation plus sequential application satisfies both readings and guarantees a single, deterministic `ValueError`. Checking remove targets against the *current* state (not the snapshot) means a batch like `[remove 1, remove 1]` fails on the second remove (ID no longer present), which is the correct sequential semantics.
- **Alternatives considered**: *Validate lazily during apply* — rejected: no observable difference for the acceptance contract, but pre-validation is simpler to reason about and test.

## Consolidated Open Questions

**None.** All Technical Context unknowns resolved; no NEEDS CLARIFICATION markers remain in plan.md or spec.md.
