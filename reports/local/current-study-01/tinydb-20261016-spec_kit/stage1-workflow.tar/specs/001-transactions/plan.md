# Implementation Plan: Atomic Batch Transactions for TinyDB

**Branch**: `001-transactions` | **Date**: 2026-10-17 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/testbed/specs/001-transactions/spec.md`

**Note**: This template is filled in by the `$speckit-plan` command; its definition describes the execution workflow.

## Summary

Add `tinydb.journal.BatchWriter`, a thin wrapper around a supplied `TinyDB` instance that applies a list of `insert`/`remove` operations to the **default table only**, atomically: either every operation takes effect (returning the inserted document IDs in order) or the complete pre-batch default-table data is restored and a `ValueError` is raised. The design is additive: no existing TinyDB public API changes. Rollback is implemented as a deep-copied pre-batch snapshot written back through the same storage the table already uses, so previously acquired `db.table('_default')` handles (which read through that storage on every access) observe both success and rollback. No-aliasing is guaranteed by deep-copying documents on the way in (insert) and on the way out (snapshot/restore).

## Technical Context

**Language/Version**: Python 3.12.14 (observed via `python3 --version`); must remain compatible with the versions declared in `pyproject.toml`.

**Primary Dependencies**: Standard library only (`copy.deepcopy`, `collections.abc.Mapping`). No new runtime dependencies (Constitution IV).

**Storage**: Whatever storage the supplied `TinyDB` uses (e.g., `MemoryStorage`, `JSONStorage`); the batch writer only calls `Storage.read()`/`Storage.write()`, never opens files.

**Testing**: pytest (`python3 -m pytest -o addopts="" ...`; the repo `pytest.ini` addopts reference `pytest-cov`, which is **not installed** in this environment, so `addopts` must be overridden on the command line). Public acceptance: `acceptance_public.py`.

**Target Platform**: Any platform supported by this repository (pure Python library; no platform-specific code).

**Project Type**: library (in-repo module `tinydb/journal.py`)

**Performance Goals**: No numeric goals. Constraint: one extra full-table deep copy per batch (snapshot) plus one extra storage write on failure (rollback) — acceptable for a correctness-first transactional wrapper.

**Constraints**: Additive only (Constitution I); upstream tests in `tests/` unchanged; `acceptance_public.py` is the public gate; default table only; single `ValueError` type for all validation/atomicity failures.

**Scale/Scope**: One new module (`tinydb/journal.py`, ~100-150 lines incl. docstrings) plus one new test file; no changes to existing modules.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution: `.specify/memory/constitution.md` (v1.0.0). Gates evaluated against it:

- **I. Preserve Existing Public API Behavior — PASS.** Design adds a new module only; `tinydb/__init__.py`, `database.py`, `table.py`, `storages.py`, and all existing tests are untouched. Evidence: `grep -rn "journal" tinydb/ tests/` returns no matches (module does not exist yet); plan touches only `tinydb/journal.py` + new tests.
- **II. Testable Acceptance Criteria — PASS.** Every FR-001..FR-009 maps to a named test in `contracts/batch-writer.md` §Test Mapping and to `quickstart.md` scenarios; acceptance suite already encodes R01/R02 (`acceptance_public.py` read in full).
- **III. Evidence Over Assertion — PASS (process rule).** Plan records observed evidence (commands + outputs) for every repository fact; implementation phase must record test command outputs before claiming done.
- **IV. Simple Scoped Implementations — PASS.** One module, stdlib only, no new abstractions; no speculative features (no cross-table, no caller-chosen IDs, no context-manager sugar).
- **V. Documented Assumptions and Regressions — PASS.** Open questions resolved in `research.md`; remaining assumptions carried in spec.md §Assumptions.

**Gate result: PASS — no violations, no Complexity Tracking entries required.**

### Post-Design Re-Check (after Phase 1)

- **I. Preserve Existing Public API Behavior — PASS (re-confirmed).** Design artifacts specify zero changes to existing modules: rollback is implemented entirely inside the new `tinydb/journal.py` by writing through the table's existing storage interface and calling the table's existing public `clear_cache()`; the only private attribute touched is the table's own `_next_id` cursor (reset to `None`, the same value `truncate()` uses), which is an internal reset, not an API change. Upstream test baseline recorded: `python3 -m pytest -o addopts= tests/ -q` → `223 passed in 1.28s` (pre-implementation).
- **II. Testable Acceptance Criteria — PASS (re-confirmed).** Contract T01–T12 test mapping + quickstart S1–S5 give every FR a runnable check; public gate `acceptance_public.py` verified to target exactly this design (`from tinydb.journal import BatchWriter`).
- **III. Evidence Over Assertion — PASS (re-confirmed).** All repository facts in research.md cite observed command output; quickstart records the pre-implementation baseline (223 passed) and the failing-collection state of the acceptance gate as evidence anchors.
- **IV. Simple Scoped Implementations — PASS (re-confirmed).** Final design: one new module, stdlib `copy.deepcopy` only, no new abstractions; alternatives (undo log, re-insert restore, storage transaction API) rejected with rationale in research.md R1.
- **V. Documented Assumptions and Regressions — PASS (re-confirmed).** Research resolved all open questions (R1–R7); remaining assumptions are in spec.md §Assumptions; no regressions expected (additive-only).

**Post-design gate result: PASS.**

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── batch-writer.md  # Public API contract for tinydb.journal.BatchWriter
└── tasks.md             # Phase 2 output ($speckit-tasks command - NOT created by $speckit-plan)
```

### Source Code (repository root)

```text
tinydb/
├── __init__.py          # unchanged (BatchWriter imported directly from tinydb.journal)
├── database.py          # unchanged (TinyDB)
├── table.py             # unchanged (Table, Document)
├── storages.py          # unchanged (Storage, MemoryStorage, JSONStorage)
└── journal.py           # NEW: BatchWriter (this feature)

tests/
├── conftest.py          # unchanged
├── test_*.py            # unchanged upstream tests
└── test_journal.py      # NEW: own tests for BatchWriter (R01-R03)

acceptance_public.py     # unchanged public acceptance gate
```

**Structure Decision**: Single-project layout (existing repository). The feature is one additive module inside the existing `tinydb` package plus one additive test file; no new packages, directories, or services. `acceptance_public.py` imports `tinydb.journal` directly, so the module must be importable as `tinydb.journal` (no re-export from `tinydb/__init__.py` is required; keeping `__init__.py` unchanged is the lowest-risk choice and satisfies Constitution I).

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

No violations — section intentionally empty.
