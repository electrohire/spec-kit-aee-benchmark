# Feature Specification: Batch Journal Writer for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "Build tinydb.journal.BatchWriter(db), wrapping a supplied TinyDB instance without changing its ordinary APIs. Use the default table only. R01: apply(operations) accepts a list of operation dictionaries (insert document / remove by doc_id), returns inserted IDs, [] for empty input, ValueError for unknown/malformed operations. R02: batch application is atomic with full rollback of the pre-batch default-table data on any error; missing-ID remove is an error; previously acquired default-table handles must reflect success and rollback. R03: ordinary TinyDB reads/writes and preexisting documents continue to work; inserted and returned nested data must not alias the caller's input."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a Batch of Inserts and Removes (Priority: P1)

An application developer wraps an existing TinyDB instance with a batch writer and submits a list of operations (insert a document, or remove a document by ID) in a single call. The call returns the IDs of the documents it inserted; removes contribute no result. This is the core value: a multi-step change expressed and applied as one batch.

**Why this priority**: Without successful batch application there is no feature; every other story builds on it.

**Independent Test**: On an empty database, apply one insert and verify the returned ID and that the document is visible through the ordinary read API; then apply one remove of that ID and verify the table is empty and the result is [].

**Acceptance Scenarios**:

1. **Given** an empty default table, **When** the batch is applied with one insert of a document, **Then** the call returns the single inserted ID and the document is readable through the ordinary TinyDB read APIs.
2. **Given** a default table containing the document with the given ID, **When** the batch is applied with one remove for that ID, **Then** the call returns [] and the table no longer contains the document.
3. **Given** any default-table state, **When** the batch is applied with an empty operation list, **Then** the call returns [] and the table is unchanged.
4. **Given** a batch mixing inserts and removes, **When** it is applied successfully, **Then** operations take effect in list order and the result is exactly the inserted IDs in insertion order.

---

### User Story 2 - Atomic Batch with Full Rollback (Priority: P1)

A developer relies on the batch being all-or-nothing: if any operation in the batch fails, the default table is restored to exactly its pre-batch state, and the failure is reported as an error. Handles to the default table that were acquired before the batch call must observe the outcome without needing to be re-acquired.

**Why this priority**: A partially applied batch would silently corrupt data; atomicity is a load-bearing guarantee, not a nice-to-have.

**Independent Test**: Seed one preexisting document, then apply a batch whose second operation removes a missing ID; verify the error is raised and the table contains exactly the preexisting document.

**Acceptance Scenarios**:

1. **Given** pre-batch default-table data and a batch in which a later operation fails (for example, a remove targeting a missing ID), **When** the batch is applied, **Then** an error is raised and the default table is restored to exactly its complete pre-batch data (documents, IDs, and order).
2. **Given** a previously acquired handle to the default table, **When** a batch succeeds or rolls back, **Then** that handle reflects the post-batch state on success and the restored pre-batch state on rollback, without re-acquisition.
3. **Given** a batch whose first operation fails, **When** it is applied, **Then** no partial changes remain in the default table.
4. **Given** a batch that removes an ID inserted by an earlier operation in the same batch, **When** it is applied, **Then** the remove is valid (sequential semantics) and the batch succeeds.

---

### User Story 3 - Strict Validation and Safe Data Handling (Priority: P2)

A developer expects malformed input to be rejected loudly and predictably, and expects no hidden sharing between their in-memory data and the database: mutating their documents or operations after a successful apply must not alter stored data, and ordinary TinyDB usage is unaffected by the wrapper.

**Why this priority**: Validation and aliasing safety protect data integrity at the edges of the feature; they do not block the core flow but are required for trustworthy use.

**Independent Test**: Apply a batch containing an unknown operation type and verify ValueError is raised with the table unchanged; then apply a valid batch with a nested document, mutate the caller's copy afterward, and verify the stored document is unchanged.

**Acceptance Scenarios**:

1. **Given** an operation with an unknown or missing op type, **When** the batch is applied, **Then** ValueError is raised and the default table is unchanged.
2. **Given** a malformed operation (missing 'document' on an insert, a non-dict document, a missing/non-integer/non-positive 'doc_id' on a remove, or a non-dict operation entry), **When** the batch is applied, **Then** ValueError is raised and the default table is unchanged.
3. **Given** a successful batch that inserted a nested document, **When** the caller mutates the original document or operation afterward, **Then** the stored data is unchanged and the returned data is not the same object as the caller's input.
4. **Given** a wrapped database with preexisting documents, **When** ordinary TinyDB reads and writes are used alongside the writer, **Then** they continue to work and observe the same data as the writer.

### Edge Cases

- Removing a missing ID is an error and triggers full rollback (not a silent no-op).
- A 'doc_id' of 0 or negative is malformed and raises ValueError.
- An empty operation list returns [] and changes nothing.
- Operations containing extra keys beyond the required ones are accepted and the extra keys are ignored (assumption A5).
- Only the default table is touched; other tables are out of scope and unaffected.
- The writer is bound to the specific TinyDB instance it was given; other instances are unaffected.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST provide a batch writer that wraps a supplied TinyDB instance additively, without changing the observable behavior of that instance's ordinary APIs.
- **FR-002**: The batch writer MUST operate on the default table only.
- **FR-003**: The batch writer MUST expose an apply operation that accepts a list of operation dictionaries, where each operation is either an insert (carrying a 'document' that is a dict) or a remove (carrying a 'doc_id' that is a positive integer).
- **FR-004**: The apply operation MUST return the list of inserted document IDs in insertion order; remove operations MUST contribute no result; an empty input list MUST return [].
- **FR-005**: The apply operation MUST raise ValueError for unknown or malformed operations (unknown op, missing or wrongly typed 'document', missing or non-positive 'doc_id', non-dict operation entry).
- **FR-006**: Batch application MUST be atomic: operations are validated and applied sequentially, and on any error the complete pre-batch default-table data MUST be restored.
- **FR-007**: A remove targeting a missing ID MUST be treated as an error (and therefore trigger rollback).
- **FR-008**: Previously acquired handles to the default table MUST reflect both successful application and rollback without re-acquisition.
- **FR-009**: Ordinary TinyDB reads and writes, including preexisting documents, MUST continue to work alongside the writer.
- **FR-010**: Inserted data and returned data MUST NOT alias the caller's input: nested structures are stored independently, and mutating a caller's document or operation after apply MUST NOT mutate stored data.

### Key Entities

- **BatchWriter**: The wrapper bound to one TinyDB instance; exposes the single apply operation.
- **Operation**: A dict describing one change: 'insert' with a 'document' (dict) or 'remove' with a 'doc_id' (positive integer).
- **Document**: A dict stored in the default table, identified by a positive integer ID.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of valid batches (mixed inserts/removes, empty, single-op) return exactly the inserted IDs in insertion order and leave the default table in the expected state.
- **SC-002**: 100% of failing batches (unknown op, malformed fields, missing-ID remove) raise ValueError and leave the default table byte-for-byte equal to its pre-batch state, as observed through previously acquired table handles.
- **SC-003**: 100% of post-apply mutations of caller-supplied documents or operations leave stored data unchanged (zero aliased fields observed in tests).
- **SC-004**: Ordinary TinyDB reads/writes and preexisting documents show zero behavioral regressions in the project's existing and public acceptance tests.
- **SC-005**: The feature is delivered without modifying any upstream test file (zero upstream test files changed).

## Assumptions

- **A1**: The supplied TinyDB instance is the only storage target; the writer does not create, open, or configure storage.
- **A2**: "Positive integer" for 'doc_id' means an integer greater than 0; booleans are not accepted as IDs.
- **A3**: The result of a successful apply is a plain Python list of IDs (not a database query object).
- **A4**: The error type for all invalid-operation and missing-ID conditions is ValueError, as stated in the requirements.
- **A5**: Extra keys on an operation dict are ignored; only 'op' plus the op-specific required key is validated.
- **A6**: Operation order within a batch is significant (sequential semantics); removing an ID inserted earlier in the same batch is valid.
- **A7**: "Restore the complete pre-batch default-table data" means document contents, IDs, and ordering are identical to the pre-batch state.
