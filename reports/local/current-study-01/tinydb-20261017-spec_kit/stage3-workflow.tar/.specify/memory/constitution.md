<!-- Sync Impact Report (temporary; remove before commit) -->
<!-- Version: 0 (scaffold) -> 1.0.0 (initial ratification) -->
<!-- Modified principles: none (new document) -->
<!-- Added sections: Core Principles (I-V), Additional Constraints, Development Workflow, Governance -->
<!-- Removed sections: none -->
<!-- Deferred TODOs: none -->
# tinydb Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
New features MUST wrap or extend existing components without changing the
observable behavior of existing public APIs. Existing callers of the ordinary
`TinyDB` interfaces MUST continue to work unchanged. Any new entry point
(e.g. `tinydb.journal.BatchWriter`) MUST be additive and MUST NOT alter the
semantics of preexisting methods.
Rationale: this milestone adds a journal/batch layer on top of TinyDB; breaking
the ordinary read/write contract would invalidate every downstream consumer.

### II. Testable Acceptance Criteria
Every requirement MUST carry at least one objective, observable acceptance
criterion that a test can check (concrete input to expected output or
exception). Vague language ("should", "fast", "easy") is NOT acceptable in a
requirement; state the concrete behavior and its observable result.
Rationale: requirements such as R01-R03 must be verifiable by `pytest`
(see `acceptance_public.py`) without interpretation.

### III. Evidence Over Assertion
Claims about behavior MUST be backed by observed evidence (a run command and
its output, or a passing test). Distinguish explicitly between what was
observed and what is assumed or unverified. Do NOT report a test as run
without a command and its output as evidence.
Rationale: autonomous work has no human to confirm results; only reproducible
evidence is trustworthy.

### IV. Simple, Scoped Implementations
Prefer the smallest implementation that satisfies the stated requirements.
Do NOT add speculative features, abstractions, or configuration beyond the
scope of the current requirement (YAGNI). Keep changes local to the affected
module (e.g. `tinydb/journal.py`).
Rationale: scope creep and unrequested generality increase risk and review
cost without adding required value.

### V. Document Assumptions and Regressions
Unresolved assumptions, open questions, and any regressions introduced MUST be
recorded in writing (e.g. `HANDOFF.md` and the relevant spec/plan documents)
rather than left implicit. A regression MUST be named, its trigger described,
and its status (open/fixed) stated.
Rationale: later phases and reviewers need an explicit record of what is
settled versus what is still open.

## Additional Constraints

- Implementation source for the batch feature is `tinydb/journal.py`.
- The batch writer MUST target the default table only.
- Upstream tests MUST remain unchanged; do not modify `acceptance_public.py`.
- Public acceptance is defined by `acceptance_public.py`.

## Development Workflow

- Work proceeds through the Spec Kit phases (constitution, specify, clarify,
  plan, tasks, implement, converge) in order.
- Application implementation is deferred to later phases; this phase only
  establishes governance.
- Keep documents concise and make evidence explicit.
- Feature artifacts live under `specs/001-transactions`.

## Governance

This constitution supersedes all other conflicting practices in the project.
Amendments require a written change to this file, a semantic version bump
(MAJOR for removed/redefined principles, MINOR for added principles or
materially expanded guidance, PATCH for clarifications), and an updated
`Last Amended` date. Compliance is reviewed at each phase boundary; a phase
MUST NOT be declared done while a principle is violated.

**Version**: 1.0.0 | **Ratified**: 2026-10-17 | **Last Amended**: 2026-10-17
