# Phase 0 Research: Batch Journal Writer for TinyDB

Feature: `specs/001-transactions/spec.md` | Date: 2026-10-17

## Unknowns from Technical Context and Their Resolution

No `[NEEDS CLARIFICATION]` markers remained in the spec; the unknowns below are
the technical decisions the plan had to make, resolved from direct inspection of
the codebase (evidence: file/line references).

### D1 - How to make a batch atomic without changing TinyDB's ordinary APIs

- **Decision**: `BatchWriter.apply` performs one read-modify-write per batch
  against the default table's storage, instead of calling `table.insert` /
  `table.remove` per operation.
- **Rationale**: `Table._update_table` (tinydb/table.py:804) already implements the
  only write path: `storage.read()` -> mutate the table dict -> `storage.write()`.
  `MemoryStorage.read()` (tinydb/storages.py:177) returns the live in-memory dict
  with **no copy**, so per-op writes would mutate shared state mid-batch and a
  later failure would leave partial changes. A single in-memory pass over a
  deep-copied snapshot, committed with one `storage.write`, gives true atomicity
  with no changes to `Table`/`TinyDB`/`Storage` public behavior (Constitution I).
- **Alternatives considered**:
  1. Call `table.insert`/`table.remove` per op and restore on error. Rejected:
     `Table.remove(doc_ids=...)` (tinydb/table.py:608) *silently skips* missing
     IDs, so a missing-ID remove would not raise as R02 requires; also each op
     does a full storage round-trip and mutates state incrementally.
  2. Wrap each op in try/except and call `storage.write(snapshot)` on failure.
     Rejected: still leaves the `_next_id` cache and per-op overhead; the single
     pass is simpler and strictly more atomic.

### D2 - ID allocation must match TinyDB's own rule

- **Decision**: Replicate `Table._get_next_id` (tinydb/table.py:751): if the
  table is empty the first ID is 1; otherwise it is `max(existing ids) + 1`,
  computed against the in-batch working dict so later ops see earlier inserts.
- **Rationale**: Keeps returned IDs identical to what ordinary sequential
  `table.insert` calls would produce (acceptance test expects `[1]` for the first
  insert). No reliance on the private `Table._next_id` cache.
- **Alternatives considered**: Reusing `Table._get_next_id` directly - rejected
  because it reads storage and mutates the private `_next_id` cache, which would
  desynchronize from a rolled-back snapshot.

### D3 - Rollback must be observable by previously acquired table handles

- **Decision**: On error, `storage.write(deepcopy(pre_batch_snapshot))`. On
  success, `storage.write(working_tables)`. Both go through the same storage
  write path ordinary writes use.
- **Rationale**: `TinyDB.table()` caches `Table` instances (tinydb/database.py:111)
  and every read goes through `Table._read_table` -> `storage.read()`
  (tinydb/table.py:771), so any handle re-reads storage on each access. A write
  to storage is therefore visible to all handles without re-acquisition (R02/FR-008).
  The query cache is per-table and only used by `search`; `all()`/`__iter__`/
  `__len__` always re-read storage (tinydb/table.py:221,715), so no stale-handle
  risk for the operations the requirements exercise.
- **Alternatives considered**: Manually invalidating each known table's query
  cache - unnecessary for the exercised read paths and would couple the writer to
  private cache internals.

### D4 - No aliasing between caller input and stored/returned data

- **Decision**: Deep-copy each inserted document **before** it enters the working
  table (`copy.deepcopy(document)`), and return IDs only (no document objects).
- **Rationale**: `Table.insert` stores `dict(document)` (tinydb/table.py:168), a
  *shallow* copy - nested structures would still alias the caller (violates R03).
  Deep-copying in the writer guarantees `mutating the caller's dict after apply`
  cannot touch stored data. Because only IDs are returned, there is no returned
  document object to alias. (Constitution IV: minimal change - deep copy is the
  smallest mechanism that satisfies R03.)
- **Alternatives considered**: Relying on `Table.insert`'s shallow copy - rejected
  (insufficient for nested data).

### D5 - Validation rules and error type

- **Decision**: Validate each operation **before** any mutation, raising
  `ValueError` for: non-dict operation; `op` not in `{'insert','remove'}`;
  insert missing `document` or `document` not a `Mapping`; remove missing
  `doc_id`, or `doc_id` not an `int` (bool excluded) or `<= 0`. A remove whose
  `doc_id` is absent from the working table at its turn is also `ValueError`.
- **Rationale**: Matches R01/R02 and spec FR-005/FR-007; bool is a subclass of
  int in Python so it is explicitly excluded (assumption A2).
- **Alternatives considered**: Raising `KeyError`/`LookupError` for missing IDs -
  rejected; the issue and spec fix the error type as `ValueError`.

### D6 - Where the code lives and how it is tested

- **Decision**: New module `tinydb/journal.py` exposing `BatchWriter`.
  New test file `tests/test_journal.py` (own tests). `acceptance_public.py`
  and all existing `tests/*.py` remain untouched.
- **Rationale**: The issue names `tinydb/journal.py` as the implementation
  source; adding a test file does not modify upstream tests (Constitution I/II).
- **Alternatives considered**: Extending `tinydb/table.py` - rejected; the issue
  specifies a dedicated module and keeps the change additive.

## Best-Practice Notes

- Atomicity via snapshot + single commit is the standard in-memory transaction
  pattern for read-modify-write stores (TinyDB's storage API only supports
  whole-database writes, per the docstring of `Table._update_table`).
- Keep the public surface minimal: one class, one method (`apply`), one return
  type (`list[int]`), one error type (`ValueError`). (Constitution IV)
