# Contract: tinydb.journal.BatchWriter

Feature: `specs/001-transactions/spec.md` | Date: 2026-10-17

This is the only new public surface for the feature. Everything else is
unchanged (Constitution I).

## Module

`tinydb/journal.py`, exporting `BatchWriter`.

## Constructor

```python
BatchWriter(db: TinyDB) -> BatchWriter
```

- Binds the writer to the supplied `TinyDB` instance and its default table
  (`db.table(db.default_table_name)`).
- Performs no writes and no schema changes; construction is side-effect free.
- Does not alter `db`'s ordinary APIs (reads/writes on `db` or any table handle
  behave exactly as before).

## Method: apply

```python
apply(operations: list[dict]) -> list[int]
```

### Inputs

- `operations`: a list; each element MUST be a dict of exactly one of the two
  valid shapes (see data-model.md): `{'op': 'insert', 'document': dict}` or
  `{'op': 'remove', 'doc_id': int > 0}`. Extra keys are ignored (A5).

### Outputs

- On success: a plain `list[int]` containing the IDs of the inserted documents,
  in insertion order. Removes contribute nothing. Empty input -> `[]`.

### Errors

- `ValueError` for any of:
  - `operations` is not a list, or an element is not a dict;
  - `op` missing or not in `{'insert', 'remove'}`;
  - insert: `document` missing or not a `Mapping`;
  - remove: `doc_id` missing, not an `int` (bool excluded), or `<= 0`;
  - remove: `doc_id` absent from the table when the operation's turn arrives
    (R02: missing-ID remove is an error).
- On `ValueError` the default table is restored to its complete pre-batch state
  (contents, IDs, order) and the error propagates to the caller.

### Atomicity and visibility

- The batch is all-or-nothing: either every operation took effect (one storage
  write) or the pre-batch state is fully restored (one storage write).
- Previously acquired `db.table('_default')` handles reflect both outcomes on
  their next read without re-acquisition.
- Only the default table is modified; other tables in the storage are carried
  through unchanged.

### Aliasing

- Stored documents are deep copies of the caller's input; mutating a caller
  document or operation after `apply` returns cannot mutate stored data (R03).
- The return value contains IDs only.

## Non-goals (out of contract)

- No multi-table batches, no update op, no persistence format change, no
  threading/locking guarantees, no context-manager or async API.
