# Quickstart / Validation Guide: Batch Journal Writer for TinyDB

Feature: `specs/001-transactions/spec.md` | Date: 2026-10-17

Validation scenarios proving the feature works end-to-end. Contract details:
[contracts/batch-writer.md](contracts/batch-writer.md). Data semantics:
[data-model.md](data-model.md). Implementation details belong to tasks.md /
implementation phase - not here.

## Prerequisites

- Python 3 with the repository importable (`PYTHONPATH=src:.` or installed editable).
- `pytest` available (used by `acceptance_public.py`).
- No storage files or network access required; scenarios use `MemoryStorage`.

## Setup

No installation steps: the feature is an in-repo module `tinydb/journal.py`.

## Scenario 1 - Basic batch (R01)

```python
from tinydb import TinyDB
from tinydb.storages import MemoryStorage
from tinydb.journal import BatchWriter

db = TinyDB(storage=MemoryStorage)
w = BatchWriter(db)
assert w.apply([{'op': 'insert', 'document': {'x': 1}}]) == [1]
assert db.all()[0]['x'] == 1
assert w.apply([{'op': 'remove', 'doc_id': 1}]) == []
assert len(db) == 0
```

**Expected**: all asserts pass; `apply` returns inserted IDs only; empty result
for remove-only batches.

## Scenario 2 - Atomicity and rollback (R02)

```python
db = TinyDB(storage=MemoryStorage)
w = BatchWriter(db)
db.insert({'x': 1})
try:
    w.apply([{'op': 'insert', 'document': {'x': 2}},
             {'op': 'remove', 'doc_id': 99}])
    raise AssertionError('expected ValueError')
except ValueError:
    pass
assert [v['x'] for v in db.all()] == [1]   # pre-batch state fully restored
```

**Expected**: `ValueError` raised; the earlier insert in the same failed batch
is gone; the preexisting document remains.

## Scenario 3 - Previously acquired handles see the outcome (R02)

```python
handle = db.table('_default')          # acquired BEFORE the batch
w.apply([{'op': 'insert', 'document': {'y': 2}}])
assert len(handle) == 2                # success visible without re-acquisition
try:
    w.apply([{'op': 'remove', 'doc_id': 12345}])
except ValueError:
    pass
assert len(handle) == 2                # rollback visible on the same handle
```

## Scenario 4 - No aliasing (R03)

```python
doc = {'nested': {'a': [1, 2]}}
w.apply([{'op': 'insert', 'document': doc}])
doc['nested']['a'].append(3)           # mutate caller data after apply
assert db.all()[0]['nested']['a'] == [1, 2]   # stored data unchanged
```

## Scenario 5 - Ordinary API coexistence (R03)

```python
db.insert({'plain': True})            # ordinary write still works
assert len(db) == len(handle)         # both views agree
```

## Automated validation commands

```bash
# Public acceptance (must pass, unmodified)
PYTHONPATH=src:. python -m pytest acceptance_public.py -v

# Own tests for this feature (added in implementation phase)
PYTHONPATH=src:. python -m pytest tests/test_journal.py -v

# Full regression (upstream tests must remain green and unchanged)
PYTHONPATH=src:. python -m pytest tests/ -q
```

**Expected outcomes**: all three commands exit 0; `acceptance_public.py` and
every file under `tests/` except the new `tests/test_journal.py` are
byte-identical to before the change.
