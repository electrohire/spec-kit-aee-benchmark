# Feature Specification: Batch Journal Writer for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17 | **Last Updated**: 2026-10-17

**Status**: Draft (milestone 3 supersedes earlier milestone text where conflicting)

**Input**: User description: "Build tinydb.journal.BatchWriter(db), wrapping a supplied TinyDB instance without changing its ordinary APIs. Use the default table only. R01: apply(operations) accepts a list of operation dictionaries; each operation is {'op':'insert','document':dict} or {'op':'remove','doc_id':positive integer}; returns inserted document IDs (removes add no result); empty input returns []; unknown/malformed operations raise ValueError. R02: batch application is atomic; validate and apply sequentially, but on any error restore the complete pre-batch default-table data; a remove targeting a missing ID is an error; previously acquired db.table('_default') handles must reflect both success and rollback. R03: ordinary TinyDB reads/writes and preexisting documents continue to work; inserted and returned nested data must not alias the caller's input; mutating an operation after apply cannot mutate the database. R04: reject bool as a doc_id even though bool is an int subclass; validate operations structurally before committing changes; raise ValueError for unsupported fields, non-list operations, or non-dict documents; accept empty dictionaries as documents. R05: preview(operations) returns the inserted IDs that apply would produce but leaves all data and the next insertion ID unchanged, including on errors; preview and failed apply must not consume IDs; existing table handles and query caches must remain coherent. R06: direct db.insert operations between calls must be seen by the wrapper; do not cache a stale initial snapshot. R05b: preview must return a new, detached list on every call; mutating a list previously returned by preview must not affect subsequent preview results or any internal writer state. R05 clarification: apply advances the wrapper's next-insertion-ID state on every successful batch and writes that state back to the underlying table so subsequent inserts (via apply or direct db.insert) continue the ID sequence without reuse or rewind, even across remove operations. R07: apply(operations, token=None) supports an optional nonempty string idempotency token; repeating an already successful identical batch/token returns a detached copy of the original inserted IDs without rerunning mutations, even if other direct database writes occurred; reusing a token with different operations raises ValueError without changing data; failed batches do not consume a token; None means normal operation; invalid tokens raise ValueError. R08: token bookkeeping belongs to this BatchWriter instance, never in user documents; a preview never records/consumes a token and keeps its original signature; return lists must not expose internal token bookkeeping through mutation."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Apply a Batch of Inserts and Removes (Priority: P1)

An application developer wraps an existing TinyDB instance with a batch writer and submits a list of operations (insert a document, or remove a document by ID) in a single call. The call returns the IDs of the documents it inserted; removes contribute no result. This is the core value: a multi-step change expressed and applied as one batch.

**Why this priority**: Without successful batch application there is no feature; every other story builds on it.

**Independent Test**: On an empty database, apply one insert and verify the returned ID and that the document is visible through the ordinary read API; then apply one remove of that ID and verify the table is empty and the result is [].

**Acceptance Scenarios**:

1. **Given** an empty default table, **When** the batch is applied with one insert of a document, **Then** the call returns the single inserted ID and the document is readable through the ordinary TinyDB read APIs.
2. **Given** a default table containing the document with the given ID, **When** the batch is applied with one remove for that ID, **Then** the call returns [] and the table no longer contains the document.
3. **Given** any default-table state, **When** the batch is applied with an empty operation list, **Then** the call returns [] and the table is unchanged.
4. **Given** a batch mixing inserts and removes, **When** it is applied successfully, **Then** operations take effect in list order and the result is exactly the inserted IDs in insertion order.
5. **Given** a batch whose operations include an insert of an empty document, **When** it is applied, **Then** the empty document is accepted and an ID is returned for it.

---

### User Story 2 - Atomic Batch with Full Rollback (Priority: P1)

A developer relies on the batch being all-or-nothing: if any operation in the batch fails, the default table is restored to exactly its pre-batch state, and the failure is reported as an error. Handles to the default table that were acquired before the batch call must observe the outcome without needing to be re-acquired.

**Why this priority**: A partially applied batch would silently corrupt data; atomicity is a load-bearing guarantee, not a nice-to-have.

**Independent Test**: Seed one preexisting document, then apply a batch whose second operation removes a missing ID; verify the error is raised and the table contains exactly the preexisting document.

**Acceptance Scenarios**:

1. **Given** pre-batch default-table data and a batch in which a later operation fails (for example, a remove targeting a missing ID), **When** the batch is applied, **Then** an error is raised and the default table is restored to exactly its complete pre-batch data (documents, IDs, and order).
2. **Given** a handle to the default table acquired before the batch call, **When** the batch succeeds or rolls back, **Then** that same handle reflects the outcome (new documents, or the restored data) without re-acquisition.
3. **Given** a batch whose first operation succeeds and a later operation fails, **When** the error is raised, **Then** the effect of the earlier in-batch operation is also undone.

---

### User Story 3 - Strict Input Validation (Priority: P2)

A developer expects malformed input to be rejected loudly and predictably, and expects no hidden sharing between their in-memory data and the database: mutating their documents or operations after a successful apply must not alter stored data, and ordinary TinyDB usage is unaffected by the wrapper.

**Why this priority**: Validation and aliasing safety protect data integrity at the edges of the feature; they do not block the core flow but are required for trustworthy use.

**Independent Test**: Apply a batch containing an unknown operation type and verify ValueError is raised with the table unchanged; then apply a valid batch with a nested document, mutate the caller's copy afterward, and verify the stored document is unchanged.

**Acceptance Scenarios**:

1. **Given** an operation with an unknown or missing op type, **When** the batch is applied, **Then** ValueError is raised and the default table is unchanged.
2. **Given** a malformed operation (missing 'document' on an insert, a non-dict document, a missing/non-integer/non-positive 'doc_id' on a remove, a boolean 'doc_id', a non-dict operation entry, or extra/unsupported keys on an operation), **When** the batch is applied, **Then** ValueError is raised and the default table is unchanged.
3. **Given** a batch that is not a list of operations, **When** it is applied or previewed, **Then** ValueError is raised and nothing is committed.
4. **Given** a successful batch that inserted a nested document, **When** the caller mutates the original document or operation afterward, **Then** the stored data is unchanged and the returned data is not the same object as the caller's input.
5. **Given** a wrapped database with preexisting documents, **When** ordinary TinyDB reads and writes are used alongside the writer, **Then** they continue to work and observe the same data as the writer.

---

### User Story 4 - Preview Without Side Effects (Priority: P2)

A developer wants to know what a batch would insert before committing it: a preview call returns the IDs that a successful apply would produce, but changes nothing. Repeated previews and previews of failing batches must not consume IDs or disturb data, and each preview result must be an independent list the caller may mutate freely.

**Why this priority**: Preview enables safe planning and retry flows; if it consumed IDs or mutated state, the apply-after-preview pattern would silently shift IDs and break callers.

**Independent Test**: On an empty database, preview one insert and verify it returns the would-be ID while the table stays empty; then apply the same batch and verify the same ID is returned and the document exists.

**Acceptance Scenarios**:

1. **Given** any default-table state, **When** a valid batch is previewed, **Then** the call returns exactly the IDs a successful apply of the same batch would return, the table data is unchanged, and the next insertion ID is unchanged.
2. **Given** a batch that would fail (unknown op, malformed fields, or a missing-ID remove), **When** it is previewed, **Then** ValueError is raised and neither the data nor the next insertion ID changes.
3. **Given** a preview result list, **When** the caller mutates or discards it, **Then** subsequent previews of the same batch return identical values and the writer's internal state is unaffected.
4. **Given** a preview of a batch, **When** the same batch is later applied, **Then** the apply returns the same IDs the preview reported.

---

### User Story 5 - Stable ID Sequences Across Mixed Usage (Priority: P2)

A developer interleaves the writer with direct database writes and expects the ID sequence to behave like one continuous allocator: no IDs are ever reused or rewound, and direct writes between calls are always visible to the writer.

**Why this priority**: ID continuity is what makes returned IDs safe to store and reference; a stale snapshot or reset allocator would silently break references.

**Independent Test**: Insert directly, apply a batch, insert directly again, then apply another batch; verify the sequence strictly increases with no reuse, and that the writer saw the direct inserts.

**Acceptance Scenarios**:

1. **Given** a direct db insert performed between two batch calls, **When** the second batch is applied, **Then** the wrapper's behavior reflects the direct insert (no stale snapshot; no ID collision with it).
2. **Given** a successful batch, **When** later inserts occur via the writer or directly, **Then** they receive the next IDs in a strictly continuing sequence with no reuse or rewind.
3. **Given** a successful batch that also removed documents, **When** subsequent inserts occur, **Then** removed IDs are never reissued and the sequence continues past the highest ID the batch advanced to.
4. **Given** a failed batch (rolled back), **When** the next successful insert occurs, **Then** no IDs consumed by the failed batch are ever reissued to a different document.

---

### User Story 6 - Idempotent Re-application with Tokens (Priority: P3)

A developer retries a batch after an uncertain outcome (for example, a network or process failure between apply and confirmation) by resubmitting the identical batch with the same idempotency token. The writer recognizes the previously successful batch and returns the original result again without applying the mutations a second time; reusing a token for a different batch is rejected.

**Why this priority**: Idempotent retries prevent duplicate documents on at-least-once delivery; the core apply/rollback flow still works without tokens, so this is a valuable but separable capability.

**Independent Test**: Apply a batch with token 'a' and note the returned IDs; apply the identical batch with token 'a' again and verify the same IDs are returned while the table still contains exactly one copy of each inserted document.

**Acceptance Scenarios**:

1. **Given** a successful apply of a batch with a token, **When** the identical batch is applied again with the same token, **Then** the original inserted IDs are returned again (as a fresh list) and no further mutations occur, even if other direct database writes happened in between.
2. **Given** a token already bound to a successful batch, **When** a different batch is applied with that same token, **Then** ValueError is raised and the data is unchanged.
3. **Given** a batch that failed (and rolled back) with a token, **When** the same batch is retried with the same token, **Then** it runs normally as if the token were unused (the failed attempt did not consume the token).
4. **Given** a token that is not a nonempty string (for example, None, an empty string, a number, or a list), **When** it is passed to apply, **Then** ValueError is raised and nothing changes; None specifically means normal operation with no token.
5. **Given** a batch applied without a token, **When** the same batch is applied again without a token, **Then** it runs again normally (no token means no idempotency).
6. **Given** a preview call, **When** it is made with or without any token-like argument, **Then** it keeps its original single-argument signature and never records or consumes a token.

### Edge Cases

- Removing a missing ID is an error and triggers full rollback (not a silent no-op).
- A 'doc_id' of 0 or negative is malformed and raises ValueError.
- A boolean 'doc_id' (True/False) is malformed and raises ValueError even though booleans are integer subclasses.
- An empty operation list returns [] and changes nothing (for both apply and preview).
- An operation dict with extra/unsupported keys raises ValueError (strict structural validation).
- A non-list operations argument (e.g., a dict, a string, or a single dict) raises ValueError.
- A non-dict document (e.g., a list or scalar) raises ValueError; an empty dict document is valid.
- Previewing or applying a failing batch never consumes or advances IDs.
- A failed batch with a token leaves the token unconsumed; a successful batch with a token binds it permanently to that batch.
- A repeated successful token returns the original result even if direct db writes changed the table in the meantime.
- Only the default table is touched; other tables are out of scope and unaffected.
- The writer is bound to the specific TinyDB instance it was given; other instances are unaffected.
- Token bookkeeping is internal to the writer instance: stored documents contain no token markers, and returned lists are plain, freely mutable copies.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST provide a batch writer that wraps a supplied TinyDB instance additively, without changing the observable behavior of that instance's ordinary APIs.
- **FR-002**: The batch writer MUST operate on the default table only.
- **FR-003**: The batch writer MUST expose an apply operation that accepts a list of operation dictionaries, where each operation is either an insert (carrying a 'document' that is a dict, possibly empty) or a remove (carrying a 'doc_id' that is a positive integer greater than 0 and not a boolean).
- **FR-004**: The apply operation MUST return the list of inserted document IDs in insertion order; remove operations MUST contribute no result; an empty input list MUST return [].
- **FR-005**: The apply operation MUST raise ValueError for unknown or malformed operations (unknown or missing op, missing or non-dict 'document', missing or non-positive or boolean 'doc_id', non-dict operation entry) and MUST raise ValueError for a non-list operations argument.
- **FR-006**: The batch writer MUST validate every operation structurally before committing any change to the default table; no partial commit may be observable from any failure.
- **FR-007**: Batch application MUST be atomic: operations are applied sequentially, and on any error (including a remove targeting a missing ID) the complete pre-batch default-table data MUST be restored.
- **FR-008**: A remove targeting a missing ID MUST be treated as an error (and therefore trigger rollback).
- **FR-009**: Previously acquired handles to the default table MUST reflect both successful application and rollback without re-acquisition.
- **FR-010**: Ordinary TinyDB reads and writes, including preexisting documents, MUST continue to work alongside the writer, and direct inserts performed between batch calls MUST be visible to the writer (no stale initial snapshot).
- **FR-011**: Inserted data and returned data MUST NOT alias the caller's input: nested structures are stored independently, and mutating a caller's document or operation after apply MUST NOT mutate stored data.
- **FR-012**: The batch writer MUST expose a preview operation that accepts the same operation-list input as apply and returns exactly the inserted IDs a successful apply of that batch would produce.
- **FR-013**: Preview MUST leave the default-table data, the next insertion ID, and all existing table handles and query caches unchanged, including when the previewed batch would fail (in which case preview raises ValueError).
- **FR-014**: Preview MUST return a new, detached list on every call; mutating a previously returned preview list MUST NOT affect subsequent preview results or the writer's internal state.
- **FR-015**: Neither preview nor a failed apply MUST consume or advance the next insertion ID; IDs that a failed batch would have used MUST never be reissued to different documents.
- **FR-016**: Every successful apply MUST advance the next-insertion-ID state and persist that state to the underlying table so that subsequent inserts, whether via the writer or direct database writes, continue the ID sequence without reuse or rewind, even after remove operations.
- **FR-017**: The apply operation MUST accept an optional idempotency token that is either absent/None (normal operation) or a nonempty string; any other token value MUST raise ValueError without changing data.
- **FR-018**: Reapplying an identical batch with a token that already recorded a successful apply MUST return a detached copy of the original inserted IDs without re-running the mutations, even if other direct database writes occurred in the meantime.
- **FR-019**: Applying a different batch with a token already bound to a successful batch MUST raise ValueError without changing data.
- **FR-020**: A failed batch MUST NOT consume or bind its token; the same token may be retried after failure as if unused.
- **FR-021**: Token bookkeeping MUST be internal to the batch writer instance and MUST never be written into user documents; preview MUST never record or consume a token and MUST keep its original single-argument signature; every returned list MUST be a plain, freely mutable copy that does not expose internal state.

### Key Entities

- **BatchWriter**: The wrapper bound to one TinyDB instance; exposes apply (with optional idempotency token) and preview.
- **Operation**: A dict describing one change: 'insert' with a 'document' (dict, possibly empty) or 'remove' with a 'doc_id' (positive integer, not boolean); no extra fields allowed.
- **Document**: A dict stored in the default table, identified by a positive integer ID.
- **Next insertion ID**: The allocator position for new document IDs; advanced by successful batches and direct writes, never rewound or reused.
- **Idempotency token**: A nonempty string binding a successful batch to its original result, kept privately by the writer instance.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of valid batches (mixed inserts/removes, empty, single-op, empty-document inserts) return exactly the inserted IDs in insertion order and leave the default table in the expected state.
- **SC-002**: 100% of failing batches (unknown op, malformed fields, boolean/zero/negative doc_id, extra keys, non-list input, missing-ID remove) raise ValueError and leave the default table and the next insertion ID equal to their pre-batch state, as observed through previously acquired table handles.
- **SC-003**: 100% of post-apply mutations of caller-supplied documents or operations leave stored data unchanged (zero aliased fields observed in tests).
- **SC-004**: 100% of preview calls return exactly the IDs a matching successful apply would return while leaving data, the next insertion ID, handles, and query caches unchanged; mutating returned preview lists has zero effect on later previews or internal state.
- **SC-005**: Across any interleaving of successful/failed batches and direct inserts, the ID sequence is strictly continuing with zero reuses and zero rewinds, including after removes.
- **SC-006**: 100% of repeated identical batch/token applies return the original IDs with zero additional mutations (table size and contents unchanged by the repeat), and 100% of token mismatches raise ValueError with zero data change; failed batches consume zero tokens.
- **SC-007**: Ordinary TinyDB reads/writes and preexisting documents show zero behavioral regressions in the project's existing and public acceptance tests.
- **SC-008**: The feature is delivered without modifying any upstream test file (zero upstream test files changed).

## Assumptions

- **A1**: The supplied TinyDB instance is the only storage target; the writer does not create, open, or configure storage.
- **A2**: "Positive integer" for 'doc_id' means an integer greater than 0; booleans are not accepted as IDs (boolean check precedes integer check).
- **A3**: The result of a successful apply or preview is a plain Python list of IDs (not a database query object), freshly allocated on each call.
- **A4**: The error type for all invalid-operation, invalid-token, missing-ID, and token-mismatch conditions is ValueError, as stated in the requirements.
- **A5**: Operation dicts are validated strictly: an insert operation carries exactly the keys 'op' and 'document'; a remove operation carries exactly the keys 'op' and 'doc_id'. Any extra/unsupported key is malformed (supersedes the earlier milestone-1 assumption that extra keys were ignored; R04 is the controlling requirement).
- **A6**: Operation order within a batch is significant (sequential semantics); removing an ID inserted earlier in the same batch is valid.
- **A7**: "Restore the complete pre-batch default-table data" means document contents, IDs, and ordering are identical to the pre-batch state.
- **A8**: "Identical batch" for token comparison means the same operations in the same order with equal operation payloads (insert documents deeply equal; remove IDs equal), independent of the caller's list or dict objects.
- **A9**: The idempotency result for a repeated token is the original inserted IDs from the first successful apply, not newly computed IDs; the repeat performs no mutations at all.
- **A10**: Token bookkeeping is per writer instance: two writers wrapping the same database do not share token state (no requirement demands sharing).
- **A11**: The next insertion ID is a property of the underlying default table state; the writer persists it there so direct database writes and other observers see a consistent allocator position.

## Change History

- **Milestone 1 (R01-R03)**: initial apply, atomicity, and aliasing requirements. All retained.
- **Milestone 2 (R04-R06, plus R05b and the R05 clarification)**: strict pre-commit validation including boolean rejection; preview with zero side effects and detached results; no stale snapshots; ID-continuity guarantee across mixed usage. All retained.
- **Milestone 3 (R07-R08)**: optional idempotency tokens on apply with per-instance bookkeeping. Retains R01-R06.
- **Conflicting evidence resolution**: an older generated note claimed "preview may consume IDs and bool IDs are accepted." That note is unverified and is superseded by R04 (bool doc_id rejected) and R05 (preview must not consume IDs); this spec follows R04/R05. A previously passing happy-path smoke test does not verify these boundaries; the acceptance scenarios above (User Stories 3-5) do.
- **Superseded assumption**: milestone-1 assumption "extra keys on an operation dict are ignored" is superseded by R04's strict structural validation (see A5).
