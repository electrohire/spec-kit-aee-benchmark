# Implementation Plan: Batch Journal Writer for TinyDB

**Branch**: `001-transactions` | **Date**: 2026-10-17 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-transactions/spec.md`

**Note**: This template is filled in by the `$speckit-plan` command; its definition describes the execution workflow.

## Summary

Add `tinydb.journal.BatchWriter(db)` wrapping a supplied `TinyDB` instance
defensively (no changes to ordinary APIs). `apply(operations)` validates a list
of `{'op':'insert','document':dict}` / `{'op':'remove','doc_id':int>0}`
operations, applies them sequentially to the **default table only**, returns the
inserted IDs (removes add nothing; empty input -> `[]`), and is fully atomic:
on any error (including a remove of a missing ID) the complete pre-batch
default-table data is restored and `ValueError` propagates. Stored documents are
deep copies, so caller mutations after `apply` cannot affect the database, and
previously acquired `db.table('_default')` handles observe both success and
rollback. Technical approach (research.md D1): one read-modify-write per batch
against the table's storage instead of per-op `Table` calls.

## Technical Context

**Language/Version**: Python 3 (repository already uses `list[int]` annotations; 3.9+ assumed)

**Primary Dependencies**: stdlib only (`copy.deepcopy`, `collections.abc.Mapping`); the existing `tinydb` package itself

**Storage**: whatever `Storage` the supplied `TinyDB` instance uses (e.g. `MemoryStorage` in tests); the writer uses `storage.read()`/`storage.write()` only

**Testing**: pytest; public acceptance in `acceptance_public.py` (unmodified); own tests in new `tests/test_journal.py`

**Target Platform**: any platform running the Python interpreter (library)

**Project Type**: library

**Performance Goals**: N/A for this milestone (in-memory correctness feature); one storage read and at most one write per `apply` call

**Constraints**: no changes to `tinydb/table.py`, `tinydb/database.py`, `tinydb/storages.py` public behavior; default table only; `ValueError` is the only error type for invalid input

**Scale/Scope**: one new module (`tinydb/journal.py`, ~100 lines) plus one new test file

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution: `.specify/memory/constitution.md` (v1.0.0). Gates evaluated against it:

- **I. Preserve Existing Public API Behavior** - PASS: feature is purely additive (`tinydb/journal.py`); no existing public method is touched; rollback/success both flow through the existing storage write path so ordinary handles keep working.
- **II. Testable Acceptance Criteria** - PASS: every spec requirement maps to an observable assertion (return values, `ValueError`, table state) covered by `acceptance_public.py` scenarios and the quickstart scenarios.
- **III. Evidence Over Assertion** - PASS: research findings cite file/line evidence (tinydb/table.py, tinydb/storages.py); implementation phase must record actual command output, not claims.
- **IV. Simple, Scoped Implementations** - PASS: one class, one method, stdlib only, no speculative features (no update op, no multi-table, no locking); the snapshot + single-write design is the smallest mechanism satisfying atomicity + aliasing.
- **V. Document Assumptions and Regressions** - PASS: assumptions A1-A7 recorded in spec.md; residual A5 (extra keys ignored) flagged in the checklist; no regressions expected, and the full upstream suite must be rerun in the implementation phase to prove it.

Gate result: **PASS** (no violations; Complexity Tracking left empty).

Post-design re-check (after Phase 1): still PASS - data-model, contract, and
quickstart introduce no new dependencies, no API changes, and no scope beyond
R01-R03.

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── batch-writer.md
└── tasks.md             # Phase 2 output ($speckit-tasks command - NOT created by $speckit-plan)
```

### Source Code (repository root)

```text
tinydb/
└── journal.py           # NEW: BatchWriter (only new source file)

tests/
└── test_journal.py      # NEW: own tests for this feature

acceptance_public.py     # PUBLIC ACCEPTANCE - unmodified
```

**Structure Decision**: Single-project library layout (existing). The change is
additive: one new module `tinydb/journal.py` (implementation source mandated by
the issue) and one new test file `tests/test_journal.py`. No existing source or
test files are modified.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

No violations - section intentionally empty.
