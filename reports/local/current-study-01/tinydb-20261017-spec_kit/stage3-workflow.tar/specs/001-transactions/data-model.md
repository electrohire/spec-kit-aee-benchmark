# Phase 1 Data Model: Batch Journal Writer for TinyDB

Feature: `specs/001-transactions/spec.md` | Date: 2026-10-17

## Entities

### BatchWriter

- **Represents**: The additive wrapper bound to exactly one `TinyDB` instance (spec entity `BatchWriter`).
- **Fields**:
  - `db`: the supplied `TinyDB` instance (never mutated structurally; ordinary APIs untouched).
  - `table`: the default table handle, obtained once via `db.table(db.default_table_name)`.
- **Behavior**: single method `apply(operations: list[dict]) -> list[int]`.
- **State transitions**: stateless between calls; all state lives in the storage.

### Operation (input, not persisted)

- **Represents**: One change in a batch (spec entity `Operation`).
- **Valid shapes** (validated before any mutation; violations raise `ValueError`):
  - `{'op': 'insert', 'document': <dict>}` - `document` MUST be a `Mapping`; extra keys ignored (A5).
  - `{'op': 'remove', 'doc_id': <int>}` - `doc_id` MUST be an `int` (bool excluded), `> 0` (A2); extra keys ignored.
- **Invalid shapes**: non-dict entry; `op` missing or not in `{'insert','remove'}`; insert without `document` or with non-Mapping `document`; remove without `doc_id` or with non-int/bool/non-positive `doc_id`.

### Document (persisted in default table)

- **Represents**: A stored record (spec entity `Document`), key = positive integer ID, value = dict.
- **Storage layout** (unchanged, existing TinyDB format):
  `{table_name: {str(doc_id): dict}}` under the single storage root dict.
- **ID assignment**: empty table -> first insert gets ID 1; otherwise `max(existing ids) + 1`, computed against the in-batch working dict (matches `Table._get_next_id`, tinydb/table.py:751).
- **Aliasing rule (R03)**: stored value is `copy.deepcopy(document)` taken before the batch commits; the result list contains IDs only, so no document object is ever returned.

## Relationships

- `BatchWriter` 1..1 `TinyDB` instance; 1..1 default `Table`; `Table` 1..1 `Storage`.
- A batch is a sequence of `Operation`s applied to the default table only; other tables in the storage root are carried through unchanged.

## Validation Rules (from spec FR-005/FR-007)

1. `operations` MUST be a list of dicts (non-list input is malformed -> `ValueError`).
2. Every operation MUST match a valid shape above, else `ValueError`.
3. A remove whose `doc_id` is not present in the working table when its turn arrives is an error -> `ValueError` (R02), which triggers rollback.
4. Sequential semantics: an earlier insert in the same batch makes its ID removable by a later remove (A6).

## State Transitions (default table)

```
pre-batch snapshot S0
  -> validate all operations (no mutation yet)
  -> apply sequentially on working dict S1..Sn (in memory only)
  -> on success: storage.write(working tables)         [committed]
  -> on any error: storage.write(deepcopy(S0))          [rolled back]
```

Observable invariants:
- After success: table equals the result of applying the operations to S0; IDs returned in insertion order.
- After rollback: table is byte-for-byte equal to S0 (contents, IDs, order) (A7).
- Previously acquired handles always re-read storage on `all()`/`__iter__`/`__len__`, so they observe either outcome (tinydb/table.py:715,771).
