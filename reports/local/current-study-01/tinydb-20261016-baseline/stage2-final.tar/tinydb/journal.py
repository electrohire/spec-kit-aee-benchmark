"""
This module provides a small batch-writing helper for TinyDB.

:class:`~tinydb.journal.BatchWriter` wraps a ``TinyDB`` instance and lets
you apply a list of simple operations (inserts and removes) to the default
table atomically: either every operation succeeds, or the default table is
restored to the state it had before the batch started.
"""

import copy

from .database import TinyDB

__all__ = ('BatchWriter',)


class BatchWriter:
    """
    Apply batches of insert/remove operations to a TinyDB's default table.

    The writer wraps an existing ``TinyDB`` instance and does not change any
    of its ordinary APIs. All operations are applied to the default table
    (``db.default_table_name``).

    Each operation is a dictionary of one of the following forms (no extra
    fields are allowed):

    - ``{'op': 'insert', 'document': <dict>}`` inserts a new document; an
      empty dictionary is a valid document
    - ``{'op': 'remove', 'doc_id': <positive integer>}`` removes an existing
      document; ``bool`` is rejected even though it subclasses ``int``

    Batches are atomic: if any operation fails (e.g. removing a document ID
    that does not exist, or a malformed operation), the default table is
    restored to the exact state it had before the batch started and the
    error is re-raised. A failed batch never consumes document IDs.

    The writer keeps its own next-insertion-ID state. On every successful
    batch that state is written back to the underlying table so that
    subsequent inserts -- via :meth:`apply` or a direct ``db.insert`` --
    continue the ID sequence without reuse or rewind, even when the batch
    contained removes.
    """

    #: Fields that are allowed in an ``insert`` operation
    _INSERT_FIELDS = frozenset(('op', 'document'))

    #: Fields that are allowed in a ``remove`` operation
    _REMOVE_FIELDS = frozenset(('op', 'doc_id'))

    def __init__(self, db: TinyDB):
        """
        Create a batch writer for the given TinyDB instance.

        :param db: the TinyDB instance to wrap
        """
        self._db = db
        # The wrapper's own next-insertion-ID state. ``None`` means "derive
        # it from the table on the next successful batch". It is never
        # consumed by :meth:`preview` or by a failed :meth:`apply`.
        self._next_id = None

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def apply(self, operations) -> list[int]:
        """
        Apply a batch of operations to the default table atomically.

        All operations are validated structurally before any change is
        committed. The batch is then applied sequentially; if any operation
        fails (e.g. a remove targeting a missing document), the complete
        pre-batch state is restored and the error is re-raised.

        :param operations: a list of operation dictionaries
        :returns: a new list containing the IDs of all inserted documents
                  (in insertion order); removes do not contribute results
        :raises ValueError: if the batch or any operation is malformed, or if
                            a remove targets a document ID that does not
                            exist
        """
        ops = self._validate_operations(operations)

        table = self._db.table(self._db.default_table_name)

        # Determine the starting ID for this batch. Direct ``db.insert``
        # calls between batches are visible because we fall back to the
        # table's own state (which includes its cached ``_next_id``).
        start_id = self._resolve_next_id(table)

        # --- Snapshot the pre-batch database state -------------------------
        # We keep a deep copy of the object returned by the storage (which
        # may be ``None`` for an empty database) so we can restore the exact
        # state later. A deep copy is required because storages such as
        # ``MemoryStorage`` return the very dict they hold, which would be
        # mutated by the batch itself.
        snapshot = copy.deepcopy(self._db.storage.read())

        inserted_ids: list[int] = []

        try:
            next_id = start_id
            for op in ops:
                op_name = op['op']

                if op_name == 'insert':
                    document = op['document']

                    # Deep-copy the document so that the database never
                    # aliases the caller's input (and mutating the
                    # operation after ``apply`` cannot mutate the database).
                    table.insert(copy.deepcopy(dict(document)))
                    inserted_ids.append(next_id)
                    next_id += 1

                else:  # 'remove'
                    doc_id = op['doc_id']

                    # ``Table.remove(doc_ids=...)`` silently skips missing
                    # IDs, but for a batch a missing ID is an error. Check
                    # against the *current* table state (earlier operations
                    # in this batch are already visible).
                    if table.get(doc_id=doc_id) is None:
                        raise ValueError(
                            f"Cannot remove document with ID {doc_id}: "
                            f'document does not exist'
                        )

                    table.remove(doc_ids=[doc_id])
        except Exception:
            # --- Rollback ---------------------------------------------------
            # Restore the exact pre-batch storage state. This makes both the
            # storage and any previously acquired table handles (which read
            # through to the storage) reflect the rollback.
            self._db.storage.write(snapshot)

            # Reset the table's internal state so it is consistent with the
            # restored data: the cached next-ID counter may have advanced
            # during the failed batch, and the query cache may hold stale
            # results. (``storage.write`` above already cleared the query
            # cache, but be explicit.) A failed batch must not consume IDs.
            table._next_id = None
            table.clear_cache()

            raise

        # --- Commit the wrapper's next-insertion-ID state -------------------
        # Write the advanced state back to the underlying table so that
        # subsequent inserts (via ``apply`` or direct ``db.insert``)
        # continue the sequence without reuse or rewind, even across
        # remove operations.
        self._next_id = next_id
        table._next_id = next_id

        return inserted_ids

    def preview(self, operations) -> list[int]:
        """
        Preview the IDs that :meth:`apply` would assign to inserted
        documents, without changing anything.

        The batch is validated with exactly the same rules as :meth:`apply`
        (so a malformed batch raises ``ValueError`` here as well), but no
        data is written, no document IDs are consumed, and the query cache
        is left untouched. Even on error, all data and the next insertion ID
        remain unchanged.

        :param operations: a list of operation dictionaries
        :returns: a new, detached list of the IDs that would be inserted
                  (in insertion order); removes do not contribute results
        :raises ValueError: if the batch or any operation is malformed, or if
                            a remove targets a document ID that does not
                            exist (mirroring :meth:`apply`)
        """
        ops = self._validate_operations(operations)

        table = self._db.table(self._db.default_table_name)

        # Simulate the batch on a deep copy of the current storage state so
        # that neither the storage, the table's cached next-ID counter, nor
        # the query cache is modified in any way.
        raw = self._db.storage.read()
        data = copy.deepcopy(raw) if raw is not None else {}
        raw_table = data.get(self._db.default_table_name)
        sim = {
            table.document_id_class(doc_id): doc
            for doc_id, doc in (raw_table or {}).items()
        }

        next_id = self._resolve_next_id(table)

        inserted_ids: list[int] = []
        for op in ops:
            if op['op'] == 'insert':
                inserted_ids.append(next_id)
                sim[next_id] = copy.deepcopy(dict(op['document']))
                next_id += 1
            else:  # 'remove'
                doc_id = op['doc_id']
                if doc_id not in sim:
                    # Mirror ``apply``: a remove targeting a missing ID is an
                    # error. Nothing was written, so all data and the next
                    # insertion ID are unchanged.
                    raise ValueError(
                        f"Cannot remove document with ID {doc_id}: "
                        f'document does not exist'
                    )
                del sim[doc_id]

        # Return a fresh list on every call; the caller may mutate it
        # without affecting subsequent previews or the writer's state.
        return list(inserted_ids)

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _validate_operations(self, operations) -> list[dict]:
        """
        Structurally validate a batch of operations before any change is
        committed.

        :returns: the operations as a list of dicts
        :raises ValueError: if the batch or any operation is malformed
        """
        # The batch itself must be a list of operation dictionaries.
        if not isinstance(operations, list):
            raise ValueError(
                f'operations must be a list of operation dicts: '
                f'{operations!r}'
            )

        for op in operations:
            if not isinstance(op, dict):
                raise ValueError(f'Operation is not a dict: {op!r}')

            op_name = op.get('op')

            if op_name == 'insert':
                if set(op.keys()) != self._INSERT_FIELDS:
                    raise ValueError(
                        f"'insert' operation has unsupported fields: "
                        f'{sorted(op.keys())!r}'
                    )
                document = op['document']
                if not isinstance(document, dict):
                    raise ValueError(
                        f"'document' is not a dict: {document!r}"
                    )
                # Note: an empty dict is a valid document.

            elif op_name == 'remove':
                if set(op.keys()) != self._REMOVE_FIELDS:
                    raise ValueError(
                        f"'remove' operation has unsupported fields: "
                        f'{sorted(op.keys())!r}'
                    )
                doc_id = op['doc_id']
                # A positive integer is required. ``bool`` is a subclass of
                # ``int``, so it is rejected explicitly.
                if isinstance(doc_id, bool) or not isinstance(doc_id, int):
                    raise ValueError(
                        f"'doc_id' is not a positive integer: {doc_id!r}"
                    )
                if doc_id <= 0:
                    raise ValueError(
                        f"'doc_id' is not a positive integer: {doc_id!r}"
                    )

            else:
                raise ValueError(f'Unknown operation: {op_name!r}')

        return operations

    def _resolve_next_id(self, table) -> int:
        """
        Determine the next document ID to hand out.

        The wrapper's own state takes precedence; otherwise the table's
        state is used (its cached ``_next_id`` if any, else the highest ID
        currently stored plus one). This is what makes direct
        ``db.insert`` calls between batches visible to the wrapper without
        caching a stale initial snapshot.
        """
        # The next ID must be larger than every ID that is known to have
        # been handed out or stored: the wrapper's own state, the table's
        # cached counter (which direct ``db.insert`` calls advance) and the
        # highest ID currently in the table. Taking the maximum is what
        # keeps the sequence moving forward without reuse or rewind.
        candidates = [1]
        if self._next_id is not None:
            candidates.append(self._next_id)
        if table._next_id is not None:
            candidates.append(table._next_id)
        raw_table = table._read_table()
        if raw_table:
            candidates.append(
                max(table.document_id_class(i) for i in raw_table.keys()) + 1
            )
        return max(candidates)
