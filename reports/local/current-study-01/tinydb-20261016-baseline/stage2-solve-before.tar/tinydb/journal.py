"""
This module provides a small batch-writing helper for TinyDB.

:class:`~tinydb.journal.BatchWriter` wraps a ``TinyDB`` instance and lets
you apply a list of simple operations (inserts and removes) to the default
table atomically: either every operation succeeds, or the default table is
restored to the state it had before the batch started.
"""

import copy
from collections.abc import Mapping

from .database import TinyDB

__all__ = ('BatchWriter',)


class BatchWriter:
    """
    Apply batches of insert/remove operations to a TinyDB's default table.

    The writer wraps an existing ``TinyDB`` instance and does not change any
    of its ordinary APIs. All operations are applied to the default table
    (``db.default_table_name``).

    Each operation is a dictionary of one of the following forms:

    - ``{'op': 'insert', 'document': <mapping>}`` inserts a new document
    - ``{'op': 'remove', 'doc_id': <positive integer>}`` removes an existing
      document

    Batches are atomic: if any operation fails (e.g. removing a document ID
    that does not exist, or a malformed operation), the default table is
    restored to the exact state it had before the batch started and the
    error is re-raised.
    """

    def __init__(self, db: TinyDB):
        """
        Create a batch writer for the given TinyDB instance.

        :param db: the TinyDB instance to wrap
        """
        self._db = db

    def apply(self, operations) -> list[int]:
        """
        Apply a batch of operations to the default table atomically.

        :param operations: a list of operation dictionaries
        :returns: a list containing the IDs of all inserted documents
                  (in insertion order); removes do not contribute results
        :raises ValueError: if the batch or any operation is malformed, or if
                            a remove targets a document ID that does not
                            exist
        """
        # --- Validate the batch itself -------------------------------------
        # Accept any iterable of operation dicts (a list is expected).
        try:
            ops = list(operations)
        except TypeError:
            raise ValueError(
                f'operations must be an iterable of operation dicts: '
                f'{operations!r}'
            ) from None

        # --- Snapshot the pre-batch database state -------------------------
        # We keep a deep copy of the object returned by the storage (which
        # may be ``None`` for an empty database) so we can restore the exact
        # state later. A deep copy is required because storages such as
        # ``MemoryStorage`` return the very dict they hold, which would be
        # mutated by the batch itself.
        snapshot = copy.deepcopy(self._db.storage.read())

        table = self._db.table(self._db.default_table_name)

        inserted_ids: list[int] = []

        try:
            for op in ops:
                # --- Validate the operation --------------------------------
                if not isinstance(op, Mapping):
                    raise ValueError(
                        f'Operation is not a mapping: {op!r}'
                    )

                op_name = op.get('op')

                if op_name == 'insert':
                    if 'document' not in op:
                        raise ValueError(
                            "'insert' operation is missing 'document'"
                        )
                    document = op['document']
                    if not isinstance(document, Mapping):
                        raise ValueError(
                            f"'document' is not a mapping: {document!r}"
                        )

                    # Deep-copy the document so that the database never
                    # aliases the caller's input (and mutating the
                    # operation after ``apply`` cannot mutate the database).
                    doc_id = table.insert(copy.deepcopy(dict(document)))
                    inserted_ids.append(doc_id)

                elif op_name == 'remove':
                    if 'doc_id' not in op:
                        raise ValueError(
                            "'remove' operation is missing 'doc_id'"
                        )
                    doc_id = op['doc_id']
                    # A positive integer is required. Note that ``bool`` is
                    # a subclass of ``int``, so it is rejected explicitly.
                    if isinstance(doc_id, bool) or not isinstance(doc_id, int):
                        raise ValueError(
                            f"'doc_id' is not a positive integer: {doc_id!r}"
                        )
                    if doc_id <= 0:
                        raise ValueError(
                            f"'doc_id' is not a positive integer: {doc_id!r}"
                        )

                    # ``Table.remove(doc_ids=...)`` silently skips missing
                    # IDs, but for a batch a missing ID is an error. Check
                    # against the *current* table state (earlier operations
                    # in this batch are already visible).
                    if table.get(doc_id=doc_id) is None:
                        raise ValueError(
                            f"Cannot remove document with ID {doc_id}: "
                            f'document does not exist'
                        )

                    table.remove(doc_ids=[doc_id])

                else:
                    raise ValueError(f'Unknown operation: {op_name!r}')
        except Exception:
            # --- Rollback ---------------------------------------------------
            # Restore the exact pre-batch storage state. This makes both the
            # storage and any previously acquired table handles (which read
            # through to the storage) reflect the rollback.
            self._db.storage.write(snapshot)

            # Reset the table's internal state so it is consistent with the
            # restored data: the cached next-ID counter may have advanced
            # during the failed batch, and the query cache may hold stale
            # results. (``storage.write`` above already cleared the query
            # cache, but be explicit.)
            table._next_id = None
            table.clear_cache()

            raise

        return inserted_ids
