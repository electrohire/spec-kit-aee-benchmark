# Contract: cachetools.tagged.TaggedCache public API

Phase 1 output. This is the externally observable contract of the new
module. Existing cachetools contracts (Cache, LRUCache, FIFOCache,
LFUCache, MRUCache, RRCache, TLRUCache, TTLCache, cached, cachedmethod,
keys) are unchanged (Constitution Principle I).

## Import

```python
from cachetools.tagged import TaggedCache
```

## Constructor

```python
TaggedCache(maxsize)
```

- maxsize: positive int, bool excluded; otherwise `ValueError` (FR-014).
- Returns a cache with zero live entries; `len(c) == 0`, `c.maxsize ==
  maxsize`.

## put

```python
c.put(key, value, tags=())
```

- key: hashable; unhashable -> TypeError (Python contract).
- value: any object; stored as a deep copy (FR-005). If deepcopy fails,
  the exception propagates and prior state is unchanged (FR-015).
- tags: default `()`; must be a finite iterable of str; not a bare str or
  bytes; duplicate tags deduplicated; empty allowed (FR-006..FR-008).
  Violations raise `ValueError` before any state change (FR-008).
- Effect: inserts or replaces the entry; the entry becomes
  most-recently-used (D2); on replacement, old tag memberships are removed
  first (FR-010). No return value (None).

## get

```python
v = c.get(key)
v = c.get(key, default)   # inherited Cache.get
```

- Hit: returns a detached deep copy of the stored value (FR-003); entry
  becomes most-recently-used (FR-012).
- Miss: `c.get(key)` raises `KeyError`; `c.get(key, default)` returns
  default (FR-004).

## invalidate

```python
n = c.invalidate(tag)
```

- Removes exactly the live entries currently carrying `tag`; returns the
  number removed (0 if none). Tag not present -> 0. (FR-009)

## Inherited observable behavior (from Cache/LRUCache, unchanged)

- `len(c)`: number of live entries (FR-013); never exceeds maxsize.
- `key in c`, `iter(c)`, `c[key]` (deep-copied, KeyError on miss),
  `c[key] = value` (plain value, no tags; refreshes recency),
  `del c[key]`, `c.pop(key[, default])`, `c.clear()`, `c.setdefault(...)`,
  `c.maxsize`, `c.currsize`, `c.getsizeof(value)`, `repr(c)`.
- Every stored value costs one slot (FR-016): eviction is purely by count
  and LRU recency, independent of value size/shape.

## Error summary

| Condition | Exception |
|---|---|
| maxsize not a positive non-bool int | ValueError |
| tags is a bare str/bytes | ValueError |
| any tag entry is not str | ValueError |
| value not deepcopy-able (on put) | the deepcopy exception (e.g., TypeError) |
| get on missing key (no default) | KeyError |
| unhashable key | TypeError |
