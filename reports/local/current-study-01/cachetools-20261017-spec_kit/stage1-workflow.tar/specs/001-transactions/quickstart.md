# Quickstart / Validation Guide: Tagged Cache (001-transactions)

Phase 1 output. Runnable validation scenarios that prove the feature works
end-to-end. See [contracts/tagged-cache-api.md](contracts/tagged-cache-api.md)
for the full API contract and [data-model.md](data-model.md) for state
invariants. Implementation details belong in tasks.md / the implement
phase.

## Prerequisites

- Python 3.12 with pytest available (repo already runs on 3.12.14).
- Source root on the path: use `PYTHONPATH=src:.` for all commands below.
- No new dependencies.

## Setup

```bash
cd /testbed
PYTHONPATH=src:. python -m pytest tests/ -q          # baseline: 216 passed (observed 2026-10-17)
```

## Implementation entry point

Create `src/cachetools/tagged.py` exposing `TaggedCache` (design in
plan.md + research.md D1-D8), and add project-owned tests in
`tests/test_tagged.py`. Do not modify `acceptance_public.py` or any
upstream test.

## Validation scenarios

### 1. Public acceptance (SC-001)

```bash
PYTHONPATH=src:. python -m pytest acceptance_public.py -q
```
Expected: 2 passed (test_public_basic, test_public_replacement).

### 2. Project-owned tests (SC-001, SC-003, SC-004, SC-005)

```bash
PYTHONPATH=src:. python -m pytest tests/test_tagged.py -v
```
Expected: all tests pass. Required coverage (one test per item at minimum):

| ID | Scenario | Expected |
|---|---|---|
| FR-001 | `TaggedCache(3)` constructs | `len(c) == 0`, `c.maxsize == 3` |
| FR-002 | put then get; re-put replaces | get returns new value copy |
| FR-003 | mutate returned nested dict | stored value unchanged on next get |
| FR-004 | get missing key | KeyError raised |
| FR-005 | mutate caller's original after put | stored value unchanged |
| FR-006 | tags as list/tuple/set/generator with duplicates | deduplicated; invalidate counts entry once |
| FR-007 | `put(k, v, tags="a")`; `put(k, v, tags=("a", 1))` | ValueError both; prior state intact |
| FR-008 | failed put after a get-hit refresh | recency order unchanged (observable via later eviction victim) |
| FR-009 | 3 entries, 2 with tag "a" | `invalidate("a") == 2`, others intact; unknown tag -> 0 |
| FR-010 | replace key's tags ("a","b") -> ("c",) | invalidate("a")==0, ("b")==0, ("c")==1 |
| FR-011 | fill maxsize to evict a tagged entry; re-put same key | invalidate counts only the live entry; evicted one not counted |
| FR-012 | get(k1) then insert to evict | LRU k2 evicted, k1 survives |
| FR-013 | mixed puts/invalidates/evictions | `len(c)` always equals live count, <= maxsize |
| FR-014 | maxsize in {0, -1, 2.5, "5", True, False} | ValueError each |
| FR-015 | put with uncopyable value over existing key | error raised; old value/tags/recency unchanged |
| FR-016 | one large nested value + one int in maxsize=2; third put | both fit; third evicts LRU (size-independent) |

### 3. Upstream regression gate (SC-002)

```bash
PYTHONPATH=src:. python -m pytest tests/ -q
```
Expected: 216 passed, 15 warnings (same as the 2026-10-17 baseline),
plus the new test_tagged.py tests if run from tests/ - the upstream files
themselves must be byte-identical (verify with `git status` / diff if
available).

### 4. Detachment smoke check (SC-005, manual)

```bash
PYTHONPATH=src:. python - <<'PY'
from cachetools.tagged import TaggedCache
c = TaggedCache(4)
c.put("k", {"n": [1, 2]}, ["t"])
v = c.get("k")
v["n"].append(3)
assert c.get("k") == {"n": [1, 2]}, "stored value must be detached"
assert c.invalidate("t") == 1 and len(c) == 0
print("smoke OK")
PY
```
Expected: prints `smoke OK`.

## Done criteria for this feature (convergence)

1. Scenario 1 passes (public acceptance).
2. Scenario 2 passes with the full FR table covered.
3. Scenario 3 matches the baseline (no upstream regressions).
4. Scenario 4 prints `smoke OK`.
5. Claim-A extension remains deferred unless explicitly adopted (research.md
   D5); if adopted, add a dedicated recency-on-replacement test.
