# Data Model: Tagged Cache (001-transactions)

Phase 1 output. Entities are described without implementation code; the
storage mechanism is the existing `LRUCache` (research.md D1) plus one tag
index.

## Entities

### Cache entry (live)

| Attribute | Type | Rules |
|---|---|---|
| key | hashable (any) | Identifies the entry; unhashable keys raise TypeError on put (Python contract) |
| value | deep-copied object | Copied on input (FR-005) and on get (FR-003); costs exactly one slot (FR-016) |
| tags | set of str | Deduplicated at put (FR-006); replaced wholesale on re-put (FR-010) |
| recency | position in LRU order | Refreshed on put (new or replace, D2) and on get hit (FR-012); LRU entry is evicted first when full |

Lifecycle states: `absent -> stored (put) -> stored (replaced, tags
swapped) -> evicted (LRU, full) | removed (invalidate/del/pop/clear) ->
absent`. Re-put of an absent key is a fresh entry (no stale tag
memberships, FR-011).

### Tag index (internal)

| Attribute | Type | Rules |
|---|---|---|
| mapping | tag (str) -> set of live keys | Invariant: every key in a set is currently stored and carries that tag; every stored entry's tags appear in exactly these sets |

Maintained at exactly two choke points (D8):
- on store: remove key from all old tag sets (if key existed), add key to
  all new tag sets;
- on removal (eviction via popitem, del, pop, clear): remove key from all
  tag sets it belongs to; drop empty sets.

`invalidate(tag)` = remove every key in `tag_index.get(tag, empty)` and
return the count; the tag's set is then empty/absent.

### Recency order (internal, owned by LRUCache)

Ordered collection of live keys, LRU at head, MRU at tail. Updated by
LRUCache on every hit and write; pruned by LRUCache on every removal. No
separate structure is needed in TaggedCache (D1).

## Validation rules (from spec FRs)

- maxsize: int, not bool, > 0, else ValueError (FR-014).
- tags: not str/bytes (bare string), finite iterable, every entry str, else
  ValueError; deduplicated; empty allowed (FR-006..FR-008).
- value: must survive deepcopy; if not, the put fails and prior
  value/tags/recency are unchanged (FR-015).

## State transitions (tag index view)

| Event | Index effect |
|---|---|
| put(new key, tags) | key added to each tag's set |
| put(existing key, new tags) | key removed from all old tag sets, then added to all new tag sets (FR-010) |
| put with invalid tags or uncopyable value | no effect (FR-008, FR-015) |
| invalidate(tag) | all keys in tag's set removed; count returned (FR-009) |
| LRU eviction | evicted key removed from all its tag sets (FR-011) |
| del/pop/clear | same removal effect as eviction |
| get hit | no index effect; recency refreshed (FR-012) |
| get miss | no effect; KeyError (FR-004) |
