# Implementation Plan: Tagged Cache (cachetools.tagged.TaggedCache)

**Branch**: `001-transactions` | **Date**: 2026-10-17 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-transactions/spec.md`

## Summary

Add `cachetools.tagged.TaggedCache(maxsize)` (R01-R03): a tag-aware cache
built on the existing `LRUCache` for bounded LRU storage. Values are deep-
copied on put and on get (full detachment, KeyError on miss); tags are
validated (finite iterable of strings, deduplicated, bare strings and
non-string entries rejected with ValueError before any state change);
`invalidate(tag)` removes exactly the live entries carrying that tag and
returns the count; recency is refreshed on get hits; `len()` counts live
entries; `maxsize` must be a positive non-bool integer (ValueError); a failed
put leaves value/tags/recency unchanged. All existing cachetools APIs remain
unchanged (additive module only). The Claim-A put-recency extension
(put_no_recency_refresh, 2026-09-21) is deferred; the chosen design happens
to satisfy it (see research.md D5) but it is not a baseline requirement.

## Technical Context

**Language/Version**: Python 3.12 (repo runs on 3.12.14; library supports the
versions declared in setup.cfg; no new syntax beyond 3.6-era features is
required)

**Primary Dependencies**: stdlib only - `collections` (OrderedDict),
`copy.deepcopy`; internal dependency on existing `cachetools.LRUCache`

**Storage**: N/A (in-memory only)

**Testing**: pytest (already used by acceptance_public.py; upstream tests use
unittest, both run under pytest)

**Target Platform**: any platform Python runs on (pure library)

**Project Type**: library (single package, src layout)

**Performance Goals**: put/get/invalidate O(1) amortized per operation
(invalidate O(k) in entries removed); no measurable overhead vs LRUCache
beyond the deepcopy required by the spec

**Constraints**: no changes to existing modules' behavior; no new third-party
dependencies; upstream tests must pass unchanged (baseline: 216 passed)

**Scale/Scope**: one new module (~100-150 lines) plus project-owned tests

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution: `.specify/memory/constitution.md` (v1.0.0).

- **I. Preserve Existing Public API Behavior**: PASS - change is additive:
  new module `src/cachetools/tagged.py` only. `src/cachetools/__init__.py`
  and all existing tests are untouched. Baseline evidence: `PYTHONPATH=src:.`
  `python -m pytest tests/ -q` -> `216 passed, 15 warnings in 0.18s`.
- **II. Testable Acceptance Criteria**: PASS - spec.md FR-001..FR-016 each
  name inputs and observable outcomes; SC-001..SC-005 are measurable; every
  FR maps to a project-owned test (see quickstart.md).
- **III. Evidence Over Assertion**: PASS - this plan cites observed commands
  (setup_plan.py JSON, pytest baseline) and labels design claims as
  decisions with rationale, not as verified behavior.
- **IV. Simple Scoped Implementations**: PASS - one module, no new
dependencies, no configuration surface; the simplest structure satisfying
FR-001..FR-016 (LRUCache subclass + one tag index dict).
- **V. Documented Assumptions and Regressions**: PASS - assumptions live in
spec.md; the Claim-A extension is recorded as a deferred intent in spec.md
Out of Scope and in research.md D5; no regressions are planned.

**Gate result: PASS (no violations, Complexity Tracking not required).**

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── tagged-cache-api.md
└── tasks.md             # Phase 2 output ($speckit-tasks command - NOT created by $speckit-plan)
```

### Source Code (repository root)

```text
src/cachetools/
├── __init__.py          # UNCHANGED (existing public API preserved)
├── tagged.py            # NEW: TaggedCache(LRUCache) with put/get/invalidate
└── ...                  # existing modules unchanged

tests/
├── test_lru.py          # UNCHANGED (upstream)
├── test_tagged.py       # NEW: project-owned tests for FR-001..FR-016
└── ...                  # other upstream tests unchanged

acceptance_public.py     # UNCHANGED (public acceptance, imports
                         # cachetools.tagged.TaggedCache)
```

**Structure Decision**: Single-project src layout already in use (setup.cfg
`packages = find:` under src). The feature adds exactly one module
`src/cachetools/tagged.py` and one test file `tests/test_tagged.py`; no
packaging changes are needed because the package is discovered from `src/`
and the new module is picked up automatically.

## Complexity Tracking

> No Constitution Check violations; table intentionally empty.
