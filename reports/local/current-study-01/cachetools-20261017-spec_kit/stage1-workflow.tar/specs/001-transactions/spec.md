# Feature Specification: Tagged Cache (cachetools.tagged.TaggedCache)

**Feature Branch**: `001-transactions`

**Created**: 2026-10-17

**Status**: Draft

**Input**: User description: "Build cachetools.tagged.TaggedCache(maxsize), using the existing
LRUCache for bounded storage and preserving all existing cachetools APIs. R01-R03
plus Claim-A candidate extension (variant put_no_recency_refresh, 2026-09-21)."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Store and retrieve values with tags (Priority: P1)

A library user creates a TaggedCache with a maximum number of entries, stores
values together with a set of tags, and later retrieves a value by key. The
value handed out is a fully detached deep copy: mutating it (including nested
objects) does not affect the stored value, and the caller cannot observe the
stored value through the returned object. Values are deep-copied on input too,
so mutating the original object after storing it does not change what the cache
returns. Missing keys raise KeyError.

**Why this priority**: This is the core value of the feature; without safe
put/get with tags, nothing else works. It is the minimal viable product.

**Independent Test**: Fully testable by constructing a TaggedCache, putting a
nested value with tags, getting it back, mutating the returned copy, and
verifying the stored value is unchanged; a second get returns equal content.

**Acceptance Scenarios**:

1. **Given** an empty cache of maxsize 2, **When** put(key, value, tags) is
called, **Then** the entry is stored and a later get(key) returns a deep copy
equal to value.
2. **Given** a stored value containing nested mutable objects, **When** the
caller mutates the object returned by get(key), **Then** a subsequent get(key)
returns the original, unmutated content.
3. **Given** a caller mutates its original object after put, **When** get(key)
is called, **Then** the stored content reflects the value as it was at put
time, not the later mutation.
4. **Given** a key that was never stored (or was evicted/invalidated), **When**
get(key) is called, **Then** KeyError is raised.
5. **Given** a key already present, **When** put(key, new_value) is called,
**Then** the entry is replaced so get(key) returns a copy of new_value.

---

### User Story 2 - Invalidate by tag and rely on LRU eviction (Priority: P2)

A user calls invalidate(tag) to remove every currently cached entry carrying
that tag, receiving the exact count removed. Tag memberships always reflect
live entries: replacing a key drops its old tags, and LRU eviction never leaves
stale tag memberships that would make later reuse of the same key behave as if
an old (evicted) entry still existed. get(key) refreshes LRU recency, so
frequently read entries survive eviction longest. len(cache) reports the number
of live entries.

**Why this priority**: Tag-based invalidation and correct LRU behavior are the
distinctive guarantees that justify the feature; they build directly on P1.

**Independent Test**: Fill a small cache to force eviction, call invalidate on
a tag, and verify the returned count, that only matching keys were removed,
that evicted keys are gone, and that re-putting an evicted key behaves as a
fresh entry.

**Acceptance Scenarios**:

1. **Given** three live entries, two carrying tag "a", **When** invalidate("a")
is called, **Then** it returns 2 and only those two keys are missing.
2. **Given** a key stored with tags ("a","b"), **When** put(key, new_value,
tags=("c",)) is called, **Then** invalidate("a") and invalidate("b") each
return 0 and invalidate("c") returns 1.
3. **Given** a cache of maxsize 2 with entries k1 (tag "old") and k2, **When**
put(k3, v3, tags=("old")) evicts k1, **Then** len(cache) is 2, invalidate
("old") returns 1 (removing only k3), and get(k1) raises KeyError.
4. **Given** entries k1, k2, k3 in a maxsize-3 cache, **When** get(k1) is
called and then put(k4, v4) evicts the least-recently-used entry, **Then** k2
(the LRU) is evicted, k1 is still present, and get(k2) raises KeyError.
5. **Given** a key evicted by LRU while carrying tag "t", **When** the same key
is put again with tag "t", **Then** invalidate("t") counts exactly the live
entries carrying "t"; the prior evicted membership is not counted or removed.

---

### User Story 3 - Safe configuration and atomic replacement (Priority: P3)

A user configures the cache with a maximum size and can rely that invalid input
never corrupts state: maxsize must be a positive integer (bool is rejected),
and a failed put (invalid tags, or a value that cannot be copied) leaves the
previously stored value, its tags, and its recency position unchanged. Every
stored value costs exactly one capacity slot regardless of its size or shape.

**Why this priority**: Defensive guarantees that prevent silent corruption;
important, but they protect the P1/P2 flows rather than adding new capability.

**Independent Test**: Attempt to construct TaggedCache with 0, -1, 2.5, "5",
True, False; attempt put with a bare string as tags, with a non-string tag
entry, and with an uncopyable value; verify each raises the documented error
and the prior state is intact.

**Acceptance Scenarios**:

1. **Given** maxsize values 0, -1, 2.5, "5", True, False, **When**
TaggedCache(maxsize) is called, **Then** a ValueError is raised (True and
False are rejected even though they are integers).
2. **Given** a cache with key k stored under tag "a", **When** put(k, v,
tags="a") (bare string) is called, **Then** ValueError is raised and get(k)
still returns the old value with tag "a" still active (invalidate("a") would
still return 1).
3. **Given** a cache with key k stored, **When** put(k, v, tags=("a", 1)) is
called, **Then** ValueError is raised and the old value/tags/recency are
unchanged.
4. **Given** a cache with key k stored, **When** put(k, value, tags) is called
with a value that cannot be deep-copied, **Then** an error is raised and the
old value, tags, and recency position are unchanged.
5. **Given** a cache of maxsize 2, **When** two entries (large nested objects
and a small int) are stored, **Then** both fit and a third put evicts the LRU
entry; size never affects slot cost.

---

### Edge Cases

- Tags given as a finite iterable (list, tuple, generator, set) of strings are
  accepted; duplicate tags are deduplicated, so invalidate counts each live
  entry once.
- An empty tags iterable (including the default) stores the entry with no tag
  memberships.
- A bare string passed as tags is rejected (a string is an iterable of
  characters, but it is not a valid tag collection).
- A tag entry that is not a string is rejected.
- Replacing an existing key with new tags removes the old tag memberships
  before the new ones take effect (no transient double membership observable
  through invalidate).
- LRU eviction of a tagged entry removes its tag memberships so later reuse of
  the same key starts clean.
- get on a hit refreshes recency; get on a miss raises KeyError and changes
  nothing.
- len(cache) always equals the number of live entries (never exceeds maxsize,
  never counts evicted or invalidated entries).
- Keys are hashable; unhashable keys raise TypeError on put (standard Python
  hashing contract).

## Requirements *(mandatory)*

### Functional Requirements

**R01 - Storage and retrieval**

- **FR-001**: TaggedCache MUST be constructible with a single required
  maxsize argument.
- **FR-002**: put(key, value, tags=()) MUST insert a new entry or replace an
  existing one for the same key; keys MUST be hashable.
- **FR-003**: get(key) MUST return a detached deep copy of the stored value;
  mutating the returned object (including nested members) MUST NOT affect the
  stored value.
- **FR-004**: get(key) MUST raise KeyError when the key is not currently
  stored.
- **FR-005**: Values MUST be deep-copied on input, so later mutation of the
  caller's original object MUST NOT change the stored content.
- **FR-006**: tags MUST be a finite iterable of strings; duplicate tags MUST
  be deduplicated so each live entry counts once per tag.
- **FR-007**: A bare string passed as tags MUST be rejected with ValueError,
  as MUST any tag entry that is not a string.
- **FR-008**: Tag validation errors MUST be raised before any existing cache
  state (values, tags, recency) is changed.

**R02 - Invalidation and LRU behavior**

- **FR-009**: invalidate(tag) MUST remove exactly the currently cached entries
  carrying that tag and MUST return the number of entries removed.
- **FR-010**: Replacing a key via put MUST remove its old tag memberships
  before the new tags take effect.
- **FR-011**: LRU eviction MUST remove the evicted entry's tag memberships so
  no stale membership affects later reuse of the same key.
- **FR-012**: get(key) on a hit MUST refresh that entry's LRU recency.
- **FR-013**: len(cache) MUST return the number of live entries.

**R03 - Configuration and atomicity**

- **FR-014**: maxsize MUST be a positive integer; bool values (True, False)
  MUST be rejected; invalid maxsize MUST raise ValueError.
- **FR-015**: A put that fails validation (invalid tags) or fails to copy the
  value MUST leave the previously stored value, its tags, and its recency
  position unchanged.
- **FR-016**: Every stored value MUST cost exactly one capacity slot
  regardless of object size or shape.

### Key Entities *(include if feature involves data)*

- **Cache entry**: A live mapping from one hashable key to one stored value
  plus the set of tags it carries; occupies exactly one of the maxsize slots.
- **Tag**: A string label shared by any number of live entries; used only for
  bulk invalidation. A tag's membership set always reflects live entries only.
- **Recency order**: The LRU ordering over live entries, updated on put (new
  or replaced) and on get hits; determines which entry is evicted when the
  cache is full.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of documented behaviors (FR-001 through FR-016) are
  verified by passing tests, including the public acceptance suite
  (acceptance_public.py) and project-owned tests; zero failures at
  convergence.
- **SC-002**: 100% of the existing public cachetools API keeps its existing
  behavior: existing upstream tests pass unchanged, and no existing name,
  signature, or documented behavior is altered or removed.
- **SC-003**: In every invalid-input scenario (bad maxsize, bare-string tags,
  non-string tag entries, uncopyable value), state preservation is 100%
  observable: prior value, tag memberships, and recency order are exactly as
  before the failed call.
- **SC-004**: Tag accounting is exact in all tested sequences: invalidate
  returns the precise live-entry count, len equals the live-entry count, and
  no evicted or invalidated entry is ever counted, removed, or refreshed.
- **SC-005**: Retrieved values are fully detached in every test: mutations to
  returned objects (including nested members) and to caller originals after
  put have zero observable effect on stored content.

## Assumptions

- Target users are Python library consumers of cachetools; the feature is a
  new additive module (cachetools.tagged) and no user-facing configuration or
  documentation site changes are in scope.
- "Deep copy" follows the standard Python deep-copy semantics for supported
  value types; values that cannot be deep-copied raise the copy mechanism's
  error, and the failed put leaves prior state unchanged (FR-015).
- Validation order: maxsize is checked at construction; tags are validated
  before value copying, so a tag error never depends on value copyability.
- Unhashable keys raise TypeError from standard Python hashing on put; this
  is the language contract, not a feature-specific error.
- Recency semantics: putting a new key makes it most-recently-used; getting a
  hit makes that entry most-recently-used. (Whether replacing an existing key
  via put also refreshes its recency is a candidate extension, not part of
  this baseline; see Out of Scope.)
- The public acceptance suite (acceptance_public.py) and upstream tests are
  the authoritative verification; project-owned tests may be added but
  upstream tests must remain unchanged.

## Out of Scope

- The Claim-A candidate extension (variant put_no_recency_refresh,
  2026-09-21): "overwriting an existing key via put refreshes its LRU
  recency, making it the most-recently-used entry." It is recorded here as a
  deferred intent for a later phase; the baseline spec (R01-R03) does not
  require it and does not forbid it. If a later phase adopts it, the spec and
  this section MUST be updated in the same change.
- Thread safety, persistence, serialization, and any non-LRU eviction
  policies.
- Changes to existing cachetools classes or modules.
