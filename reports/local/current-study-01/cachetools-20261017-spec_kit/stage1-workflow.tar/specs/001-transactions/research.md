# Research: Tagged Cache (001-transactions)

Phase 0 output. All NEEDS CLARIFICATION items from the plan are resolved
below (there were none left in the spec; the items here are the technical
unknowns extracted from Technical Context and the dependency on the existing
LRUCache).

## D1 - Class structure: subclass LRUCache vs compose a private LRUCache

- **Decision**: `class TaggedCache(LRUCache)`; store the deep-copied value
  in the inherited LRUCache (which owns `__data` and the recency
  `__order`), plus one extra dict `tag_index: dict[str, set[key]]` mapping
tag -> set of live keys carrying that tag.
- **Rationale**: The issue explicitly says "using the existing
  cachetools.LRUCache for bounded storage". Subclassing reuses LRU eviction
  and recency-for-free (LRUCache.__getitem__ refreshes on hit, __setitem__
  refreshes on write, popitem evicts LRU). Inheritance keeps `len`, `in`,
  `iter`, `pop`, `clear`, `maxsize`, `currsize` working unchanged from the
  base Cache class, so the public surface is coherent. A single tag index is
  the minimal extra state that makes invalidate(tag) O(k) and replacement
  cleanup trivial (remove old key from every old tag's set, add to new
  tags' sets).
- **Alternatives considered**:
  - Composition (private `self._lru = LRUCache(maxsize)`): rejected -
    TaggedCache would no longer BE an LRUCache, would need to re-implement
    len/in/iter/pop/clear, and would diverge from the issue wording.
  - Flat `dict[key, (value, frozenset(tags))]` with a side index: rejected -
    duplicates what LRUCache already provides (recency order, eviction
    loop) and risks drift from upstream LRU semantics.

## D2 - Recency on replacement (put of an existing key)

- **Decision**: put always calls `LRUCache.__setitem__` (via `self[key] =
  value`), so a replacement moves the key to most-recently-used, exactly
  like the upstream LRUCache assignment semantics. A failed put (bad tags or
  deepcopy failure) never reaches `__setitem__`, so recency is untouched.
- **Rationale**: Matches upstream LRUCache behavior for `cache[key] = value`
  (verified in source: `__setitem__` -> `__update(key)` ->
  `move_to_end`). This is also what the Claim-A candidate extension
  (put_no_recency_refresh, 2026-09-21) asks for, so the design satisfies
  the extension for free; it is still tracked as deferred per spec Out of
  Scope (D5).
- **Alternatives considered**: Suppress refresh on replacement to keep old
  recency - rejected: contradicts upstream LRUCache semantics and would
  require intercepting `__setitem__` with extra state; adds complexity with
  no baseline requirement (FR-002 only says "inserts/replaces").

## D3 - deepcopy failure handling and atomicity (FR-015)

- **Decision**: In `put`, order of operations: (1) validate tags (raise
  ValueError before touching state), (2) `value = deepcopy(value)` (if this
  raises, nothing has been stored yet, so old value/tags/recency are
  intact), (3) remove old tag memberships if the key existed, (4) store via
  `self[key] = value` (LRU eviction + recency update), (5) add new tag
  memberships. Steps 3-5 are the only state mutations and only run after
  both validations succeed.
- **Rationale**: deepcopy runs before any mutation, which makes the
  state-preservation guarantee (FR-015: "invalid replacement input must
  leave the old value/tags/recency unchanged") hold by construction for
  both ValueError (tags) and any deepcopy exception. Tag index updates are
  keyed by the same key, so replacement cleanup (step 3) + add (step 5)
  cannot double-count.
- **Alternatives considered**: Copy after storing (store raw, copy on
  get only) - rejected, violates FR-005 (values copied on input). Try/except
  around steps 3-5 with rollback - unnecessary because step 2 precedes all
  mutations; kept simple (Principle IV).

## D4 - Tag validation rules (FR-006..FR-008)

- **Decision**: `tags` must not be `str` or `bytes` (bare string rejection);
  it must be a finite iterable; every entry must be `str` (bool/int/etc.
  rejected); deduplicate with `set(tags)` while preserving validation (check
  every entry, not just unique ones); empty result is allowed (no
  memberships). Validation raises `ValueError` with a clear message.
- **Rationale**: Spec R01: "Tags must be a finite iterable of strings;
  deduplicate tags. Reject a bare string as tags and nonstring tag
  entries with ValueError, before changing existing state." Excluding
  `bytes` follows the same "bare string" intent (a bytes literal is not a
  collection of string tags); this is an informed default documented in
  spec Assumptions. Finite-iterable is naturally satisfied by consuming the
  iterable in a loop (generators included); no length pre-check needed.
- **Alternatives considered**: Accept any hashable tag (ints, tuples) -
  rejected, spec says strings only. Use `collections.abc.Iterable` isinstance
  check - rejected, duck-typing via `iter(tags)` is simpler and catches
  non-iterables with TypeError, which is the standard Python contract for
  non-iterable arguments (the spec only mandates ValueError for the two
  string-related cases).

## D5 - Claim-A candidate extension (put recency refresh)

- **Decision**: Not adopted into the baseline; recorded as a deferred
  intent (spec.md Out of Scope). The D2 design already exhibits the
  extension's behavior (replacement refreshes recency), so if a later phase
  adopts Claim-A, no code change is needed - only spec/checklist updates.
  If a later phase rejects it, D2 must be revisited.
- **Rationale**: The issue lists it as a "candidate extension" dated
  2026-09-21, separate from R01-R03; the latest requirement text (R01-R03)
  governs the baseline. Constitution Principle V requires tracking deferred
  intents explicitly.
- **Alternatives considered**: Adopt it now (it is free under D2) - rejected
  for process reasons: adopting a claim variant requires its own spec
  update in the same change (spec Out of Scope says so), which belongs to a
  later phase, not plan.

## D6 - maxsize validation (FR-014)

- **Decision**: In `TaggedCache.__init__`, require
  `isinstance(maxsize, int) and not isinstance(maxsize, bool) and
  maxsize > 0`, else `ValueError("maxsize must be a positive integer")`.
  Then delegate to `LRUCache.__init__(self, maxsize)`.
- **Rationale**: R03: "maxsize must be a positive integer, excluding
  bool." `isinstance(True, int)` is True in Python, so the explicit bool
  exclusion is mandatory. Checked in the subclass `__init__` so the base
  classes keep their existing (unvalidated) behavior - Principle I.
- **Alternatives considered**: Validate in the base Cache class - rejected,
  changes existing public behavior (e.g., `Cache("inf")`-style usages and
  upstream tests), violates Principle I. Use `operator.index()` - rejected,
  it would accept non-int integer-like objects and still needs the bool
  exclusion; the spec says integer.

## D7 - get() contract: KeyError on miss, deepcopy on hit (FR-003, FR-004)

- **Decision**: Override `__getitem__` to `return deepcopy(super().__getitem__(key))`
  (super().__getitem__ raises KeyError on miss via `__missing__`, and
  refreshes recency on hit via LRUCache). Do NOT override `get(key,
  default=None)` - the inherited `Cache.get` calls `self[key]` and returns
  the default on KeyError, which composes correctly with the
  deepcopy-on-hit behavior.
- **Rationale**: Keeps recency refresh and KeyError semantics identical to
  LRUCache while adding the detachment guarantee. Overriding `get` would be
  redundant (Principle IV).
- **Alternatives considered**: Copy at storage time only and return the
  stored object - rejected, violates FR-003 (returned object must be
  detached). Return `copy.deepcopy` lazily via a wrapper object - rejected,
  over-engineered; deepcopy of the value is the spec's literal contract.

## D8 - Eviction and tag-index consistency (FR-011)

- **Decision**: Eviction happens inside `Cache.__setitem__` via
  `self.popitem()` when full. `popitem` is overridden: it first calls
  `super().popitem()` (LRUCache: pops the LRU key, which also removes it
  from `__order` and `__data`), then removes that key from every tag set in
  `tag_index` (dropping empty sets). `__delitem__` is overridden the same
  way so `pop(key)`, `clear()`, and direct `del` all keep the index clean.
- **Rationale**: Every removal path (eviction, pop, del, clear) funnels
  through `__delitem__`/`popitem` in the base class, so overriding exactly
  those two methods guarantees "no stale memberships affect later reuse of
  the same key" (FR-011) and keeps `invalidate` counts exact (SC-004).
- **Alternatives considered**: Lazy cleanup (prune index during
  invalidate) - rejected: a stale entry in the index would make
  invalidate(tag) attempt to remove an absent key or miscount; eager
  removal at the two choke points is simpler and exact.

## D9 - Testing and verification strategy

- **Decision**: Project-owned tests in `tests/test_tagged.py` (pytest
  style, matching acceptance_public.py), one test per FR plus the edge-case
  list from spec.md; run with `PYTHONPATH=src:. python -m pytest tests/
  acceptance_public.py -q`. Upstream tests stay byte-identical.
- **Rationale**: Constitution II (testable criteria) and III (evidence);
  SC-001 requires the public acceptance suite to pass at convergence.
- **Alternatives considered**: unittest style like upstream tests -
  acceptable but pytest matches the acceptance file and is already the
  runner; either is fine, pytest chosen for brevity.
