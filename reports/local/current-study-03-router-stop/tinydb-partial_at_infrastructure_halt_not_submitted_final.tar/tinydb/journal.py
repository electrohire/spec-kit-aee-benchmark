"""
This module provides :class:`BatchWriter`, an additive wrapper around a
:class:`~tinydb.database.TinyDB` instance that applies batches of insert and
remove operations against the database's default table atomically.

The wrapper does not modify the wrapped database or any existing tinydb
module: ordinary reads/writes on the database keep working unchanged while
the batch writer is in use.
"""

from collections.abc import Mapping
from copy import deepcopy

from .database import TinyDB

__all__ = ('BatchWriter',)

# The name of the table all batch operations target (FR-002: default table
# only). This is TinyDB's built-in default table name.
_DEFAULT_TABLE = '_default'

# The set of operation names a batch entry may carry.
_VALID_OPS = frozenset({'insert', 'remove'})


class BatchWriter:
    """
    Apply batches of insert/remove operations to a TinyDB default table.

    A batch writer wraps a supplied :class:`~tinydb.database.TinyDB`
    instance and exposes a single method, :meth:`apply`, which takes a list
    of operation dictionaries and applies them to the database's default
    table atomically.

    Each operation must be one of:

    - ``{'op': 'insert', 'document': <mapping>}`` — insert a new document
      and report its assigned document ID in the result,
    - ``{'op': 'remove', 'doc_id': <positive int>}`` — remove the document
      with the given ID; a remove of a missing ID is an error.

    Any unknown or malformed operation (wrong or missing ``op``, missing or
    wrongly typed payload, non-mapping document, non-positive or non-integer
    document ID, non-mapping operation entry, or a batch that is not a list)
    raises :class:`ValueError`.

    Application is atomic: operations are validated and applied
    sequentially, but if any operation fails, the complete pre-batch state
    of the default table is restored — including for table handles that
    were acquired before the batch — and the original error is re-raised.

    Documents inserted via a batch are stored as independent deep copies of
    the caller's input: mutating the caller's operation payloads after a
    successful :meth:`apply` does not change the database, and the stored
    data is not the caller's own objects.

    :param db: The :class:`~tinydb.database.TinyDB` instance to wrap
    """

    def __init__(self, db: TinyDB):
        """
        Wrap the given database instance.

        The wrapper only holds a reference to the database; it does not
        alter the database's ordinary APIs or state.
        """
        self.db = db

    def apply(self, operations) -> list:
        """
        Apply a batch of operations to the default table atomically.

        :param operations: a list of operation dictionaries; each entry is
            either ``{'op': 'insert', 'document': <mapping>}`` or
            ``{'op': 'remove', 'doc_id': <positive int>}``
        :returns: the list of IDs of the documents inserted by this batch,
            in insertion order; remove operations contribute no entries and
            an empty batch returns an empty list
        :raises ValueError: if the batch is not a list of operation
            dictionaries, if any operation is unknown or malformed, or if a
            remove targets a document ID that does not exist
        """
        table = self.db.table(_DEFAULT_TABLE)

        # Validate the batch as a whole before touching any state, so a
        # non-list batch is rejected without side effects (FR-005).
        self._validate_batch(operations)

        # Take a deep copy of the complete pre-batch database state. A deep
        # copy is mandatory because storages such as ``MemoryStorage`` return
        # their live data structure from ``read()``; mutating the snapshot
        # would corrupt the database, and restoring a shared reference would
        # be a no-op.
        snapshot = self._snapshot()

        inserted_ids = []
        try:
            for index, operation in enumerate(operations):
                self._validate_operation(index, operation)

                op = operation['op']
                if op == 'insert':
                    # Store an independent deep copy of the caller's payload
                    # so neither the database nor the returned IDs alias the
                    # caller's input (FR-009). ``Table.insert`` itself only
                    # shallow-copies via ``dict(document)``.
                    doc_id = table.insert(deepcopy(operation['document']))
                    inserted_ids.append(doc_id)
                else:  # op == 'remove'
                    doc_id = operation['doc_id']
                    # ``Table.remove`` silently skips missing IDs, so we
                    # have to check existence ourselves: a remove targeting a
                    # missing document ID is an error (FR-007).
                    if doc_id not in {int(k) for k in table._read_table()}:
                        raise ValueError(
                            f'Operation {index}: remove of missing '
                            f'document ID {doc_id}'
                        )
                    table.remove(doc_ids=[doc_id])
        except ValueError:
            # Restore the complete pre-batch state and re-raise the original
            # error (FR-006). Writing the snapshot back through the storage
            # is visible to every table handle because each ``Table`` reads
            # its data from the storage on every operation; resetting the
            # default table's non-persisted ID counter makes the next insert
            # derive its ID from the restored data.
            self.db.storage.write(snapshot)
            table._next_id = None
            raise

        return inserted_ids

    def _snapshot(self) -> dict:
        """
        Return a deep copy of the complete current database state.

        An empty database (``read()`` returning ``None``) is snapshotted as
        an empty dict, which is equivalent for restore purposes.
        """
        state = self.db.storage.read()
        if state is None:
            return {}
        return deepcopy(state)

    @staticmethod
    def _validate_batch(operations) -> None:
        """
        Validate that the batch itself is a list of operation mappings.

        :raises ValueError: if ``operations`` is not a list/tuple of
            mappings
        """
        if not isinstance(operations, (list, tuple)):
            raise ValueError(
                f'Batch must be a list of operation dictionaries, got '
                f'{type(operations).__name__}'
            )
        for index, operation in enumerate(operations):
            if not isinstance(operation, Mapping):
                raise ValueError(
                    f'Operation {index} must be a dictionary, got '
                    f'{type(operation).__name__}'
                )

    @staticmethod
    def _validate_operation(index: int, operation: Mapping) -> None:
        """
        Validate a single operation entry.

        :raises ValueError: if the operation is unknown or malformed
        """
        op = operation.get('op')
        if op not in _VALID_OPS:
            raise ValueError(
                f'Operation {index}: unknown or missing op {op!r}; '
                f'expected one of {sorted(_VALID_OPS)}'
            )

        if op == 'insert':
            document = operation.get('document')
            if not isinstance(document, Mapping):
                raise ValueError(
                    f'Operation {index}: insert requires a mapping '
                    f'document, got {type(document).__name__}'
                )
        else:  # op == 'remove'
            doc_id = operation.get('doc_id')
            # ``bool`` is a subclass of ``int``, so it must be rejected
            # explicitly; zero and negative IDs are not valid document IDs.
            if not isinstance(doc_id, int) or isinstance(doc_id, bool) \
                    or doc_id <= 0:
                raise ValueError(
                    f'Operation {index}: remove requires a positive '
                    f'integer doc_id, got {doc_id!r}'
                )
