"""
Transactional extension for TinyDB.

Provides ``TransactionalTinyDB`` which adds transaction support to TinyDB.
Transactions buffer all writes and either commit them (on normal exit) or
roll them back (on exception). Nested transactions create independent
savepoints.
"""

import copy
import math
from typing import Any, Iterator, Optional

from .database import TinyDB
from .storages import Storage


class _TransactionalStorage:
    """Storage wrapper that buffers writes during transactions with savepoint support."""

    def __init__(self, original_storage: Storage) -> None:
        self._original = original_storage
        # Stack of savepoints: each entry is (snapshot, buffer) for a transaction level
        self._savepoints: list[tuple[Optional[dict], dict]] = []

    # ---- Storage interface (proxied to original) ----

    def read(self) -> Optional[dict[str, dict[str, Any]]]:
        if self._savepoints:
            # Return the buffer from the innermost transaction
            _, buffer = self._savepoints[-1]
            return buffer
        return self._original.read()

    def write(self, data: dict[str, dict[str, Any]]) -> None:
        if self._savepoints:
            # Update the buffer in the innermost transaction
            _, buffer = self._savepoints[-1]
            self._savepoints[-1] = (self._savepoints[-1][0], data)
        else:
            self._original.write(data)

    def close(self) -> None:
        self._original.close()

    # ---- Transaction protocol ----

    def __enter__(self) -> "_TransactionalStorage":
        """Start a transaction: create a savepoint."""
        if not self._savepoints:
            # Outermost transaction: snapshot from original storage
            snapshot = copy.deepcopy(self._original.read()) or {}
            buffer = copy.deepcopy(snapshot)
        else:
            # Nested transaction: snapshot from current buffer (parent's state)
            _, parent_buffer = self._savepoints[-1]
            if parent_buffer is not None:
                snapshot = copy.deepcopy(parent_buffer)
                buffer = copy.deepcopy(parent_buffer)
            else:
                # Parent has no buffer yet
                snapshot = {}
                buffer = {}
        
        self._savepoints.append((snapshot, buffer))
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        """Commit on success, rollback on any exception."""
        if not self._savepoints:
            return False
        
        snapshot, buffer = self._savepoints.pop()
        
        try:
            if exc_type is None:
                # Commit: merge buffer into parent's buffer
                if self._savepoints:
                    # Merge into parent's buffer
                    parent_snapshot, parent_buffer = self._savepoints[-1]
                    if parent_buffer is not None:
                        parent_buffer.update(buffer)
                    else:
                        self._savepoints[-1] = (parent_snapshot, copy.deepcopy(buffer))
                else:
                    # Outermost commit: write to original storage
                    self._original.write(buffer)
        finally:
            pass
        
        return False

    def backup(self) -> dict[str, dict[str, Any]]:
        """Return a deep copy of the current database state."""
        data = self.read()
        if data is None:
            return {}
        return copy.deepcopy(data)


class TransactionalTinyDB(TinyDB):
    """
    TinyDB with transaction support.

    A transaction groups multiple operations into an atomic unit.  All writes
    inside the transaction are buffered and only persisted when the transaction
    completes successfully.  If an exception occurs (including ``BaseException``
    subclasses) the transaction is rolled back and the database is restored to
    its state before the transaction began.

    Nested transactions create independent savepoints.  A successful inner
    transaction merges its changes into the outer transaction without writing
    to the backend.  Only the outermost successful transaction writes to the
    backend exactly once.

    Usage::

        from tinydb import TransactionalTinyDB

        db = TransactionalTinyDB(storage=MemoryStorage)

        with db.transaction():
            db.insert({'name': 'Alice'})
            with db.transaction():
                db.insert({'name': 'Bob'})
            # Bob is visible within the outer transaction
        # Both Alice and Bob are now persisted atomically.

    .. versionadded:: 4.9
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Wrap the storage so we can intercept writes during transactions
        self._transactional_storage: Optional[_TransactionalStorage] = None
        self._original_storage = self._storage
        self._storage = _TransactionalStorage(self._original_storage)
        self._transactional_storage = self._storage

    def transaction(self) -> Iterator["TransactionalTinyDB"]:
        """
        Return a context manager that starts a transaction.

        The context manager yields the same ``TransactionalTinyDB`` instance.
        On normal exit all buffered writes are committed.  On any exception
        (including ``BaseException`` subclasses) the transaction is rolled
        back.

        Nested transactions create independent savepoints.
        """
        return _TransactionContext(self)

    def _clear_all_table_caches(self) -> None:
        """Clear query caches for all tables, including the default table."""
        for table in self._tables.values():
            table.clear_cache()
        # Also clear the default table's cache (it may not be in _tables)
        default_table = self.table(self.default_table_name)
        default_table.clear_cache()

    def backup(self) -> dict[str, dict[str, Any]]:
        """
        Return a deep copy of the current database state.

        During a transaction, includes tentative changes. Returns an empty
        dict for an empty database.
        
        The returned snapshot is deeply detached: modifying it does not
        affect the database, and later database changes do not affect it.
        
        :returns: A dict of {table_name: {doc_id_str: doc_dict}}
        """
        return self._transactional_storage.backup()

    def restore(self, snapshot: dict[str, dict[str, Any]]) -> None:
        """
        Replace the complete logical database with the given snapshot.

        The snapshot is a dict of {table_name: {doc_id_str: doc_dict}}.
        Tables absent from the snapshot are removed.

        Validation:
        - Root and table values must be dicts
        - Table names must be strings
        - Document IDs must be canonical positive decimal strings (e.g. '1', '23')
          - Reject: '0', '-1', '01', int, bool
        - Document values must be JSON-compatible and finite
          - Reject: NaN, Infinity, sets, non-string dict keys

        On validation failure, raises ValueError without modifying the database.

        Inside a transaction, restore is rollbackable. Outside a transaction,
        performs one backend write.

        :param snapshot: The snapshot to restore
        :raises ValueError: If the snapshot is invalid
        """
        # Validate the snapshot before any mutation
        self._validate_snapshot(snapshot)

        # Deep copy the snapshot to avoid mutating caller's data
        restored = copy.deepcopy(snapshot)

        # Determine if we're in a transaction
        if self._transactional_storage._savepoints:
            # In a transaction: update the current buffer
            _, buffer = self._transactional_storage._savepoints[-1]
            if buffer is not None:
                buffer.clear()
                buffer.update(restored)
            else:
                self._transactional_storage._savepoints[-1] = \
                    (self._transactional_storage._savepoints[-1][0], restored)
        else:
            # Not in a transaction: write directly to storage
            self._transactional_storage._original.write(restored)

        # Clear table caches and reset table instances
        # Only keep table instances for tables that exist in the snapshot
        snapshot_table_names = set(snapshot.keys())
        self._tables = {
            name: table for name, table in self._tables.items()
            if name in snapshot_table_names
        }
        # Clear caches for remaining tables
        for table in self._tables.values():
            table.clear_cache()

    def _validate_snapshot(self, snapshot: dict[str, dict[str, Any]]) -> None:
        """
        Validate a snapshot before restoring.
        
        :raises ValueError: If the snapshot is invalid
        """
        if not isinstance(snapshot, dict):
            raise ValueError("Snapshot root must be a dictionary")

        for table_name, table_data in snapshot.items():
            # Table name must be a string
            if not isinstance(table_name, str):
                raise ValueError(f"Table name must be a string, got {type(table_name).__name__}")

            # Table data must be a dictionary
            if not isinstance(table_data, dict):
                raise ValueError(f"Table '{table_name}' data must be a dictionary")

            for doc_id_str, doc in table_data.items():
                # Document ID must be a canonical positive decimal string
                self._validate_doc_id(doc_id_str)

                # Document must be a dictionary
                if not isinstance(doc, dict):
                    raise ValueError(f"Document '{doc_id_str}' must be a dictionary")

                # Validate document values are JSON-compatible
                self._validate_json_value(doc, path=f"document '{doc_id_str}'")

    def _validate_doc_id(self, doc_id_str: Any) -> None:
        """
        Validate a document ID string.
        
        Must be a canonical positive decimal string (e.g. '1', '23').
        Reject: '0', '-1', '01', int, bool.
        """
        if not isinstance(doc_id_str, str):
            raise ValueError(f"Document ID must be a string, got {type(doc_id_str).__name__}")

        # Reject booleans (they're a subclass of int in Python)
        if isinstance(doc_id_str, bool):
            raise ValueError(f"Document ID must be a string, got bool")

        # Must be a valid decimal string
        try:
            value = int(doc_id_str)
        except ValueError:
            raise ValueError(f"Document ID '{doc_id_str}' is not a valid decimal string")

        # Must be positive (greater than 0)
        if value <= 0:
            raise ValueError(f"Document ID '{doc_id_str}' must be positive")

        # Must be canonical (no leading zeros, except for '0' which is rejected above)
        if doc_id_str != str(value):
            raise ValueError(f"Document ID '{doc_id_str}' is not canonical (has leading zeros or negative sign)")

    def _validate_json_value(self, value: Any, path: str = "value") -> None:
        """
        Validate that a value is JSON-compatible and finite.
        
        :raises ValueError: If the value is not JSON-compatible
        """
        if isinstance(value, dict):
            # All keys must be strings
            for key in value.keys():
                if not isinstance(key, str):
                    raise ValueError(
                        f"Dictionary keys in {path} must be strings, "
                        f"got {type(key).__name__}"
                    )
            # Recursively validate values
            for key, val in value.items():
                self._validate_json_value(val, path=f"{path}['{key}']")
        elif isinstance(value, list):
            # Validate each element
            for i, item in enumerate(value):
                self._validate_json_value(item, path=f"{path}[{i}]")
        elif isinstance(value, bool):
            # Booleans are valid JSON
            pass
        elif isinstance(value, (int, float)):
            # Check for NaN and Infinity
            if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                raise ValueError(f"Float value in {path} must be finite")
        elif value is not None:
            # Other types (str, bytes, etc.) are not JSON-compatible
            raise ValueError(f"Value in {path} must be JSON-compatible, got {type(value).__name__}")

    def close(self) -> None:
        """Close the database, committing any pending transaction first."""
        # If we're inside a transaction that hasn't been exited, commit it
        if (self._transactional_storage is not None and
                self._transactional_storage._savepoints):
            while self._transactional_storage._savepoints:
                self._transactional_storage._savepoints.pop()
        super().close()


class _TransactionContext:
    """Context manager for a TinyDB transaction."""

    def __init__(self, db: TransactionalTinyDB) -> None:
        self._db = db
        self._storage: Optional[_TransactionalStorage] = db._transactional_storage

    def __enter__(self) -> TransactionalTinyDB:
        self._storage.__enter__()
        return self._db

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        self._storage.__exit__(exc_type, exc_val, exc_tb)
        # Clear all query caches to avoid stale data from the transaction
        self._db._clear_all_table_caches()
        return False  # Don't suppress exceptions
