"""
Transactional extension for TinyDB.

Provides ``TransactionalTinyDB`` which adds transaction support to TinyDB.
Transactions buffer all writes and either commit them (on normal exit) or
roll them back (on exception). Nested transactions create independent
savepoints.
"""

import copy
from typing import Any, Iterator, Optional

from .database import TinyDB
from .storages import Storage


class _TransactionalStorage:
    """Storage wrapper that buffers writes during transactions with savepoint support."""

    def __init__(self, original_storage: Storage) -> None:
        self._original = original_storage
        # Stack of savepoints: each entry is (snapshot, buffer) for a transaction level
        self._savepoints: list[tuple[Optional[dict], dict]] = []

    # ---- Storage interface (proxied to original) ----

    def read(self) -> Optional[dict[str, dict[str, Any]]]:
        if self._savepoints:
            # Return the buffer from the innermost transaction
            _, buffer = self._savepoints[-1]
            return buffer
        return self._original.read()

    def write(self, data: dict[str, dict[str, Any]]) -> None:
        if self._savepoints:
            # Update the buffer in the innermost transaction
            _, buffer = self._savepoints[-1]
            self._savepoints[-1] = (self._savepoints[-1][0], data)
        else:
            self._original.write(data)

    def close(self) -> None:
        self._original.close()

    # ---- Transaction protocol ----

    def __enter__(self) -> "_TransactionalStorage":
        """Start a transaction: create a savepoint."""
        if not self._savepoints:
            # Outermost transaction: snapshot from original storage
            snapshot = copy.deepcopy(self._original.read()) or {}
            buffer = copy.deepcopy(snapshot)
        else:
            # Nested transaction: snapshot from current buffer (parent's state)
            _, parent_buffer = self._savepoints[-1]
            if parent_buffer is not None:
                snapshot = copy.deepcopy(parent_buffer)
                buffer = copy.deepcopy(parent_buffer)
            else:
                # Parent has no buffer yet
                snapshot = {}
                buffer = {}
        
        self._savepoints.append((snapshot, buffer))
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        """Commit on success, rollback on any exception.
        
        On rollback, no writes are performed because the original storage
        was never modified during the transaction (all writes were buffered).
        
        Returns True to suppress the exception if it was a nested rollback.
        """
        if not self._savepoints:
            return False
        
        snapshot, buffer = self._savepoints.pop()
        
        try:
            if exc_type is None:
                # Commit: merge buffer into parent's buffer
                if self._savepoints:
                    # Merge into parent's buffer
                    parent_snapshot, parent_buffer = self._savepoints[-1]
                    if parent_buffer is not None:
                        # Deep merge: parent keeps its keys, buffer adds/updates
                        parent_buffer.update(buffer)
                    else:
                        # Parent has no buffer, create one
                        self._savepoints[-1] = (parent_snapshot, copy.deepcopy(buffer))
                else:
                    # Outermost commit: write to original storage
                    self._original.write(buffer)
            # Rollback: no writes needed - the original storage was never
            # modified during the transaction, so it still has the correct
            # pre-transaction state.
        finally:
            pass
        
        # Don't suppress exceptions - let them propagate
        return False


class TransactionalTinyDB(TinyDB):
    """
    TinyDB with transaction support.

    A transaction groups multiple operations into an atomic unit.  All writes
    inside the transaction are buffered and only persisted when the transaction
    completes successfully.  If an exception occurs (including ``BaseException``
    subclasses) the transaction is rolled back and the database is restored to
    its state before the transaction began.

    Nested transactions create independent savepoints.  A successful inner
    transaction merges its changes into the outer transaction without writing
    to the backend.  Only the outermost successful transaction writes to the
    backend exactly once.

    Usage::

        from tinydb import TransactionalTinyDB

        db = TransactionalTinyDB(storage=MemoryStorage)

        with db.transaction():
            db.insert({'name': 'Alice'})
            with db.transaction():
                db.insert({'name': 'Bob'})
            # Bob is visible within the outer transaction
        # Both Alice and Bob are now persisted atomically.

    .. versionadded:: 4.9
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Wrap the storage so we can intercept writes during transactions
        self._transactional_storage: Optional[_TransactionalStorage] = None
        self._original_storage = self._storage
        self._storage = _TransactionalStorage(self._original_storage)
        self._transactional_storage = self._storage

    def transaction(self) -> Iterator["TransactionalTinyDB"]:
        """
        Return a context manager that starts a transaction.

        The context manager yields the same ``TransactionalTinyDB`` instance.
        On normal exit all buffered writes are committed.  On any exception
        (including ``BaseException`` subclasses) the transaction is rolled
        back.

        Nested transactions create independent savepoints.
        """
        return _TransactionContext(self)

    def _clear_all_table_caches(self) -> None:
        """Clear query caches for all tables, including the default table."""
        for table in self._tables.values():
            table.clear_cache()
        # Also clear the default table's cache (it may not be in _tables)
        default_table = self.table(self.default_table_name)
        default_table.clear_cache()

    def close(self) -> None:
        """Close the database, committing any pending transaction first."""
        # If we're inside a transaction that hasn't been exited, commit it
        # to avoid leaving the storage in a transactional state.
        if (self._transactional_storage is not None and
                self._transactional_storage._savepoints):
            # Commit all pending transactions
            while self._transactional_storage._savepoints:
                self._transactional_storage._savepoints.pop()
        super().close()


class _TransactionContext:
    """Context manager for a TinyDB transaction."""

    def __init__(self, db: TransactionalTinyDB) -> None:
        self._db = db
        self._storage: Optional[_TransactionalStorage] = db._transactional_storage

    def __enter__(self) -> TransactionalTinyDB:
        self._storage.__enter__()
        return self._db

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        self._storage.__exit__(exc_type, exc_val, exc_tb)
        # Clear all query caches to avoid stale data from the transaction
        # Clear caches after every transaction exit (inner or outer)
        self._db._clear_all_table_caches()
        return False  # Don't suppress exceptions
