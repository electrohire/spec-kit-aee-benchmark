"""
Transactional extension for TinyDB.

Provides ``TransactionalTinyDB`` which adds transaction support to TinyDB.
Transactions buffer all writes and either commit them (on normal exit) or
roll them back (on exception).
"""

import copy
from typing import Any, Iterator, Optional

from .database import TinyDB
from .storages import Storage


class _TransactionalStorage:
    """Storage wrapper that buffers writes during a transaction."""

    def __init__(self, original_storage: Storage) -> None:
        self._original = original_storage
        self._in_transaction = False
        self._snapshot: Optional[dict] = None
        self._buffer: Optional[dict] = None

    # ---- Storage interface (proxied to original) ----

    def read(self) -> Optional[dict[str, dict[str, Any]]]:
        if self._in_transaction and self._buffer is not None:
            return self._buffer
        return self._original.read()

    def write(self, data: dict[str, dict[str, Any]]) -> None:
        if self._in_transaction:
            # Buffer the write instead of persisting it
            self._buffer = data
        else:
            self._original.write(data)

    def close(self) -> None:
        self._original.close()

    # ---- Transaction protocol ----

    def __enter__(self) -> "_TransactionalStorage":
        """Start a transaction: snapshot state and begin buffering."""
        if self._in_transaction:
            raise RuntimeError(
                "Nesting transaction() is not supported in this release"
            )
        self._in_transaction = True
        self._snapshot = copy.deepcopy(self._original.read())
        self._buffer = copy.deepcopy(self._snapshot)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Commit on success, rollback on any exception.
        
        On rollback, no writes are performed because the original storage
        was never modified during the transaction (all writes were buffered).
        """
        try:
            if exc_type is None:
                # Commit: write the buffered state to the original storage
                if self._buffer is not None:
                    self._original.write(self._buffer)
            # Rollback: no writes needed - the original storage was never
            # modified during the transaction, so it still has the correct
            # pre-transaction state.
        finally:
            self._in_transaction = False
            self._snapshot = None
            self._buffer = None


class TransactionalTinyDB(TinyDB):
    """
    TinyDB with transaction support.

    A transaction groups multiple operations into an atomic unit.  All writes
    inside the transaction are buffered and only persisted when the transaction
    completes successfully.  If an exception occurs (including ``BaseException``
    subclasses) the transaction is rolled back and the database is restored to
    its state before the transaction began.

    Usage::

        from tinydb import TransactionalTinyDB

        db = TransactionalTinyDB(storage=MemoryStorage)

        with db.transaction():
            db.insert({'name': 'Alice'})
            db.insert({'name': 'Bob'})
        # Both inserts are now persisted atomically.

        try:
            with db.transaction():
                db.insert({'name': 'Charlie'})
                raise ValueError('oops')
        except ValueError:
            pass
        # The insert was rolled back; Charlie does not exist.

    .. versionadded:: 4.9
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Wrap the storage so we can intercept writes during transactions
        self._transactional_storage: Optional[_TransactionalStorage] = None
        self._original_storage = self._storage
        self._storage = _TransactionalStorage(self._original_storage)
        self._transactional_storage = self._storage

    def transaction(self) -> Iterator["TransactionalTinyDB"]:
        """
        Return a context manager that starts a transaction.

        The context manager yields the same ``TransactionalTinyDB`` instance.
        On normal exit all buffered writes are committed.  On any exception
        (including ``BaseException`` subclasses) the transaction is rolled
        back.

        Nesting calls to ``transaction()`` raises ``RuntimeError``.
        """
        return _TransactionContext(self)

    def _clear_all_table_caches(self) -> None:
        """Clear query caches for all tables, including the default table."""
        for table in self._tables.values():
            table.clear_cache()
        # Also clear the default table's cache (it may not be in _tables)
        default_table = self.table(self.default_table_name)
        default_table.clear_cache()

    def close(self) -> None:
        """Close the database, committing any pending transaction first."""
        # If we're inside a transaction that hasn't been exited, commit it
        # to avoid leaving the storage in a transactional state.
        if (self._transactional_storage is not None and
                self._transactional_storage._in_transaction):
            # This shouldn't normally happen, but handle it gracefully
            self._transactional_storage.__exit__(None, None, None)
        super().close()


class _TransactionContext:
    """Context manager for a TinyDB transaction."""

    def __init__(self, db: TransactionalTinyDB) -> None:
        self._db = db
        self._storage: Optional[_TransactionalStorage] = db._transactional_storage

    def __enter__(self) -> TransactionalTinyDB:
        self._storage.__enter__()
        return self._db

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._storage.__exit__(exc_type, exc_val, exc_tb)
        # Clear all query caches to avoid stale data from the transaction
        self._db._clear_all_table_caches()
