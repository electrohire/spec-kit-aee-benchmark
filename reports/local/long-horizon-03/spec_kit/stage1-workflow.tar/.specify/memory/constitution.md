# TinyDB Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
All existing public APIs of TinyDB MUST remain functional and unchanged. New features, including TransactionalTinyDB, MUST NOT alter the behavior of existing TinyDB operations, named tables, or default table access. Backward compatibility is non-negotiable: any change that breaks existing code is a regression and must be rejected.

### II. Attach Testable Acceptance Criteria to Requirements
Every requirement MUST have explicit, testable acceptance criteria. Requirements without testable criteria are incomplete. Acceptance criteria MUST be verifiable through automated tests (unit, integration, or acceptance). Assertions in code or documentation that cannot be tested MUST be flagged as unverified.

### III. Distinguish Observed Evidence from Unverified Assertions
Observed evidence (test results, benchmark data, verified behavior) MUST be clearly distinguished from unverified assertions (claims, assumptions, design intentions). Unverified assertions MUST be documented as such and MUST NOT be treated as facts. When evidence conflicts with an assertion, the evidence takes precedence.

### IV. Prefer Simple Scoped Implementations
Implementations MUST be scoped to the minimum necessary complexity to satisfy the requirement. Avoid over-engineering, premature abstraction, or features beyond the stated scope. For the initial release, TransactionalTinyDB is single-instance and single-thread only. Concurrent-writer safety, power-loss durability, and rollback after arbitrary partial backend write failure are explicitly out of scope.

### V. Document Unresolved Assumptions and Regressions
All unresolved assumptions, known limitations, and regressions MUST be documented in the codebase and/or specification artifacts. Assumptions MUST include the context in which they apply and the conditions under which they may be invalidated. Regressions MUST be tracked with a clear description of what changed and why.

## Additional Constraints

### TransactionalTinyDB Scope
The TransactionalTinyDB feature has the following explicit constraints:

- Single-instance, single-thread operation only. No concurrent-writer safety is promised.
- Supports MemoryStorage and JSONStorage backends.
- No power-loss durability guarantee.
- No rollback guarantee after arbitrary partial backend write failure.
- Nesting `transaction()` calls raises `RuntimeError` (caught nesting error leaves parent usable).
- A committed JSONStorage database survives close/reopen; rollback leaves persisted state unchanged.
- The existing upstream test suite MUST continue to pass without modification.

### Acceptance Requirements
The following requirements have explicit acceptance criteria:

- **R01**: TransactionalTinyDB accepts the same constructor arguments as TinyDB.
- **R02**: `with db.transaction() as current:` yields the same db; mutations are visible within the transaction.
- **R03**: No backend `storage.write` call occurs during a transaction; successful exit writes the complete logical database exactly once.
- **R04**: Any exception (including `BaseException` subclasses) propagates out and rolls back with zero backend writes.
- **R05**: Rollback restores nested mutable values, table creation/deletion, and preexisting query results.
- **R06**: After commit/rollback, existing handles can insert without ID collisions.
- **R07**: Nesting `transaction()` raises `RuntimeError`.
- **R08**: Committed JSONStorage survives close/reopen; rollback leaves persisted state unchanged.

## Governance

This constitution supersedes all other development practices for the TinyDB project. Amendments require:

1. Documentation of the change with rationale.
2. Verification that no existing acceptance criteria are violated.
3. Version increment per the semantic versioning policy below.

All pull requests and code reviews MUST verify compliance with this constitution. Complexity MUST be justified against Principle IV (Simple Scoped Implementations).

### Versioning Policy
- **MAJOR**: Backward-incompatible governance changes, principle removals, or redefinitions.
- **MINOR**: New principles, sections, or materially expanded guidance.
- **PATCH**: Clarifications, wording refinements, typo fixes, non-semantic changes.

**Version**: 1.0.0 | **Ratified**: 2026-09-17 | **Last Amended**: 2026-09-17
