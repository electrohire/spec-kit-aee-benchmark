# Quickstart: Validating TransactionalTinyDB

**Date**: 2026-09-17
**Feature**: Opt-in Transactions for TinyDB

## Prerequisites

- Python 3.10+ installed
- The TinyDB repository at `/testbed`
- `pytest` installed (already in `uv.lock`)

## Validation Scenarios

### Scenario 1: Verify Upstream Tests Pass (Baseline)

**Purpose**: Confirm that the existing TinyDB test suite passes before any changes.

**Command**:
```bash
cd /testbed
python -m pytest -c /dev/null tests -q
```

**Expected Outcome**: All existing tests pass. This is the baseline that must not regress.

---

### Scenario 2: Verify Acceptance Tests Pass

**Purpose**: Confirm that the 5 public acceptance tests in `acceptance_public.py` pass.

**Command**:
```bash
cd /testbed
python -m pytest -c /dev/null acceptance_public.py -v
```

**Expected Outcome**: All 5 tests pass:
- `test_R01_R02_R03_commit` — Atomic writes and single write-on-commit
- `test_R04_R05_R06_rollback` — Exception rollback and ID uniqueness
- `test_R08_json_persistence` — JSONStorage survives close/reopen
- `test_R07_reject_nested_initial_release` — Nested transaction rejection

---

### Scenario 3: Verify Basic Transaction Commit

**Purpose**: Confirm that a transaction commits data correctly.

**Command**:
```bash
python3 -c "
from tinydb import TransactionalTinyDB
from tinydb.storages import MemoryStorage

db = TransactionalTinyDB(storage=MemoryStorage)
with db.transaction() as current:
    assert current is db
    db.insert({'name': 'Alice'})
    db.insert({'name': 'Bob'})
assert len(db) == 2
assert db.all() == [{'name': 'Alice', '_id': 1}, {'name': 'Bob', '_id': 2}]
print('PASS: Basic transaction commit')
db.close()
"
```

**Expected Outcome**: Prints `PASS: Basic transaction commit`.

---

### Scenario 4: Verify Transaction Rollback

**Purpose**: Confirm that a transaction rolls back on exception.

**Command**:
```bash
python3 -c "
from tinydb import TransactionalTinyDB, Query
from tinydb.storages import MemoryStorage

db = TransactionalTinyDB(storage=MemoryStorage)
db.insert({'value': 1})

try:
    with db.transaction():
        db.update({'value': 999})
        raise ValueError('rollback')
except ValueError:
    pass

assert db.search(Query().value == 1)
assert not db.search(Query().value == 999)
print('PASS: Transaction rollback')
db.close()
"
```

**Expected Outcome**: Prints `PASS: Transaction rollback`.

---

### Scenario 5: Verify Nested Transaction Rejection

**Purpose**: Confirm that nested transactions raise `RuntimeError`.

**Command**:
```bash
python3 -c "
from tinydb import TransactionalTinyDB
from tinydb.storages import MemoryStorage

db = TransactionalTinyDB(storage=MemoryStorage)
with db.transaction():
    db.insert({'a': 1})
    try:
        with db.transaction():
            pass
    except RuntimeError:
        pass
    db.insert({'b': 2})
assert len(db) == 2
print('PASS: Nested transaction rejection')
db.close()
"
```

**Expected Outcome**: Prints `PASS: Nested transaction rejection`.

---

### Scenario 6: Verify JSONStorage Persistence

**Purpose**: Confirm that committed data survives close/reopen.

**Command**:
```bash
python3 -c "
import tempfile, os
from tinydb import TransactionalTinyDB, TinyDB
from tinydb.storages import JSONStorage

with tempfile.TemporaryDirectory() as tmpdir:
    path = os.path.join(tmpdir, 'test.json')
    with TransactionalTinyDB(path) as db:
        with db.transaction():
            db.insert({'kept': True})
    with TinyDB(path) as check:
        assert check.all() == [{'kept': True}]
print('PASS: JSONStorage persistence')
"
```

**Expected Outcome**: Prints `PASS: JSONStorage persistence`.

---

### Scenario 7: Verify Write Counting

**Purpose**: Confirm that a transaction writes exactly once on commit and zero times on rollback.

**Command**:
```bash
python3 -c "
import copy
from tinydb import TransactionalTinyDB
from tinydb.storages import MemoryStorage

class CountingStorage(MemoryStorage):
    def __init__(self):
        super().__init__()
        self.writes = []
    def write(self, data):
        self.writes.append(copy.deepcopy(data))
        super().write(data)

db = TransactionalTinyDB(storage=CountingStorage)
with db.transaction():
    db.insert({'a': 1})
    db.insert({'b': 2})
assert len(db.writes) == 1
print('PASS: Write counting (commit)')

db.writes.clear()
try:
    with db.transaction():
        db.insert({'c': 3})
        raise ValueError()
except ValueError:
    pass
assert len(db.writes) == 0
print('PASS: Write counting (rollback)')
db.close()
"
```

**Expected Outcome**: Prints `PASS: Write counting (commit)` and `PASS: Write counting (rollback)`.

## Running All Tests

```bash
cd /testbed
python -m pytest -c /dev/null tests acceptance_public.py -v
```

**Expected Outcome**: All tests pass, including:
- All existing upstream tests (no regressions)
- All 5 acceptance tests
- All new focused transaction tests
