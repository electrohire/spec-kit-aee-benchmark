# Contract: TransactionalTinyDB Public API

**Date**: 2026-09-17
**Feature**: Opt-in Transactions for TinyDB

## Overview

This document defines the public API contract for `TransactionalTinyDB`, the transactional extension to TinyDB.

## Import

```python
from tinydb import TransactionalTinyDB
```

## Class: TransactionalTinyDB

### Constructor

```python
TransactionalTinyDB(*args, **kwargs) -> TransactionalTinyDB
```

**Parameters**: Same as `TinyDB` constructor.
- `storage` (keyword-only, default `JSONStorage`): The storage class to use.
- All other `*args` and `**kwargs` are passed to the storage class.

**Returns**: A new `TransactionalTinyDB` instance.

**Behavior**: Identical to `TinyDB` constructor. All existing constructor arguments and keyword arguments are accepted and passed through to the storage backend.

### Method: transaction()

```python
db.transaction() -> TransactionContext
```

**Returns**: A context manager (`TransactionContext`) that yields the database instance itself.

**Usage**:
```python
with db.transaction() as current:
    assert current is db  # Yields the same db instance
    db.insert({'key': 'value'})
    # Changes are buffered, not written to storage
# On exit: changes are written to storage exactly once
```

**Behavior**:
1. On `__enter__`: Takes a snapshot of the current database state. Replaces `storage.write` with a no-op. Returns the database instance.
2. On `__exit__` (no exception): Writes the accumulated database state to storage exactly once.
3. On `__exit__` (exception): Restores the snapshot to storage. Clears all query caches. Propagates the exception.

**Raises**: `RuntimeError` if called while already inside a transaction (nesting is not supported in this release).

## Class: TransactionContext

A context manager. Users do not instantiate this class directly.

```python
with db.transaction() as ctx:
    # ctx is the same as db
    ...
```

## API Compatibility

All existing `TinyDB` methods work identically within a transaction:
- `db.insert(document)` — Buffered during transaction, written on commit.
- `db.update(fields, cond)` — Buffered during transaction, written on commit.
- `db.remove(cond)` — Buffered during transaction, written on commit.
- `db.search(cond)` — Returns results from the current (potentially modified) state.
- `db.get(cond, doc_id)` — Returns the current document (potentially modified).
- `db.table(name)` — Returns the same table instance as outside a transaction.
- `db.drop_table(name)` — Buffered during transaction, written on commit.
- `db.drop_tables()` — Buffered during transaction, written on commit.

## Error Contract

| Error Type | When Raised | Behavior |
|-----------|-------------|----------|
| `RuntimeError` | `transaction()` called while already in a transaction | Propagates to caller; parent transaction remains usable |
| Any exception from user code | Raised inside `with db.transaction():` block | Transaction rolls back; exception propagates; zero writes |
| `BaseException` (e.g., `KeyboardInterrupt`) | Raised inside `with db.transaction():` block | Transaction rolls back; exception propagates; zero writes |

## Persistence Contract

| Scenario | Committed Data Survives Close/Reopen? | Rollback Changes Persisted State? |
|----------|---------------------------------------|-----------------------------------|
| `JSONStorage` | Yes | No |
| `MemoryStorage` | N/A (in-memory only) | N/A (in-memory only) |
