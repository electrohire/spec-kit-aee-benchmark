# Data Model: TransactionalTinyDB

**Date**: 2026-09-17
**Feature**: Opt-in Transactions for TinyDB

## Entities

### TransactionalTinyDB

A subclass of `TinyDB` that adds transactional semantics.

**Attributes** (inherited from `TinyDB`):
- `_storage`: Storage instance (MemoryStorage or JSONStorage)
- `_tables`: Dict of active table instances
- `_opened`: Boolean flag for context manager

**New Methods**:
- `transaction() -> TransactionContext`: Returns a context manager for transactional operations.

**Inherited Methods** (all work identically within a transaction):
- `insert(document)`, `insert_multiple(documents)`: Insert documents into the default table.
- `update(fields, cond, doc_ids)`, `update_multiple(updates)`: Update matching documents.
- `remove(cond, doc_ids)`: Remove matching documents.
- `get(cond, doc_id, doc_ids)`: Retrieve a document.
- `search(cond)`: Search for documents matching a query.
- `table(name)`: Get or create a table instance.
- `tables()`: Get all table names.
- `drop_tables()`, `drop_table(name)`: Remove tables.
- `truncate()`: Remove all documents from the default table.
- `close()`: Close the database.

### TransactionContext

A context manager that wraps a database instance and provides transactional semantics.

**Attributes**:
- `_db`: Reference to the `TransactionalTinyDB` instance.
- `_storage`: Reference to the database's storage instance.
- `_snapshot`: Deep copy of the storage data at transaction start (used for rollback).
- `_original_write`: Reference to the original `storage.write` method (restored on exit).

**Methods**:
- `__enter__() -> TransactionalTinyDB`: Takes a snapshot of storage data, replaces `storage.write` with a no-op, returns the database instance.
- `__exit__(exc_type, exc_val, exc_tb) -> bool`: On success, writes the accumulated state once. On exception, restores the snapshot and clears all query caches. Always restores the original `write` method. Returns `False` to propagate exceptions.

### Storage (MemoryStorage / JSONStorage)

The underlying storage mechanism. During a transaction, its `write` method is temporarily replaced with a no-op.

**Storage Data Structure**:
```python
{
    'table_name': {
        '1': {document...},
        '2': {document...},
        ...
    },
    ...
}
```

## State Transitions

### Transaction Lifecycle

```
[Idle]
  │
  │ db.transaction()
  ▼
[Transaction Active]
  │
  │ Mutations (buffered, no writes)
  ▼
[Commit] ────────────────► [Idle]
  │                            (storage.write called once)
  │
  │ Exception
  ▼
[Rollback] ──────────────► [Idle]
  │                            (snapshot restored, caches cleared)
```

### Query Cache State

| Transaction State | Query Cache |
|------------------|-------------|
| Idle | Normal (populated by queries) |
| Transaction Active | Stale (mutations not reflected) |
| Commit | Cleared (refreshed on next query) |
| Rollback | Cleared (prevents stale data) |

## Relationships

- `TransactionalTinyDB` **has-a** `Storage` (inherited from `TinyDB`)
- `TransactionalTinyDB` **has-a** `TransactionContext` (returned by `transaction()`)
- `TransactionContext` **references** `TransactionalTinyDB` and its `Storage`
- `TransactionalTinyDB` **has-many** `Table` instances (inherited from `TinyDB`)

## Validation Rules

1. **No nested transactions**: `transaction()` called while already in a transaction raises `RuntimeError`.
2. **Single write on commit**: `storage.write` is called exactly once on successful commit.
3. **Zero writes on rollback**: `storage.write` is never called on rollback (snapshot is restored via the no-op interception).
4. **Deep copy integrity**: The snapshot must be a complete deep copy of the storage data at transaction start.
5. **Cache consistency**: All query caches must be cleared on both commit and rollback.
