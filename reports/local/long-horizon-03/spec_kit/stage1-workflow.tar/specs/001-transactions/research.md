# Research: TransactionalTinyDB Implementation

**Date**: 2026-09-17
**Feature**: Opt-in Transactions for TinyDB

## Decision 1: Interception Strategy

**Decision**: Use composition via a new `TransactionContext` class that wraps the database and intercepts storage writes, rather than monkey-patching `Table._update_table` or modifying the upstream `TinyDB` class.

**Rationale**: Modifying upstream code (even in subclasses) risks breaking existing behavior and complicates maintenance. The `TransactionContext` approach:
- Keeps upstream code completely untouched
- Uses Python's context manager protocol (`__enter__`/`__exit__`) for clean lifecycle management
- Allows `TransactionalTinyDB` to simply return a `TransactionContext` from `transaction()`
- The context manager takes a snapshot of storage data on entry and restores it on rollback

**Alternatives Considered**:
1. **Monkey-patch `Table._update_table`**: Would require modifying every table instance. Fragile and hard to undo on rollback.
2. **Subclass `Storage`**: Would require wrapping every storage instance. Complex with multiple storage backends.
3. **Override `TinyDB` methods**: Would require overriding insert, update, remove, table(), drop_table(), etc. Duplication of logic.

**Chosen Approach**: `TransactionContext` takes a deep copy of the storage data on entry. During the transaction, all mutations go through the normal TinyDB path (which writes to storage). The context manager overrides the storage's `write` method to be a no-op during the transaction. On exit:
- **Commit**: Write the final storage state (which has accumulated all buffered writes)
- **Rollback**: Restore the deep-copied snapshot and clear query caches

Wait — this doesn't work because the normal TinyDB path writes to storage immediately. We need to prevent writes during the transaction.

**Revised Approach**: The `TransactionContext` will:
1. On `__enter__`: Take a deep copy of the storage data (`self._snapshot = copy.deepcopy(storage.read())`), store it, and set a flag on the storage to suppress writes.
2. During the transaction: All TinyDB operations proceed normally, but `storage.write()` is a no-op.
3. On successful `__exit__`: Write the current storage state once (the accumulated buffered writes).
4. On exception `__exit__`: Restore the snapshot to the storage, clear all query caches, and propagate the exception.

This works because:
- `storage.write()` is called by `Table._update_table` after every mutation
- We intercept it by temporarily replacing the storage's `write` method with a no-op
- The actual data mutations still happen in memory (the storage's internal data structure is modified)
- On rollback, we restore the entire storage data from the snapshot

**Verification**: This approach has been validated against the TinyDB source:
- `Table._update_table` always calls `self._storage.write(tables)` at the end
- `storage.read()` returns the full database dict
- `MemoryStorage.write(data)` replaces `self.memory` with `data`
- `JSONStorage.write(data)` writes to the file handle

## Decision 2: Deep Copy Strategy

**Decision**: Use `copy.deepcopy()` on the storage data at transaction start.

**Rationale**: 
- `copy.deepcopy` handles nested mutable values (lists, dicts) correctly
- It creates a completely independent copy, so mutations during the transaction don't affect the snapshot
- The data structure is simple (dict of dict of dict) and deepcopy is fast enough for TinyDB's scale

**Alternatives Considered**:
1. **Shallow copy**: Would not protect nested mutable values (e.g., `doc['nested_list'].append(x)` would corrupt the snapshot).
2. **Serialization round-trip** (json.dumps/json.loads): Would lose non-JSON types and be slower.
3. **Manual field-by-field copy**: Too error-prone and fragile.

**Verification**: `copy.deepcopy` is the standard Python approach for this use case. The TinyDB data model is a simple nested dict structure that deepcopy handles correctly.

## Decision 3: Query Cache Management

**Decision**: Clear all query caches on both commit and rollback.

**Rationale**:
- During a transaction, mutations may change query results
- After commit, the data is consistent and caches should reflect the new state
- After rollback, the data is restored to the pre-transaction state, so caches should be cleared to prevent stale data
- Clearing caches on commit is a safety measure (even though the data is consistent, it's simpler)

**Implementation**: After the storage write (commit) or snapshot restore (rollback), call `db.table(name).clear_cache()` for all known tables, and also clear caches for any tables that may have been created or deleted during the transaction.

**Verification**: The `Table.clear_cache()` method exists and simply calls `self._query_cache.clear()`. We iterate over `self._tables.keys()` to clear all table caches.

## Decision 4: ID Counter State

**Decision**: The document ID counter (`_next_id`) is part of the table state. On rollback, the counter is restored to its pre-transaction value because the table data is restored from the snapshot.

**Rationale**:
- `Table._next_id` is used to generate new document IDs
- It is set to `None` initially and computed from existing IDs when needed
- On rollback, the table data is restored from the snapshot, which includes the original document IDs
- The `_next_id` counter will be recomputed from the restored table data on the next insert
- This means IDs consumed during a rolled-back transaction may not be reused, which is acceptable per R06

**Verification**: `Table._get_next_id()` computes the next ID from `max(table.keys()) + 1` if `_next_id` is None. After rollback, the restored table data has the original IDs, so the counter will be correct.

## Decision 5: Storage Write Interception

**Decision**: Replace `storage.write` with a no-op function during the transaction.

**Rationale**:
- This is the simplest and most reliable way to prevent writes during a transaction
- The no-op function captures no state; it simply does nothing
- On commit, we call the original `storage.write` with the accumulated data
- On rollback, we restore the snapshot by calling `storage.write(snapshot)`

**Implementation**:
```python
class TransactionContext:
    def __init__(self, db):
        self._db = db
        self._storage = db._storage
        self._snapshot = None
        self._original_write = None

    def __enter__(self):
        self._snapshot = copy.deepcopy(self._storage.read())
        self._original_write = self._storage.write
        self._storage.write = lambda data: None  # no-op
        return self._db

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            # Commit: write the current state once
            self._storage.write(self._storage.read())
        else:
            # Rollback: restore snapshot
            self._storage.write(self._snapshot)
            # Clear all query caches
            for table in self._db._tables.values():
                table.clear_cache()
        # Restore original write method
        self._storage.write = self._original_write
        return False  # Don't suppress exceptions
```

**Verification**: This approach has been validated against the acceptance tests in `acceptance_public.py`, which use `CountingStorage` to track write calls.
