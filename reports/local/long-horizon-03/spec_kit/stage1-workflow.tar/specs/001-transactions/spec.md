# Feature Specification: Opt-in Transactions for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-09-17

**Status**: Draft

**Input**: User description: "Extend TinyDB with TransactionalTinyDB supporting single-instance, single-thread transactions with commit/rollback semantics."

## User Scenarios & Testing

### User Story 1 - Atomic Write Operations (Priority: P1)

A developer uses TinyDB for local data storage and needs to perform multiple related mutations (inserts, updates, deletions) as a single atomic unit. If any mutation fails, all changes should be rolled back so the database remains consistent.

**Why this priority**: This is the core value proposition of the transactional feature. Without atomicity, developers must implement their own rollback logic, which is error-prone and duplicates effort.

**Independent Test**: Can be fully tested by creating a database, performing mutations inside a transaction context, and verifying that either all changes are persisted (on commit) or none are (on rollback).

**Acceptance Scenarios**:

1. **Given** a fresh database with no data, **When** a transaction inserts multiple documents and exits normally, **Then** all documents are persisted and visible outside the transaction.
2. **Given** a database with existing data, **When** a transaction modifies data and raises an exception, **Then** the original data is preserved and no changes are written.
3. **Given** an active transaction, **When** mutations are performed through the database handle or table handles obtained before entry, **Then** all mutations are visible within the transaction scope.

---

### User Story 2 - Single Write-on-Commit (Priority: P1)

A developer wants to ensure that all changes in a transaction are written to storage exactly once, reducing I/O overhead and ensuring consistency.

**Why this priority**: This is a performance and correctness requirement. Multiple writes during a transaction risk partial persistence and inconsistent state.

**Independent Test**: Can be fully tested by wrapping a CountingStorage around MemoryStorage and verifying that exactly one `write` call occurs on successful commit and zero writes occur during the transaction or on rollback.

**Acceptance Scenarios**:

1. **Given** a transaction with multiple mutations across different tables, **When** the transaction exits successfully, **Then** the storage backend's `write` method is called exactly once.
2. **Given** a transaction that raises an exception, **When** the exception propagates out, **Then** the storage backend's `write` method is never called.

---

### User Story 3 - Persistence Survives Close/Reopen (Priority: P2)

A developer uses JSONStorage with transactions and expects committed data to survive database close and reopen.

**Why this priority**: This ensures that the transactional feature works correctly with persistent storage, not just in-memory storage.

**Independent Test**: Can be fully tested by committing data in a transaction, closing the database, reopening it, and verifying the data persists.

**Acceptance Scenarios**:

1. **Given** a JSONStorage database, **When** a transaction commits data, **Then** closing and reopening the database shows the committed data.
2. **Given** a JSONStorage database, **When** a transaction rolls back, **Then** the persisted state on disk is unchanged.

---

### User Story 4 - Nested Transaction Rejection (Priority: P3)

A developer accidentally attempts to nest transactions and expects a clear error that does not corrupt the parent transaction.

**Why this priority**: This is a safety feature to prevent subtle bugs from nested transaction usage in the initial release.

**Independent Test**: Can be fully tested by creating a transaction, attempting to enter another transaction inside it, and verifying a `RuntimeError` is raised while the parent transaction remains usable.

**Acceptance Scenarios**:

1. **Given** an active transaction, **When** `db.transaction()` is called inside the context, **Then** a `RuntimeError` is raised.
2. **Given** a nested transaction error is caught, **When** the parent transaction continues, **Then** the parent transaction remains functional.

---

### Edge Cases

- What happens when `BaseException` (e.g., `KeyboardInterrupt`) is raised inside a transaction? The transaction must roll back with zero writes.
- How does the system handle a transaction that modifies a document with nested mutable values (e.g., lists, dicts)? Rollback must restore the original values.
- What happens when multiple tables are modified in a single transaction? All changes must be written atomically.
- How does the system handle query cache invalidation after rollback? Cached results must not reflect rolled-back data.

## Requirements

### Functional Requirements

- **FR-001**: `TransactionalTinyDB` MUST accept the same constructor arguments as `TinyDB` and pass them through to the storage backend.
- **FR-002**: `TransactionalTinyDB` MUST support all existing TinyDB operations (insert, update, search, get, remove, etc.) without behavioral changes.
- **FR-003**: `TransactionalTinyDB` MUST expose a `transaction()` method that returns a context manager yielding the database instance itself.
- **FR-004**: Within a transaction context, all mutations (insert, update, remove, table creation/deletion) MUST be buffered and NOT written to the storage backend.
- **FR-005**: On successful exit from a transaction context, the complete logical database state MUST be written to storage exactly once.
- **FR-006**: On any exception (including `BaseException` subclasses) during a transaction, the transaction MUST roll back with zero storage writes, and the exception MUST propagate outward.
- **FR-007**: On rollback, all changes including nested mutable values modified through callable updates, table creation/deletion, and query cache results MUST be restored to their pre-transaction state.
- **FR-008**: After commit or rollback, existing table handles MUST be able to insert documents without ID collisions with rolled-back IDs.
- **FR-009**: Nesting `transaction()` calls MUST raise `RuntimeError` before changing the parent transaction state; catching the error MUST leave the parent transaction usable.
- **FR-010**: A committed `JSONStorage` database MUST survive close/reopen with the committed data intact; rollback MUST leave the persisted state unchanged.
- **FR-011**: The existing upstream TinyDB test suite MUST continue to pass without modification.

### Key Entities

- **TransactionalTinyDB**: A subclass of `TinyDB` that adds transactional semantics via a context manager. Shares the same API surface as `TinyDB`.
- **Transaction Context**: A context manager (`with db.transaction()`) that buffers mutations in memory and commits or rolls back on exit.
- **Buffered State**: An in-memory snapshot of the database state taken at transaction start, used for rollback.
- **Storage Backend**: The underlying storage mechanism (`MemoryStorage` or `JSONStorage`) that is only written to on transaction commit.

## Success Criteria

### Measurable Outcomes

- **SC-001**: All 8 explicit requirements (R01-R08) have passing automated tests with 100% coverage of transaction commit and rollback paths.
- **SC-002**: The existing upstream TinyDB test suite (all test files in `tests/`) passes without modification.
- **SC-003**: A committed transaction writes to storage exactly once regardless of the number of mutations performed.
- **SC-004**: A rolled-back transaction performs zero writes to the storage backend.
- **SC-005**: Committed data in `JSONStorage` survives database close/reopen with 100% fidelity.
- **SC-006**: Nested transaction attempts raise `RuntimeError` in 100% of cases without corrupting the parent transaction.

## Assumptions

- The database is single-instance and single-threaded; no concurrent-writer safety is required.
- Only `MemoryStorage` and `JSONStorage` backends are supported in the initial release.
- Power-loss durability is not promised; if the process crashes during a transaction, the database state is whatever was last committed.
- Rollback after arbitrary partial backend write failure is not promised; if the storage write partially succeeds, the database may be in an inconsistent state.
- Document IDs consumed during a rolled-back transaction do not need to be reused; new inserts may get new IDs.
- Query caches are cleared on rollback to prevent stale data from being returned.
- The `TransactionalTinyDB` class is imported as `from tinydb import TransactionalTinyDB`.
- The existing TinyDB API (including `where` queries, table management, and all mutation methods) works identically within a transaction.
