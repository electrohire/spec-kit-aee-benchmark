# Implementation Plan: Opt-in Transactions for TinyDB

**Branch**: `001-transactions` | **Date**: 2026-09-17 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-transactions/spec.md`

## Summary

Add `TransactionalTinyDB` as a subclass of `TinyDB` that provides single-instance, single-thread transactional semantics via a `transaction()` context manager. The implementation intercepts storage writes during a transaction, buffers changes in memory, and writes the complete database state exactly once on commit. On rollback (any exception), all changes are discarded and the pre-transaction state is restored. Nesting transactions raises `RuntimeError` in this release.

## Technical Context

**Language/Version**: Python 3.10+ (TinyDB's `requires-python` constraint)

**Primary Dependencies**: None beyond TinyDB's existing dependencies. `TransactionalTinyDB` is implemented entirely within the `tinydb` package.

**Storage**: MemoryStorage (in-memory dict) and JSONStorage (JSON file on disk). Both are supported by the existing TinyDB codebase.

**Testing**: pytest (existing test infrastructure). Tests run with `python -m pytest -c /dev/null tests acceptance_public.py`.

**Target Platform**: Any OS where Python 3.10+ runs (Linux, macOS, Windows). No platform-specific code.

**Project Type**: Library (Python package). `TransactionalTinyDB` is a new module added to the `tinydb` package.

**Performance Goals**: No specific performance targets. The transaction should add minimal overhead beyond the buffering cost.

**Constraints**: Single-instance, single-thread only. No concurrent-writer safety, no power-loss durability, no rollback after partial backend write failure.

**Scale/Scope**: Single database instance. The feature adds ~200-300 lines of Python code to the `tinydb` package.

## Constitution Check

### Gate: Must pass before Phase 0 research. Re-check after Phase 1 design.

| Principle | Compliance | Notes |
|-----------|-----------|-------|
| I. Preserve Existing Public API Behavior | ✅ Compliant | `TransactionalTinyDB` is a subclass; existing `TinyDB` class is unchanged. All existing operations work identically. |
| II. Attach Testable Acceptance Criteria to Requirements | ✅ Compliant | All 8 requirements (R01-R08) have explicit acceptance scenarios in the spec. Tests exist in `acceptance_public.py`. |
| III. Distinguish Observed Evidence from Unverified Assertions | ✅ Compliant | All assertions in the spec are testable. Assumptions are documented in the spec's Assumptions section. |
| IV. Prefer Simple Scoped Implementations | ✅ Compliant | Single-instance, single-thread only. No over-engineering. Uses in-memory buffering (simple dict copy). |
| V. Document Unresolved Assumptions and Regressions | ✅ Compliant | 8 assumptions documented. No regressions expected; upstream tests must pass. |

**Gate Result**: PASS — No violations. Proceed to Phase 0.

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output ($speckit-plan command)
├── data-model.md        # Phase 1 output ($speckit-plan command)
├── quickstart.md        # Phase 1 output ($speckit-plan command)
├── contracts/           # Phase 1 output ($speckit-plan command)
│   └── transactional-api.md
└── checklists/
    └── requirements.md
```

### Source Code (repository root)

```text
tinydb/
├── __init__.py          # Add TransactionalTinyDB to exports
├── database.py          # TinyDB class (unchanged)
├── transactional.py     # NEW: TransactionalTinyDB class + TransactionContext
├── storages.py          # Storage base class (unchanged)
├── table.py             # Table class (unchanged)
├── queries.py           # Query class (unchanged)
└── ...

tests/
├── test_transactions.py # NEW: Focused transaction tests
├── test_tinydb.py       # Existing (unchanged)
├── test_operations.py   # Existing (unchanged)
└── ...

acceptance_public.py     # Existing acceptance tests (unchanged)
```

**Structure Decision**: Add a new `transactional.py` module in the `tinydb` package. This follows TinyDB's existing pattern of one module per major component (e.g., `database.py`, `table.py`, `storages.py`). The `TransactionalTinyDB` class is a subclass of `TinyDB` in `transactional.py`, imported into `__init__.py`.

## Complexity Tracking

> No constitution violations to justify. This section is left empty.

## Phase 0: Research

### Research Tasks

1. **TinyDB storage interception pattern**: How to intercept `_storage.write()` calls without modifying the upstream `Table._update_table` method.
2. **Deep copy strategy**: How to efficiently snapshot the database state for rollback (shallow vs deep copy of the storage data).
3. **Query cache management**: How to handle query cache invalidation during and after transactions.
4. **ID counter state**: How to preserve document ID counter state across transactions.

### Research Findings

See `research.md` for detailed findings.

## Phase 1: Design & Contracts

### Data Model

See `data-model.md` for entity relationships and state transitions.

### Contracts

See `contracts/transactional-api.md` for the public API contract.

### Quickstart

See `quickstart.md` for runnable validation scenarios.

## Implementation Tasks (Summary)

1. Create `tinydb/transactional.py` with `TransactionalTinyDB` class and `TransactionContext` context manager.
2. Add `TransactionalTinyDB` to `tinydb/__init__.py` exports.
3. Create `tests/test_transactions.py` with focused transaction tests.
4. Verify all upstream tests pass: `python -m pytest -c /dev/null tests acceptance_public.py`.
5. Verify acceptance tests pass: `acceptance_public.py`.

## Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| Deep copy performance on large databases | Moderate | Use `copy.deepcopy` only on transaction start; profile if needed |
| Query cache stale data after rollback | High | Clear all query caches on rollback |
| Nested mutable value corruption | High | Deep copy table data before transaction; restore on rollback |
| Breaking upstream tests | High | Run upstream tests before and after; no modifications to upstream code |
