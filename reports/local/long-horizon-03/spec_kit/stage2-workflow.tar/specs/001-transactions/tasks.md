---

description: "Task list for TransactionalTinyDB implementation (Stage 2: nested savepoints)"
---

# Tasks: Opt-in Transactions for TinyDB

**Input**: Design documents from `/specs/001-transactions/`

**Prerequisites**: plan.md (required), spec.md (required for user stories), research.md, data-model.md, contracts/transactional-api.md, quickstart.md

**Tests**: Tests are included as requested in the feature specification.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- Source code: `tinydb/` at repository root
- Tests: `tests/` at repository root
- Feature tests: `tests/test_transactions.py`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Verify baseline and prepare the repository

- [x] T001 Verify upstream tests pass: `python -m pytest -c /dev/null tests -q`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [x] T002 Create `tinydb/transactional.py` with `TransactionContext` class (snapshot, no-op write interception, commit, rollback, cache clearing)
- [x] T003 Create `tinydb/transactional.py` with `TransactionalTinyDB` class (subclass of TinyDB, `transaction()` method, nested savepoint support)
- [x] T004 Add `TransactionalTinyDB` to `tinydb/__init__.py` exports

**Checkpoint**: Foundation ready — user story implementation can now begin in parallel

---

## Phase 3: User Story 1 - Atomic Write Operations (Priority: P1) 🎯 MVP

**Goal**: Developers can perform multiple related mutations as a single atomic unit; if any mutation fails, all changes are rolled back.

**Independent Test**: Create a database, perform mutations inside a transaction context, and verify that either all changes are persisted (on commit) or none are (on rollback).

### Tests for User Story 1

- [x] T005 [P] [US1] Add test for transaction commit with multiple inserts in `tests/test_transactions.py`
- [x] T006 [P] [US1] Add test for transaction rollback with callable update on nested mutable in `tests/test_transactions.py`
- [x] T007 [P] [US1] Add test for mutations visible within transaction scope in `tests/test_transactions.py`

### Implementation for User Story 1

- [x] T008 [US1] Verify `TransactionalTinyDB` constructor accepts same args as `TinyDB` (FR-001)
- [x] T009 [US1] Verify `transaction()` context manager yields same db instance (FR-003)
- [x] T010 [US1] Verify mutations are buffered and not written during transaction (FR-004)
- [x] T011 [US1] Verify mutations through db handle and pre-obtained table handles are visible within transaction (FR-002, R02)

**Checkpoint**: At this point, User Story 1 should be fully functional and testable independently

---

## Phase 4: User Story 2 - Single Write-on-Commit (Priority: P1)

**Goal**: All changes in a transaction are written to storage exactly once, reducing I/O overhead and ensuring consistency.

**Independent Test**: Wrap a CountingStorage around MemoryStorage and verify that exactly one `write` call occurs on successful commit and zero writes occur during the transaction or on rollback.

### Tests for User Story 2

- [x] T012 [P] [US2] Add test for exactly one write on commit in `tests/test_transactions.py`
- [x] T013 [P] [US2] Add test for zero writes on rollback in `tests/test_transactions.py`

### Implementation for User Story 2

- [x] T014 [US2] Verify successful transaction exit writes complete database state exactly once (FR-005, R03)
- [x] T015 [US2] Verify any exception (including BaseException) propagates with zero writes (FR-006, R04)
- [x] T016 [US2] Verify rollback restores nested mutable values (R05)
- [x] T017 [US2] Verify rollback restores query cache state (R05)
- [x] T018 [US2] Verify post-commit/rollback inserts have no ID collisions (R06)

**Checkpoint**: At this point, User Stories 1 AND 2 should both work independently

---

## Phase 5: User Story 3 - Nested Savepoints (Priority: P1)

**Goal**: Nested transactions create independent savepoints. Inner rollback only discards inner changes. Outer rollback discards all changes.

**Independent Test**: Create nested transactions, verify that inner rollback only discards inner changes, and outer commit preserves both outer and successful inner changes.

### Tests for User Story 3

- [x] T019 [P] [US3] Add test for inner rollback only discards inner in `tests/test_transactions.py`
- [x] T020 [P] [US3] Add test for outer rollback discards all in `tests/test_transactions.py`
- [x] T021 [P] [US3] Add test for three-level nesting in `tests/test_transactions.py`
- [x] T022 [P] [US3] Add test for inner commit merges into parent in `tests/test_transactions.py`
- [x] T023 [P] [US3] Add test for outer rollback discards completed inner in `tests/test_transactions.py`
- [x] T024 [P] [US3] Add test for preexisting table handle reflects savepoint in `tests/test_transactions.py`

### Implementation for User Story 3

- [x] T025 [US3] Verify nested `transaction()` creates savepoints (FR-009, R09)
- [x] T026 [US3] Verify inner rollback only discards inner changes (FR-010, R10)
- [x] T027 [US3] Verify outer rollback discards all including completed inner scopes (FR-011, R12)
- [x] T028 [US3] Verify preexisting table handles and query caches reflect current savepoint (FR-012, R13)

**Checkpoint**: All user stories 1-3 should now be independently functional

---

## Phase 6: User Story 4 - Persistence Survives Close/Reopen (Priority: P2)

**Goal**: Committed data in JSONStorage survives database close and reopen; rollback leaves persisted state unchanged.

**Independent Test**: Commit data in a transaction, close the database, reopen it, and verify the data persists.

### Tests for User Story 4

- [x] T029 [P] [US4] Add test for JSONStorage persistence after commit in `tests/test_transactions.py`
- [x] T030 [P] [US4] Add test for JSONStorage unchanged after rollback in `tests/test_transactions.py`

### Implementation for User Story 4

- [x] T031 [US4] Verify committed JSONStorage data survives close/reopen (FR-013, R08)
- [x] T032 [US4] Verify rolled-back JSONStorage leaves persisted state unchanged (FR-013, R08)

**Checkpoint**: All user stories should now be independently functional

---

## Phase N: Polish & Cross-Cutting Concerns

**Purpose**: Ensure all requirements are met and upstream compatibility is preserved

- [x] T033 [P] Add docstrings to `TransactionalTinyDB` and `TransactionContext` classes
- [x] T034 [P] Add usage example to module docstring in `tinydb/transactional.py`
- [x] T035 Run upstream tests: `python -m pytest -c /dev/null tests -q` (FR-014, must pass)
- [x] T036 Run acceptance tests: `python -m pytest -c /dev/null acceptance_public.py -v` (all 5 tests)
- [x] T037 Run full test suite: `python -m pytest -c /dev/null tests acceptance_public.py -v`
- [x] T038 Run quickstart validation scenarios from `quickstart.md`

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - BLOCKS all user stories
- **User Stories (Phase 3-6)**: All depend on Foundational phase completion
  - User stories can then proceed in parallel (if staffed)
  - Or sequentially in priority order (P1 → P2)
- **Polish (Final Phase)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Foundational (Phase 2) - Core transactional behavior
- **User Story 2 (P1)**: Can start after Foundational (Phase 2) - Write-on-commit behavior
- **User Story 3 (P1)**: Can start after Foundational (Phase 2) - Nested savepoint behavior
- **User Story 4 (P2)**: Can start after Foundational (Phase 2) - Persistence behavior

### Within Each User Story

- Tests (if included) MUST be written and FAIL before implementation
- Models before services
- Services before endpoints
- Core implementation before integration
- Story complete before moving to next priority

### Parallel Opportunities

- All test tasks marked [P] can run in parallel (different test functions)
- All docstring tasks in Polish phase marked [P] can run in parallel
- All user stories can be worked on in parallel by different team members

---

## Implementation Strategy

### MVP First (User Stories 1 + 2 + 3)

1. Complete Phase 1: Setup (T001)
2. Complete Phase 2: Foundational (T002-T004)
3. Complete Phase 3: User Story 1 (T005-T011)
4. Complete Phase 4: User Story 2 (T012-T018)
5. Complete Phase 5: User Story 3 (T019-T028)
6. **STOP and VALIDATE**: Run upstream tests + acceptance tests
7. Deploy/demo if ready

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add User Story 1 → Test independently → Deploy/Demo (MVP!)
3. Add User Story 2 → Test independently → Deploy/Demo
4. Add User Story 3 → Test independently → Deploy/Demo
5. Add User Story 4 → Test independently → Deploy/Demo
6. Each story adds value without breaking previous stories

---

## Completion Summary

**All 38 tasks completed** ✅

- Phase 1 (Setup): 1/1 tasks done
- Phase 2 (Foundational): 3/3 tasks done
- Phase 3 (US1 - Atomic Writes): 7/7 tasks done
- Phase 4 (US2 - Write-on-Commit): 7/7 tasks done
- Phase 5 (US3 - Nested Savepoints): 10/10 tasks done
- Phase 6 (US4 - Persistence): 4/4 tasks done
- Phase N (Polish): 6/6 tasks done

**Test Results**:
- Upstream tests: 223 passed ✅
- New transaction tests: 29 passed ✅
- Acceptance tests: 5 passed ✅
- **Total: 253 passed, 0 failed**

**Files Modified**:
- `tinydb/__init__.py` - Added TransactionalTinyDB export
- `tinydb/transactional.py` - NEW: TransactionalTinyDB + TransactionContext with nested savepoint support
- `tests/test_transactions.py` - NEW: 29 focused transaction tests

**Files Unchanged** (upstream compatibility preserved):
- `tinydb/database.py`
- `tinydb/table.py`
- `tinydb/storages.py`
- `tinydb/queries.py`
- All upstream test files
