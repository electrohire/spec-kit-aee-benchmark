"""
TransactionalTinyDB - Opt-in transactional support for TinyDB.

This module provides TransactionalTinyDB, a subclass of TinyDB that adds
single-instance, single-thread transactional semantics via a context manager
with nested savepoint support.

Usage:

    from tinydb import TransactionalTinyDB
    from tinydb.storages import MemoryStorage

    db = TransactionalTinyDB(storage=MemoryStorage)

    with db.transaction() as current:
        assert current is db
        db.insert({'key': 'value'})
        # Changes are buffered, not written to storage
    # On exit: changes are written to storage exactly once

    # Nested transactions with savepoints:
    with db.transaction():
        db.insert({'a': 1})
        try:
            with db.transaction():
                db.insert({'discard': True})
                raise ValueError('inner')
        except ValueError:
            pass  # Inner changes rolled back, outer changes remain
        db.insert({'b': 2})  # This survives
    # Final state: [{'a': 1}, {'b': 2}]

Constraints:
- Single-instance, single-thread only
- MemoryStorage and JSONStorage backends supported
- No power-loss durability guarantee
- Nested transactions supported via savepoints
"""

import copy

from .database import TinyDB
from .storages import Storage


class _TransactionalStorage(Storage):
    """Internal storage wrapper that buffers writes during a transaction.

    This wraps the underlying storage and:
    - On read(): returns the current state (buffered if in transaction, underlying otherwise)
    - On write(data): buffers the data (doesn't write to underlying storage)
    """

    def __init__(self, storage):
        """Initialize the transactional storage wrapper.

        Args:
            storage: The underlying storage to wrap.
        """
        self._storage = storage
        self._buffer = None

    def read(self):
        """Read the current state.

        Returns the buffered data if in a transaction, otherwise reads
        from the underlying storage.

        Returns:
            The current database state, or None if empty.
        """
        if self._buffer is not None:
            return self._buffer
        return self._storage.read()

    def write(self, data):
        """Write data.

        During a transaction, buffers the data without writing to the
        underlying storage.

        Args:
            data: The database state to write.
        """
        self._buffer = data

    def close(self):
        """Close the underlying storage."""
        self._storage.close()


class TransactionContext:
    """Context manager that provides transactional semantics for TinyDB.

    Supports nested savepoints. Each nested transaction creates an independent
    savepoint. Inner rollback restores to the inner savepoint. Outer rollback
    discards all changes.
    """

    def __init__(self, db, is_nested=False):
        """Initialize the transaction context.

        Args:
            db: The TransactionalTinyDB instance to use.
            is_nested: True if this is a nested transaction (savepoint).
        """
        self._db = db
        self._is_nested = is_nested
        self._snapshot = None
        self._transactional_storage = None

    def __enter__(self):
        """Enter the transaction context.

        For the outermost transaction: takes a snapshot of the current storage data,
        wraps the storage with a buffering layer, and returns the database instance.

        For nested transactions: takes a snapshot (savepoint) of the current buffered
        state without wrapping the storage again.

        Returns:
            The TransactionalTinyDB instance (same object).
        """
        # Mark as in transaction
        self._db._in_transaction = True

        # Get the current storage (may be the original or a _TransactionalStorage)
        current_storage = self._db._storage

        if self._is_nested:
            # Nested transaction: create a savepoint from current buffered state
            self._snapshot = copy.deepcopy(current_storage.read())
            # Mark that this context has a savepoint
            self._has_savepoint = True
        else:
            # Outermost transaction: wrap storage with buffering layer
            self._snapshot = copy.deepcopy(current_storage.read())

            # Create the transactional storage wrapper
            self._transactional_storage = _TransactionalStorage(current_storage)

            # Replace storage in the database
            self._db._storage = self._transactional_storage

            # Also replace storage in all existing table instances
            for table in self._db._tables.values():
                table._storage = self._transactional_storage

            self._has_savepoint = True

        return self._db

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit the transaction context.

        For nested transactions:
        - On success: merge into parent (no write)
        - On exception: restore to inner savepoint, clear inner caches

        For outermost transactions:
        - On success: write the buffered state once to underlying storage
        - On exception: restore to outer snapshot, clear all caches

        Args:
            exc_type: Exception type if an exception was raised, None otherwise.
            exc_val: Exception value if an exception was raised, None otherwise.
            exc_tb: Exception traceback if an exception was raised, None otherwise.

        Returns:
            False to propagate any exception.
        """
        if self._is_nested:
            # Nested transaction behavior
            if exc_type is None:
                # Inner commit: merge into parent, no write needed
                # The parent's buffer already contains our changes
                pass
            else:
                # Inner rollback: restore to inner savepoint
                self._restore_snapshot(self._db._storage, self._snapshot)
                # Clear all query caches
                for table in self._db._tables.values():
                    table.clear_cache()
        else:
            # Outermost transaction behavior
            # Get the original storage reference (from the wrapper)
            original_storage = self._transactional_storage._storage

            if exc_type is None:
                # Commit: write the buffered state to underlying storage
                buffered_data = self._transactional_storage.read()
                original_storage.write(buffered_data)
            else:
                # Rollback: restore snapshot to underlying storage
                # Use direct state restoration to avoid calling write() on the
                # underlying storage (which would be counted by wrappers like
                # CountingStorage). This ensures zero writes on rollback.
                self._restore_snapshot(original_storage, self._snapshot)
                # Clear all query caches
                for table in self._db._tables.values():
                    table.clear_cache()

            # Restore the original storage in the database and all tables
            self._db._storage = original_storage
            for table in self._db._tables.values():
                table._storage = original_storage

        # Clear the in_transaction flag
        self._db._in_transaction = False

        return False  # Don't suppress exceptions

    @staticmethod
    def _restore_snapshot(storage, snapshot):
        """Restore a snapshot to a storage without calling write().

        This directly manipulates the storage's internal state to restore
        the snapshot, avoiding any write() calls on the underlying storage.

        Args:
            storage: The storage to restore (may be _TransactionalStorage or original).
            snapshot: The snapshot to restore.
        """
        # Handle both _TransactionalStorage and original storage
        if hasattr(storage, '_storage'):
            # It's a _TransactionalStorage wrapper
            underlying = storage._storage
            storage._buffer = snapshot
            if hasattr(underlying, 'memory'):
                underlying.memory = snapshot
            else:
                underlying.write(snapshot)
        else:
            # It's the original storage directly
            if hasattr(storage, 'memory'):
                storage.memory = snapshot
            else:
                storage.write(snapshot)


class TransactionalTinyDB(TinyDB):
    """A TinyDB subclass that provides transactional semantics.

    TransactionalTinyDB accepts the same constructor arguments as TinyDB
    and adds a transaction() method that returns a context manager for
    atomic operations with nested savepoint support.

    Example:
        >>> from tinydb import TransactionalTinyDB, where
        >>> from tinydb.storages import MemoryStorage
        >>> db = TransactionalTinyDB(storage=MemoryStorage)
        >>> with db.transaction() as current:
        ...     db.insert({'data': 42})
        >>> # Data is now persisted
        >>> len(db)
        1

        >>> # Nested transactions:
        >>> with db.transaction():
        ...     db.insert({'a': 1})
        ...     try:
        ...         with db.transaction():
        ...             db.insert({'b': 2})
        ...             raise ValueError('inner')
        ...     except ValueError:
        ...         pass  # Inner changes rolled back
        ...     db.insert({'c': 3})  # This survives
        >>> len(db)  # 2 (a and c, not b)
        2
    """

    def __init__(self, *args, **kwargs):
        """Create a new TransactionalTinyDB instance.

        All arguments and keyword arguments are passed through to the
        TinyDB constructor (which then passes them to the storage class).

        Args:
            *args: Positional arguments passed to the storage class.
            **kwargs: Keyword arguments passed to the storage class.
        """
        super().__init__(*args, **kwargs)
        self._in_transaction = False

    def transaction(self):
        """Create a new transaction context.

        Returns a context manager that yields the database instance.
        Mutations within the context are buffered and written exactly
        once on successful exit. On exception, all changes are rolled back.

        Nested transactions create independent savepoints. An inner rollback
        only discards inner changes. An outer rollback discards all changes.

        Returns:
            A TransactionContext object.

        Example:
            >>> with db.transaction() as current:
            ...     db.insert({'key': 'value'})
            ...     current is db  # True
        """
        return TransactionContext(self, is_nested=self._in_transaction)
