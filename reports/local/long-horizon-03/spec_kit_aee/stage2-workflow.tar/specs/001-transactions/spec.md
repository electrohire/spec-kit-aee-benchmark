# Feature Specification: Opt-in Transactions for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2025-01-01

**Status**: Draft

**Input**: User description: "Extend TinyDB with TransactionalTinyDB providing opt-in transactional semantics for single-instance, single-thread use with MemoryStorage and JSONStorage."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Atomic Batch Operations (Priority: P1)

A developer needs to perform multiple related database mutations (inserts, updates, deletions) as a single atomic unit. If any operation fails, all changes are rolled back so the database remains in a consistent state. This is the core value proposition of transactions.

**Why this priority**: Without atomicity, partial failures leave the database in an inconsistent state. This is the primary reason developers need transactions.

**Independent Test**: Can be fully tested by creating a transaction, performing multiple inserts/updates, and verifying that a committed transaction writes all changes exactly once, while a rolled-back transaction writes nothing.

**Acceptance Scenarios**:

1. **Given** a database with some existing data, **When** a transaction inserts and updates multiple documents, **Then** on successful commit, all changes are visible and the backend received exactly one write.
2. **Given** a database with some existing data, **When** a transaction performs mutations and then raises an exception, **Then** no changes are persisted and the database state is unchanged.
3. **Given** a transaction context, **When** the developer accesses the database via `with db.transaction() as current:`, **Then** `current` is the same `db` instance and mutations through it are visible within the scope.

---

### User Story 2 - Table Management in Transactions (Priority: P2)

A developer needs to create or delete tables as part of a transactional operation. Table creation/deletion should participate in the transaction's commit or rollback semantics.

**Why this priority**: Table management is a common administrative operation that benefits from atomicity, especially when combined with data migration.

**Independent Test**: Can be tested by creating a table inside a transaction, committing it (table persists), or rolling back (table disappears).

**Acceptance Scenarios**:

1. **Given** an empty database, **When** a transaction creates a new table and inserts data, **Then** on commit the table and data persist.
2. **Given** an existing table, **When** a transaction deletes the table and then raises an exception, **Then** the table is restored after rollback.

---

### User Story 3 - Nested Mutable Value Rollback (Priority: P2)

A developer modifies nested mutable values (lists, dicts) within documents using callable updates. After a rollback, these nested modifications must be fully undone, not just the top-level document reference.

**Why this priority**: Python's mutable objects are passed by reference; without proper snapshotting, nested mutations leak across rollbacks.

**Independent Test**: Can be tested by inserting a document with a mutable nested value, using a callable update to mutate it inside a transaction, then verifying the nested value is restored after rollback.

**Acceptance Scenarios**:

1. **Given** a document with `{'nested': [1]}`, **When** a transaction calls `update(lambda doc: doc['nested'].append(2))` and then fails, **Then** the document's nested value remains `[1]`.
2. **Given** a transaction that modifies nested values, **When** the transaction succeeds, **Then** the nested mutations are committed.

---

### User Story 4 - Persistence Across Close/Reopen (Priority: P3)

A developer commits a transaction to a file-backed database, closes it, and reopens it later. The committed data must survive the close/reopen cycle.

**Why this priority**: This validates that the transaction commit correctly triggers the storage write, not just an in-memory update.

**Independent Test**: Can be tested by committing a transaction, closing the database, reopening it, and verifying the committed data is present.

**Acceptance Scenarios**:

1. **Given** a file-backed database, **When** a transaction is committed and the database is closed, **Then** reopening the database shows the committed data.
2. **Given** a file-backed database, **When** a transaction is rolled back, **Then** reopening the database shows the pre-transaction state.

---

### Edge Cases

- **Nested transactions**: Attempting to nest `transaction()` calls raises `RuntimeError` before altering the parent transaction; the parent remains usable after the exception is caught.
- **BaseException propagation**: Exception types other than `Exception` (e.g., `KeyboardInterrupt`, `SystemExit`) trigger rollback and do not corrupt the database state.
- **Query cache invalidation**: Query results cached before a transaction must not return data from discarded work after rollback.
- **ID collision avoidance**: After a rollback, subsequent inserts must not reuse document IDs that were consumed by the rolled-back transaction.
- **Multiple table mutations in one transaction**: A transaction that modifies multiple tables must write all tables atomically.

## Requirements *(mandatory)*

### Functional Requirements

#### Constructor and API Compatibility

- **FR-001**: `TransactionalTinyDB` MUST accept the same constructor arguments as `TinyDB` (storage class, path, and kwargs).
- **FR-002**: The existing `TinyDB` class and all non-transactional operations MUST continue to work normally with no behavioral changes.

#### Transaction Context

- **FR-003**: `with db.transaction() as current:` MUST yield the same `db` instance (i.e., `current is db`).
- **FR-004**: Mutations through `db` or any table handles obtained before entering the transaction MUST be visible within the transaction scope.

#### Commit Semantics

- **FR-005**: No backend storage write call MUST occur during a transaction.
- **FR-006**: A successful transaction commit MUST write the complete logical database exactly once via a single storage write call, even when multiple tables are modified.

#### Rollback Semantics

- **FR-007**: Any exception (including `BaseException` subclasses) propagating out of a transaction MUST trigger a full rollback with zero backend writes.
- **FR-008**: After a rolled-back transaction, a later transaction MUST continue to work normally.
- **FR-009**: Rollback MUST restore nested mutable values modified through callable updates (e.g., `update(lambda doc: doc['nested'].append(2))`).
- **FR-010**: Rollback MUST restore table creation and deletion operations.
- **FR-011**: Query caches MUST NOT return data from discarded work after rollback.

#### ID Safety

- **FR-012**: After commit or rollback, existing table handles MUST be able to insert new documents without ID collisions with IDs consumed by rolled-back work.

#### Nesting Restriction

- **FR-013**: Nesting `transaction()` calls MUST raise `RuntimeError` before altering the parent transaction state.
- **FR-014**: A caught `RuntimeError` from a nested transaction MUST leave the parent transaction usable.

#### Persistence

- **FR-015**: A committed file-backed database MUST survive close/reopen with all committed data intact.
- **FR-016**: A rolled-back transaction MUST leave the persisted state of a file-backed database unchanged.

### Key Entities

- **TransactionalTinyDB**: A subclass of `TinyDB` that adds transactional semantics via a context manager. Shares all public APIs with `TinyDB`.
- **Transaction context**: An atomic scope created by `db.transaction()` that buffers all mutations and commits or rolls back on exit.
- **Storage write buffer**: Internal state that accumulates the logical database state during a transaction, replaced on commit.
- **Document snapshots**: State captured before transaction entry to enable rollback of mutable values.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: All 16 functional requirements (FR-001 through FR-016) MUST have executable test cases that pass when run with the project's test runner.
- **SC-002**: The existing upstream test suite MUST continue to pass without modification, confirming backward compatibility.
- **SC-003**: A committed transaction to a file-backed storage MUST persist across database close and reopen, verifiable by reopening the same file and reading committed documents.
- **SC-004**: A rolled-back transaction MUST result in zero storage write calls being recorded, verifiable by instrumenting the storage backend.
- **SC-005**: Nested transaction calls MUST raise an error within 1ms of invocation, with the parent transaction remaining fully functional.

## Assumptions

- The database is single-instance and single-threaded; no concurrent-writer safety is provided.
- Only in-memory and file-based JSON storage are supported in v1; other storage backends (e.g., SQLite, Redis) are out of scope.
- Power-loss durability is not guaranteed; transactions are in-memory only until commit.
- Rollback after an arbitrary partial backend write failure is not promised; if the storage write fails mid-commit, the database may be corrupted.
- The transaction context manager does not support nesting in v1; nested calls raise an error.
- Query caches are invalidated on rollback; stale cache entries from discarded work will not be returned.
- The `TransactionalTinyDB` class is imported via `from tinydb import TransactionalTinyDB`.
