---

description: "Task list for opt-in transactions feature"
---

# Tasks: Opt-in Transactions for TinyDB

**Input**: Design documents from `/specs/001-transactions/`

**Prerequisites**: plan.md (required), spec.md (required for user stories)

**Tests**: Tests are REQUIRED - acceptance_public.py contains public test cases.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3, US4)
- Include exact file paths in descriptions

## Path Conventions

- **Single project**: `tinydb/` at repository root, `tests/` for test files
- **Tests**: `tests/test_transactions.py` for transaction-specific tests
- **Public acceptance**: `acceptance_public.py` for milestone acceptance tests

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Understand existing TinyDB architecture and prepare for extension

- [X] T001 Inspect TinyDB source structure: `tinydb/database.py`, `tinydb/table.py`, `tinydb/storages.py`
- [X] T002 [P] Verify existing TinyDB test suite passes: `python -m pytest -c /dev/null tests`
- [X] T003 [P] Review acceptance_public.py public test cases

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core TransactionalTinyDB class and transaction context manager

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T004 Create `TransactionalTinyDB` class in `tinydb/database.py` that subclasses `TinyDB`
- [X] T005 [P] Implement `transaction()` context manager method on `TransactionalTinyDB`
- [X] T006 [P] Implement document snapshotting mechanism for rollback (deep copy of mutable values)
- [X] T007 [P] Implement storage write buffering (no writes during transaction, single write on commit)
- [X] T008 [P] Implement query cache invalidation on rollback
- [X] T009 [P] Implement nesting detection that raises `RuntimeError` before altering parent state
- [X] T010 Add `TransactionalTinyDB` export to `tinydb/__init__.py`

**Checkpoint**: Foundation ready - `TransactionalTinyDB` class exists with basic transaction context manager

---

## Phase 3: User Story 1 - Atomic Batch Operations (Priority: P1) 🎯 MVP

**Goal**: Multiple database mutations execute as a single atomic unit; commit writes all changes exactly once, rollback writes nothing.

**Independent Test**: Create a transaction, perform multiple inserts/updates, verify committed transaction writes all changes exactly once, rolled-back transaction writes nothing.

### Tests for User Story 1

- [X] T011 [P] [US1] Test commit writes exactly once in `tests/test_transactions.py`
- [X] T012 [P] [US1] Test rollback writes zero times in `tests/test_transactions.py`
- [X] T013 [P] [US1] Test `current is db` in transaction context in `tests/test_transactions.py`

### Implementation for User Story 1

- [X] T014 [US1] Implement `__enter__` and `__exit__` for transaction context manager in `tinydb/database.py`
- [X] T015 [US1] Implement mutation visibility within transaction scope in `tinydb/database.py`
- [X] T016 [US1] Implement single storage.write on successful commit in `tinydb/database.py`
- [X] T017 [US1] Implement rollback on exception with zero writes in `tinydb/database.py`

**Checkpoint**: User Story 1 fully functional - atomic batch operations work correctly

---

## Phase 4: User Story 2 - Table Management in Transactions (Priority: P2)

**Goal**: Table creation and deletion participate in transaction commit/rollback semantics.

**Independent Test**: Create a table inside a transaction, commit it (table persists), or roll back (table disappears).

### Tests for User Story 2

- [X] T018 [P] [US2] Test table creation persists on commit in `tests/test_transactions.py`
- [X] T019 [P] [US2] Test table deletion rolls back in `tests/test_transactions.py`

### Implementation for User Story 2

- [X] T020 [US2] Capture table state (created/deleted tables) on transaction entry in `tinydb/database.py`
- [X] T021 [US2] Apply table creation/deletion to buffer during transaction in `tinydb/database.py`
- [X] T022 [US2] Restore table state on rollback in `tinydb/database.py`

**Checkpoint**: User Stories 1 AND 2 both work independently - table management is transactional

---

## Phase 5: User Story 3 - Nested Mutable Value Rollback (Priority: P2)

**Goal**: Nested mutable values (lists, dicts) modified through callable updates are fully restored on rollback.

**Independent Test**: Insert a document with a mutable nested value, use callable update to mutate it inside a transaction, verify nested value is restored after rollback.

### Tests for User Story 3

- [X] T023 [P] [US3] Test nested mutable value rollback in `tests/test_transactions.py`
- [X] T024 [P] [US3] Test callable update rollback in `tests/test_transactions.py`

### Implementation for User Story 3

- [X] T025 [US3] Implement deep copy snapshot of mutable documents on transaction entry in `tinydb/database.py`
- [X] T026 [US3] Apply snapshot restoration on rollback in `tinydb/database.py`
- [X] T027 [US3] Ensure query caches don't return discarded work data in `tinydb/database.py`

**Checkpoint**: User Stories 1, 2, AND 3 all work independently - nested mutable rollback is correct

---

## Phase 6: User Story 4 - Persistence Across Close/Reopen (Priority: P3)

**Goal**: Committed data survives database close/reopen; rolled-back data does not persist.

**Independent Test**: Commit a transaction, close database, reopen, verify committed data is present.

### Tests for User Story 4

- [X] T028 [P] [US4] Test committed data survives close/reopen in `tests/test_transactions.py`
- [X] T029 [P] [US4] Test rolled-back data does not persist after close/reopen in `tests/test_transactions.py`

### Implementation for User Story 4

- [X] T030 [US4] Verify storage.write is called on commit for JSONStorage in `tinydb/database.py`
- [X] T031 [US4] Verify storage.write is NOT called on rollback in `tinydb/database.py`

**Checkpoint**: All user stories independently functional - persistence across close/reopen verified

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Final verification, documentation, and upstream test compatibility

- [X] T032 [P] Run full upstream TinyDB test suite: `python -m pytest -c /dev/null tests` - verify all pass
- [X] T033 [P] Run public acceptance tests: `python -m pytest -c /dev/null acceptance_public.py` - verify all pass
- [X] T034 [US1] Test BaseException propagation (KeyboardInterrupt, SystemExit) triggers rollback in `tests/test_transactions.py`
- [X] T035 [US3] Test query cache invalidation after rollback in `tests/test_transactions.py`
- [X] T036 [US4] Test ID collision avoidance after rollback in `tests/test_transactions.py`
- [X] T037 [US4] Test multiple table mutations in one transaction write atomically in `tests/test_transactions.py`
- [X] T038 Update `tinydb/__init__.py` `__all__` to include `TransactionalTinyDB`
- [X] T039 [P] Add usage documentation for `TransactionalTinyDB` in `docs/` or docstrings

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - BLOCKS all user stories
- **User Stories (Phase 3+)**: All depend on Foundational phase completion
  - User stories can proceed in parallel (if staffed)
  - Or sequentially in priority order (P1 → P2 → P3)
- **Polish (Phase 7)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Foundational (Phase 2) - No dependencies on other stories
- **User Story 2 (P2)**: Can start after Foundational (Phase 2) - Depends on US1 foundational work
- **User Story 3 (P2)**: Can start after Foundational (Phase 2) - Depends on US1 foundational work
- **User Story 4 (P3)**: Can start after Foundational (Phase 2) - Depends on US1 foundational work

### Within Each User Story

- Tests MUST be written and FAIL before implementation
- Implementation before integration
- Story complete before moving to next priority

### Parallel Opportunities

- All Setup tasks marked [P] can run in parallel
- All Foundational tasks marked [P] can run in parallel (within Phase 2)
- Once Foundational phase completes, all user stories can start in parallel (if team capacity allows)
- All tests for a user story marked [P] can run in parallel

---

## Parallel Example: Foundational Phase

```bash
# Launch all foundational tasks together:
Task: "Create TransactionalTinyDB class in tinydb/database.py"
Task: "Implement transaction() context manager in tinydb/database.py"
Task: "Implement document snapshotting for rollback in tinydb/database.py"
Task: "Implement storage write buffering in tinydb/database.py"
Task: "Implement query cache invalidation on rollback in tinydb/database.py"
Task: "Implement nesting detection in tinydb/database.py"
Task: "Add TransactionalTinyDB export to tinydb/__init__.py"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL - blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: Run `python -m pytest -c /dev/null acceptance_public.py`
5. Deploy/demo if ready

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add User Story 1 → Test independently → Deploy/Demo (MVP!)
3. Add User Story 2 → Test independently → Deploy/Demo
4. Add User Story 3 → Test independently → Deploy/Demo
5. Add User Story 4 → Test independently → Deploy/Demo
6. Each story adds value without breaking previous stories

### Parallel Team Strategy

With multiple developers:

1. Team completes Setup + Foundational together
2. Once Foundational is done:
   - Developer A: User Story 1
   - Developer B: User Story 2
   - Developer C: User Story 3
   - Developer D: User Story 4
3. Stories complete and integrate independently

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Each user story should be independently completable and testable
- Verify tests fail before implementing
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- Avoid: vague tasks, same file conflicts, cross-story dependencies that break independence
- **Critical**: Do NOT modify upstream tests - all changes must be additive
