# Implementation Plan: Opt-in Transactions for TinyDB

**Feature**: specs/001-transactions/spec.md
**Branch**: 001-transactions
**Created**: 2025-01-01
**Status**: Draft

## Technical Context

- **Language**: Python 3.8+
- **Framework**: TinyDB 4.x (existing)
- **Storage**: MemoryStorage, JSONStorage (v1 only)
- **Concurrency**: Single-instance, single-thread only

## Architecture

TransactionalTinyDB extends TinyDB with a context manager that:
1. Buffers mutations in memory during transaction
2. Commits all changes via single storage.write on success
3. Rolls back to pre-transaction state on any exception

## Implementation Tasks

1. Create `TransactionalTinyDB` class in `tinydb/database.py`
2. Implement `transaction()` context manager method
3. Add document snapshotting for rollback
4. Add query cache invalidation on rollback
5. Add nesting detection (RuntimeError)
6. Add tests for all requirements

## Constitution Compliance

- Principle I: Additive only, no existing API changes
- Principle II: All FRs have testable acceptance criteria
- Principle III: Evidence distinguished from assertions
- Principle IV: Single-instance, single-thread, MemoryStorage/JSONStorage only
- Principle V: Limitations documented

## Risks

- Nested mutable value rollback requires deep copying
- Query cache invalidation must cover all cache paths
- ID collision avoidance requires careful ID management
