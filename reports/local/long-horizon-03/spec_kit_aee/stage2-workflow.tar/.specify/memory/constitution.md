# TinyDB Transactions Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
All existing TinyDB public APIs MUST remain functionally unchanged. The introduction of `TransactionalTinyDB` MUST be additive only — it extends functionality without modifying or removing any existing behavior of `TinyDB`, its tables, queries, storages, or utilities. Non-transactional code paths MUST behave identically to pre-feature TinyDB. This ensures backward compatibility and zero disruption to existing users.

### II. Attach Testable Acceptance Criteria to Requirements
Every requirement MUST have explicit, testable acceptance criteria. Requirements without verifiable tests are unverified assertions and MUST be treated as such. Each criterion MUST be expressible as a concrete test case that can be executed with `python -m pytest -c /dev/null tests acceptance_public.py`. This ensures that compliance is objectively measurable, not merely claimed.

### III. Distinguish Observed Evidence from Unverified Assertions
Implementation notes, design decisions, and test results MUST clearly separate what was empirically observed (e.g., "storage.write was called exactly once") from what is asserted without proof (e.g., "rollback works correctly"). Unverified claims MUST be documented as assumptions with explicit risk notes. This prevents false confidence in untested behavior.

### IV. Prefer Simple Scoped Implementations
Feature implementations MUST be scoped to the minimum necessary surface area. For this release, transactions are single-instance, single-thread, supporting only `MemoryStorage` and `JSONStorage`. No concurrent-writer safety, power-loss durability, or rollback after arbitrary partial backend write failure is promised. Simplicity reduces defect risk and aids verification.

### V. Document Unresolved Assumptions and Regressions
All known limitations, assumptions, and potential regressions MUST be explicitly documented alongside the feature. This includes scope boundaries (e.g., no nested transaction support in v1), unsupported storage backends, and edge cases not yet verified. Documentation MUST be accessible to reviewers and maintainers to prevent hidden debt.

## Feature Scope and Constraints

The `TransactionalTinyDB` class provides opt-in transactional semantics over TinyDB:

- **Constructor parity**: Accepts the same arguments as `TinyDB`.
- **Context manager**: `with db.transaction() as current:` yields the same `db` instance.
- **Atomic commit**: A successful commit writes the entire logical database exactly once via a single `storage.write` call.
- **Rollback on failure**: Any exception (including `BaseException` subclasses) triggers full rollback with zero backend writes.
- **Cache invalidation**: Query caches MUST NOT return data from discarded work.
- **ID handle safety**: Post-commit/rollback inserts MUST not collide with IDs consumed by rolled-back work.
- **Nesting restriction**: Nested `transaction()` calls raise `RuntimeError` before altering parent state.
- **Persistence guarantee**: Committed state survives close/reopen for `JSONStorage`; rollback leaves persisted state unchanged.

These constraints define the boundary of the v1 release. Extensions beyond this scope require a new constitution amendment.

## Governance

This constitution supersedes all other development practices within the TinyDB Transactions feature scope. All PRs and reviews MUST verify compliance with these principles. Amendments require documentation of the change, rationale, and migration plan if applicable.

**Versioning policy**:
- MAJOR: Backward-incompatible principle removal or redefinition.
- MINOR: New principle or materially expanded guidance.
- PATCH: Clarifications, wording refinements, typo fixes.

**Compliance review**: Every feature PR MUST reference the relevant principle(s) and demonstrate compliance via tests or documented evidence.

**Version**: 1.0.0 | **Ratified**: 2025-01-01 | **Last Amended**: 2025-09-17
