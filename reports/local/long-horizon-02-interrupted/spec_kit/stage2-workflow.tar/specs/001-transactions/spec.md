# Feature Specification: Nested Savepoint Transactions for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-09-17

**Status**: Draft

**Input**: User description: "Extend this existing TinyDB repository with `from tinydb import TransactionalTinyDB`. Keep ordinary TinyDB behavior unchanged. This is a single-instance, single-thread feature for JSON-compatible document data, using MemoryStorage or JSONStorage. Stage 1 requirements R01-R06 and R08 are retained. Stage 2 replaces R07 (nesting rejection) with R09-R13 (nested savepoints support)."

## User Scenarios & Testing

### User Story 1 - Atomic Write with Automatic Commit (Priority: P1)

A developer wants to perform multiple database mutations (inserts, updates, table operations) as a single atomic unit. The changes should only be persisted if the entire block completes without exception. If the block succeeds, all changes are written to storage exactly once.

**Why this priority**: This is the core value proposition of transactions — ensuring data consistency across multiple operations. Without it, partial failures can leave the database in an inconsistent state.

**Independent Test**: Can be fully tested by opening a database, performing multiple inserts/updates inside a `with db.transaction()` block, and verifying that all changes are persisted after the block exits normally.

**Acceptance Scenarios**:

1. **Given** an empty database, **When** a transaction block inserts documents into multiple tables and exits normally, **Then** all changes are persisted to storage exactly once.
2. **Given** a database with existing data, **When** a transaction block updates existing documents and inserts new ones and exits normally, **Then** all mutations are visible and storage contains the complete updated state.
3. **Given** a transaction block is entered, **When** the block is executing, **Then** no backend storage.write call has occurred.

---

### User Story 2 - Automatic Rollback on Exception (Priority: P1)

A developer performs a series of mutations inside a transaction block, but an exception occurs partway through. The developer expects all changes made during the transaction to be discarded, and the database to return to its pre-transaction state. A later transaction should still work normally.

**Why this priority**: Rollback is essential for data integrity — without it, partial failures leave the database in an inconsistent state and the developer has no recovery mechanism.

**Independent Test**: Can be fully tested by inserting a document, entering a transaction that modifies data and raises an exception, then verifying the original data is restored and no backend writes occurred.

**Acceptance Scenarios**:

1. **Given** a database with existing data, **When** a transaction modifies data and raises an exception, **Then** all modifications are discarded, no backend writes occurred, and the original data is fully restored.
2. **Given** a transaction rolled back due to exception, **When** a new transaction is opened, **Then** it operates normally and can insert documents without ID collisions with the rolled-back work.
3. **Given** a transaction block, **When** a `BaseException` subclass is raised inside it, **Then** the exception propagates out and the transaction rolls back with zero backend writes.

---

### User Story 3 - Nested Transactions with Savepoints (Priority: P1)

A developer wants to use nested transaction blocks to provide fine-grained error handling. Inner transactions create independent savepoints. A successful inner transaction merges into its parent without writing to the backend. A failed inner transaction rolls back only its own changes, leaving the outer transaction intact and able to continue or commit.

**Why this priority**: Nested transactions enable structured error handling at multiple levels of business logic, allowing partial failures to be recovered without discarding all work.

**Independent Test**: Can be fully tested by entering an outer transaction, inserting data, entering an inner transaction that raises an exception, catching it, inserting more data in the outer scope, and verifying the outer commit persists only the outer data.

**Acceptance Scenarios**:

1. **Given** an outer transaction is active, **When** an inner `db.transaction()` is entered, **Then** a new savepoint is created and yields the same db instance.
2. **Given** a successful inner transaction, **When** the inner scope exits normally, **Then** its changes are merged into the parent savepoint without writing to the backend.
3. **Given** a failed inner transaction, **When** the inner scope exits with an exception, **Then** only the inner changes are rolled back and the outer transaction continues.
4. **Given** an outer transaction that fails, **When** the outer scope exits with an exception, **Then** all inner scopes are discarded and zero backend writes occur.
5. **Given** three levels of nested transactions, **When** the innermost scope fails, **Then** only the innermost changes are rolled back.

---

### User Story 4 - Persistence Across Close/Reopen (Priority: P2)

A developer commits changes inside a transaction using JSONStorage, closes the database, and reopens it. The committed changes should be visible after reopen. Changes that were rolled back should not appear.

**Why this priority**: Ensures durability of committed transactions across application restarts, which is critical for any database feature.

**Independent Test**: Can be fully tested by committing a transaction, closing the database, reopening it, and verifying committed data persists while rolled-back data does not.

**Acceptance Scenarios**:

1. **Given** a JSONStorage database with committed transaction data, **When** the database is closed and reopened, **Then** the committed data is present.
2. **Given** a JSONStorage database with rolled-back transaction data, **When** the database is closed and reopened, **Then** the rolled-back data is absent and the persisted state is unchanged.

---

### Edge Cases

- What happens when a transaction modifies mutable nested values (e.g., lists inside documents)? Rollback must restore the original nested values.
- What happens when a table is created and deleted within a transaction? Rollback must restore the table state.
- What happens when query caches contain data modified inside a transaction? Rollback must clear cached results from discarded work.
- What happens when `BaseException` (e.g., `KeyboardInterrupt`) is raised inside a transaction? The transaction must still roll back.
- What happens when an outer transaction fails after an inner transaction has already committed? All inner changes are discarded.
- What happens when nested savepoints are used for three or more levels? Each savepoint must be independently rollbackable.
- What happens when ID counters are consumed inside a rolled-back inner scope? The next insert must not collide with IDs from the rolled-back scope.

## Requirements

### Functional Requirements

- **FR-001**: System MUST provide a `TransactionalTinyDB` class exported from the `tinydb` package that accepts the same constructor arguments as `TinyDB`.
- **FR-002**: System MUST support `with db.transaction() as current:` context manager that yields the same `db` instance.
- **FR-003**: System MUST make mutations visible within the transaction block through the same `db` or table handles obtained before entry.
- **FR-004**: System MUST NOT call backend `storage.write` during any transaction. On successful outermost exit, the complete logical database must be written exactly once.
- **FR-005**: System MUST roll back all changes and produce zero backend writes when any exception (including `BaseException` subclasses) propagates out of the transaction block.
- **FR-006**: System MUST restore nested mutable values changed through callable updates, table creation/deletion, and preexisting table-handle query results on rollback. Query caches must not return data from discarded work.
- **FR-007**: System MUST allow existing table handles to insert documents without ID collisions after commit or rollback. Exact reuse of IDs consumed by rolled-back work is not required.
- **FR-008**: System MUST persist committed data across database close/reopen for `JSONStorage`. Rollback must leave the persisted state unchanged.
- **FR-009**: System MUST NOT alter the behavior of existing `TinyDB` code paths. The existing upstream test suite MUST continue to pass.
- **FR-010**: System MUST support nested `transaction()` contexts that create independent savepoints, including at least three levels. Each context yields the same db.
- **FR-011**: System MUST merge successful inner transaction exits into the parent savepoint without writing to the backend. Only the outermost successful exit writes storage.
- **FR-012**: System MUST roll back only the changes of a failed inner scope. If the exception is caught inside the outer scope, earlier outer work remains and later outer work can still commit.
- **FR-013**: System MUST discard even successfully completed inner scopes when an outer scope fails. No backend writes occur on outer failure.
- **FR-014**: System MUST make preexisting table handles and warmed query caches reflect the current active savepoint after inner rollback. Subsequent inserts must not collide with live IDs.

### Key Entities

- **TransactionalTinyDB**: A subclass or thin wrapper of `TinyDB` that adds transaction support. Shares the same constructor signature and non-transactional API surface.
- **Transaction Context**: A per-database state flag indicating whether a transaction is active. Tracks a stack of savepoints for nested transactions.
- **Savepoint**: A snapshot of the database state captured at `__enter__` of a transaction scope. Used as the rollback target for that scope. Inner savepoints are independent of outer ones.
- **Savepoint Stack**: A LIFO stack of savepoints. The outermost savepoint is the base; each nested transaction pushes a new savepoint. On exit, the topmost savepoint is either merged (commit) or discarded (rollback).
- **Write Buffer**: An in-memory representation of changes made during the transaction. On commit of the outermost scope, the buffer is merged into the savepoint and the savepoint is written to storage; on rollback, the buffer is discarded.

## Success Criteria

### Measurable Outcomes

- **SC-001**: Zero backend storage writes occur during any active transaction scope.
- **SC-002**: After a successful transaction, exactly one storage write occurs containing all changes from the transaction.
- **SC-003**: After a rolled-back transaction, the database state is identical to the state before the transaction began.
- **SC-004**: Nested transaction savepoints support at least three levels of nesting.
- **SC-005**: A failed inner transaction rolls back only its own changes without affecting outer work.
- **SC-006**: A failed outer transaction discards all inner changes and writes nothing.
- **SC-007**: A committed database survives close/reopen with all committed data intact.
- **SC-008**: The existing upstream TinyDB test suite passes 100% after the feature is added.
- **SC-009**: Existing non-transactional TinyDB code continues to function identically.
- **SC-010**: After any commit or rollback, subsequent inserts do not produce ID collisions with documents from rolled-back scopes.

## Assumptions

- The feature is single-instance and single-threaded; no concurrent-writer safety is provided.
- Only `MemoryStorage` and `JSONStorage` are supported as backends.
- Deep copy of the storage snapshot at each savepoint entry is used for rollback (sufficient for JSON-compatible data).
- Nested transactions use independent savepoints rather than true database-level savepoints.
- Rollback does not guarantee recovery from partial backend write failures (e.g., disk full mid-write).
- Power-loss durability is not guaranteed; committed data survives only normal close/reopen.
- The `TransactionalTinyDB` class is a drop-in replacement for `TinyDB` that adds transaction support without changing existing behavior.
- ID counters are monotonic and never reused; rolled-back IDs are simply skipped.
