# Feature Specification: Opt-in Transactions for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-09-17

**Status**: Draft

**Input**: User description: "Extend this existing TinyDB repository with `from tinydb import TransactionalTinyDB`. Keep ordinary TinyDB behavior unchanged. This is a single-instance, single-thread feature for JSON-compatible document data, using MemoryStorage or JSONStorage."

## User Scenarios & Testing

### User Story 1 - Atomic Write with Automatic Commit (Priority: P1)

A developer wants to perform multiple database mutations (inserts, updates, table operations) as a single atomic unit. The changes should only be persisted if the entire block completes without exception. If the block succeeds, all changes are written to storage exactly once.

**Why this priority**: This is the core value proposition of transactions — ensuring data consistency across multiple operations. Without it, partial failures can leave the database in an inconsistent state.

**Independent Test**: Can be fully tested by opening a database, performing multiple inserts/updates inside a `with db.transaction()` block, and verifying that all changes are persisted after the block exits normally.

**Acceptance Scenarios**:

1. **Given** an empty database, **When** a transaction block inserts documents into multiple tables and exits normally, **Then** all changes are persisted to storage exactly once.
2. **Given** a database with existing data, **When** a transaction block updates existing documents and inserts new ones and exits normally, **Then** all mutations are visible and storage contains the complete updated state.
3. **Given** a transaction block is entered, **When** the block is executing, **Then** no backend storage.write call has occurred.

---

### User Story 2 - Automatic Rollback on Exception (Priority: P1)

A developer performs a series of mutations inside a transaction block, but an exception occurs partway through. The developer expects all changes made during the transaction to be discarded, and the database to return to its pre-transaction state. A later transaction should still work normally.

**Why this priority**: Rollback is essential for data integrity — without it, partial failures leave the database in an inconsistent state and the developer has no recovery mechanism.

**Independent Test**: Can be fully tested by inserting a document, entering a transaction that modifies data and raises an exception, then verifying the original data is restored and no backend writes occurred.

**Acceptance Scenarios**:

1. **Given** a database with existing data, **When** a transaction modifies data and raises an exception, **Then** all modifications are discarded, no backend writes occurred, and the original data is fully restored.
2. **Given** a transaction rolled back due to exception, **When** a new transaction is opened, **Then** it operates normally and can insert documents without ID collisions with the rolled-back work.
3. **Given** a transaction block, **When** a `BaseException` subclass is raised inside it, **Then** the exception propagates out and the transaction rolls back with zero backend writes.

---

### User Story 3 - Persistence Across Close/Reopen (Priority: P2)

A developer commits changes inside a transaction using JSONStorage, closes the database, and reopens it. The committed changes should be visible after reopen. Changes that were rolled back should not appear.

**Why this priority**: Ensures durability of committed transactions across application restarts, which is critical for any database feature.

**Independent Test**: Can be fully tested by committing a transaction, closing the database, reopening it, and verifying committed data persists while rolled-back data does not.

**Acceptance Scenarios**:

1. **Given** a JSONStorage database with committed transaction data, **When** the database is closed and reopened, **Then** the committed data is present.
2. **Given** a JSONStorage database with rolled-back transaction data, **When** the database is closed and reopened, **Then** the rolled-back data is absent and the persisted state is unchanged.

---

### User Story 4 - Nested Transaction Rejection (Priority: P3)

A developer accidentally attempts to nest transaction blocks. The system should raise a `RuntimeError` to prevent undefined behavior. The outer transaction should remain usable after the nesting error is caught.

**Why this priority**: Prevents subtle data corruption bugs from nested transactions while preserving the outer transaction's functionality.

**Independent Test**: Can be fully tested by entering a transaction, attempting to enter a nested transaction, verifying the RuntimeError is raised, and verifying the outer transaction continues to work.

**Acceptance Scenarios**:

1. **Given** an active transaction, **When** a nested `db.transaction()` is entered, **Then** a `RuntimeError` is raised.
2. **Given** a caught nesting error, **When** the outer transaction continues and exits normally, **Then** the outer transaction commits successfully.

---

### Edge Cases

- What happens when a transaction modifies mutable nested values (e.g., lists inside documents)? Rollback must restore the original nested values.
- What happens when a table is created and deleted within a transaction? Rollback must restore the table state.
- What happens when query caches contain data modified inside a transaction? Rollback must clear cached results from discarded work.
- What happens when `BaseException` (e.g., `KeyboardInterrupt`) is raised inside a transaction? The transaction must still roll back.

## Requirements

### Functional Requirements

- **FR-001**: System MUST provide a `TransactionalTinyDB` class exported from the `tinydb` package that accepts the same constructor arguments as `TinyDB`.
- **FR-002**: System MUST support `with db.transaction() as current:` context manager that yields the same `db` instance.
- **FR-003**: System MUST make mutations visible within the transaction block through the same `db` or table handles obtained before entry.
- **FR-004**: System MUST NOT call backend `storage.write` during any transaction. On successful exit, the complete logical database must be written exactly once.
- **FR-005**: System MUST roll back all changes and produce zero backend writes when any exception (including `BaseException` subclasses) propagates out of the transaction block.
- **FR-006**: System MUST restore nested mutable values changed through callable updates, table creation/deletion, and preexisting table-handle query results on rollback. Query caches must not return data from discarded work.
- **FR-007**: System MUST allow existing table handles to insert documents without ID collisions after commit or rollback. Exact reuse of IDs consumed by rolled-back work is not required.
- **FR-008**: System MUST raise `RuntimeError` when `transaction()` is called while another transaction is active (nesting rejection). The parent transaction must remain usable after the error is caught.
- **FR-009**: System MUST persist committed data across database close/reopen for `JSONStorage`. Rollback must leave the persisted state unchanged.
- **FR-010**: System MUST NOT alter the behavior of existing `TinyDB` code paths. The existing upstream test suite MUST continue to pass.

### Key Entities

- **TransactionalTinyDB**: A subclass or thin wrapper of `TinyDB` that adds transaction support. Shares the same constructor signature and non-transactional API surface.
- **Transaction Context**: A per-database state flag indicating whether a transaction is active. Tracks the snapshot of storage data taken at transaction entry for rollback.
- **Storage Snapshot**: A deep copy of the database state captured at `__enter__` of the transaction, used as the rollback target.
- **Write Buffer**: An in-memory representation of changes made during the transaction. On commit, the buffer is merged into the snapshot; on rollback, the buffer is discarded.

## Success Criteria

### Measurable Outcomes

- **SC-001**: Zero backend storage writes occur during any active transaction scope.
- **SC-002**: After a successful transaction, exactly one storage write occurs containing all changes from the transaction.
- **SC-003**: After a rolled-back transaction, the database state is identical to the state before the transaction began.
- **SC-004**: Nested transaction attempts raise `RuntimeError` in under 1ms.
- **SC-005**: A committed database survives close/reopen with all committed data intact.
- **SC-006**: The existing upstream TinyDB test suite passes 100% after the feature is added.
- **SC-007**: Existing non-transactional TinyDB code continues to function identically.

## Assumptions

- The feature is single-instance and single-threaded; no concurrent-writer safety is provided.
- Only `MemoryStorage` and `JSONStorage` are supported as backends.
- Deep copy of the storage snapshot at transaction entry is used for rollback (sufficient for JSON-compatible data).
- Transaction nesting is not supported in this initial release; nested calls raise `RuntimeError`.
- Rollback does not guarantee recovery from partial backend write failures (e.g., disk full mid-write).
- Power-loss durability is not guaranteed; committed data survives only normal close/reopen.
- The `TransactionalTinyDB` class is a drop-in replacement for `TinyDB` that adds transaction support without changing existing behavior.
