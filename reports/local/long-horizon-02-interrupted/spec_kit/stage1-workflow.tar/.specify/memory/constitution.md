# TinyDB Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
All existing TinyDB public APIs MUST remain unchanged. New features MUST be opt-in and MUST NOT alter the behavior of existing code paths. TransactionalTinyDB accepts the same constructor arguments as TinyDB and existing non-transactional operations and named/default tables work normally. The existing upstream test suite MUST continue to pass after any change.

### II. Attach Testable Acceptance Criteria to Requirements
Every requirement MUST have explicit, testable acceptance criteria. Requirements R01 through R08 each define observable behavior that can be verified by automated tests. Assertions without testable criteria are not requirements.

### III. Distinguish Observed Evidence from Unverified Assertions
Claims about behavior MUST be backed by observed evidence (test results, storage state inspections). Unverified assertions about implementation details, performance, or edge cases MUST be flagged as assumptions. Code comments and documentation MUST clearly separate verified facts from hypotheses.

### IV. Prefer Simple Scoped Implementations
Implementations MUST be scoped to the minimum set of changes required to satisfy the acceptance criteria. For this release: single-instance, single-thread, JSON-compatible data using MemoryStorage or JSONStorage only. Do not promise concurrent-writer safety, power-loss durability, or rollback after arbitrary partial backend write failure.

### V. Document Unresolved Assumptions and Regressions
All unresolved assumptions, known limitations, and potential regressions MUST be documented alongside the code and in this constitution. Any deviation from upstream behavior MUST be explicitly recorded with rationale and mitigation.

## Additional Constraints

The following requirements define the scope and boundaries of the transactional extension:

- **R01**: TransactionalTinyDB accepts the same constructor arguments as TinyDB; existing nontransactional operations and named/default tables work normally.
- **R02**: `with db.transaction() as current:` yields the same db. Mutations through the db or table handles obtained before entry are visible within the transaction.
- **R03**: No backend storage.write call occurs during a transaction. Successful outer exit writes the complete logical database exactly once, even for multiple tables.
- **R04**: Any exception, including BaseException subclasses, propagates out and rolls back the entire scope with zero backend writes. A later transaction still works.
- **R05**: Rollback restores nested mutable values changed through supported callable updates, table creation/deletion, and preexisting table-handle query results. Query caches must not return data from discarded work.
- **R06**: After commit/rollback, existing handles can insert without ID collisions. Exact reuse of IDs consumed by rolled-back work is not required.
- **R07**: For this initial release, nesting transaction() raises RuntimeError before changing the parent transaction. A caught nesting error leaves the parent usable.
- **R08**: A committed JSONStorage database survives close/reopen; rollback leaves its persisted state unchanged. The existing upstream test suite continues to pass.

## Development Workflow

All development follows a test-driven approach:

1. Write acceptance tests that encode the observable behavior defined in the requirements.
2. Implement the minimal code to satisfy the tests.
3. Verify the existing upstream test suite continues to pass.
4. Document any assumptions, limitations, or regressions.

## Governance

This constitution supersedes all other development practices for the TinyDB transactional extension. Amendments require:

- Documentation of the change and its rationale.
- Updated test coverage reflecting the new principle or behavior.
- Version increment per the semantic versioning policy below.

All changes MUST preserve backward compatibility with the TinyDB public API unless a MAJOR version bump is justified and documented.

**Versioning Policy**:
- MAJOR: Backward incompatible changes to the public API or principle removals/redefinitions.
- MINOR: New principles, sections, or materially expanded guidance.
- PATCH: Clarifications, wording, typo fixes, non-semantic refinements.

**Version**: 1.0.0 | **Ratified**: 2026-09-17 | **Last Amended**: 2026-09-17
