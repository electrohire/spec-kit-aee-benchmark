# Feature Specification: Transactions, Nested Savepoints, and Backup/Restore for TinyDB

**Feature Branch**: `001-transactions`

**Created**: 2026-09-17

**Status**: Draft

**Input**: User description: "Extend this existing TinyDB repository with `from tinydb import TransactionalTinyDB`. Stage 1: opt-in transactions (R01-R08). Stage 2: nested savepoints replacing R07 rejection with R09-R13 support. Stage 3: detached backup() and restore(snapshot) with validation (R14-R19). Preserve all earlier requirements."

## User Scenarios & Testing

### User Story 1 - Atomic Write with Automatic Commit (Priority: P1)

A developer wants to perform multiple database mutations (inserts, updates, table operations) as a single atomic unit. The changes should only be persisted if the entire block completes without exception. If the block succeeds, all changes are written to storage exactly once.

**Why this priority**: This is the core value proposition of transactions — ensuring data consistency across multiple operations. Without it, partial failures can leave the database in an inconsistent state.

**Independent Test**: Can be fully tested by opening a database, performing multiple inserts/updates inside a `with db.transaction()` block, and verifying that all changes are persisted after the block exits normally.

**Acceptance Scenarios**:

1. **Given** an empty database, **When** a transaction block inserts documents into multiple tables and exits normally, **Then** all changes are persisted to storage exactly once.
2. **Given** a database with existing data, **When** a transaction block updates existing documents and inserts new ones and exits normally, **Then** all mutations are visible and storage contains the complete updated state.
3. **Given** a transaction block is entered, **When** the block is executing, **Then** no backend storage.write call has occurred.

---

### User Story 2 - Automatic Rollback on Exception (Priority: P1)

A developer performs a series of mutations inside a transaction block, but an exception occurs partway through. The developer expects all changes made during the transaction to be discarded, and the database to return to its pre-transaction state. A later transaction should still work normally.

**Why this priority**: Rollback is essential for data integrity — without it, partial failures leave the database in an inconsistent state and the developer has no recovery mechanism.

**Independent Test**: Can be fully tested by inserting a document, entering a transaction that modifies data and raises an exception, then verifying the original data is restored and no backend writes occurred.

**Acceptance Scenarios**:

1. **Given** a database with existing data, **When** a transaction modifies data and raises an exception, **Then** all modifications are discarded, no backend writes occurred, and the original data is fully restored.
2. **Given** a transaction rolled back due to exception, **When** a new transaction is opened, **Then** it operates normally and can insert documents without ID collisions with the rolled-back work.
3. **Given** a transaction block, **When** a `BaseException` subclass is raised inside it, **Then** the exception propagates out and the transaction rolls back with zero backend writes.

---

### User Story 3 - Nested Transactions with Savepoints (Priority: P1)

A developer wants to use nested transaction blocks to provide fine-grained error handling. Inner transactions create independent savepoints. A successful inner transaction merges into its parent without writing to the backend. A failed inner transaction rolls back only its own changes, leaving the outer transaction intact and able to continue or commit.

**Why this priority**: Nested transactions enable structured error handling at multiple levels of business logic, allowing partial failures to be recovered without discarding all work.

**Independent Test**: Can be fully tested by entering an outer transaction, inserting data, entering an inner transaction that raises an exception, catching it, inserting more data in the outer scope, and verifying the outer commit persists only the outer data.

**Acceptance Scenarios**:

1. **Given** an outer transaction is active, **When** an inner `db.transaction()` is entered, **Then** a new savepoint is created and yields the same db instance.
2. **Given** a successful inner transaction, **When** the inner scope exits normally, **Then** its changes are merged into the parent savepoint without writing to the backend.
3. **Given** a failed inner transaction, **When** the inner scope exits with an exception, **Then** only the inner changes are rolled back and the outer transaction continues.
4. **Given** an outer transaction that fails, **When** the outer scope exits with an exception, **Then** all inner scopes are discarded and zero backend writes occur.
5. **Given** three levels of nested transactions, **When** the innermost scope fails, **Then** only the innermost changes are rolled back.

---

### User Story 4 - Backup and Restore Database State (Priority: P1)

A developer needs to capture a point-in-time snapshot of the database and later restore it. The backup returns a deeply detached copy; modifying it does not affect the live database. Restore validates the snapshot structure, replaces the entire database, and works within transactions.

**Why this priority**: Backup/restore is essential for data recovery, testing, and migration workflows. Deep detachment ensures the backup is a true point-in-time snapshot.

**Independent Test**: Can be fully tested by inserting data, calling `backup()`, modifying the returned snapshot, verifying the database is unchanged, then calling `restore()` with a valid snapshot and verifying the database reflects the restored state.

**Acceptance Scenarios**:

1. **Given** a database with data, **When** `db.backup()` is called, **Then** it returns a deeply detached dictionary representation of all tables.
2. **Given** a backup snapshot, **When** nested values in the snapshot are modified, **Then** the database remains unchanged.
3. **Given** a valid snapshot, **When** `db.restore(snapshot)` is called, **Then** the database is replaced with the restored data and existing handles/caches reflect the new state.
4. **Given** an invalid snapshot (e.g., non-dict root, invalid table names, non-canonical document IDs), **When** `db.restore(snapshot)` is called, **Then** a `ValueError` is raised, the database is unchanged, and zero backend writes occur.
5. **Given** a transaction, **When** `db.restore()` is called inside it and the outer scope fails, **Then** the restore is discarded and the database returns to its pre-transaction state.

---

### User Story 5 - Persistence Across Close/Reopen (Priority: P2)

A developer commits changes inside a transaction using JSONStorage, closes the database, and reopens it. The committed changes should be visible after reopen. Changes that were rolled back should not appear.

**Why this priority**: Ensures durability of committed transactions across application restarts, which is critical for any database feature.

**Independent Test**: Can be fully tested by committing a transaction, closing the database, reopening it, and verifying committed data persists while rolled-back data does not.

**Acceptance Scenarios**:

1. **Given** a JSONStorage database with committed transaction data, **When** the database is closed and reopened, **Then** the committed data is present.
2. **Given** a JSONStorage database with rolled-back transaction data, **When** the database is closed and reopened, **Then** the rolled-back data is absent and the persisted state is unchanged.
3. **Given** a JSONStorage database restored via `restore()`, **When** the database is closed and reopened, **Then** the restored data is present.

---

### Edge Cases

- What happens when a transaction modifies mutable nested values (e.g., lists inside documents)? Rollback must restore the original nested values.
- What happens when a table is created and deleted within a transaction? Rollback must restore the table state.
- What happens when query caches contain data modified inside a transaction? Rollback must clear cached results from discarded work.
- What happens when `BaseException` (e.g., `KeyboardInterrupt`) is raised inside a transaction? The transaction must still roll back.
- What happens when an outer transaction fails after an inner transaction has already committed? All inner changes are discarded.
- What happens when nested savepoints are used for three or more levels? Each savepoint must be independently rollbackable.
- What happens when ID counters are consumed inside a rolled-back inner scope? The next insert must not collide with IDs from the rolled-back scope.
- What happens when `restore()` is called with an empty snapshot `{}`? The entire database should be cleared.
- What happens when `backup()` is called on an empty database? It should return `{}`.
- What happens when `restore()` is called with document IDs like `'0'`, `'-1'`, `'01'`, integers, or booleans? Validation must reject them.
- What happens when `restore()` is called with NaN, Infinity, sets, or non-string nested dictionary keys in document values? Validation must reject them.

## Requirements

### Functional Requirements

#### Stage 1: Opt-in Transactions (R01-R08)

- **FR-001**: System MUST provide a `TransactionalTinyDB` class exported from the `tinydb` package that accepts the same constructor arguments as `TinyDB`.
- **FR-002**: System MUST support `with db.transaction() as current:` context manager that yields the same `db` instance.
- **FR-003**: System MUST make mutations visible within the transaction block through the same `db` or table handles obtained before entry.
- **FR-004**: System MUST NOT call backend `storage.write` during any transaction. On successful outermost exit, the complete logical database must be written exactly once.
- **FR-005**: System MUST roll back all changes and produce zero backend writes when any exception (including `BaseException` subclasses) propagates out of the transaction block.
- **FR-006**: System MUST restore nested mutable values changed through callable updates, table creation/deletion, and preexisting table-handle query results on rollback. Query caches must not return data from discarded work.
- **FR-007**: System MUST allow existing table handles to insert documents without ID collisions after commit or rollback. Exact reuse of IDs consumed by rolled-back work is not required.
- **FR-008**: System MUST persist committed data across database close/reopen for `JSONStorage`. Rollback must leave the persisted state unchanged.

#### Stage 2: Nested Savepoints (R09-R13, supersedes R07)

- **FR-009**: System MUST support nested `transaction()` contexts that create independent savepoints, including at least three levels. Each context yields the same db.
- **FR-010**: System MUST merge successful inner transaction exits into the parent savepoint without writing to the backend. Only the outermost successful exit writes storage.
- **FR-011**: System MUST roll back only the changes of a failed inner scope. If the exception is caught inside the outer scope, earlier outer work remains and later outer work can still commit.
- **FR-012**: System MUST discard even successfully completed inner scopes when an outer scope fails. No backend writes occur on outer failure.
- **FR-013**: System MUST make preexisting table handles and warmed query caches reflect the current active savepoint after inner rollback. Subsequent inserts must not collide with live IDs.

#### Stage 3: Detached Backup and Transactional Restore (R14-R19)

- **FR-014**: System MUST provide `db.backup()` that returns all tables (including the default table) from the current logical state. During a transaction it includes tentative changes. Empty DB returns `{}`.
- **FR-015**: System MUST return deeply detached backups: changing nested backup values does not change the database, and later database changes do not mutate an earlier backup.
- **FR-016**: System MUST provide `db.restore(snapshot)` that replaces the complete logical database, removing tables absent from the snapshot. It must deeply copy caller input. Existing table handles, caches, and subsequent ID allocation must reflect restored data without collisions.
- **FR-017**: System MUST validate the entire snapshot before any mutation/write. Root/table/document containers must be dictionaries, table names strings, document IDs canonical positive decimal strings (e.g., `'1'`, `'23'`; not `'0'`, `'-1'`, `'01'`, int, or bool). Document values must be JSON-compatible and finite (reject NaN/Infinity, sets, non-string nested dictionary keys). Invalid snapshots raise `ValueError` with zero backend writes and the prior database preserved.
- **FR-018**: System MUST make `restore()` inside any transaction rollbackable and not write storage until successful outer commit. Failed inner restore scopes restore parent state; outer rollback discards successful inner restores. `backup()` observes active state.
- **FR-019**: System MUST perform one backend write when `restore()` is called outside a transaction. JSONStorage backup/restore must survive close/reopen. `{}` is a valid replacement database.

### Key Entities

- **TransactionalTinyDB**: A subclass or thin wrapper of `TinyDB` that adds transaction support. Shares the same constructor signature and non-transactional API surface.
- **Transaction Context**: A per-database state flag indicating whether a transaction is active. Tracks a stack of savepoints for nested transactions.
- **Savepoint**: A snapshot of the database state captured at `__enter__` of a transaction scope. Used as the rollback target for that scope. Inner savepoints are independent of outer ones.
- **Savepoint Stack**: A LIFO stack of savepoints. The outermost savepoint is the base; each nested transaction pushes a new savepoint. On exit, the topmost savepoint is either merged (commit) or discarded (rollback).
- **Backup Snapshot**: A deeply detached, JSON-compatible dictionary `{table_name: {document_id_string: document_dictionary}}` representing the database state at a point in time.
- **Restore Validation**: Pre-mutation validation of snapshot structure, types, and value constraints before any database mutation.

## Success Criteria

### Measurable Outcomes

- **SC-001**: Zero backend storage writes occur during any active transaction scope.
- **SC-002**: After a successful transaction, exactly one storage write occurs containing all changes from the transaction.
- **SC-003**: After a rolled-back transaction, the database state is identical to the state before the transaction began.
- **SC-004**: Nested transaction savepoints support at least three levels of nesting.
- **SC-005**: A failed inner transaction rolls back only its own changes without affecting outer work.
- **SC-006**: A failed outer transaction discards all inner changes and writes nothing.
- **SC-007**: A committed database survives close/reopen with all committed data intact.
- **SC-008**: The existing upstream TinyDB test suite passes 100% after the feature is added.
- **SC-009**: Existing non-transactional TinyDB code continues to function identically.
- **SC-010**: After any commit or rollback, subsequent inserts do not produce ID collisions with documents from rolled-back scopes.
- **SC-011**: `backup()` returns a deeply detached copy that is independent of subsequent database mutations.
- **SC-012**: `restore()` with an invalid snapshot raises `ValueError` without modifying the database or writing to storage.
- **SC-013**: `restore()` inside a transaction is fully rollbackable and does not write storage until outer commit.
- **SC-014**: A restored database survives close/reopen with all restored data intact.

## Assumptions

- The feature is single-instance and single-threaded; no concurrent-writer safety is provided.
- Only `MemoryStorage` and `JSONStorage` are supported as backends.
- Deep copy of the storage snapshot at each savepoint entry is used for rollback (sufficient for JSON-compatible data).
- Nested transactions use independent savepoints rather than true database-level savepoints.
- Rollback does not guarantee recovery from partial backend write failures (e.g., disk full mid-write).
- Power-loss durability is not guaranteed; committed data survives only normal close/reopen.
- The `TransactionalTinyDB` class is a drop-in replacement for `TinyDB` that adds transaction support without changing existing behavior.
- ID counters are monotonic and never reused; rolled-back IDs are simply skipped.
- Backup snapshots are in-memory only; no file-based backup APIs are provided.
- Document ID strings in backups/restores must be canonical positive decimal strings (no leading zeros, no negative numbers, no zero, no non-string types).
- Nested dictionary keys in document values must be strings for JSON compatibility.
