"""Batch journaling for the default table of a TinyDB database.

:class:`BatchWriter` wraps a supplied :class:`tinydb.TinyDB` instance and
applies an ordered list of insert/remove operations to the database's
default table only. The wrapped database's ordinary APIs are never modified.
"""

from copy import deepcopy
from typing import Any, List, Mapping

from .database import TinyDB
from .table import Table

__all__ = ['BatchWriter']

_INSERT = 'insert'
_REMOVE = 'remove'
_OP_KEY = 'op'
_DOCUMENT_KEY = 'document'
_DOC_ID_KEY = 'doc_id'


class BatchWriter:
    """Apply atomic batches of insert/remove operations to the default table."""

    def __init__(self, db: TinyDB) -> None:
        self.db = db
        self._table: Table = db.table(db.default_table_name)

    def apply(self, operations: Any) -> List[int]:
        if not isinstance(operations, list):
            raise ValueError('operations must be a list of operation dicts')

        if not operations:
            return []

        for operation in operations:
            self._validate_operation(operation)

        # Snapshot pre-batch state for rollback.
        db_data = self.db.storage.read() or {}
        pre_batch_data = deepcopy(db_data)
        raw_default = pre_batch_data.setdefault(self.db.default_table_name, {})
        # Normalize doc IDs to int for in-memory processing.
        default_table = {
            int(doc_id): doc for doc_id, doc in raw_default.items()
        }

        inserted_ids: List[int] = []
        try:
            for operation in operations:
                next_id = self._apply_operation(default_table, operation)
                if next_id is not None:
                    inserted_ids.append(next_id)
                # Sync in-memory state back into pre_batch_data before writing.
                pre_batch_data[self.db.default_table_name] = default_table
                self.db.storage.write(self._normalize_for_storage(pre_batch_data))
        except Exception:
            self.db.storage.write(db_data)
            self._table._next_id = None
            raise

        # Success: keep the table's next-ID cache consistent.
        max_id = max((int(doc_id) for doc_id in default_table), default=0)
        if self._table._next_id is None or self._table._next_id <= max_id:
            self._table._next_id = max_id + 1

        # Update the table's in-memory _data so pre-existing handles reflect
        # the new state.  Use plain dicts (not Document instances) to avoid
        # interference with Table.remove() which calls _cond(doc) on the
        # stored value.
        self._table._data = {
            str(doc_id): dict(doc) for doc_id, doc in default_table.items()
        }

        return inserted_ids

    def _normalize_for_storage(self, data: dict) -> dict:
        result = {}
        for table_name, table in data.items():
            if table_name == self.db.default_table_name:
                result[table_name] = {
                    str(doc_id): doc for doc_id, doc in table.items()
                }
            else:
                result[table_name] = table
        return result

    @staticmethod
    def _validate_operation(operation: Any) -> None:
        if not isinstance(operation, dict):
            raise ValueError(
                f'operation must be a dict, got {type(operation).__name__}'
            )
        op = operation.get(_OP_KEY)
        if op == _INSERT:
            document = operation.get(_DOCUMENT_KEY)
            if not isinstance(document, Mapping):
                raise ValueError(
                    "insert operation requires a 'document' that is a Mapping"
                )
        elif op == _REMOVE:
            doc_id = operation.get(_DOC_ID_KEY)
            if not isinstance(doc_id, int) or isinstance(doc_id, bool) or doc_id <= 0:
                raise ValueError(
                    "remove operation requires a 'doc_id' that is a positive integer"
                )
        else:
            raise ValueError(f"unknown operation kind: {op!r}")

    @staticmethod
    def _apply_operation(default_table: dict, operation: dict):
        if operation[_OP_KEY] == _INSERT:
            doc_id = BatchWriter._next_doc_id(default_table)
            default_table[doc_id] = deepcopy(dict(operation[_DOCUMENT_KEY]))
            return doc_id
        doc_id = operation[_DOC_ID_KEY]
        if doc_id not in default_table:
            raise ValueError(f'document with ID {doc_id} does not exist')
        del default_table[doc_id]
        return None

    @staticmethod
    def _next_doc_id(default_table: dict) -> int:
        if not default_table:
            return 1
        return max(int(doc_id) for doc_id in default_table) + 1
