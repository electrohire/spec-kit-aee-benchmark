# cachetools Constitution

## Core Principles

### I. Preserve Existing Public API Behavior
All existing public APIs of cachetools MUST remain functionally unchanged. New modules and classes MUST NOT alter the behavior, signatures, or semantics of any previously published interface. Backward compatibility is non-negotiable.

### II. Attach Testable Acceptance Criteria to Requirements
Every requirement MUST have explicit, testable acceptance criteria. Acceptance criteria MUST be verifiable through automated tests. Requirements without associated testable criteria are incomplete and must not be considered implemented.

### III. Distinguish Observed Evidence from Unverified Assertions
Claims about behavior, performance, or correctness MUST be supported by observed evidence (test results, measurements, logs). Unverified assertions MUST be flagged as assumptions and kept separate from confirmed facts. Documentation MUST clearly label each claim as evidence-based or assumed.

### IV. Prefer Simple Scoped Implementations
Implementations MUST be scoped to the minimum necessary functionality required to satisfy the stated requirements. Avoid adding features, abstractions, or complexity not explicitly required. Simplicity is preferred over generality.

### V. Document Unresolved Assumptions and Regressions
All unresolved assumptions, known regressions, and open questions MUST be documented explicitly. Assumptions MUST state what is being assumed, why, and what would invalidate it. Regressions MUST describe the affected behavior, root cause (if known), and planned remediation.

## Acceptance Criteria

Acceptance criteria MUST be written per requirement and MUST satisfy the following:
- Each criterion is independently verifiable through an automated test.
- Criteria cover both happy-path and error/edge-case scenarios.
- Criteria reference specific classes, methods, and behaviors.
- Criteria distinguish between observed test results and assumed behavior.

## Development Standards

Implementation MUST follow these standards:
- Source code lives in `src/cachetools/` under the appropriate module namespace.
- Tests MUST not modify upstream test files.
- Values are copied on input and output (deep copy semantics).
- Tags are validated before any state mutation occurs.
- LRU eviction must not leave stale tag memberships.

## Governance

This constitution supersedes all other development practices within the cachetools project. Amendments require:
1. Documentation of the change and its rationale.
2. Version bump according to semantic versioning (MAJOR/MINOR/PATCH).
3. Explicit notation of any backward-incompatible changes.

All new code MUST comply with these principles. Deviations MUST be documented as regressions with justification.

**Version**: 1.0.0 | **Ratified**: 2026-09-18 | **Last Amended**: 2026-09-18
