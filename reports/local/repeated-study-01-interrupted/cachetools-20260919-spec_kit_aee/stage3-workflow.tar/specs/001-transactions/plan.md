# Implementation Plan: TaggedCache with LRU Eviction

**Branch**: `001-transactions` | **Date**: 2026-09-18 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-transactions/spec.md`

## Summary

Build `cachetools.tagged.TaggedCache(maxsize)`, a tag-aware bounded cache built on `cachetools.LRUCache`. It supports per-entry string tags, tag-based invalidation (`invalidate(tag)`), deep-copy semantics for values, and strict input validation before state mutation. The implementation preserves all existing cachetools APIs.

## Technical Context

**Language/Version**: Python 3.7+ (cachetools 5.5.2 target)

**Primary Dependencies**: `cachetools` package (LRUCache, Cache base class), `copy` module (deepcopy)

**Storage**: In-memory dict + OrderedDict (inherited from LRUCache)

**Testing**: pytest (project uses tox.ini with pytest)

**Target Platform**: Any platform supporting Python 3.7+

**Project Type**: Library (Python package)

**Performance Goals**: O(1) put/get, O(t) invalidate where t = entries with given tag, O(1) len()

**Constraints**: Values cost 1 capacity slot regardless of object size. Tags must be finite iterable of strings. Bool excluded from maxsize validation.

**Scale/Scope**: Single new class `TaggedCache` in `src/cachetools/tagged.py`; no changes to existing modules.

## Constitution Check

**GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.**

| Constitution Principle | Check | Result |
|---|---|---|
| I. Preserve Existing Public API Behavior | New module `tagged.py` does not modify `__init__.py`, `Cache`, or `LRUCache` | PASS |
| II. Attach Testable Acceptance Criteria | Each FR has explicit acceptance scenarios in spec.md | PASS |
| III. Distinguish Observed from Asserted | Plan marks assumptions; implementation will produce test evidence | PASS |
| IV. Prefer Simple Scoped Implementation | Single class, no extra abstractions | PASS |
| V. Document Unresolved Assumptions | Assumptions section below documents 7 items | PASS |

**Constitution Check Result: PASS** — No violations detected.

## Project Structure

### Documentation (this feature)

```text
specs/001-transactions/
├── plan.md              # This file ($speckit-plan command output)
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   └── tagged_api.md    # TaggedCache public API contract
└── spec.md              # Feature specification
```

### Source Code (repository root)

```text
src/cachetools/
├── __init__.py          # Existing; unchanged
├── tagged.py            # NEW: TaggedCache implementation

tests/
├── test_tagged.py       # NEW: TaggedCache tests (author's own)
└── [existing tests]     # Unchanged

acceptance_public.py     # Public acceptance test (read-only)
```

**Structure Decision**: Single new module `src/cachetools/tagged.py` containing `TaggedCache`. No changes to existing source files. Tests in `tests/test_tagged.py`.

## Phase 0: Research

### Design Decisions

**Decision 0-1**: Use `copy.deepcopy` for value serialization.
- **Rationale**: Spec requires deep copy on both input (put) and output (get). `copy.deepcopy` is the standard Python approach.
- **Alternatives considered**: `copy.copy` (shallow — would not satisfy deep copy requirement), custom serialization (over-engineering), pickle (security risk, fragile).

**Decision 0-2**: Use an internal `dict[str, set[Any]]` for tag-to-keys membership index.
- **Rationale**: Enables O(1) lookup of entries by tag, making `invalidate(tag)` proportional only to matching entries. Keys are stored in sets for O(1) removal.
- **Alternatives considered**: Linear scan of all entries (O(n) invalidate, simpler but slower), frozenset per entry (no separate index, forces linear scan).

**Decision 0-3**: Validate tags before any state mutation in `put()`.
- **Rationale**: Spec requirement R01 mandates ValueError before changing state. Full validation pass (is iterable, not bare string, all elements are strings, deduplication) must complete before calling parent `__setitem__`.
- **Alternatives considered**: Partial validation on first element (would leave partial state on later failure), lazy validation (violates spec).

**Decision 0-4**: Inherit from `LRUCache` directly and override `__setitem__`, `__delitem__`, `__getitem__`, and add `invalidate()`.
- **Rationale**: Reuses LRU eviction logic, order tracking, maxsize enforcement, and `len()`/`currsize` from base class. Minimizes code duplication.
- **Alternatives considered**: Composition (would need to reimplement MutableMapping interface), inheriting from `Cache` (loses LRU ordering).

**Decision 0-5**: `maxsize` setter validates and rejects non-positive/non-int/bool values.
- **Rationale**: Spec R03 requires maxsize to be a positive int excluding bool. A property setter enforces this on replacement.
- **Alternatives considered**: No setter (maxsize immutable after init — simpler but less flexible), silent clamp (violates "leave old value unchanged" requirement).

### Assumptions

1. `LRUCache.__init__` accepts `(maxsize, getsizeof=None)` — confirmed by reading source.
2. `LRUCache.__getitem__` calls `__update(key)` on access (refreshes LRU recency) — confirmed by source.
3. `LRUCache.__delitem__` removes from both `__data` and `__order` — confirmed by source.
4. `LRUCache.popitem()` evicts the least recently used entry — confirmed by source.
5. `copy.deepcopy` is available and correct for typical cache values (primitives, lists, dicts, tuples) — standard library guarantee.
6. Tags are stored as `frozenset` internally for hashability and immutability — design choice for correctness.
7. Existing `Cache.getsizeof` returns 1 per entry; TaggedCache inherits this unless a custom `getsizeof` is passed.

## Phase 1: Design & Contracts

See generated artifacts below.

### Complexity Tracking

No complexity violations detected. Single class, minimal scope.
