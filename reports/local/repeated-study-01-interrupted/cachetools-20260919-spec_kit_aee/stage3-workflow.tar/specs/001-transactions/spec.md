# Feature Specification: TaggedCache with LRU Eviction

**Feature Branch**: `001-tagged-cache`

**Created**: 2026-09-18

**Status**: Draft

**Input**: User description: "Build cachetools.tagged.TaggedCache(maxsize), using the existing cachetools.LRUCache for bounded storage and preserving all existing cachetools APIs."

## User Scenarios & Testing

### User Story 1 - Tagged Entry Insertion and Retrieval (Priority: P1)

A cache consumer needs to store entries with tags for later group-based invalidation. The consumer puts entries with keys, values, and a set of string tags. When retrieving an entry by key, the consumer expects to receive a detached deep copy of the stored value. If the key does not exist, a KeyError is raised.

**Why this priority**: This is the core functionality — without put/get, the TaggedCache cannot serve its purpose.

**Independent Test**: Create a TaggedCache, call put with tags, call get and verify the returned value matches the stored value and is a deep copy.

**Acceptance Scenarios**:

1. **Given** an empty TaggedCache(maxsize=2), **When** I call `c.put('a', 1, ['x'])`, **Then** the entry is stored with key 'a', value 1, and tag 'x'.
2. **Given** a cache with `c.put('a', [1, 2], ['x'])`, **When** I call `val = c.get('a')`, **Then** `val` equals `[1, 2]` and `val is not [1, 2]` (deep copy).
3. **Given** a cache without key 'missing', **When** I call `c.get('missing')`, **Then** a KeyError is raised.
4. **Given** a cache with `c.put('a', obj)`, **When** the value `obj` is mutated after put, **Then** `c.get('a')` still returns the original value (input is copied).

---

### User Story 2 - Tag-Based Invalidation (Priority: P1)

A cache consumer needs to remove all entries carrying a specific tag. The `invalidate(tag)` method removes exactly the entries that carry that tag and returns the count of removed entries. Replacing an existing key must remove its old tag memberships before assigning new ones.

**Why this priority**: Tag-based invalidation is the distinguishing feature of TaggedCache versus plain LRUCache.

**Independent Test**: Insert entries with overlapping tags, invalidate a tag, verify only matching entries are removed and the return count is correct.

**Acceptance Scenarios**:

1. **Given** `c.put('a', 1, ['x'])` and `c.put('b', 2, ['x'])`, **When** I call `removed = c.invalidate('x')`, **Then** `removed == 2` and `len(c) == 0`.
2. **Given** `c.put('a', 1, ['old'])` then `c.put('a', 2, ['new'])`, **When** I call `c.invalidate('old')`, **Then** `removed == 0` (old tags are gone) and `c.get('a') == 2`.
3. **Given** a cache with entries tagged 'x' and 'y', **When** I call `c.invalidate('z')` (no matching tag), **Then** `removed == 0` and no entries are removed.

---

### User Story 3 - LRU Eviction with Tag Integrity (Priority: P2)

A cache consumer expects that when the cache reaches maxsize and a new entry is inserted, the least-recently-used entry is evicted. Eviction must not leave stale tag memberships that affect later operations. The `get(key)` call refreshes the LRU recency of the entry.

**Why this priority**: Eviction is fundamental to bounded caches; tag integrity during eviction ensures correctness of invalidate operations.

**Independent Test**: Fill cache to maxsize, insert a new entry, verify the LRU entry is evicted and its tags no longer appear in invalidate results.

**Acceptance Scenarios**:

1. **Given** `c = TaggedCache(2)`, `c.put('a', 1, ['x'])`, `c.put('b', 2, ['y'])`, **When** I call `c.put('c', 3, ['z'])`, **Then** the LRU entry ('a') is evicted and `len(c) == 2`.
2. **Given** the same scenario, **When** I call `c.invalidate('x')`, **Then** `removed == 0` (evicted entry's tag is not stale).
3. **Given** a cache with entries, **When** I call `c.get('existing_key')`, **Then** the entry's LRU recency is updated (subsequent eviction evicts a different entry).
4. **Given** `len(c)` after operations, **Then** it returns the count of live entries only.

---

### User Story 4 - Input Validation (Priority: P2)

A cache consumer may pass invalid arguments to put. The TaggedCache must validate tags before modifying any state. Tags must be a finite iterable of strings. A bare string passed as tags must be rejected with ValueError. Non-string tag entries must be rejected with ValueError. The cache must remain unchanged after a validation failure.

**Why this priority**: Validation protects the cache from corruption and ensures API contract safety.

**Independent Test**: Call put with a bare string as tags, verify ValueError is raised and the cache is unchanged.

**Acceptance Scenarios**:

1. **Given** a TaggedCache, **When** I call `c.put('a', 1, 'x')` (bare string), **Then** ValueError is raised and the cache is unchanged.
2. **Given** a TaggedCache, **When** I call `c.put('a', 1, ['x', 42])` (non-string entry), **Then** ValueError is raised and the cache is unchanged.
3. **Given** a TaggedCache, **When** I call `c.put('a', 1, ['x', 'x'])` (duplicate tags), **Then** tags are deduplicated to `['x']` and the entry is stored.

---

### User Story 5 - Maxsize Validation and Immutability (Priority: P3)

A cache consumer must provide a positive integer for maxsize. The maxsize must not accept booleans (since bool is a subclass of int). Invalid replacement input for maxsize must leave the old maxsize, tags, and recency unchanged.

**Why this priority**: Ensures the cache boundary is well-defined and robust against invalid configuration.

**Independent Test**: Create TaggedCache with maxsize=True, verify ValueError is raised.

**Acceptance Scenarios**:

1. **Given** `c = TaggedCache(2)`, **When** I attempt to set `c.maxsize = True`, **Then** ValueError is raised and `c.maxsize` remains 2.
2. **Given** `c = TaggedCache(2)`, **When** I attempt to set `c.maxsize = -1`, **Then** ValueError is raised and `c.maxsize` remains 2.
3. **Given** `c = TaggedCache(2)`, **When** I attempt to set `c.maxsize = 0`, **Then** ValueError is raised and `c.maxsize` remains 2.

---

### Edge Cases

- What happens when maxsize is set to a non-integer (e.g., float, None)? → ValueError; state unchanged.
- How does the system handle an empty iterable of tags `()`? → Valid; entry stored with no tags, cannot be invalidated by tag.
- What happens when getsizeof is provided and values have varying sizes? → Values cost one capacity slot regardless of object size (default getsizeof). Custom getsizeof can override.
- What happens when a key is replaced with a value of different size? → Old value is removed, new value is inserted; tags are replaced.

## Requirements

### Functional Requirements

- **FR-001**: The `TaggedCache(maxsize)` class MUST inherit from or reuse `cachetools.LRUCache` for bounded storage.
- **FR-002**: `TaggedCache.put(key, value, tags=())` MUST insert or replace an entry, storing the key, a deep copy of the value, and a deduplicated set of string tags.
- **FR-003**: `TaggedCache.get(key)` MUST return a deep copy of the stored value for the given key, and refresh LRU recency.
- **FR-004**: `TaggedCache.get(key)` MUST raise `KeyError` if the key does not exist in the cache.
- **FR-005**: `TaggedCache.invalidate(tag)` MUST remove exactly the entries that carry the specified tag and return the number of removed entries.
- **FR-006**: Replacing an entry via `put` MUST remove the entry's old tag memberships before assigning new tags.
- **FR-007**: LRU eviction MUST not leave stale tag memberships; evicted entries' tags MUST not be affected by subsequent `invalidate` calls.
- **FR-008**: `len(cache)` MUST return the count of live (non-evicted, non-deleted) entries.
- **FR-009**: Tags MUST be validated as a finite iterable of strings; a bare string MUST raise `ValueError` before any state change.
- **FR-010**: Non-string entries in the tags iterable MUST raise `ValueError` before any state change.
- **FR-011**: Duplicate tags in the iterable MUST be deduplicated.
- **FR-012**: `maxsize` MUST be validated as a positive integer, excluding `bool` type.
- **FR-013**: Invalid `maxsize` replacement MUST raise an error and leave the old maxsize, tags, and recency unchanged.
- **FR-014**: Values MUST be deep-copied on input (`put`) and on output (`get`).
- **FR-015**: Keys MUST be hashable (enforced by dict-based storage).
- **FR-016**: Each value MUST cost exactly one capacity slot regardless of object size (unless a custom `getsizeof` is provided).

### Key Entities

- **TaggedCache Entry**: A tuple of (key, deep_copied_value, set_of_string_tags) stored in the underlying LRU cache. Tags are deduplicated and validated.
- **Tag Membership Index**: An internal mapping from tag strings to sets of keys that carry that tag, used for efficient tag-based invalidation.
- **LRU Order**: An ordered structure (inherited from LRUCache) tracking insertion and access recency for eviction purposes.

## Success Criteria

### Measurable Outcomes

- **SC-001**: All public acceptance tests in `acceptance_public.py` pass without modification.
- **SC-002**: Tag-based invalidation removes exactly the matching entries with O(t) time where t is the number of entries carrying the tag.
- **SC-003**: LRU eviction correctly removes the least-recently-used entry and does not leave stale tag memberships.
- **SC-004**: Input validation rejects invalid tags and maxsize before any state mutation, verified by inspecting cache state after failed operations.
- **SC-005**: Deep copy semantics are preserved: `get` returns a value that is independent of subsequent mutations to the original or cached value.
- **SC-006**: `len(cache)` accurately reflects the number of live entries at all times, including after eviction, replacement, and invalidation.

## Assumptions

- The `cachetools` package version is 5.5.2 or compatible; the `LRUCache` base class provides `__getitem__`, `__setitem__`, `__delitem__`, `popitem`, `maxsize` property, and `currsize` property.
- Deep copy is performed using `copy.deepcopy` from the standard library.
- The `getsizeof` method from the base `Cache` class defaults to returning 1 per entry; a custom `getsizeof` can be passed to `__init__` if needed.
- Tags are stored as a `frozenset` internally for efficient membership checking and iteration.
- The `put` method does not accept `getsizeof` as a parameter; it is set at construction time.
- The `invalidate` method does not accept a default value for missing tags; it simply returns 0.
- Existing cachetools APIs (`Cache`, `LRUCache`, `FIFOCache`, etc.) are not modified.
