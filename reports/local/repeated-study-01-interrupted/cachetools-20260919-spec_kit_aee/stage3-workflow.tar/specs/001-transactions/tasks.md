---

description: "Task list for TaggedCache milestone 1 - TaggedCache with LRU Eviction"
---

# Tasks: TaggedCache with LRU Eviction

**Input**: Design documents from `/specs/001-transactions/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/tagged_api.md, constitution.md

**Tests**: Tests are written alongside implementation per user story. Public acceptance via `acceptance_public.py`.

---

## Phase 1: Setup

**Goal**: Initialize project structure and verify baseline.

- [ ] T001 [P] Verify cachetools package is importable and LRUCache base class is accessible in `src/cachetools/__init__.py`
- [ ] T002 [P] Verify pytest is available and `python -m pytest --version` runs successfully
- [ ] T003 [P] Ensure `src/cachetools/tagged.py` file exists (empty or stub) as the implementation target

**Checkpoint**: Project baseline is verified; pytest can run, cachetools imports correctly.

---

## Phase 2: Foundational

**Goal**: Implement the core TaggedCache class structure with foundational components that all user stories depend on.

- [ ] T004 [P] Create `TaggedCache` class in `src/cachetools/tagged.py` inheriting from `cachetools.LRUCache`
- [ ] T005 [P] Implement `__init__(self, maxsize, getsizeof=None)` that validates `maxsize` as a positive integer (excluding `bool`) and calls `super().__init__(maxsize, getsizeof)`
- [ ] T006 [P] Implement internal `_tags` attribute: a `dict[str, set]` mapping tag strings to sets of keys for O(t) tag-based lookup
- [ ] T007 Implement `put(self, key, value, tags=())` with full tag validation (reject bare string, reject non-string entries, deduplicate) before any state mutation, then deep-copy value and store with tags
- [ ] T008 Implement `get(self, key)` that returns a deep copy of the stored value and refreshes LRU recency via parent `__getitem__`
- [ ] T009 Implement `invalidate(self, tag)` that looks up keys in `_tags[tag]`, deletes each key from the cache, cleans up `_tags` entries, and returns the count of removed entries
- [ ] T010 Implement `_evict_stale_tags(self, key)` helper to remove stale tag memberships when a key is evicted or replaced

**Checkpoint**: TaggedCache class has all core methods implemented. All user story methods exist and follow the spec requirements.

---

## Phase 3: User Story 1 - Tagged Entry Insertion and Retrieval (Priority: P1)

**Goal**: Enable storing entries with string tags and retrieving deep-copied values by key.

**Independent Test**: Create a TaggedCache(2), call `put('a', 1, ['x'])`, call `get('a')` and verify it returns 1. Verify `get('missing')` raises KeyError. Verify deep copy semantics.

### Implementation Tasks

- [ ] T011 [US1] Implement `put(key, value, tags=())` in `src/cachetools/tagged.py` to insert or replace an entry, storing a deep copy of the value and deduplicated tag set
- [ ] T012 [US1] Implement `get(key)` in `src/cachetools/tagged.py` to return a deep copy of the stored value, refreshing LRU recency
- [ ] T013 [US1] Write unit tests in `tests/test_tagged.py` for US1: basic put/get, deep copy on output, deep copy on input, KeyError on missing key

**Checkpoint**: User Story 1 is fully functional and testable independently. `acceptance_public.py::test_public_basic` passes.

---

## Phase 4: User Story 2 - Tag-Based Invalidation (Priority: P1)

**Goal**: Remove all entries carrying a specific tag and return the count of removed entries. Replacing a key must remove its old tag memberships.

**Independent Test**: Insert entries with overlapping tags, invalidate a tag, verify only matching entries are removed and the return count is correct. Verify replacing a key removes old tag memberships.

### Implementation Tasks

- [ ] T014 [US2] Implement `invalidate(tag)` in `src/cachetools/tagged.py` to remove exactly entries carrying the specified tag, return count removed
- [ ] T015 [US2] Implement tag membership tracking in `put()` so that replacing a key removes old tag memberships before assigning new ones
- [ ] T016 [US2] Write unit tests in `tests/test_tagged.py` for US2: invalidate removes correct entries, replace removes old tags, invalidate non-existent tag returns 0

**Checkpoint**: User Stories 1 AND 2 both work independently. `acceptance_public.py::test_public_replacement` passes.

---

## Phase 5: User Story 3 - LRU Eviction with Tag Integrity (Priority: P2)

**Goal**: When cache reaches maxsize, evict LRU entry without leaving stale tag memberships. get() refreshes LRU recency.

**Independent Test**: Fill cache to maxsize, insert new entry, verify LRU entry is evicted and its tags no longer affect invalidate results.

### Implementation Tasks

- [ ] T017 [US3] Override `__delitem__` in `src/cachetools/tagged.py` to clean up `_tags` index when a key is deleted (eviction or explicit delete)
- [ ] T018 [US3] Write unit tests in `tests/test_tagged.py` for US3: LRU eviction removes correct entry, invalidated tag count is 0 after eviction, get refreshes recency, len() counts live entries

**Checkpoint**: All user stories 1-3 are independently functional. LRU eviction does not leave stale tag memberships.

---

## Phase 6: User Story 4 - Input Validation (Priority: P2)

**Goal**: Validate tags before modifying any state. Reject bare strings and non-string tag entries with ValueError.

**Independent Test**: Call put with a bare string as tags, verify ValueError is raised and the cache is unchanged.

### Implementation Tasks

- [ ] T019 [US4] Implement tag validation helper in `src/cachetools/tagged.py` that checks tags is not a bare string, is iterable, and all elements are strings
- [ ] T020 [US4] Write unit tests in `tests/test_tagged.py` for US4: bare string raises ValueError, non-string entries raise ValueError, duplicate tags are deduplicated, empty iterable is valid

**Checkpoint**: All user stories 1-4 are independently functional. Invalid inputs are rejected before any state mutation.

---

## Phase 7: User Story 5 - Maxsize Validation and Immutability (Priority: P3)

**Goal**: Validate maxsize as a positive integer (excluding bool). Invalid replacement must leave old state unchanged.

**Independent Test**: Create TaggedCache with maxsize=True, verify ValueError is raised.

### Implementation Tasks

- [ ] T021 [US5] Implement `maxsize` property setter in `src/cachetools/tagged.py` that validates positive integer (excluding bool) and leaves old value unchanged on invalid input
- [ ] T022 [US5] Write unit tests in `tests/test_tagged.py` for US5: maxsize=True raises ValueError, maxsize=-1 raises ValueError, maxsize=0 raises ValueError, valid replacement works

**Checkpoint**: All user stories are complete. Maxsize validation is robust.

---

## Phase 8: Polish & Cross-Cutting Concerns

**Goal**: Final validation, cleanup, and acceptance testing.

- [ ] T023 [P] Run `acceptance_public.py` to verify all public acceptance tests pass
- [ ] T024 [P] Run full test suite `python -m pytest tests/test_tagged.py -v` to verify all unit tests pass
- [ ] T025 [P] Verify upstream tests remain unchanged (no modifications to existing test files)
- [ ] T026 [P] Code cleanup: remove any debug prints, ensure docstrings for public methods, verify PEP 8 style
- [ ] T027 [P] Verify `len(cache)` returns correct count after all operations (put, get, invalidate, eviction)
- [ ] T028 [P] Verify deep copy semantics: mutations to returned value do not affect cached value and vice versa

**Checkpoint**: All acceptance criteria met. Code is clean, tested, and ready for review.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - BLOCKS all user stories
- **User Stories (Phase 3-7)**: All depend on Foundational phase completion
  - US1 (Phase 3) and US2 (Phase 4) can be developed in parallel after Foundational
  - US3 (Phase 5) depends on US2 (tag cleanup during eviction)
  - US4 (Phase 6) can be developed in parallel with US3
  - US5 (Phase 7) can be developed in parallel with US3 and US4
- **Polish (Phase 8)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Foundational (Phase 2) - Core put/get functionality
- **User Story 2 (P1)**: Can start after Foundational (Phase 2) - Depends on US1 for put/get
- **User Story 3 (P2)**: Can start after Foundational (Phase 2) - Depends on US2 for tag cleanup semantics
- **User Story 4 (P2)**: Can start after Foundational (Phase 2) - Independent validation work
- **User Story 5 (P3)**: Can start after Foundational (Phase 2) - Independent maxsize validation

### Within Each User Story

- Implementation before tests
- Core method implementation before integration
- Story complete before moving to next priority

### Parallel Opportunities

- All Setup tasks (T001-T003) can run in parallel
- All Foundational tasks (T004-T010) can run in parallel (T007 depends on T004-T006)
- Once Foundational phase completes:
  - US1 (Phase 3) and US2 (Phase 4) can proceed in parallel
  - US3 (Phase 5) can start after US2
  - US4 (Phase 6) can start after Foundational
  - US5 (Phase 7) can start after Foundational
- All Polish tasks (T023-T028) can run in parallel

---

## Parallel Example: Foundational Phase

```bash
# Launch foundational tasks together:
Task: "Create TaggedCache class in src/cachetools/tagged.py"
Task: "Implement __init__ with maxsize validation"
Task: "Implement internal _tags index"

# Then implement core methods:
Task: "Implement put with tag validation"
Task: "Implement get with deep copy"
Task: "Implement invalidate"
Task: "Implement _evict_stale_tags helper"
```

---

## Implementation Strategy

### MVP First (User Stories 1-2 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL - blocks all stories)
3. Complete Phase 3: User Story 1 (put/get)
4. Complete Phase 4: User Story 2 (invalidate)
5. **STOP and VALIDATE**: Run `acceptance_public.py` - both public tests should pass
6. Deploy/demo if ready

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add US1 → Test independently → Deploy/Demo (MVP!)
3. Add US2 → Test independently → Deploy/Demo
4. Add US3 → Test independently → Deploy/Demo
5. Add US4 → Test independently → Deploy/Demo
6. Add US5 → Test independently → Deploy/Demo
7. Polish → Final validation

### Parallel Team Strategy

With multiple developers:

1. Team completes Setup + Foundational together
2. Once Foundational is done:
   - Developer A: User Story 1 (put/get)
   - Developer B: User Story 2 (invalidate)
   - Developer C: User Story 4 (input validation)
3. After US1+US2+US4:
   - Developer A: User Story 3 (LRU eviction)
   - Developer B: User Story 5 (maxsize validation)
4. All developers: Polish & acceptance testing

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Each user story should be independently completable and testable
- Verify tests fail before implementing
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- Avoid: vague tasks, same file conflicts, cross-story dependencies that break independence
- Implementation file: `src/cachetools/tagged.py`
- Test file: `tests/test_tagged.py`
- Public acceptance: `acceptance_public.py` (do not modify)
