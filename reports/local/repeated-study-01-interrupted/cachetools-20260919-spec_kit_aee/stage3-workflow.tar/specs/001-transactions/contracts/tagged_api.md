# API Contract: TaggedCache

**Date**: 2026-09-18

## Module: `cachetools.tagged`

### Class: `TaggedCache`

```python
class TaggedCache(LRUCache):
    """Tag-aware bounded cache with deep-copy semantics."""
    
    def __init__(self, maxsize: int, getsizeof: Callable[[Any], int] | None = None) -> None:
        """Initialize TaggedCache.
        
        Args:
            maxsize: Maximum number of entries. Must be a positive int (not bool).
            getsizeof: Optional callable returning size of each value. Defaults to 1.
            
        Raises:
            ValueError: If maxsize is not a positive integer or is a bool.
        """
        ...
    
    def put(self, key: Any, value: Any, tags: Iterable[str] = ()) -> None:
        """Insert or replace a cache entry with tags.
        
        Args:
            key: Hashable cache key.
            value: Value to cache (deep-copied on storage).
            tags: Finite iterable of string tags. Must not be a bare string.
                  Duplicate tags are deduplicated.
                  
        Raises:
            ValueError: If tags is a bare string, or any tag element is not a string.
                        Raised before any state mutation.
        """
        ...
    
    def get(self, key: Any) -> Any:
        """Retrieve a deep copy of the cached value.
        
        Args:
            key: Cache key to look up.
            
        Returns:
            Deep copy of the stored value.
            
        Raises:
            KeyError: If the key is not in the cache.
        """
        ...
    
    def invalidate(self, tag: str) -> int:
        """Remove all entries carrying the specified tag.
        
        Args:
            tag: Tag string to invalidate.
            
        Returns:
            Number of entries removed.
        """
        ...
    
    @property
    def maxsize(self) -> int:
        """The maximum size of the cache."""
        ...
    
    @maxsize.setter
    def maxsize(self, value: int) -> None:
        """Set the maximum size.
        
        Raises:
            ValueError: If value is not a positive integer or is a bool.
        """
        ...
    
    # Inherited from LRUCache/Cache (behavior preserved):
    # __len__, __contains__, __delitem__, pop, setdefault, currsize, getsizeof
```

### Method: `put(key, value, tags=())`

**Preconditions**:
- `key` must be hashable (enforced by dict-based storage).
- `tags` must be an iterable (not a bare string) of strings.

**Postconditions**:
- Entry is stored with deep-copied value and deduplicated tags.
- If key existed, old tags are removed from tag index before new tags are added.
- LRU recency is updated (most recently put key is at end of order).

**Failure modes**:
- `ValueError` raised for invalid tags before any state change.
- If `getsizeof(value) > maxsize`, raises `ValueError("value too large")` from base class.

### Method: `get(key)`

**Preconditions**:
- Key exists in cache.

**Postconditions**:
- Returns a deep copy of the stored value.
- LRU recency is updated (key moved to end of order).

**Failure modes**:
- `KeyError` raised if key does not exist.

### Method: `invalidate(tag)`

**Preconditions**:
- `tag` is a string.

**Postconditions**:
- All entries carrying `tag` are removed from cache, tag index, and tag mapping.
- Returns the count of removed entries.
- Entries not carrying `tag` are unaffected.

**Failure modes**:
- Returns 0 if no entries carry the tag.

### Property: `maxsize`

**Getter**:
- Returns the current maximum size (positive int, not bool).

**Setter**:
- Validates input is a positive int and not bool.
- On invalid input, raises `ValueError` and leaves old value unchanged.
