# Data Model: TaggedCache

**Date**: 2026-09-18

## Entity: TaggedCache

A tag-aware bounded cache that extends `cachetools.LRUCache`.

### Attributes

| Attribute | Type | Description |
|---|---|---|
| `maxsize` | `int` (positive, not bool) | Maximum number of entries the cache can hold. Stored in base `Cache.__maxsize`. |
| `__data` | `dict[Any, Any]` | Key-value storage inherited from `Cache.__data`. Values are deep-copied. |
| `__order` | `OrderedDict[Any, None]` | LRU order tracking inherited from `LRUCache.__order`. |
| `__tags` | `dict[Any, frozenset[str]]` | Internal mapping from key to its deduplicated tag set. |
| `__tag_index` | `dict[str, set[Any]]` | Internal mapping from tag string to set of keys carrying that tag. |
| `__size` | `dict[Any, int]` or `_DefaultSize` | Per-key size tracking inherited from `Cache.__size`. |
| `__currsize` | `int` | Current total size inherited from `Cache.__currsize`. |
| `getsizeof` | `Callable[[Any], int]` | Size function; defaults to returning 1 per entry. |

### Relationships

- **Inherits from**: `LRUCache` → `Cache` → `collections.abc.MutableMapping`
- **__tags[key] → frozenset[str]**: Each cached key maps to its tag set. When a key is replaced, this mapping is updated atomically (old tags removed from `__tag_index` before new tags added).
- **__tag_index[tag] → set[Any]**: Each tag maps to the set of keys carrying it. Updated on put (add), invalidate (remove), and eviction (remove).

### State Transitions

| Operation | State Change |
|---|---|
| `put(key, value, tags=())` | Validate tags → if key exists, remove old tags from `__tag_index` → call parent `__setitem__` → add new tags to `__tags` and `__tag_index` |
| `get(key)` | Call parent `__getitem__` (which calls `__update` for LRU refresh) → deep copy value → return copy |
| `invalidate(tag)` | Look up keys in `__tag_index[tag]` → for each key: remove from `__tag_index`, delete from `__tags`, call parent `__delitem__` → return count |
| `popitem()` (inherited) | Call parent `popitem()` → remove evicted key from `__tags` and `__tag_index` |
| `__delitem__(key)` (override) | Remove key from `__tags` and `__tag_index` → call parent `__delitem__` |
| `maxsize = new_value` (setter) | Validate new_value is positive int and not bool → if valid, update `__maxsize` |

### Validation Rules

| Rule | Source | Enforcement |
|---|---|---|
| Tags must be iterable, not a bare string | R01 | Check `isinstance(tags, str)` before iteration |
| All tag elements must be strings | R01 | Check `isinstance(t, str)` for each element |
| Tags are deduplicated | R01 | Convert to `frozenset` |
| maxsize must be positive int, not bool | R03 | Check `isinstance(maxsize, int) and not isinstance(maxsize, bool) and maxsize > 0` |
| Values are deep-copied | R01 | `copy.deepcopy(value)` on put and get |

### Invariants

1. `len(__tags) == len(__data)` at all times (every cached key has a tag entry).
2. Every key in `__tag_index[tag]` exists in `__data` and has `tag` in `__tags[key]`.
3. Every key in `__tags` has a corresponding entry in `__tag_index` for each of its tags.
4. `len(__data) <= maxsize` at all times.
5. `__order` reflects LRU recency: most recently accessed key is at the end.
