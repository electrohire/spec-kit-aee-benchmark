# Quickstart: TaggedCache Validation Guide

**Date**: 2026-09-18

## Prerequisites

- Python 3.7+ installed
- Repository cloned at `/testbed`
- `pytest` available (`pip install pytest`)
- PYTHONPATH includes `src` directory

## Setup

```bash
cd /testbed
export PYTHONPATH=src:.
```

## Validation Scenarios

### Scenario 1: Basic Put and Get

**Goal**: Verify `put` stores an entry with tags and `get` returns a deep copy.

```bash
python3 -c "
from cachetools.tagged import TaggedCache

c = TaggedCache(2)
c.put('a', 1, ['x'])
assert c.get('a') == 1
assert len(c) == 1
print('PASS: basic put/get')
"
```

**Expected**: No errors; prints `PASS: basic put/get`.

**Reference**: spec.md User Story 1, FR-002, FR-003

---

### Scenario 2: Tag-Based Invalidation

**Goal**: Verify `invalidate(tag)` removes exactly matching entries.

```bash
python3 -c "
from cachetools.tagged import TaggedCache

c = TaggedCache(2)
c.put('a', 1, ['x'])
c.put('b', 2, ['x'])
removed = c.invalidate('x')
assert removed == 2, f'Expected 2, got {removed}'
assert len(c) == 0
print('PASS: tag-based invalidation')
"
```

**Expected**: No errors; prints `PASS: tag-based invalidation`.

**Reference**: spec.md User Story 2, FR-005

---

### Scenario 3: Replacement Removes Old Tags

**Goal**: Verify replacing a key removes its old tag memberships.

```bash
python3 -c "
from cachetools.tagged import TaggedCache

c = TaggedCache(2)
c.put('a', 1, ['old'])
c.put('a', 2, ['new'])
removed = c.invalidate('old')
assert removed == 0, f'Expected 0, got {removed}'
assert c.get('a') == 2
print('PASS: replacement removes old tags')
"
```

**Expected**: No errors; prints `PASS: replacement removes old tags`.

**Reference**: spec.md User Story 2, FR-006, acceptance_public.py `test_public_replacement`

---

### Scenario 4: Input Validation

**Goal**: Verify bare string and non-string tags raise ValueError before state change.

```bash
python3 -c "
from cachetools.tagged import TaggedCache

c = TaggedCache(2)

# Bare string should raise ValueError
try:
    c.put('a', 1, 'x')
    assert False, 'Should have raised ValueError'
except ValueError:
    pass

# Non-string entry should raise ValueError
try:
    c.put('a', 1, ['x', 42])
    assert False, 'Should have raised ValueError'
except ValueError:
    pass

# Cache should be empty (no state change)
assert len(c) == 0
print('PASS: input validation')
"
```

**Expected**: No errors; prints `PASS: input validation`.

**Reference**: spec.md User Story 4, FR-009, FR-010

---

### Scenario 5: Maxsize Validation

**Goal**: Verify maxsize rejects bool and non-positive values.

```bash
python3 -c "
from cachetools.tagged import TaggedCache

# True should raise ValueError
try:
    TaggedCache(maxsize=True)
    assert False, 'Should have raised ValueError'
except ValueError:
    pass

# Negative should raise ValueError
try:
    TaggedCache(maxsize=-1)
    assert False, 'Should have raised ValueError'
except ValueError:
    pass

# Zero should raise ValueError
try:
    TaggedCache(maxsize=0)
    assert False, 'Should have raised ValueError'
except ValueError:
    pass

print('PASS: maxsize validation')
"
```

**Expected**: No errors; prints `PASS: maxsize validation`.

**Reference**: spec.md User Story 5, FR-012

---

### Scenario 6: LRU Eviction with Tag Integrity

**Goal**: Verify LRU eviction does not leave stale tag memberships.

```bash
python3 -c "
from cachetools.tagged import TaggedCache

c = TaggedCache(2)
c.put('a', 1, ['x'])
c.put('b', 2, ['y'])
c.put('c', 3, ['z'])  # 'a' should be evicted (LRU)
assert len(c) == 2

# Evicted key 'a' with tag 'x' should not be found
removed = c.invalidate('x')
assert removed == 0, f'Expected 0 stale removals, got {removed}'
print('PASS: LRU eviction with tag integrity')
"
```

**Expected**: No errors; prints `PASS: LRU eviction with tag integrity`.

**Reference**: spec.md User Story 3, FR-007

---

### Scenario 7: Deep Copy Semantics

**Goal**: Verify get returns a detached deep copy.

```bash
python3 -c "
from cachetools.tagged import TaggedCache

c = TaggedCache(2)
c.put('a', [1, 2, 3], ['x'])
val = c.get('a')
assert val == [1, 2, 3]
assert val is not [1, 2, 3]  # Different object
val.append(4)
assert c.get('a') == [1, 2, 3]  # Original unchanged
print('PASS: deep copy semantics')
"
```

**Expected**: No errors; prints `PASS: deep copy semantics`.

**Reference**: spec.md User Story 1, FR-014

---

### Scenario 8: Public Acceptance Tests

**Goal**: Run the public acceptance test suite.

```bash
cd /testbed
python3 -m pytest acceptance_public.py -v
```

**Expected**: All tests pass.

**Reference**: acceptance_public.py
