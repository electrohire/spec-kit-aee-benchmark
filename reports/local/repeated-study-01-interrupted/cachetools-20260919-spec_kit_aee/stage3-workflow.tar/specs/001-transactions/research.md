# Research: TaggedCache Implementation

**Date**: 2026-09-18

## Decision 0-1: copy.deepcopy for value serialization

**Decision**: Use `copy.deepcopy` from the standard library for both input and output value copying.

**Rationale**: The spec requires detached deep copies on both `put` (input) and `get` (output). `copy.deepcopy` is the standard, well-tested Python approach for this. It handles nested mutable structures (lists, dicts, sets) correctly.

**Alternatives considered**:
- `copy.copy` (shallow): Would not satisfy deep copy requirement; nested mutations would leak.
- Custom serialization (e.g., `json.dumps`/`json.loads`): Fragile (does not handle all types), slower, and unnecessary.
- `pickle`: Security risk, fragile across Python versions.

**Outcome**: `copy.deepcopy` adopted.

## Decision 0-2: Tag-to-keys membership index

**Decision**: Internal `dict[str, set[Any]]` mapping tag strings to sets of keys.

**Rationale**: Enables O(1) lookup of entries by tag. `invalidate(tag)` iterates only the matching keys. When an entry is replaced, old tags are removed from the index before new tags are added. When an entry is evicted, its tags are removed from the index.

**Alternatives considered**:
- Linear scan of all entries on `invalidate()`: Simpler code but O(n) per call.
- Frozenset per entry with no separate index: No index to consult; forces linear scan.

**Outcome**: Tag-to-keys index adopted.

## Decision 0-3: Validate tags before state mutation

**Decision**: Full validation of the `tags` argument in `put()` before any call to parent `__setitem__`.

**Rationale**: Spec R01 requires ValueError before changing existing state. The validation sequence is:
1. Check if tags is a bare string (raise ValueError).
2. Convert tags to a finite iterable (list).
3. Check each element is a string (raise ValueError on first non-string).
4. Deduplicate (frozenset → sorted list for consistency).
5. Only then proceed with parent setitem.

**Alternatives considered**:
- Partial validation: Would leave partial state on later failure — violates spec.
- Lazy validation: Would allow invalid state to persist — violates spec.

**Outcome**: Full pre-validation adopted.

## Decision 0-4: Inherit from LRUCache

**Decision**: `TaggedCache` inherits directly from `LRUCache`.

**Rationale**: Reuses LRU eviction, order tracking, maxsize enforcement, `len()`, `currsize`, and `getsizeof`. Only `__setitem__`, `__delitem__`, `__getitem__` are overridden to add tag management.

**Alternatives considered**:
- Composition: Would need to reimplement MutableMapping interface.
- Inherit from Cache: Loses LRU ordering.

**Outcome**: LRUCache inheritance adopted.

## Decision 0-5: maxsize property setter

**Decision**: Add a `maxsize` property setter that validates and rejects non-positive, non-int, and bool values.

**Rationale**: Spec R03 requires maxsize to be a positive int excluding bool. A property setter enforces this on replacement.

**Alternatives considered**:
- No setter (immutable after init): Simpler but less flexible.
- Silent clamp: Violates "leave old value unchanged" requirement.

**Outcome**: Validated property setter adopted.

## Assumptions Confirmed

1. ✅ `LRUCache.__init__` accepts `(maxsize, getsizeof=None)` — confirmed from `src/cachetools/__init__.py` line 203.
2. ✅ `LRUCache.__getitem__` calls `__update(key)` on access — confirmed line 210-212.
3. ✅ `LRUCache.__delitem__` removes from both `__data` and `__order` — confirmed line 221-223.
4. ✅ `LRUCache.popitem()` evicts the least recently used entry — confirmed line 226-233.
5. ✅ `copy.deepcopy` is available — standard library.
6. ✅ Tags stored as `frozenset` internally — design choice for correctness.
7. ✅ `Cache.getsizeof` returns 1 per entry — confirmed line 144.
