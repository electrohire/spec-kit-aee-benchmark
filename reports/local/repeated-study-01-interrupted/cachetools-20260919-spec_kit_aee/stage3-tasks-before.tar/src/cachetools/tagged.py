"""TaggedCache - a tag-aware bounded cache built on LRUCache."""

import copy
import time
from collections.abc import Iterable

from cachetools import Cache, LRUCache


class TaggedCache(LRUCache):
    """A cache that supports per-entry string tags for group-based invalidation.

    Inherits from cachetools.LRUCache for bounded storage and LRU eviction.
    Supports tagging entries, tag-based invalidation, and deep-copy semantics.
    """

    def __init__(self, maxsize, timer=None, getsizeof=None):
        """Create a TaggedCache with the given maxsize.

        Args:
            maxsize: Maximum number of entries. Must be a positive integer
                     (bool is excluded).
            timer: Callable returning the current time (default: time.monotonic).
            getsizeof: Optional callable returning the size of a value.

        Raises:
            ValueError: If maxsize is not a positive integer or is a bool.
        """
        if isinstance(maxsize, bool) or not isinstance(maxsize, int) or maxsize <= 0:
            raise ValueError("maxsize must be a positive integer (not bool)")
        super().__init__(maxsize, getsizeof)
        self._tags = {}  # tag -> set of keys
        if timer is None:
            self._timer = time.monotonic
        else:
            self._timer = timer
        self._expires = {}  # key -> expiry timestamp (None = no expiry)

    # ------------------------------------------------------------------ maxsize
    @property
    def maxsize(self):
        """The maximum size of the cache."""
        return super().maxsize

    @maxsize.setter
    def maxsize(self, value):
        """Set maxsize, validating it is a positive integer (not bool)."""
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError("maxsize must be a positive integer (not bool)")
        # Cache uses name-mangled _Cache__maxsize
        self._Cache__maxsize = value

    # ------------------------------------------------------------------ helpers
    def _remove_key_from_tags(self, key):
        """Remove *key* from every tag set it belongs to."""
        for tag, key_set in list(self._tags.items()):
            key_set.discard(key)
            if not key_set:
                del self._tags[tag]

    def _evict_stale_tags(self, key):
        """Remove *key* from every tag set it belongs to (alias for cleanup)."""
        self._remove_key_from_tags(key)

    def _is_expired(self, key):
        """Return True if *key* has expired."""
        exp = self._expires.get(key)
        if exp is None:
            return False
        return self._timer() >= exp

    def _expire(self):
        """Remove all expired entries. Does not touch recency of surviving entries."""
        # Iterate over the underlying data directly to avoid recursion
        expired_keys = [k for k in Cache.__iter__(self) if self._is_expired(k)]
        for k in expired_keys:
            self._remove_key_from_tags(k)
            Cache.__delitem__(self, k)

    # ------------------------------------------------------------------ __delitem__
    def __delitem__(self, key):
        """Delete a key and clean up tag memberships."""
        self._evict_stale_tags(key)
        self._expires.pop(key, None)
        Cache.__delitem__(self, key)

    # ------------------------------------------------------------------ clear
    def clear(self):
        """Remove all entries and reset tag index."""
        self._tags.clear()
        self._expires.clear()
        Cache.clear(self)

    # ------------------------------------------------------------------ put
    def put(self, key, value, tags=(), ttl=None):
        """Insert or replace an entry with the given key, value, and tags.

        Args:
            key: Hashable key.
            value: Value to cache (deep-copied on input).
            tags: Iterable of string tags (deduplicated). Must not be a bare
                  string and must not contain non-string entries.
            ttl: Time-to-live in seconds. None means no expiration. A finite
                 nonnegative int/float (excluding bool) sets expiry at
                 timer() + ttl. TTL zero is immediately expired.

        Raises:
            ValueError: If tags is a bare string or contains non-string entries,
                        or if ttl is invalid.
        """
        # --- validate tags BEFORE any state mutation ---
        if isinstance(tags, str):
            raise ValueError("tags must not be a bare string")
        if not isinstance(tags, Iterable):
            raise ValueError("tags must be an iterable")
        tag_list = list(tags)
        for t in tag_list:
            if not isinstance(t, str):
                raise ValueError("all tag entries must be strings")
        # deduplicate while preserving order
        seen = set()
        deduped = []
        for t in tag_list:
            if t not in seen:
                seen.add(t)
                deduped.append(t)

        # --- validate ttl BEFORE any state mutation ---
        if ttl is not None:
            if isinstance(ttl, bool) or not isinstance(ttl, (int, float)) or ttl < 0:
                raise ValueError("ttl must be a nonnegative number (not bool)")

        # Expire any existing entry for this key before replacing
        if key in self:
            self._remove_key_from_tags(key)
            Cache.__delitem__(self, key)

        # Check if TTL zero means immediately expired
        if ttl is not None and ttl == 0:
            # Store then immediately expire
            copied_value = copy.deepcopy(value)
            Cache.__setitem__(self, key, copied_value)
            self._expires[key] = self._timer()
            for t in deduped:
                self._tags.setdefault(t, set()).add(key)
            # Immediately expire this entry
            self._remove_key_from_tags(key)
            Cache.__delitem__(self, key)
            return

        # --- deep-copy value and store ---
        copied_value = copy.deepcopy(value)
        Cache.__setitem__(self, key, copied_value)

        # --- record expiry ---
        if ttl is not None:
            self._expires[key] = self._timer() + ttl
        else:
            self._expires[key] = None

        # --- record new tag memberships ---
        for t in deduped:
            self._tags.setdefault(t, set()).add(key)

    # ------------------------------------------------------------------ get
    def get(self, key, default=None):
        """Return a deep copy of the value for *key*, or *default*.

        Refreshes LRU recency on access. Raises ``KeyError`` when *key* is
        missing and no *default* is provided (mirrors dict semantics).
        Expired entries are removed before access.
        """
        # Expire entries first
        self._expire()

        if key in self:
            # Use LRUCache.__getitem__ to trigger LRU recency update
            value = LRUCache.__getitem__(self, key)
            return copy.deepcopy(value)
        elif default is not None:
            return default
        else:
            raise KeyError(key)

    # ------------------------------------------------------------------ invalidate
    def invalidate(self, tag):
        """Remove all entries carrying *tag* and return the count removed."""
        # Expire entries first
        self._expire()
        keys = self._tags.pop(tag, set())
        count = 0
        for k in keys:
            if k in self:
                Cache.__delitem__(self, k)
                count += 1
        return count

    # ------------------------------------------------------------------ invalidate_many
    def invalidate_many(self, tags, mode='any'):
        """Remove entries by tag(s) and return the count removed.

        Args:
            tags: Iterable of string tags to match.
            mode: 'any' removes entries matching at least one tag (union),
                  'all' removes entries matching every tag (intersection).

        Returns:
            int: Number of distinct keys removed.

        Raises:
            ValueError: If mode is invalid or tags contain non-string entries,
                        before any mutation.
        """
        # --- validate BEFORE any state mutation ---
        if mode not in ('any', 'all'):
            raise ValueError("mode must be 'any' or 'all'")
        if isinstance(tags, str):
            raise ValueError("tags must not be a bare string")
        if not isinstance(tags, Iterable):
            raise ValueError("tags must be an iterable")
        tag_list = list(tags)
        for t in tag_list:
            if not isinstance(t, str):
                raise ValueError("all tag entries must be strings")

        # Empty requested tags -> remove zero entries
        if not tag_list:
            return 0

        # Expire entries first (count only live entries)
        self._expire()

        if mode == 'any':
            # Union: any key that has at least one of the requested tags
            keys_to_remove = set()
            for t in tag_list:
                keys_to_remove.update(self._tags.get(t, set()))
        else:  # mode == 'all'
            # Intersection: keys that have ALL requested tags
            keys_to_remove = set(self._tags.get(tag_list[0], set()))
            for t in tag_list[1:]:
                keys_to_remove.intersection_update(self._tags.get(t, set()))

        # Remove each key from the cache (which also cleans tag index)
        count = 0
        for k in keys_to_remove:
            if k in self:
                Cache.__delitem__(self, k)
                count += 1
        return count

    # ------------------------------------------------------------------ resize
    def resize(self, maxsize):
        """Resize the cache to a new maxsize.

        Validates that maxsize is a positive integer (not bool) first.
        Shrinking evicts least-recently-used entries; growing does not evict.
        Failed resizing preserves all state.

        Args:
            maxsize: New maximum number of entries.

        Raises:
            ValueError: If maxsize is not a positive integer or is a bool.
        """
        # --- validate BEFORE any state mutation ---
        if isinstance(maxsize, bool) or not isinstance(maxsize, int) or maxsize <= 0:
            raise ValueError("maxsize must be a positive integer (not bool)")

        # Expire entries first
        self._expire()

        # If shrinking, evict LRU entries until currsize <= maxsize
        if maxsize < self.currsize:
            while self.currsize > maxsize:
                self.popitem()

        # Update maxsize (name-mangled in LRUCache)
        self._Cache__maxsize = maxsize

    # ------------------------------------------------------------------ __len__
    def __len__(self):
        """Return the number of live (non-expired) entries."""
        self._expire()
        return Cache.__len__(self)

    # ------------------------------------------------------------------ __contains__
    def __contains__(self, key):
        """Return True if key is in the cache and not expired."""
        if key not in self._expires:
            return False
        if self._is_expired(key):
            # Clean up expired entry
            self._remove_key_from_tags(key)
            Cache.__delitem__(self, key)
            return False
        return True

    # ------------------------------------------------------------------ __iter__
    def __iter__(self):
        """Iterate over live (non-expired) keys."""
        self._expire()
        return Cache.__iter__(self)
